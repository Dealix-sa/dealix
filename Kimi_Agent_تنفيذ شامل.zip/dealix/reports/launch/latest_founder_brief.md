# Today's Founder Brief
Generated: 2026-06-17T04:57:58.407179

## 1. Highest Priority Action
[Review 13 outreach drafts and approve 3 for sending]

## 2. Top Prospects to Review
15 verified companies in pipeline
Review top 10 priority A targets

## 3. Drafts to Approve
13 drafts pending approval

## 4. Replies to Handle
Check replies ledger for interested responses

## 5. Meetings to Book
Target: 1 meeting today
Current meetings: check meetings ledger

## 6. Proposals to Send
Target: 1 proposal this week

## 7. Delivery Blockers
1 active projects — check for blockers

## 8. Proof Reports Due
Check projects needing weekly proof report

## 9. Retainer Opportunities
1 intakes — identify conversion opportunities

## 10. One Decision to Make Today
[Choose: Which sector to focus on this week?]

## Metrics
- Targets: 15
- Verified: 15
- Drafts pending: 13
- Active projects: 1
- Intakes: 1
