# Demo Objection Handling

## During Demo

### "We don't need this"
- "Fair. What do you currently use for follow-up?"
- Listen. Find the gap.

### "Too expensive"
- "The diagnostic sprint is 10K SAR. Just a map and a plan."
- "Can I ask — what's the cost of losing one client?"

### "We have a CRM"
- "Great. Which one?"
- "Does it handle WhatsApp follow-up and review management too?"

### "We need to think about it"
- "Of course. What specifically needs thinking?"
- "Can I send you a one-pager on [specific topic]?"

### "Not the right time"
- "I understand. What would make it the right time?"
- "Can I check back next quarter?"

### "Show me proof"
- "We have case studies [if available with permission]."
- "Or we can start with a diagnostic sprint — that's the proof."

### "We tried AI before"
- "What happened?"
- "We use human-in-the-loop. AI suggests, human approves."

### "Need approval from..."
- "Who needs to approve?"
- "Can we schedule a 15-min call with them?"

## Rules

- Never argue
- Always listen first
- Ask questions
- End with next step
- No pressure
