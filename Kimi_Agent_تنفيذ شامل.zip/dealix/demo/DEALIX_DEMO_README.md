# Dealix Demo Pack

Complete demo assets for each product.

## How to Use

Each demo file contains:
- The problem
- Before Dealix
- After Dealix
- Inputs
- Outputs
- How to explain in 10 minutes
- What we don't promise
- Next step

## Primary Products for Market

1. **Company Diagnosis Sprint** — Sales entry point
2. **Revenue Command Room OS** — Revenue visibility
3. **WhatsApp / Inbox Follow-up OS** — Follow-up automation
4. **AI Trust & Compliance OS** — AI governance

## Secondary Products

5. **Review & Reputation OS**
6. **Operations & Delivery OS**
7. **Company Brain OS** (advanced service only)

## Important

Company Brain OS is a secondary service, not the main offering.
Don't demo Company Brain OS before client understands the core OS.

## Demo Structure

Every demo follows this structure:
```
1. Problem (1 min)
2. Before Dealix (2 min)
3. After Dealix (3 min)
4. Inputs/Outputs (2 min)
5. What we don't promise (1 min)
6. Next step (1 min)
```
