# Production Readiness Checklist

## Application

- [ ] Code compiles without errors
- [ ] All tests passing
- [ ] No secrets in repo
- [ ] .env.example up to date
- [ ] Dependencies pinned
- [ ] README complete

## Safety

- [ ] EXTERNAL_SEND_ENABLED=false
- [ ] OUTBOUND_MODE=draft_only
- [ ] Approval gates active
- [ ] Fake claims blocking active
- [ ] Suppression list active
- [ ] Rate limits configured
- [ ] PDPL policies in place

## Data

- [ ] Ledgers initialized
- [ ] CSV headers correct
- [ ] No test data in production
- [ ] Backup strategy defined

## Operations

- [ ] Makefile targets working
- [ ] Scripts executable
- [ ] Reports generating
- [ ] Founder OS ready

## Documentation

- [ ] All packs documented
- [ ] SOPs written
- [ ] Templates ready
- [ ] Decision log template

## Final Gate

- [ ] make business-validate passes
- [ ] make launch-validate passes
- [ ] make test passes
- [ ] No blockers
