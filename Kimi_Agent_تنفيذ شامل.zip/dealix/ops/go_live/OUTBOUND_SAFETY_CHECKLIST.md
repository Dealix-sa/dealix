# Outbound Safety Checklist

## Defaults

- [ ] EXTERNAL_SEND_ENABLED=false
- [ ] OUTBOUND_MODE=draft_only
- [ ] EMAIL_SEND_ENABLED=false
- [ ] WHATSAPP_SEND_ENABLED=false
- [ ] WHATSAPP_ALLOW_LIVE_SEND=false

## Approval

- [ ] OUTBOUND_REQUIRE_APPROVAL=true
- [ ] Approval logged in audit_log
- [ ] approved_by field required

## Verification

- [ ] OUTBOUND_REQUIRE_VERIFIED_TARGET=true
- [ ] OUTBOUND_REQUIRE_SOURCE_URL=true

## Claims

- [ ] OUTBOUND_BLOCK_FAKE_CLAIMS=true
- [ ] OUTBOUND_BLOCK_GUARANTEED_ROI=true
- [ ] Blocked phrases list active

## Email

- [ ] Unsubscribe link required
- [ ] EMAIL_DAILY_LIMIT=25
- [ ] Suppression list checked

## WhatsApp

- [ ] Opt-in required
- [ ] Template-only mode
- [ ] No cold messages
- [ ] "إلغاء" respected

## Rate Limits

- [ ] Email: 25/day
- [ ] WhatsApp: 50/day
- [ ] LinkedIn: 20/day

## Audit

- [ ] Every send attempt logged
- [ ] Replies classified
- [ ] Policy violations flagged

## Verification Command

```bash
python -c "
from app.client_os.policy_gate import get_gate
g = get_gate()
print(f'EXTERNAL_SEND_ENABLED: {g.EXTERNAL_SEND_ENABLED}')
print(f'OUTBOUND_MODE: {g.OUTBOUND_MODE}')
print(f'REQUIRE_APPROVAL: {g.OUTBOUND_REQUIRE_APPROVAL}')
print(f'BLOCK_FAKE: {g.OUTBOUND_BLOCK_FAKE_CLAIMS}')
print(f'WHATSAPP_LIVE: {g.WHATSAPP_ALLOW_LIVE_SEND}')
"
```

Expected output:
```
EXTERNAL_SEND_ENABLED: False
OUTBOUND_MODE: draft_only
REQUIRE_APPROVAL: True
BLOCK_FAKE: True
WHATSAPP_LIVE: False
```
