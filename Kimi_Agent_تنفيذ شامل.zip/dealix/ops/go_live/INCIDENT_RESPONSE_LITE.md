# Incident Response Lite

## Types

### Data Breach
1. Stop all operations
2. Notify founder immediately
3. Isolate affected system
4. Document what happened
5. Notify affected clients (within 72h per PDPL)
6. Fix and verify
7. Post-incident review

### Policy Violation
1. Flag in audit log
2. Notify founder
3. Review and fix
4. Update policy if needed

### System Failure
1. Check logs
2. Restart if needed
3. Notify founder
4. Document

### Client Complaint
1. Log in audit
2. Respond within 4 hours
3. Investigate
4. Fix or explain
5. Document resolution

## Contacts

- Founder: [TBD]
- Technical: [TBD]
- Legal: [TBD]

## Escalation

1. Day 1: Fix by team
2. Day 2: Founder involved
3. Day 3: External help
