# Backup & Restore Checklist

## Backup Strategy

### Daily
- ledgers/*.csv
- reports/*.md
- .env (encrypted)

### Weekly
- Full repo snapshot
- Git push to remote

### Monthly
- Archive old data
- Review retention

## Restore Process

1. Stop operations
2. Restore from backup
3. Verify integrity
4. Resume operations
5. Notify team

## Retention

- Daily: 30 days
- Weekly: 12 weeks
- Monthly: 12 months

## Test

- [ ] Restore tested monthly
- [ ] Time to restore < 1 hour
- [ ] Data integrity verified
