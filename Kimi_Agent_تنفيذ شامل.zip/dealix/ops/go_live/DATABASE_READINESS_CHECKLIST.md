# Database Readiness Checklist

## CSV Ledgers

- [ ] All CSV files have headers
- [ ] All CSV files are readable
- [ ] All CSV files are writable
- [ ] No corruption
- [ ] Backup exists

## Integrity

- [ ] company_id references are consistent
- [ ] No orphaned records
- [ ] No duplicate IDs

## Performance

- [ ] Read operations < 1s
- [ ] Write operations < 1s
- [ ] No locking issues

## Backup

- [ ] Daily backup configured
- [ ] Restore tested
- [ ] Backup retention: 30 days

## Migration

- [ ] Schema changes documented
- [ ] Migration scripts tested
- [ ] Rollback plan ready
