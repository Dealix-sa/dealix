# Environment Variables Audit

## Required

| Variable | Default | Required |
|----------|---------|----------|
| DEALIX_LEDGER_DIR | ledgers | Yes |
| APP_ENV | development | Yes |

## Safety (all false by default)

| Variable | Default | Purpose |
|----------|---------|---------|
| EXTERNAL_SEND_ENABLED | false | Enable external send |
| OUTBOUND_MODE | draft_only | draft_only or controlled_live |
| EMAIL_SEND_ENABLED | false | Enable email |
| WHATSAPP_SEND_ENABLED | false | Enable WhatsApp |
| WHATSAPP_ALLOW_LIVE_SEND | false | Allow live WhatsApp |

## Optional

| Variable | Default | Purpose |
|----------|---------|---------|
| DATABASE_URL | - | Database connection |
| OPENAI_API_KEY | - | AI features |
| EMAIL_SMTP_HOST | - | SMTP server |
| EMAIL_SMTP_PORT | 587 | SMTP port |
| EMAIL_SMTP_USER | - | SMTP user |

## Verify

Check .env.example matches actual requirements.
No secrets in .env.example.
