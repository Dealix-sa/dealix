# Domain / Email / DNS Checklist

## Domain

- [ ] dealix.sa registered
- [ ] DNS configured
- [ ] SSL certificate
- [ ] WWW redirect

## Email

- [ ] SPF record
- [ ] DKIM record
- [ ] DMARC record
- [ ] MX record
- [ ] Unsubscribe link template

## DNS Records

| Record | Value | Status |
|--------|-------|--------|
| A | [IP] | [ ] |
| MX | [mail server] | [ ] |
| TXT (SPF) | v=spf1 ... | [ ] |
| TXT (DKIM) | [key] | [ ] |

## Verification

```bash
dig dealix.sa A
dig dealix.sa MX
dig dealix.sa TXT
```

## Note

Only needed when going live with email sending.
Currently EXTERNAL_SEND_ENABLED=false.
