# Data Model
## نموذج البيانات — [اسم الشركة]

---

## الكيانات الرئيسية

### 1. clients
- client_id (PK)
- company_id (FK)
- client_name
- primary_contact
- sector
- goal
- created_at

### 2. interactions
- interaction_id (PK)
- client_id (FK)
- type
- content
- created_at

### 3. reports
- report_id (PK)
- client_id (FK)
- period
- content
- created_at

### 4. audit_log
- audit_id (PK)
- action
- entity_type
- entity_id
- actor
- timestamp

### 5. users
- user_id (PK)
- client_id (FK)
- role
- permissions
- created_at

## العلاقات

```
clients ||--o{ interactions : has
clients ||--o{ reports : generates
clients ||--o{ users : has
```

## مصادر البيانات

-

## تكرار التحديث

-
