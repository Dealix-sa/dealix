# خطة أول 90 يوم

## الأيام 1-30 — Foundation (انظر FIRST_30_DAYS_ACTION_PLAN_AR.md)

## الأيام 31-60 — Traction

### الأهداف
- 5 diagnostic sprints مكتملة
- 2 pilot OS نشطة
- 1 managed OS
- 3 case studies داخلية

### الإجراءات
- [ ] تشغيل يومي (make market-day)
- [ ] تكرار البيع في قطاعين
- [ ] إنتاج case studies
- [ ] تحديث sector playbooks
- [ ] بناء partner conversations
- [ ] تحسين الرسائل
- [ ] توسيع LinkedIn content

### Deliverables
- [ ] 800+ targets
- [ ] 5 diagnostic sprints
- [ ] 2 pilots
- [ ] 1 managed OS
- [ ] 3 case studies

## الأيام 61-90 — Scale

### الأهداف
- 10 diagnostic sprints
- 4 pilot OS
- 2 managed OS
- 1 strategic partnership
- 250K SAR revenue

### الإجراءات
- [ ] تكرار النموذج في 3 قطاعات
- [ ] إطلاق partner program
- [ ] بناء case studies عامة (بإذن)
- [ ] تحديث product catalog
- [ ] تحسين pricing
- [ ] التخطيط للـ Q2

### Deliverables
- [ ] 1500+ targets
- [ ] 10 diagnostic sprints
- [ ] 4 pilots
- [ ] 2 managed OS
- [ ] 1 partnership
- [ ] 250K SAR

## Metrics Summary

| Metric | 30d | 60d | 90d |
|--------|-----|-----|-----|
| Targets | 400 | 800 | 1500 |
| Meetings | 10 | 25 | 35 |
| Diagnostics | 4 | 7 | 12 |
| Pilots | 2 | 3 | 6 |
| Managed | 1 | 1 | 4 |
| Revenue | 60K | 120K | 250K |
