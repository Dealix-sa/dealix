# Launch Metrics

## Daily Metrics

| Metric | Target | Source |
|--------|--------|--------|
| Targets researched | 20/day | ledgers/companies.csv |
| Drafts reviewed | 5/day | ledgers/outreach_log.csv |
| Manual sends | 3/day | ledgers/outreach_log.csv |
| Replies received | Track | ledgers/replies.csv |
| Meetings booked | 0.5/day | ledgers/meetings.csv |

## Weekly Metrics

| Metric | Target | Source |
|--------|--------|--------|
| Total targets | 100/week | ledgers/companies.csv |
| Outreach sent | 15/week | ledgers/outreach_log.csv |
| Meetings | 2-3/week | ledgers/meetings.csv |
| Proposals | 1/week | ledgers/proposals.csv |
| Founder actions completed | 7/10 | reports/ |

## Monthly Metrics

| Metric | Target | Source |
|--------|--------|--------|
| Diagnostics sold | 4/month | ledgers/client_intakes.csv |
| Pilots launched | 2/month | ledgers/projects.csv |
| Managed OS | 1/month | ledgers/projects.csv |
| Revenue | 60K SAR | business/pricing/ |
| Pipeline value | 200K SAR | ledgers/proposals.csv |

## Quarterly Metrics

| Metric | Target | Source |
|--------|--------|--------|
| Total revenue | 250K SAR | business/pricing/ |
| Active clients | 8-10 | ledgers/projects.csv |
| Retainers | 4 | ledgers/renewals.csv |
| Partnerships | 1 | partnerships/ |
| Case studies | 3 | proof/ |

## Founder Scorecard

انظر: founder/war_room/DAILY_SALES_SCORECARD.md
