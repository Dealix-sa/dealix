# روتين المؤسس اليومي — فترة الإطلاق

## الصباح (30 دقيقة)

### 1. Command Room Check
```bash
make market-day
```
- Pipeline status
- Active clients
- Blockers
- Founder actions

### 2. Scorecard Update
انظر: founder/war_room/DAILY_SALES_SCORECARD.md

### 3. Top 3 Actions
- ما أهم 3 أشياء لهذا اليوم؟
- ما الذي سيحرك الإبرة؟

## منتصف اليوم (4-6 ساعات)

### Outreach Block (1-2 ساعة)
- مراجعة 5 outreach drafts
- الموافقة على 3
- إرسال يدوي
- تحديث ledgers

### Meeting Block (1-3 ساعات)
- Discovery calls
- Follow-up calls
- Client check-ins
- Proposal presentations

### Content Block (30 دقيقة)
- LinkedIn post
- Sector insight
- أو engagement

## آخر اليوم (15-30 دقيقة)

### Ledger Update
- تحديث outreach_log
- تحديث meetings
- تحديث tasks

### Proof Notes
- ما تم اليوم
- ملاحظات العملاء

### Tomorrow Planning
- أهم 3 أولويات
- المواعيد
- المتابعات

## الجمعة — Weekly Review

1. مراجعة metrics الأسبوع
2. Founder decision log
3. Blockers update
4. Next week plan
5. Sector priority check

## الأهداف اليومية

| Metric | Target |
|--------|--------|
| Drafts reviewed | 5 |
| Manual sends | 3 |
| Meetings | 1 |
| Content | 1 |
| Ledgers updated | Yes |
| Founder actions | 7/10 |
