# خطة أول 7 أيام

## الهدف
إثبات الحركة. لا نطلب الكمال.

## اليوم 1 — الاثنين
- [ ] تشغيل make company-full-day
- [ ] فحص ledgers الحالية
- [ ] تجهيز 20 target جديد
- [ ] مراجعة 5 outreach draft
- [ ] الموافقة على 3 drafts
- [ ] إرسال 3 رسائل يدوياً
- [ ] محتوى LinkedIn واحد

## اليوم 2 — الثلاثاء
- [ ] تشغيل make company-full-day
- [ ] تجهيز 20 target جديد
- [ ] مراجعة 5 outreach draft
- [ ] إرسال 3 رسائل يدوياً
- [ ] متابعة ردود الأمس
- [ ] محتوى LinkedIn واحد

## اليوم 3 — الأربعاء
- [ ] تشغيل make company-full-day
- [ ] تجهيز 20 target جديد
- [ ] مراجعة 5 outreach draft
- [ ] إرسال 3 رسائل يدوياً
- [ ] حجز أول مكالمة
- [ ] تحديث founder decision log

## اليوم 4 — الخميس
- [ ] تشغيل make company-full-day
- [ ] تجهيز 20 target جديد
- [ ] مراجعة 5 outreach draft
- [ ] إرسال 3 رسائل يدوياً
- [ ] مكالمة discovery أولى
- [ ] تدوين notes في intake form

## اليوم 5 — الجمعة
- [ ] مراجعة الأسبوع
- [ ] تحديث ledgers
- [ ] مراجعة founder actions
- [ ] تحديث sector priority map
- [ ] تخطيط الأسبوع القادم

## اليوم 6-7 — عطلة نهاية الأسبوع
- [ ] قراءة ردود
- [ ] تحديث LinkedIn
- [ ] محتوى إضافي

## Metrics Target (7 أيام)
- Targets: 80+
- Drafts reviewed: 25
- Manual sends: 15
- Meetings booked: 2
- Proposals: 0-1

## Founder Actions
1. تجهيز targets
2. مراجعة drafts
3. إرسال يدوي
4. متابعة ردود
5. حجز meetings
6. Discovery calls
7. تحديث ledgers
8. محتوى LinkedIn
9. مراجعة أسبوعية
10. تخطيط قادم
