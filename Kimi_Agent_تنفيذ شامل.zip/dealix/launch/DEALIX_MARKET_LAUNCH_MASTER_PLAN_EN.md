# Dealix Market Launch Master Plan

## Goal

Transform Dealix from an internal system into a real market launch machine that enters the market within 30 days.

## Principle

We don't seek perfection.
We seek:
1. First workflow that proves value
2. First 3 beta clients
3. First proof report
4. First retainer
5. First case study

## Roadmap

### Week 1 — Prove Motion
- Run company-full-day daily
- Prepare 500 targets
- Review 125 drafts
- Manually send 50-75 messages
- Book 3-5 meetings
- Generate first 2 proposals
- Select first beta client

### Week 2 — First Sprint
- Execute Diagnosis Sprint
- Deliver current state map
- Deliver pain map
- Deliver first workflow recommendation
- Deliver initial proof report
- Convert client to Pilot OS

### Week 3 — Repeat Sales
- Repeat targeting
- Launch daily LinkedIn content
- Produce 3 sector one-pagers
- Improve messages based on replies
- Close second client

### Week 4 — Retainer / Expansion
- Convert client to Managed OS
- Build internal case study
- Update presentation
- Solidify offer ladder
- Build one potential partnership

## Numeric Goals

| Metric | 7 Days | 30 Days | 90 Days |
|--------|--------|---------|---------|
| Targets | 100 | 500 | 1500 |
| Drafts reviewed | 25 | 125 | 400 |
| Manual sends | 15 | 75 | 250 |
| Meetings | 2 | 10 | 35 |
| Diagnostics | 0 | 4 | 12 |
| Pilots | 0 | 2 | 6 |
| Managed OS | 0 | 1 | 4 |
| Revenue | 0 | 60K SAR | 250K SAR |

## Products for Market

1. Company Diagnosis Sprint (sales entry)
2. Revenue Command Room OS
3. WhatsApp / Inbox Follow-up OS
4. AI Trust & Compliance OS

## Sequence Required

- Don't sell Company Brain OS until client buys 2+ products
- Don't sell Custom Enterprise before Diagnostic Sprint
- Don't launch Strategic Partnership before 3 months

## Launch Gates

See LAUNCH_GATES.md

## Metrics

See LAUNCH_METRICS.md

## Blockers

See LAUNCH_BLOCKERS.md
