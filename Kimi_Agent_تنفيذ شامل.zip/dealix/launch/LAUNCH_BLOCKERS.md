# Launch Blockers

## Current Blockers

### Blocker #1
**What**: Need first beta client
**Impact**: Cannot start delivery sprint
**Owner**: Founder
**ETA**: Week 2
**Mitigation**: Increase outreach volume

### Blocker #2
**What**: LinkedIn content not started
**Impact**: No inbound channel
**Owner**: Founder
**ETA**: Week 1
**Mitigation**: Batch create 7 posts

### Blocker #3
**What**: No case studies yet
**Impact**: Harder to close clients
**Owner**: Founder
**ETA**: Week 4
**Mitigation**: Close first client fast

## Resolved Blockers

- [x] Business OS built
- [x] Client OS built
- [x] Tests passing
- [x] Trust policies written
- [x] Templates ready

## Potential Blockers

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| Low reply rate | Medium | Medium | Improve messaging |
| Client not ready | Medium | High | Focus on education |
| Team capacity | Low | High | Hire or delay |
| Pricing resistance | Medium | Medium | Diagnostic as entry |
| Competitor reaction | Low | Low | Move fast |

## Escalation

If blocker persists > 3 days:
1. Document in detail
2. Propose 2 alternatives
3. Get founder decision
4. Update decision log
