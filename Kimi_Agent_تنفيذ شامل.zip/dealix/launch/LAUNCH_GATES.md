# Launch Gates

## Pre-Launch Gate

لا نبدأ الإطلاق إلا إذا:

- [ ] Product catalog مكتمل
- [ ] Pricing strategy محدد
- [ ] Offer stack واضح
- [ ] ICP qualification defined
- [ ] Trust policies written
- [ ] Approval gates configured
- [ ] Founder daily OS ready
- [ ] Templates ready (intake, diagnosis, proposal, proof)
- [ ] Ledgers ready
- [ ] Scripts working
- [ ] Tests passing

## Week 1 Gate

ننتقل للأسبوع 2 إذا:

- [ ] 80+ targets في ledger
- [ ] 15+ outreach sent
- [ ] 1+ meeting booked
- [ ] Founder actions محدثة

## Week 2 Gate

ننتقل للأسبوع 3 إذا:

- [ ] 1 diagnostic sprint مباع
- [ ] Intake مكتمل
- [ ] Diagnosis report generated
- [ ] Pain map delivered

## Week 3 Gate

ننتقل للأسبوع 4 إذا:

- [ ] 2 diagnostic sprints مباعة
- [ ] 2+ meetings booked
- [ ] 3 one-pagers produced

## Week 4 Gate

نعلن الجاهزية إذا:

- [ ] 1+ managed OS أو قريب
- [ ] Case study داخلي
- [ ] 400+ targets
- [ ] 10+ meetings
- [ ] Revenue > 0

## Monthly Gates

### Month 2
- [ ] 3+ diagnostic sprints
- [ ] 1+ pilot active
- [ ] 1+ case study

### Month 3
- [ ] 5+ diagnostic sprints
- [ ] 2+ pilots
- [ ] 1+ managed OS
- [ ] 1+ partnership conversation
