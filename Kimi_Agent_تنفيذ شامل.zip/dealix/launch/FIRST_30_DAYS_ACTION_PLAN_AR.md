# خطة أول 30 يوم

## الأسبوع 1 — إثبات الحركة

### الأهداف
- 100 target مؤهل
- 25 draft مراجعة
- 15 إرسال يدوي
- 2 مكالمة محجوزة

### الإجراءات اليومية
- تشغيل make company-full-day
- تجهيز 20 target جديد
- مراجعة 5 drafts
- إرسال 3 رسائل يدوياً
- متابعة ردود
- محتوى LinkedIn يومي

### Deliverables
- [ ] 100 target في ledger
- [ ] 15+ outreach sent
- [ ] 2+ meetings booked
- [ ] Founder decision log محدث

---

## الأسبوع 2 — أول Sprint

### الأهداف
- تنفيذ Diagnosis Sprint لأول عميل
- تسليم current state map
- تسليم pain map
- تسليم first workflow recommendation

### الإجراءات
- [ ] إجراء intake meeting
- [ ] جمع بيانات العميل
- [ ] تشغيل diagnosis engine
- [ ] بناء needs map
- [ ] بناء blueprint
- [ ] عرض recommendation
- [ ] تسليم proof report أولي
- [ ] تحويل العميل إلى Pilot OS

### Deliverables
- [ ] Intake form مكتمل
- [ ] Diagnosis report
- [ ] Pain map
- [ ] First workflow recommendation
- [ ] Initial proof report
- [ ] Pilot OS proposal (معتمد)

---

## الأسبوع 3 — تكرار البيع

### الأهداف
- إغلاق ثاني عميل
- إنتاج 3 one-pagers قطاعية
- تحسين الرسائل
- تكرار الاستهداف

### الإجراءات
- [ ] تجهيز 150 target جديد
- [ ] مراجعة 40 draft
- [ ] إرسال 20 رسالة يدوياً
- [ ] 3-5 meetings
- [ ] إنتاج one-pager: عيادات
- [ ] إنتاج one-pager: عقارات
- [ ] إنتاج one-pager: تدريب
- [ ] محتوى LinkedIn يومي
- [ ] Discovery calls
- [ ] إغلاق ثاني diagnostic sprint

### Deliverables
- [ ] 250+ total targets
- [ ] 3 one-pagers
- [ ] 2 diagnostic sprints مباعة
- [ ] 2+ pilots محتملة

---

## الأسبوع 4 — Retainer / Expansion

### الأهداف
- تحويل عميل إلى Managed OS
- بناء case study داخلي
- تثبيت offer ladder
- بناء شراكة واحدة

### الإجراءات
- [ ] تجهيز 150 target جديد
- [ ] مراجعة 35 draft
- [ ] إرسال 20 رسالة يدوياً
- [ ] 3-5 meetings
- [ ] عرض managed OS لأول عميل
- [ ] بناء case study (داخلي)
- [ ] تحديث presentation
- [ ] التواصل مع شريك محتمل
- [ ] مراجعة 30 يوم
- [ ] تخطيط 30-60 يوم

### Deliverables
- [ ] 400+ total targets
- [ ] 1 managed OS (أو قريب)
- [ ] Case study داخلي
- [ ] Updated presentation
- [ ] 1 partnership conversation
- [ ] 30-day review report

---

## Metrics (30 يوم)

| Metric | Target |
|--------|--------|
| Total targets | 400+ |
| Drafts reviewed | 125 |
| Manual sends | 75 |
| Meetings | 10 |
| Diagnostics sold | 4 |
| Pilots launched | 2 |
| Managed OS | 1 |
| Revenue | 60K SAR |

## Founder Daily Routine

انظر: founder/war_room/FOUNDER_SALES_WAR_ROOM_AR.md
