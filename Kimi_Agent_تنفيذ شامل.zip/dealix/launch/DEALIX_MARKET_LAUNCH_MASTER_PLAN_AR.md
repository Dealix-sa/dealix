# خطة إطلاق Dealix السوقية

## الهدف

تحويل Dealix من نظام داخلي إلى آلة إطلاق سوق حقيقية تدخل السوق خلال 30 يوم.

## المبدأ

لا نبحث عن الكمال.
نبحث عن:
1. أول workflow يثبت القيمة
2. أول 3 عملاء beta
3. أول proof report
4. أول retainer
5. أول case study

## خارطة الطريق

### الأسبوع 1 — إثبات الحركة
- تشغيل company-full-day يومياً
- تجهيز 500 target
- مراجعة 125 draft
- إرسال يدوي 50-75 رسالة
- حجز 3-5 مكالمات
- توليد أول 2 proposal
- اختيار أول beta client

### الأسبوع 2 — أول Sprint
- تنفيذ Diagnosis Sprint
- تسليم current state map
- تسليم pain map
- تسليم first workflow recommendation
- تسليم proof report أولي
- تحويل العميل إلى Pilot OS

### الأسبوع 3 — تكرار البيع
- تكرار الاستهداف
- إطلاق محتوى LinkedIn يومي
- إنتاج 3 one-pagers قطاعية
- تحسين الرسائل بناءً على الردود
- إغلاق ثاني عميل

### الأسبوع 4 — Retainer / Expansion
- تحويل عميل إلى Managed OS
- بناء case study داخلي
- تحديث البرزنتيشن
- تثبيت offer ladder
- بناء شراكة واحدة محتملة

## الأهداف العددية

| المقياس | 7 أيام | 30 يوم | 90 يوم |
|---------|--------|--------|--------|
| Targets | 100 | 500 | 1500 |
| Drafts reviewed | 25 | 125 | 400 |
| Manual sends | 15 | 75 | 250 |
| Meetings | 2 | 10 | 35 |
| Diagnostics | 0 | 4 | 12 |
| Pilots | 0 | 2 | 6 |
| Managed OS | 0 | 1 | 4 |
| Revenue | 0 | 60K SAR | 250K SAR |

## المنتجات المطلوبة للسوق

1. Company Diagnosis Sprint (مدخل البيع)
2. Revenue Command Room OS
3. WhatsApp / Inbox Follow-up OS
4. AI Trust & Compliance OS

## التسلسل المطلوب

لا نبيع Company Brain OS إلا بعد أن يشتري العميل منتجين على الأقل.
لا نبيع Custom Enterprise إلا بعد Diagnostic Sprint.
لا نطلق Strategic Partnership إلا بعد 3 أشهر.

## Launch Gates

انظر LAUNCH_GATES.md

## Metrics

انظر LAUNCH_METRICS.md

## Blockers

انظر LAUNCH_BLOCKERS.md
