# Sector Pitches — عروض القطاعات

## العيادات

**الألم**: مواعيد تُنسى، تقييمات سلبية غير مدارة، متابعة المرضى ضعيفة
**الخدمة**: WhatsApp Follow-up OS + Review & Reputation OS
**زاوية الرسالة**: "مرضاكم يتواصلون على واتساب. هل تردون في الوقت المناسب؟"
**Discovery Questions**:
- كم نسبة الغياب عن المواعيد؟
- كيف تتبعون المرضى بعد الزيارة؟
- كيف تديرون التقييمات السلبية؟
**Objections**: السعر، التعقيد، "لدينا receptionist"
**First Sprint**: تصنيف رسائل الواتساب + مسودات ردود
**Proof Metrics**: نسبة الرد، سرعة الرد، رضا المرضى

## العقارات

**الألم**: عملاء محتملين يُفقدون، متابعة يدوية، لا تتبع
**الخدمة**: Revenue Command Room + WhatsApp Follow-up
**زاوية الرسالة**: "كل استفسار عميل هو فرصة. هل تتابعونها جميعاً؟"
**Discovery Questions**:
- كم استفسار يصل يومياً؟
- ما نسبة التحويل من استفسار إلى زيارة؟
- كيف تتابعون العملاء بعد العرض؟
**Objections**: السوق بطيء، "نعمل بالعلاقات"
**First Sprint**: Lead classification + follow-up queue
**Proof Metrics**: نسبة المتابعة، العملاء النشطين

## التدريب والاستشارات

**الألم**: تسجيل يدوي، حضور غير متابع، خريجون يُفقدون
**الخدمة**: Operations + Follow-up OS
**زاوية الرسالة**: "كل متدرب يمثل عميلاً محتملاً. هل تتابعون رحلته؟"
**Discovery Questions**:
- كيف يسجل المتدربون حالياً؟
- كم نسبة الحضور؟
- كيف تتواصلون مع الخريجين؟
**Objections**: "نحن صغار"، "لدينا Excel"
**First Sprint**: Registration workflow + attendance tracking
**Proof Metrics**: نسبة الحضور، متابعة الخريجين

## اللوجستيات

**الألم**: شكاوى متكررة، تأخير غير موثق، لا متابعة
**الخدمة**: Operations + Delivery OS
**زاوية الرسالة**: "كل شحنة تمثل وعداً. هل تستطيعون تتبعها جميعاً؟"
**Discovery Questions**:
- كم شكوى يومياً؟
- كيف تتبعون الشحنات؟
- ما SLA للرد على الشكاوى؟
**Objections**: "لدينا نظام"، التكلفة
**First Sprint**: Complaint classification + response tracking
**Proof Metrics**: وقت الرد على الشكوى، نسبة الرضا

## المطاعم

**الألم**: حجوزات تضيع، تقييمات سلبية، لا متابعة
**الخدمة**: Review OS + WhatsApp Follow-up
**زاوية الرسالة**: "كل تقييم يؤثر على 10 قرارات حجز. هل تديرونها؟"
**Discovery Questions**:
- كم نسبة الغياب عن الحجوزات؟
- كيف تردون على التقييمات السلبية؟
- كيف تتابعون عملاء التوصيل؟
**Objections**: "نحن مشغولون"، السعر
**First Sprint**: Review response drafts + reservation confirmation
**Proof Metrics**: نسبة الحجوزات المؤكدة، رد على التقييمات

## وكالات التسويق

**الألم**: متابعة عملاء، تقارير يدوية، لا proof
**الخدمة**: Revenue Command Room + Proof Reports
**زاوية الرسالة**: "عملاؤكم يحتاجون proof. هل لديكم تقارير أسبوعية؟"
**Discovery Questions**:
- كيف تتابعون عملاءكم؟
- ما نوع التقارير التي تقدمونها؟
- هل لديكم نظام للردود السريعة؟
**Objections**: "نحن نبيع marketing"، التنافس
**First Sprint**: Client follow-up system + report template
**Proof Metrics**: سرعة المتابعة، رضا العملاء

## B2B Services

**الألم**: دورة بيع طويلة، متابعة ضعيفة، لا تتبع
**الخدمة**: Revenue Command Room + Follow-up OS
**زاوية الرسالة**: "كل فرصة تمثل شهور عمل. هل تتابعونها بشكل منظم؟"
**Discovery Questions**:
- ما متوسط دورة البيع؟
- كم فرصة نشطة الآن؟
- ما أكبر سبب لفقدان فرص؟
**Objections**: دورة طويلة، قرار متعدد
**First Sprint**: Pipeline tracking + follow-up system
**Proof Metrics**: نسبة التحويل، سرعة المتابعة

## المقاولات

**الألم**: تسليمات متأخرة، شكاوى، لا تتبع
**الخدمة**: Operations + Delivery OS
**زاوية الرسالة**: "كل مشروع يمثل سمعتكم. هل تتابعون التسليمات؟"
**Discovery Questions**:
- كم مشروع نشط؟
- كيف تتابعون التسليمات؟
- ما نسبة التأخير؟
**Objections**: "نحن شركات تشغيل"، التعقيد
**First Sprint**: Project tracking + milestone alerts
**Proof Metrics**: نسبة التسليم في الوقت، الشكاوى

## معارض السيارات

**الألم**: استفسارات تُفقد، متابعة ضعيفة، صيانة
**الخدمة**: Revenue Command Room + Follow-up
**زاوية الرسالة**: "كل زائر يمثل فرصة. هل تتابعون الاستفسارات؟"
**Discovery Questions**:
- كم استفسار يومياً؟
- ما نسبة التحويل؟
- كيف تتابعون عملاء الصيانة؟
**Objections**: "المنافسة شديدة"، السعر
**First Sprint**: Lead capture + follow-up queue
**Proof Metrics**: نسبة المتابعة، التحويل

## مكاتب المحاماة والاستشارات

**الألم**: حالات معقدة، متابعة طويلة، سرية
**الخدمة**: AI Trust + Follow-up OS
**زاوية الرسالة**: "كل حالة تمثل مسؤولية. هل تتابعونها بشكل آمن؟"
**Discovery Questions**:
- كم حالة نشطة؟
- كيف تتابعون العملاء؟
- ما متطلبات السرية؟
**Objections**: السرية، "لدينا نظام"
**First Sprint**: Secure follow-up + case tracking
**Proof Metrics**: سرعة المتابعة، الامتثال
