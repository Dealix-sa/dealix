# Sales System

Complete sales assets for Dealix:
- Sales operating system
- ICP qualification
- Discovery script
- Outreach sequences
- Proposal templates
- Closing playbook

## Usage

```bash
# Validate sales assets
python scripts/business/validate_sales_assets.py

# Generate outreach
python scripts/revenue/generate_outreach_drafts.py
```
