# Dealix Client Operating Loop
## Complete End-to-End Client Lifecycle OS

**Part of:** Dealix — AI Operating Systems for Companies

---

## Objective

Manage the complete client lifecycle within Dealix, from first company research to renewal or expansion.

## Lifecycle Stages

```
Target Research
→ Company Intelligence
→ Pain Hypothesis
→ Outreach Draft
→ Human Approval
→ Controlled Send
→ Reply Classification
→ Meeting Booking
→ Client Intake
→ Company Diagnosis
→ Needs Map
→ Solution Blueprint
→ Proposal Draft
→ Client Project Workspace
→ Delivery Plan
→ UAT
→ Proof Report
→ Monthly Client Success
→ Expansion / Renewal
```

## What Is Automated vs Human-Required

| Stage | Automation | Human Required |
|-------|-----------|----------------|
| Target Research | Data ingestion, validation | Sector review |
| Company Intelligence | Auto-analysis | Angle adjustment |
| Pain Hypothesis | Hypothesis generation | Language review |
| Outreach Draft | Assisted drafts | Pre-send approval |
| Reply Classification | Auto-classification | Complex replies |
| Meeting Booking | Notifications | Confirmation |
| Client Intake | Structured form | Discovery interview |
| Diagnosis | 8-dimension analysis | Result validation |
| Needs Map | Needs mapping | Priority review |
| Blueprint | System design | Design approval |
| Proposal | Draft generation | Pricing review |
| Delivery | Task tracking | Client UAT |
| Proof Report | Automated report | Client feedback |
| Client Success | Monthly review | Renewal decision |

## Daily Founder Usage

```bash
# Morning: run the full day
make client-os-day

# Or step by step
make client-targets        # Research and analyze companies
make client-outreach       # Generate outreach drafts
make client-replies        # Review replies

# For a specific client
make client-diagnose CLIENT=client_001
make client-blueprint CLIENT=client_001
make client-proposal CLIENT=client_001
make client-delivery-day CLIENT=client_001
make client-success-day CLIENT=client_001
```

## New Client Entry Process

1. Complete Client Intake
2. Pass gate: `intake_status=completed`
3. Run Diagnosis
4. Generate Needs Map
5. Build Blueprint
6. Generate Proposal
7. Client approves
8. Start Delivery
9. UAT
10. Proof Report
11. Client Success

## Diagnosis Process

```bash
python scripts/client_os/run_client_diagnosis.py --client CLIENT_ID
```

Covers 8 dimensions: Revenue, Follow-up, Operations, Reputation, Data, Team, AI, Governance.

## Proposal Generation

```bash
# Blueprint must exist first
make client-blueprint CLIENT=client_001
make client-proposal CLIENT=client_001
```

## Delivery Process

1. create_project() opens workspace
2. create_default_tasks() adds tasks
3. update_task_status() tracks progress
4. Client UAT
5. Launch

## Proof Reports

```bash
python scripts/client_os/run_client_success_day.py --client CLIENT_ID --proof
```

## Renewal Process

1. generate_monthly_review() calculates health score
2. If >= 80: renew_recommended
3. If 50-79: renew_with_conditions
4. If < 50: review_required

## Governance & Safety

- No external send without approval
- No WhatsApp cold automation without opt-in
- No guaranteed claims
- No guaranteed ROI
- Source URL required
- Full audit trail
- Company Brain OS is a secondary service within Dealix
