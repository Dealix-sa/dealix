# Human Approval Model
## نموذج الموافقة البشرية

**الجزء من:** Dealix Client Operating Loop

---

## المبدأ الأساسي

> No uncontrolled external send.

كل إجراء خارجي يحتاج إلى موافقة بشرية صريحة.

## نقاط الموافقة المطلوبة

| الإجراء | الموافقة المطلوبة |
|---------|-----------------|
| إرسال إيميل | approval_status=approved |
| إرسال واتساب | approval_status + opt-in |
| LinkedIn message | approval_status=approved |
| تغيير في acceptance criteria | approval من العميل |
| إطلاق النظام | UAT signature |

## مستويات الموافقة

1. **draft** — المسودة جاهزة للمراجعة
2. **pending** — قيد المراجعة
3. **approved** — تمت الموافقة
4. **rejected** — مرفوض

## من يوافق

- **Outreach drafts**: مؤسس Dealix أو مدير الموافقات
- **Proposals**: المؤسس + العميل
- **Delivery milestones**: مدير المشروع + العميل
- **Proof reports**: مدير النجاح

## سجل الموافقات

كل موافقة تسجل في:
- outreach_log.approved_by
- audit_log (action=outreach_approval)
- ledgers (التحديث الفوري)

## الضوابط

- لا يمكن تغيير الموافقة retroactively
- الرفض يحتاج سبباً
- كل موافقة مرتبطة بـ actor محدد
- سجل الموافقات غير قابل للحذف
