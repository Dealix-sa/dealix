# Dealix Client Operating Loop
## نظام تشغيل دورة العميل الكاملة

**الجزء من:** Dealix — AI Operating Systems for Companies

---

## الهدف

إدارة دورة العميل الكاملة داخل Dealix، من أول البحث عن الشركات حتى التجديد أو التوسعة.

## المراحل

```
Target Research
→ Company Intelligence
→ Pain Hypothesis
→ Outreach Draft
→ Human Approval
→ Controlled Send
→ Reply Classification
→ Meeting Booking
→ Client Intake
→ Company Diagnosis
→ Needs Map
→ Solution Blueprint
→ Proposal Draft
→ Client Project Workspace
→ Delivery Plan
→ UAT
→ Proof Report
→ Monthly Client Success
→ Expansion / Renewal
```

## ماذا يؤتمت

| المرحلة | الأتمتة | الحاجة البشرية |
|---------|---------|---------------|
| Target Research | جمع البيانات، التحقق | مراجعة القطاعات |
| Company Intelligence | تحليل تلقائي | تعديل الزاوية |
| Pain Hypothesis | توليد فرضيات | مراجعة اللغة |
| Outreach Draft | مسودات مساعدة | موافقة قبل الإرسال |
| Reply Classification | تصنيف تلقائي | repies معقدة |
| Meeting Booking | إشعارات | تأكيد الموعد |
| Client Intake | نموذج منظم | مقابلة الاكتشاف |
| Diagnosis | تحليل 8 أبعاد | تأكيد النتائج |
| Needs Map | خريطة احتياجات | مراجعة الأولويات |
| Blueprint | تصميم النظام | الموافقة على التصميم |
| Proposal | مسودة العرض | مراجعة الأسعار |
| Delivery | تتبع المهام | UAT من العميل |
| Proof Report | تقرير آلي | ملاحظات العميل |
| Client Success | مراجعة شهرية | قرار التجديد |

## كيف يستخدمه المؤسس يومياً

```bash
# الصباح: تشغيل اليوم الكامل
make client-os-day

# أو خطوة بخطوة
make client-targets        # جلب وتحليل شركات
make client-outreach       # توليد مسودات تواصل
make client-replies        # مراجعة الردود

# لعميل محدد
make client-diagnose CLIENT=client_001
make client-blueprint CLIENT=client_001
make client-proposal CLIENT=client_001
make client-delivery-day CLIENT=client_001
make client-success-day CLIENT=client_001
```

## كيف يدخل عميل جديد

1. يكتمل Client Intake
2. يمر gate: `intake_status=completed`
3. يبدأ Diagnosis
4. يولد Needs Map
5. يبنى Blueprint
6. يولد Proposal
7. يوافق العميل
8. يبدأ Delivery
9. UAT
10. Proof Report
11. Client Success

## كيف يطلع diagnosis

```bash
python scripts/client_os/run_client_diagnosis.py --client CLIENT_ID
```

يغطي 8 أبعاد: Revenue, Follow-up, Operations, Reputation, Data, Team, AI, Governance.

## كيف يطلع proposal

```bash
# يحتاج blueprint أولاً
make client-blueprint CLIENT=client_001
make client-proposal CLIENT=client_001
```

## كيف يتم التسليم

1. create_project() يفتح workspace
2. create_default_tasks() يضيف المهام
3. update_task_status() يحدث الحالة
4. UAT من العميل
5. launch

## كيف تصدر proof reports

```bash
python scripts/client_os/run_client_success_day.py --client CLIENT_ID --proof
```

## كيف يتم التجديد

1. generate_monthly_review() يحسب health score
2. إذا >= 80: renew_recommended
3. إذا 50-79: renew_with_conditions
4. إذا < 50: review_required

## الحوكمة والأمان

- لا إرسال خارجي بدون موافقة
- لا واتساب cold بدون opt-in
- لا ادعاءات مضمونة
- لا ROI مضمون
- source_url مطلوب
- audit trail كامل
- Company Brain OS خدمة ثانوية داخل Dealix
