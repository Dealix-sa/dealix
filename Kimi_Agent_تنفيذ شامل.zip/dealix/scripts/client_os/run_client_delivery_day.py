#!/usr/bin/env python3
"""
Dealix Client OS — Delivery Day Runner

Manages project delivery tasks.

Usage:
    python scripts/client_os/run_client_delivery_day.py --client CLIENT_ID [--project PROJECT_ID]
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.delivery_planner import create_project, get_project_summary, update_task_status
from app.client_os.storage import get_storage


def main():
    parser = argparse.ArgumentParser(description="Dealix Delivery Day")
    parser.add_argument("--client", required=True, help="Client ID")
    parser.add_argument("--project", default="", help="Project ID")
    parser.add_argument("--complete-task", default="", help="Task ID to mark as completed")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX DELIVERY DAY")
    print("=" * 50)

    client_id = args.client
    print(f"\nClient: {client_id}")

    # Check for existing project
    storage = get_storage()
    projects = storage.read_all("projects")
    client_projects = [p for p in projects if p.get("client_id") == client_id]

    if client_projects:
        project = client_projects[0]
        project_id = project.get("project_id", "")
        print(f"Using existing project: {project_id}")
    elif args.project:
        project_id = args.project
        print(f"Using project: {project_id}")
    else:
        # Create new project
        print("\nCreating new project...")
        result = create_project(client_id=client_id)
        if "error" in result:
            print(f"  [ERROR] {result['error']}")
            sys.exit(1)
        project_id = result["project_id"]
        print(f"  Project: {project_id}")
        print(f"  Tasks: {result['tasks_created']}")

    # Show project summary
    print("\nProject Summary:")
    summary = get_project_summary(project_id)
    print(f"  Name: {summary.get('project_name', '')}")
    print(f"  Phase: {summary.get('current_phase', '')}")
    print(f"  Total Tasks: {summary.get('total_tasks', 0)}")
    for status, count in summary.get("task_status", {}).items():
        print(f"    {status}: {count}")

    # Complete task if specified
    if args.complete_task:
        print(f"\nCompleting task: {args.complete_task}")
        update_task_status(args.complete_task, "completed")
        print("  Task marked as completed")

    print("\n" + "=" * 50)
    print("DELIVERY_DAY_COMPLETE")
    print(f"project_id={project_id}")
    print(f"total_tasks={summary.get('total_tasks', 0)}")
    print("=" * 50)


if __name__ == "__main__":
    main()
