#!/usr/bin/env python3
"""
Dealix Client OS — Proposal Runner

Generates proposal draft for a client.

Usage:
    python scripts/client_os/run_client_proposal.py --client CLIENT_ID
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.proposal_builder import generate_proposal


def main():
    parser = argparse.ArgumentParser(description="Dealix Proposal Builder")
    parser.add_argument("--client", required=True, help="Client ID")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX PROPOSAL BUILDER")
    print("=" * 50)

    client_id = args.client
    print(f"\nClient: {client_id}")

    print("\nGenerating proposal...")
    result = generate_proposal(client_id)

    if "error" in result:
        print(f"  [ERROR] {result['error']}")
        print("\n  Hint: Ensure blueprint exists first:")
        print(f"    python scripts/client_os/run_client_blueprint.py --client {client_id}")
        sys.exit(1)

    print(f"\n  Proposal ID: {result['proposal_id']}")
    print(f"  Project ID: {result['project_id']}")
    print(f"  Blueprint ID: {result['blueprint_id']}")
    print(f"  Status: {result['status']}")
    print(f"  Policy Check: {result['policy_check']}")
    if result.get("policy_reason"):
        print(f"  Policy Note: {result['policy_reason']}")

    print("\n" + "=" * 50)
    print("PROPOSAL_COMPLETE")
    print(f"proposal_id={result['proposal_id']}")
    print(f"status={result['status']}")
    print(f"requires_approval=true")
    print("=" * 50)


if __name__ == "__main__":
    main()
