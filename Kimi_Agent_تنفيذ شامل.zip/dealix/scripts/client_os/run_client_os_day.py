#!/usr/bin/env python3
"""
Dealix Client OS — Full Day Runner

Runs the complete Client Operating Loop for a day:
1. Target research
2. Qualification
3. Pain hypothesis
4. Outreach draft generation
5. Reply classification
6. Delivery status review
7. Proof due review
8. Command room summary
9. latest_company_day.md

Usage:
    python scripts/client_os/run_client_os_day.py [--sample]
"""

import argparse
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.company_research import ingest_companies
from app.client_os.qualification import qualify_all_pending
from app.client_os.pain_hypothesis import batch_generate_hypotheses
from app.client_os.outreach_draft import generate_outreach_draft
from app.client_os.reply_classifier import get_interested_replies
from app.client_os.storage import get_storage


def generate_command_room_summary():
    """Generate command room summary report."""
    storage = get_storage()

    companies = storage.read_all("companies")
    outreach = storage.read_all("outreach_log")
    replies = storage.read_all("replies")
    intakes = storage.read_all("client_intakes")
    blueprints = storage.read_all("blueprints")
    proposals = storage.read_all("proposals")
    projects = storage.read_all("projects")
    proof_reports = storage.read_all("proof_reports")

    verified = [c for c in companies if c.get("verification_status") == "verified"]
    drafts_pending = [m for m in outreach if m.get("approval_status") == "draft"]
    approved_sends = [m for m in outreach if m.get("approval_status") == "approved"]
    interested = get_interested_replies()
    intakes_pending = [i for i in intakes if i.get("intake_status") == "pending"]
    active_projects = [p for p in projects if p.get("status") == "active"]

    summary = f"""# Dealix Command Room — Client OS
Generated: {datetime.now().isoformat()}

## Revenue Pipeline
- targets_researched={len(companies)}
- qualified_companies={len(verified)}
- drafts_ready={len(drafts_pending)}
- approved_sends={len(approved_sends)}
- replies_total={len(replies)}
- interested_replies={len(interested)}

## Client Analysis
- new_intakes={len(intakes)}
- intakes_pending={len(intakes_pending)}
- blueprints_ready={len(blueprints)}
- proposals_ready={len(proposals)}

## Delivery
- active_projects={len(active_projects)}
- proof_reports={len(proof_reports)}

## Trust
- mode=DRAFT_ONLY (no uncontrolled send)
- fake_claims_blocked=true
- approval_gates_active=true

## Founder Actions (Next 10)
"""
    # Generate founder actions
    actions = []
    if drafts_pending:
        actions.append(f"1. Review {len(drafts_pending)} outreach drafts pending approval")
    if intakes_pending:
        actions.append(f"2. Follow up on {len(intakes_pending)} pending intakes")
    if interested:
        actions.append(f"3. Respond to {len(interested)} interested replies")
    if not blueprints and intakes:
        completed_intakes = [i for i in intakes if i.get("intake_status") == "completed"]
        if completed_intakes:
            actions.append(f"4. Generate blueprints for {len(completed_intakes)} completed intakes")
    if proposals:
        draft_proposals = [p for p in proposals if p.get("status") == "draft"]
        if draft_proposals:
            actions.append(f"5. Review {len(draft_proposals)} proposal drafts")
    if active_projects:
        actions.append(f"6. Check delivery status on {len(active_projects)} active projects")
    if not actions:
        actions.append("1. Run target research to find new companies")
        actions.append("2. Review existing pipeline")

    for i, action in enumerate(actions[:10], 1):
        summary += f"{i}. {action}\n"

    return summary


def main():
    parser = argparse.ArgumentParser(description="Dealix Client OS Full Day")
    parser.add_argument("--sample", action="store_true", default=True, help="Use sample data")
    args = parser.parse_args()

    print("=" * 60)
    print("DEALIX CLIENT OPERATING SYSTEM — FULL DAY")
    print("=" * 60)

    # Step 1-3: Target research
    print("\n[PHASE 1] Target Research & Qualification")
    companies = ingest_companies(use_sample=args.sample)
    print(f"  Companies ingested: {len(companies)}")

    qualified = qualify_all_pending()
    verified = [q for q in qualified if q.get("verification_status") == "verified"]
    print(f"  Qualified: {len(qualified)}, Verified: {len(verified)}")

    hypotheses = batch_generate_hypotheses()
    print(f"  Hypotheses: {len(hypotheses)}")

    # Step 4: Outreach drafts
    print("\n[PHASE 2] Outreach Draft Generation")
    drafts = []
    for company in verified[:3]:  # Limit to 3 for demo
        draft = generate_outreach_draft(company.get("company_id", ""))
        if "error" not in draft:
            drafts.append(draft)
    print(f"  Drafts created: {len(drafts)}")

    # Step 5: Reply classification (simulate)
    print("\n[PHASE 3] Reply Classification")
    interested = get_interested_replies()
    print(f"  Interested replies: {len(interested)}")

    # Step 6: Delivery status
    print("\n[PHASE 4] Delivery Status Review")
    storage = get_storage()
    projects = storage.read_all("projects")
    active = [p for p in projects if p.get("status") == "active"]
    print(f"  Active projects: {len(active)}")

    # Step 7: Proof reports
    print("\n[PHASE 5] Proof Reports Review")
    proofs = storage.read_all("proof_reports")
    print(f"  Proof reports: {len(proofs)}")

    # Step 8-9: Command room summary
    print("\n[PHASE 6] Generating Command Room Summary...")
    summary = generate_command_room_summary()

    # Write report
    report_path = Path("reports/client_os/latest_company_day.md")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(summary)
    print(f"  Report saved: {report_path}")

    # Final output
    print("\n" + "=" * 60)
    print("CLIENT_OS_DAY_COMPLETE")
    print(f"targets_researched={len(companies)}")
    print(f"drafts_created={len(drafts)}")
    print(f"replies_classified={len(interested)}")
    print(f"intakes_pending={len(storage.read_all('client_intakes'))}")
    print(f"blueprints_ready={len(storage.read_all('blueprints'))}")
    print(f"proposals_ready={len(storage.read_all('proposals'))}")
    print(f"proof_reports_due={len(proofs)}")
    print(f"founder_actions={len([l for l in summary.split(chr(10)) if l.strip().startswith(chr(ord('1'))) or l.strip().startswith('2.') or l.strip().startswith('3.')])}")
    print("=" * 60)


if __name__ == "__main__":
    main()
