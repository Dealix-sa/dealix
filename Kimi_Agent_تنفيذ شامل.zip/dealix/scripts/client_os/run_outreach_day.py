#!/usr/bin/env python3
"""
Dealix Client OS — Outreach Day Runner

Generates outreach drafts for verified companies.
No sending — all drafts.

Usage:
    python scripts/client_os/run_outreach_day.py [--limit 10]
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.storage import get_storage
from app.client_os.schemas import Channel
from app.client_os.outreach_draft import generate_outreach_draft, get_pending_drafts


def main():
    parser = argparse.ArgumentParser(description="Dealix Outreach Day")
    parser.add_argument("--limit", type=int, default=10, help="Max drafts to generate")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX OUTREACH DAY")
    print("=" * 50)

    storage = get_storage()
    companies = storage.read_all("companies")
    verified = [c for c in companies if c.get("verification_status") == "verified"]

    print(f"\nFound {len(verified)} verified companies")

    drafts = []
    for company in verified[:args.limit]:
        company_id = company.get("company_id", "")
        company_name = company.get("company_name", "")

        # Generate email draft
        print(f"\n  Drafting for: {company_name}")
        draft = generate_outreach_draft(
            company_id=company_id,
            channel=Channel.EMAIL,
            template_type="introduction"
        )
        if "error" not in draft:
            drafts.append(draft)
            print(f"    Email draft: {draft['message_id']} [{draft['approval_status']}]")
        else:
            print(f"    Error: {draft['error']}")

    pending = get_pending_drafts()

    print("\n" + "=" * 50)
    print(f"OUTREACH_DAY_COMPLETE")
    print(f"drafts_created={len(drafts)}")
    print(f"drafts_pending_approval={len(pending)}")
    print(f"mode=DRAFT_ONLY (no sending)")
    print("=" * 50)


if __name__ == "__main__":
    main()
