#!/usr/bin/env python3
"""
Dealix Client OS — Target Research Runner

Usage:
    python scripts/client_os/run_target_research.py [--source targets.csv]
"""

import argparse
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.company_research import ingest_companies
from app.client_os.qualification import qualify_all_pending
from app.client_os.company_intelligence import generate_intelligence_brief
from app.client_os.pain_hypothesis import batch_generate_hypotheses


def main():
    parser = argparse.ArgumentParser(description="Dealix Target Research")
    parser.add_argument("--source", help="Path to external targets CSV")
    parser.add_argument("--sample", action="store_true", default=True, help="Use sample data")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX TARGET RESEARCH")
    print("=" * 50)

    # Step 1: Ingest companies
    print("\n[1/4] Ingesting companies...")
    companies = ingest_companies(source=args.source, use_sample=args.sample)
    print(f"      Added {len(companies)} companies")

    # Step 2: Qualify
    print("\n[2/4] Qualifying companies...")
    results = qualify_all_pending()
    verified = [r for r in results if r.get("verification_status") == "verified"]
    print(f"      Qualified {len(results)} companies, {len(verified)} verified")

    # Step 3: Intelligence briefs
    print("\n[3/4] Generating intelligence briefs...")
    briefs = []
    for company in companies:
        brief = generate_intelligence_brief(company.get("company_id", ""))
        if "error" not in brief:
            briefs.append(brief)
    print(f"      Generated {len(briefs)} briefs")

    # Step 4: Pain hypotheses
    print("\n[4/4] Generating pain hypotheses...")
    hypotheses = batch_generate_hypotheses()
    print(f"      Generated {len(hypotheses)} hypotheses")

    print("\n" + "=" * 50)
    print(f"TARGET_RESEARCH_COMPLETE")
    print(f"companies_ingested={len(companies)}")
    print(f"companies_verified={len(verified)}")
    print(f"briefs_generated={len(briefs)}")
    print(f"hypotheses_generated={len(hypotheses)}")
    print("=" * 50)


if __name__ == "__main__":
    main()
