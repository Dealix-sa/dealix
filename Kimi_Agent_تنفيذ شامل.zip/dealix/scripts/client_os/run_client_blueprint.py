#!/usr/bin/env python3
"""
Dealix Client OS — Blueprint Runner

Generates system blueprint for a client.

Usage:
    python scripts/client_os/run_client_blueprint.py --client CLIENT_ID [--project PROJECT_ID]
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.blueprint_builder import generate_blueprint
from app.client_os.needs_mapper import generate_needs_map


def main():
    parser = argparse.ArgumentParser(description="Dealix Blueprint Builder")
    parser.add_argument("--client", required=True, help="Client ID")
    parser.add_argument("--project", default="", help="Project ID (optional)")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX BLUEPRINT BUILDER")
    print("=" * 50)

    client_id = args.client

    # First ensure needs map exists
    print(f"\nClient: {client_id}")
    print("\n[1/2] Ensuring needs map exists...")
    needs_result = generate_needs_map(client_id)
    if "error" in needs_result:
        print(f"  [ERROR] {needs_result['error']}")
        sys.exit(1)
    print(f"  Needs map: {needs_result.get('needs_map_id', '')}")
    print(f"  Primary need: {needs_result.get('primary_need', '')}")
    print(f"  Recommended OS: {needs_result.get('recommended_os', '')}")

    # Generate blueprint
    print("\n[2/2] Generating system blueprint...")
    result = generate_blueprint(client_id, project_id=args.project)

    if "error" in result:
        print(f"  [ERROR] {result['error']}")
        sys.exit(1)

    print(f"\n  Blueprint ID: {result['blueprint_id']}")
    print(f"  Project ID: {result['project_id']}")
    print(f"  Recommended OS: {result['recommended_os']}")
    print(f"  Workflow: {result['workflow_summary']}")

    print("\n" + "=" * 50)
    print("BLUEPRINT_COMPLETE")
    print(f"blueprint_id={result['blueprint_id']}")
    print(f"project_id={result['project_id']}")
    print("=" * 50)


if __name__ == "__main__":
    main()
