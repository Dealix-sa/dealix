#!/usr/bin/env python3
"""
Dealix Client OS — Client Intake Runner

Runs client intake process.

Usage:
    python scripts/client_os/run_client_intake.py --client CLIENT_ID [--complete]
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.intake_engine import create_intake, complete_intake, get_intake_summary


def main():
    parser = argparse.ArgumentParser(description="Dealix Client Intake")
    parser.add_argument("--client", required=True, help="Client ID (or 'sample' for demo)")
    parser.add_argument("--complete", action="store_true", help="Mark intake as completed")
    parser.add_argument("--goal", default="", help="Business goal")
    parser.add_argument("--pain", default="", help="Main pain point")
    parser.add_argument("--tools", default="", help="Current tools")
    parser.add_argument("--owner", default="", help="Decision owner")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX CLIENT INTAKE")
    print("=" * 50)

    client_id = args.client

    if args.complete:
        print(f"\nCompleting intake for: {client_id}")
        result = complete_intake(client_id)
        print(f"  Status: {result.get('status', 'unknown')}")
    else:
        print(f"\nCreating intake for: {client_id}")
        # Try to get existing
        existing = get_intake_summary(client_id)
        if "error" not in existing and existing.get("status"):
            print(f"  Intake already exists — status: {existing['status']}")
            print(f"\n  Goal: {existing.get('goal', '')}")
            print(f"  Pain: {existing.get('main_pain', '')}")
            print(f"  Tools: {existing.get('current_tools', '')}")
        else:
            result = create_intake(
                company_id=f"comp_{client_id}",
                client_name=client_id,
                goal=args.goal or "تحسين العمليات التشغيلية",
                main_pain=args.pain or "عدم وجود نظام موحد",
                current_tools=args.tools or "Excel + WhatsApp يدوي",
                decision_owner=args.owner or "المدير التنفيذي",
                sector="تجارة تجزئة",
            )
            print(f"  Created intake: {result.get('client_id', '')}")
            print(f"  Questions answered: {result.get('questions_answered', 0)}/{result.get('total_questions', 0)}")

    print("\n" + "=" * 50)
    print("INTAKE_COMPLETE")
    print("=" * 50)


if __name__ == "__main__":
    main()
