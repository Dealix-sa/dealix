#!/usr/bin/env python3
"""
Dealix Client OS — Reply Review Runner

Classifies replies and generates follow-up actions.

Usage:
    python scripts/client_os/run_reply_review.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.reply_classifier import get_interested_replies, get_pending_human_review
from app.client_os.storage import get_storage


def main():
    print("=" * 50)
    print("DEALIX REPLY REVIEW")
    print("=" * 50)

    storage = get_storage()
    replies = storage.read_all("replies")

    print(f"\nTotal replies in system: {len(replies)}")

    # Summary by category
    categories = {}
    for reply in replies:
        cat = reply.get("category", "unknown")
        categories[cat] = categories.get(cat, 0) + 1

    print("\nBreakdown by category:")
    for cat, count in sorted(categories.items()):
        print(f"  {cat}: {count}")

    # Interested replies
    interested = get_interested_replies()
    print(f"\nInterested/book_meeting: {len(interested)}")

    # Pending human review
    pending_review = get_pending_human_review()
    print(f"Pending human review: {len(pending_review)}")

    print("\n" + "=" * 50)
    print(f"REPLY_REVIEW_COMPLETE")
    print(f"total_replies={len(replies)}")
    print(f"interested_count={len(interested)}")
    print(f"human_review_needed={len(pending_review)}")
    print("=" * 50)


if __name__ == "__main__":
    main()
