#!/usr/bin/env python3
"""
Dealix Client OS — Client Success Day Runner

Generates monthly review and health check.

Usage:
    python scripts/client_os/run_client_success_day.py --client CLIENT_ID [--project PROJECT_ID]
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.client_success import generate_monthly_review
from app.client_os.proof_reporter import generate_proof_report
from app.client_os.storage import get_storage


def main():
    parser = argparse.ArgumentParser(description="Dealix Client Success Day")
    parser.add_argument("--client", required=True, help="Client ID")
    parser.add_argument("--project", default="", help="Project ID")
    parser.add_argument("--proof", action="store_true", help="Also generate proof report")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX CLIENT SUCCESS DAY")
    print("=" * 50)

    client_id = args.client
    print(f"\nClient: {client_id}")

    # Find project
    storage = get_storage()
    projects = storage.read_all("projects")
    client_projects = [p for p in projects if p.get("client_id") == client_id]

    if not client_projects:
        print("[ERROR] No project found for client")
        print(f"Run: python scripts/client_os/run_client_delivery_day.py --client {client_id}")
        sys.exit(1)

    project = client_projects[0]
    project_id = args.project or project.get("project_id", "")

    # Generate proof report if requested
    if args.proof:
        print("\n[1/2] Generating proof report...")
        proof_result = generate_proof_report(project_id=project_id)
        if "error" in proof_result:
            print(f"  [WARNING] {proof_result['error']}")
        else:
            print(f"  Proof ID: {proof_result['proof_id']}")

    # Generate monthly review
    print("\n[2/2] Generating monthly review...")
    result = generate_monthly_review(project_id=project_id)

    if "error" in result:
        print(f"  [ERROR] {result['error']}")
        sys.exit(1)

    print(f"\n  Renewal ID: {result['renewal_id']}")
    print(f"  Health Score: {result['health_score']}/100")
    print(f"  Renewal: {result['renewal_recommendation']}")
    print(f"\n  Expansion Opportunities:")
    for opp in result.get("expansion_opportunities", []):
        print(f"    - {opp}")

    print("\n" + "=" * 50)
    print("CLIENT_SUCCESS_COMPLETE")
    print(f"renewal_id={result['renewal_id']}")
    print(f"health_score={result['health_score']}")
    print(f"renewal={result['renewal_recommendation']}")
    print("=" * 50)


if __name__ == "__main__":
    main()
