#!/usr/bin/env python3
"""
Dealix Client OS — Client Diagnosis Runner

Runs company diagnosis for a client.

Usage:
    python scripts/client_os/run_client_diagnosis.py --client CLIENT_ID
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.diagnosis_engine import generate_diagnosis
from app.client_os.policy_gate import get_gate


def main():
    parser = argparse.ArgumentParser(description="Dealix Client Diagnosis")
    parser.add_argument("--client", required=True, help="Client ID")
    parser.add_argument("--revenue", default="", help="Revenue assessment override")
    parser.add_argument("--followup", default="", help="Follow-up assessment override")
    args = parser.parse_args()

    print("=" * 50)
    print("DEALIX CLIENT DIAGNOSIS")
    print("=" * 50)

    client_id = args.client

    # Gate check
    print(f"\nClient: {client_id}")
    gate = get_gate()
    passed, reason = gate.check_intake_before_diagnosis(client_id)
    print(f"Gate check: {'PASSED' if passed else 'FAILED'} — {reason}")

    if not passed:
        print("\n[ERROR] Cannot run diagnosis without completed intake")
        print("Run: python scripts/client_os/run_client_intake.py --client {client} --complete")
        sys.exit(1)

    # Run diagnosis
    print("\nGenerating diagnosis...")
    answers = {}
    if args.revenue:
        answers["main_pain"] = args.revenue
    if args.followup:
        answers["current_tools"] = args.followup

    result = generate_diagnosis(client_id, answers=answers if answers else None)

    if "error" in result:
        print(f"[ERROR] {result['error']}")
        sys.exit(1)

    print(f"\n  Diagnosis ID: {result['diagnosis_id']}")
    print(f"  Overall Risk: {result['overall_risk']}")
    print(f"\n  Key Gaps:")
    for gap in result.get("key_gaps", []):
        print(f"    - {gap}")

    print(f"\n  Dimensions:")
    for dim, data in result.get("dimensions", {}).items():
        print(f"    {dim}: {data['level']} — {data['assessment'][:50]}...")

    print("\n" + "=" * 50)
    print("DIAGNOSIS_COMPLETE")
    print(f"diagnosis_id={result['diagnosis_id']}")
    print(f"overall_risk={result['overall_risk']}")
    print(f"gaps_found={len(result.get('key_gaps', []))}")
    print("=" * 50)


if __name__ == "__main__":
    main()
