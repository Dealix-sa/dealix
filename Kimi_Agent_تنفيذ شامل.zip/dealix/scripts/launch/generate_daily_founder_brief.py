#!/usr/bin/env python3
"""
Generate daily founder brief.
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.storage import get_storage


def main():
    print("=" * 50)
    print("DAILY FOUNDER BRIEF")
    print("=" * 50)

    storage = get_storage()
    companies = storage.read_all("companies")
    outreach = storage.read_all("outreach_log")
    intakes = storage.read_all("client_intakes")
    projects = storage.read_all("projects")

    verified = [c for c in companies if c.get("verification_status") == "verified"]
    drafts = [m for m in outreach if m.get("approval_status") == "draft"]
    active_proj = [p for p in projects if p.get("status") == "active"]

    brief = f"""# Today's Founder Brief
Generated: {datetime.now().isoformat()}

## 1. Highest Priority Action
[Review {len(drafts)} outreach drafts and approve 3 for sending]

## 2. Top Prospects to Review
{len(verified)} verified companies in pipeline
Review top 10 priority A targets

## 3. Drafts to Approve
{len(drafts)} drafts pending approval

## 4. Replies to Handle
Check replies ledger for interested responses

## 5. Meetings to Book
Target: 1 meeting today
Current meetings: check meetings ledger

## 6. Proposals to Send
Target: 1 proposal this week

## 7. Delivery Blockers
{len(active_proj)} active projects — check for blockers

## 8. Proof Reports Due
Check projects needing weekly proof report

## 9. Retainer Opportunities
{len(intakes)} intakes — identify conversion opportunities

## 10. One Decision to Make Today
[Choose: Which sector to focus on this week?]

## Metrics
- Targets: {len(companies)}
- Verified: {len(verified)}
- Drafts pending: {len(drafts)}
- Active projects: {len(active_proj)}
- Intakes: {len(intakes)}
"""

    report_dir = Path("reports/launch")
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / "latest_founder_brief.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(brief)

    print(f"\nBrief saved: {report_path}")
    print("\n" + "=" * 50)
    print("FOUNDER_BRIEF_COMPLETE")
    print("=" * 50)


if __name__ == "__main__":
    main()
