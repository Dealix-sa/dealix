#!/usr/bin/env python3
"""Validate prospecting pack."""
import sys
from pathlib import Path

REQUIRED = [
    "gtm/prospecting/PROSPECTING_OPERATING_MODEL_AR.md",
    "gtm/prospecting/TARGET_RESEARCH_SOP_AR.md",
    "gtm/prospecting/TARGET_VERIFICATION_SOP_AR.md",
    "gtm/prospecting/SECTOR_TARGETING_RULES_AR.md",
    "gtm/prospecting/100_TARGET_DAY_TEMPLATE.csv",
    "gtm/prospecting/PROSPECT_SCORING_MODEL.md",
    "gtm/prospecting/OUTREACH_APPROVAL_CHECKLIST.md",
    "gtm/prospecting/MANUAL_SEND_SOP_AR.md",
]

def main():
    ok = True
    for f in REQUIRED:
        p = Path(f)
        if not p.exists():
            print(f"FAIL: {f}")
            ok = False
        else:
            print(f"PASS: {f}")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
