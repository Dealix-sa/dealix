#!/usr/bin/env python3
"""Validate closing pack."""
import sys
from pathlib import Path

REQUIRED = [
    "closing/CLOSING_PLAYBOOK_AR.md",
    "closing/DEAL_ACCEPTANCE_CHECKLIST.md",
    "closing/DECISION_MEETING_SCRIPT_AR.md",
    "closing/PROPOSAL_REVIEW_SCRIPT_AR.md",
    "closing/PRICE_OBJECTION_SCRIPT_AR.md",
    "closing/SECURITY_PRIVACY_OBJECTION_SCRIPT_AR.md",
    "closing/WHY_DEALIX_NOW_AR.md",
    "closing/WHY_NOT_CHATBOT_AR.md",
    "closing/WHY_NOT_CRM_AR.md",
    "closing/NEXT_STEP_MESSAGES_AR.md",
]

def main():
    ok = True
    for f in REQUIRED:
        p = Path(f)
        if not p.exists():
            print(f"FAIL: {f}")
            ok = False
        else:
            print(f"PASS: {f}")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
