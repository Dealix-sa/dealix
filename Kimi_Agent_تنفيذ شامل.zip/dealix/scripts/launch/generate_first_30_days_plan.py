#!/usr/bin/env python3
"""
Generate personalized first 30 days plan.
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def main():
    print("=" * 50)
    print("FIRST 30 DAYS PLAN")
    print("=" * 50)

    now = datetime.now()
    plan = f"""# First 30 Days Plan
Generated: {now.isoformat()}
Start Date: {now.strftime('%Y-%m-%d')}

## Week 1 — Prove Motion
Goals:
- 100 targets
- 25 drafts reviewed
- 15 manual sends
- 2 meetings

Daily Actions:
- Run make market-day
- Research 20 targets
- Review 5 drafts
- Send 3 messages
- Follow up on replies

## Week 2 — First Sprint
Goals:
- 1 diagnostic sprint
- Current state map
- Pain map
- First workflow

Actions:
- Conduct intake meeting
- Run diagnosis
- Build needs map
- Deliver proof report
- Convert to pilot

## Week 3 — Repeat Sales
Goals:
- 2nd client
- 3 one-pagers
- LinkedIn daily

Actions:
- Prospect 150 targets
- 40 drafts reviewed
- 20 sends
- 3-5 meetings
- Content production

## Week 4 — Retainer/Expansion
Goals:
- 1 managed OS
- Case study
- Partnership conversation

Actions:
- Convert pilot to managed
- Build case study
- Update presentation
- Partner outreach
- Monthly review

## Daily Routine
Morning: make market-day + scorecard
Midday: outreach + meetings
Evening: ledger update + tomorrow plan

## Success Metrics
| Metric | 7d | 14d | 21d | 30d |
|--------|-----|-----|-----|-----|
| Targets | 100 | 200 | 350 | 400+ |
| Meetings | 2 | 5 | 8 | 10 |
| Diagnostics | 0 | 1 | 2 | 4 |
| Revenue | 0 | 10K | 35K | 60K |
"""

    report_dir = Path("reports/launch")
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / "latest_gtm_actions.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(plan)

    print(f"\nPlan saved: {report_path}")
    print("\n" + "=" * 50)
    print("30_DAYS_PLAN_COMPLETE")
    print("=" * 50)


if __name__ == "__main__":
    main()
