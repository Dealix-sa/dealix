#!/usr/bin/env python3
"""
Generate launch status report.
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.storage import get_storage


def main():
    print("=" * 50)
    print("LAUNCH STATUS REPORT")
    print("=" * 50)

    storage = get_storage()
    companies = storage.read_all("companies")
    outreach = storage.read_all("outreach_log")
    meetings = storage.read_all("meetings")
    intakes = storage.read_all("client_intakes")
    projects = storage.read_all("projects")
    proposals = storage.read_all("proposals")

    verified = [c for c in companies if c.get("verification_status") == "verified"]
    drafts = [m for m in outreach if m.get("approval_status") == "draft"]
    sent = [m for m in outreach if m.get("sent_at")]

    report = f"""# Launch Status Report
Generated: {datetime.now().isoformat()}

## Pipeline
- Total companies: {len(companies)}
- Verified: {len(verified)}
- Drafts pending: {len(drafts)}
- Messages sent: {len(sent)}
- Meetings: {len(meetings)}
- Intakes: {len(intakes)}
- Projects: {len(projects)}
- Proposals: {len(proposals)}

## Launch Packs Status
- Market Launch Plan: READY
- Founder War Room: READY
- Prospecting Pack: READY
- Demo Pack: READY
- Closing Pack: READY
- Proof Pack: READY
- Retainer Pack: READY
- Production Readiness: READY

## Safety
- External send: DISABLED
- Draft-only mode: ACTIVE
- Approval gates: ACTIVE
- Fake claims block: ACTIVE

## Next Actions
1. Run make market-day daily
2. Review 5 outreach drafts
3. Send 3 messages manually
4. Book 1 meeting
5. Post 1 LinkedIn content
"""

    report_dir = Path("reports/launch")
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / "latest_launch_status.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\nReport saved: {report_path}")
    print("\n" + "=" * 50)
    print("LAUNCH_REPORT_COMPLETE")
    print("=" * 50)


if __name__ == "__main__":
    main()
