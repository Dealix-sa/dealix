#!/usr/bin/env python3
"""
Run the full launch day: validate, report, brief.
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def main():
    print("=" * 50)
    print("DEALIX LAUNCH DAY")
    print("=" * 50)

    # Step 1: Validate
    print("\n[1/3] Validating launch assets...")
    import subprocess
    result = subprocess.run(
        [sys.executable, "scripts/launch/validate_launch_assets.py"],
        capture_output=True, text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print("[ERROR] Validation failed!")
        sys.exit(1)

    # Step 2: Launch report
    print("\n[2/3] Generating launch report...")
    result = subprocess.run(
        [sys.executable, "scripts/launch/generate_launch_report.py"],
        capture_output=True, text=True
    )
    print(result.stdout)

    # Step 3: Founder brief
    print("\n[3/3] Generating founder brief...")
    result = subprocess.run(
        [sys.executable, "scripts/launch/generate_daily_founder_brief.py"],
        capture_output=True, text=True
    )
    print(result.stdout)

    print("\n" + "=" * 50)
    print("LAUNCH_DAY_COMPLETE")
    print(f"Time: {datetime.now().isoformat()}")
    print("=" * 50)


if __name__ == "__main__":
    main()
