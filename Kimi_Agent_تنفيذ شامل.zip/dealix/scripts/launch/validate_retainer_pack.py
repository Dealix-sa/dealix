#!/usr/bin/env python3
"""Validate retainer pack."""
import sys
from pathlib import Path

REQUIRED = [
    "retainers/RETAINER_CONVERSION_PLAYBOOK_AR.md",
    "retainers/MANAGED_OS_RETAINER_MODEL_AR.md",
    "retainers/MONTHLY_EXECUTIVE_REVIEW_TEMPLATE.md",
    "retainers/EXPANSION_OPPORTUNITY_MAP.md",
    "retainers/RENEWAL_EMAILS_AR.md",
    "retainers/RETAINER_SCOPE_BOUNDARIES.md",
    "retainers/RETAINER_HEALTH_SCORE.md",
]

def main():
    ok = True
    for f in REQUIRED:
        p = Path(f)
        if not p.exists():
            print(f"FAIL: {f}")
            ok = False
        else:
            print(f"PASS: {f}")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
