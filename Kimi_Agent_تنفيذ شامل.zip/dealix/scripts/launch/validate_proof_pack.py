#!/usr/bin/env python3
"""Validate proof pack."""
import sys
from pathlib import Path

REQUIRED = [
    "proof/PROOF_REPORTING_MASTER_SOP_AR.md",
    "proof/BEFORE_AFTER_TEMPLATE.md",
    "proof/WEEKLY_PROOF_REPORT_TEMPLATE.md",
    "proof/EXECUTIVE_PROOF_SUMMARY_TEMPLATE.md",
    "proof/DELIVERY_ACCEPTANCE_TEMPLATE.md",
    "proof/CLIENT_VALUE_LOG.md",
    "proof/CASE_STUDY_INTERNAL_TEMPLATE.md",
    "proof/CASE_STUDY_PUBLIC_TEMPLATE.md",
]

def main():
    ok = True
    for f in REQUIRED:
        p = Path(f)
        if not p.exists():
            print(f"FAIL: {f}")
            ok = False
        else:
            print(f"PASS: {f}")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
