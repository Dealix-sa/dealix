#!/usr/bin/env python3
"""Validate demo pack."""
import sys
from pathlib import Path

REQUIRED = [
    "demo/DEALIX_DEMO_README.md",
    "demo/COMPANY_DIAGNOSIS_DEMO_AR.md",
    "demo/REVENUE_COMMAND_ROOM_DEMO_AR.md",
    "demo/WHATSAPP_FOLLOWUP_OS_DEMO_AR.md",
    "demo/REVIEW_REPUTATION_OS_DEMO_AR.md",
    "demo/COMPANY_BRAIN_OS_DEMO_AR.md",
    "demo/AI_TRUST_COMPLIANCE_DEMO_AR.md",
    "demo/DEMO_TALK_TRACK_AR.md",
    "demo/DEMO_OBJECTION_HANDLING_AR.md",
]

def main():
    ok = True
    for f in REQUIRED:
        p = Path(f)
        if not p.exists():
            print(f"FAIL: {f}")
            ok = False
        else:
            print(f"PASS: {f}")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
