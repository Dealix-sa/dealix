#!/usr/bin/env python3
"""
Validate all launch assets exist and are non-empty.
"""

import sys
from pathlib import Path


def check(path, min_size=50):
    p = Path(path)
    if not p.exists():
        return False, "MISSING"
    if p.stat().st_size < min_size:
        return False, f"TOO_SMALL ({p.stat().st_size})"
    return True, "OK"


def main():
    print("=" * 50)
    print("LAUNCH ASSETS VALIDATION")
    print("=" * 50)

    required = {
        "Launch": [
            "launch/DEALIX_MARKET_LAUNCH_MASTER_PLAN_AR.md",
            "launch/FIRST_30_DAYS_ACTION_PLAN_AR.md",
            "launch/LAUNCH_GATES.md",
            "launch/LAUNCH_METRICS.md",
        ],
        "Founder War Room": [
            "founder/war_room/FOUNDER_SALES_WAR_ROOM_AR.md",
            "founder/war_room/DAILY_SALES_SCORECARD.md",
            "founder/war_room/CLOSING_DECISION_RULES.md",
            "founder/war_room/DEAL_REVIEW_TEMPLATE.md",
        ],
        "Prospecting": [
            "gtm/prospecting/PROSPECTING_OPERATING_MODEL_AR.md",
            "gtm/prospecting/PROSPECT_SCORING_MODEL.md",
            "gtm/prospecting/OUTREACH_APPROVAL_CHECKLIST.md",
            "gtm/prospecting/100_TARGET_DAY_TEMPLATE.csv",
        ],
        "Demo": [
            "demo/DEALIX_DEMO_README.md",
            "demo/COMPANY_DIAGNOSIS_DEMO_AR.md",
            "demo/REVENUE_COMMAND_ROOM_DEMO_AR.md",
            "demo/DEMO_TALK_TRACK_AR.md",
        ],
        "Closing": [
            "closing/CLOSING_PLAYBOOK_AR.md",
            "closing/DEAL_ACCEPTANCE_CHECKLIST.md",
            "closing/DECISION_MEETING_SCRIPT_AR.md",
            "closing/NEXT_STEP_MESSAGES_AR.md",
        ],
        "Proof": [
            "proof/PROOF_REPORTING_MASTER_SOP_AR.md",
            "proof/WEEKLY_PROOF_REPORT_TEMPLATE.md",
            "proof/BEFORE_AFTER_TEMPLATE.md",
            "proof/CASE_STUDY_PUBLIC_TEMPLATE.md",
        ],
        "Retainers": [
            "retainers/RETAINER_CONVERSION_PLAYBOOK_AR.md",
            "retainers/RETAINER_HEALTH_SCORE.md",
            "retainers/MONTHLY_EXECUTIVE_REVIEW_TEMPLATE.md",
            "retainers/RENEWAL_EMAILS_AR.md",
        ],
        "Go Live": [
            "ops/go_live/PRODUCTION_READINESS_CHECKLIST.md",
            "ops/go_live/OUTBOUND_SAFETY_CHECKLIST.md",
            "ops/go_live/INCIDENT_RESPONSE_LITE.md",
        ],
    }

    all_ok = True
    total = 0
    passed = 0

    for cat, files in required.items():
        print(f"\n[{cat}]")
        for f in files:
            total += 1
            ok, msg = check(f)
            status = "PASS" if ok else "FAIL"
            print(f"  {status}: {f} — {msg}")
            if ok:
                passed += 1
            else:
                all_ok = False

    print("\n" + "=" * 50)
    print(f"RESULT: {passed}/{total} passed")
    print("=" * 50)
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
