#!/usr/bin/env python3
"""
scripts/commercial/generate_invoice_from_contract.py

Generate an invoice from an active contract.

Usage:
    python -m scripts.commercial.generate_invoice_from_contract --contract CONTRACT_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.commercial import invoice_engine


def main():
    parser = argparse.ArgumentParser(description="Generate invoice from contract")
    parser.add_argument("--contract", required=True, help="Contract ID")
    parser.add_argument("--amount", default="5000", help="Invoice amount")
    args = parser.parse_args()

    print("=" * 50)
    print(f"GENERATE INVOICE — {args.contract}")
    print("=" * 50)

    invoice = invoice_engine.generate_from_contract(args.contract, args.amount)

    if "error" not in invoice:
        print(f"\n✅ Invoice generated:")
        print(f"   Invoice ID: {invoice.get('invoice_id', invoice.get('id', 'N/A'))}")
        print(f"   Amount:     {invoice.get('amount', args.amount)}")
    else:
        print(f"\n❌ {invoice['error']}")

    print("=" * 50)


if __name__ == "__main__":
    main()
