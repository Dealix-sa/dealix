#!/usr/bin/env python3
"""
scripts/commercial/check_proposals_pending.py

List all proposals pending approval or client response.

Usage:
    python -m scripts.commercial.check_proposals_pending
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.commercial import proposal_manager


def main():
    print("=" * 50)
    print("PENDING PROPOSALS")
    print("=" * 50)

    proposals = proposal_manager.list_pending_approvals()

    if not proposals:
        print("\nNo pending proposals.")
        print("=" * 50)
        return

    print(f"\n{len(proposals)} pending proposals:\n")
    for p in proposals:
        print(f"  [{p.get('proposal_id', '?')}] {p.get('client_id', '?')}")
        print(f"   Status: {p.get('status', '?')}")
        print(f"   Created: {p.get('created_at', 'unknown')}")
        print()

    print("=" * 50)


if __name__ == "__main__":
    main()
