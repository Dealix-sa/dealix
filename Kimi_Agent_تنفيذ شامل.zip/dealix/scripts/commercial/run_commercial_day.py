#!/usr/bin/env python3
"""
scripts/commercial/run_commercial_day.py

Daily commercial operations: check proposals, contracts, invoices, and payments.

Usage:
    python -m scripts.commercial.run_commercial_day
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.commercial import proposal_manager
from app.commercial import contract_engine
from app.commercial import invoice_engine
from app.commercial import payment_tracker
from app.commercial.pipeline import get_full_pipeline


def main():
    print("=" * 50)
    print("DEALIX — Daily Commercial Run")
    print("=" * 50)

    # 1. Check pending proposals
    print("\n[1/4] Checking proposals...")
    pending_props = proposal_manager.list_pending_approvals()
    print(f"      {len(pending_props)} proposals pending approval")
    for p in pending_props[:3]:
        print(f"        - {p.get('proposal_id', '?')}: {p.get('client_id', '?')}")

    # 2. Check pipeline
    print("\n[2/4] Pipeline summary...")
    pipe = get_full_pipeline()
    print(f"      Proposals: {pipe['proposals']['total']}")
    print(f"      Contracts: {pipe['contracts']['total']}")
    print(f"      Invoices:  {pipe['invoices']['total']}")

    # 3. Check invoices
    print("\n[3/4] Checking invoices...")
    print(f"      Total invoices: {pipe['invoices']['total']}")
    print(f"      Paid: {pipe['invoices']['paid']} | Pending: {pipe['invoices']['pending']}")

    # 4. Check payments
    print("\n[4/4] Checking payments...")
    print(f"      Total payments: {pipe['payments']['total']}")

    print("\n" + "=" * 50)
    print("Commercial day complete.")
    print("=" * 50)


if __name__ == "__main__":
    main()
