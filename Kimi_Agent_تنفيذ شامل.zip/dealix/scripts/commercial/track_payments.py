#!/usr/bin/env python3
"""
scripts/commercial/track_payments.py

Track payment status and list overdue invoices.

Usage:
    python -m scripts.commercial.track_payments
    python -m scripts.commercial.track_payments --invoice INVOICE_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.commercial import payment_tracker
from app.commercial.pipeline import get_full_pipeline


def main():
    parser = argparse.ArgumentParser(description="Track payments")
    parser.add_argument("--invoice", help="Check specific invoice")
    args = parser.parse_args()

    print("=" * 50)
    print("PAYMENT TRACKER")
    print("=" * 50)

    pipe = get_full_pipeline()

    if args.invoice:
        print(f"\nInvoice: {args.invoice}")
        print(f"Status:  (check invoices.csv for details)")
    else:
        print(f"\nTotal Payments: {pipe['payments']['total']}")
        print(f"Invoices:  {pipe['invoices']['total']} total")
        print(f"  Paid:    {pipe['invoices']['paid']}")
        print(f"  Pending: {pipe['invoices']['pending']}")

    print("=" * 50)


if __name__ == "__main__":
    main()
