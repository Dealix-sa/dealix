#!/usr/bin/env python3
"""
scripts/ops/check_env_variables.py

Check that all required environment variables are set.

Usage:
    python -m scripts.ops.check_env_variables
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

# Required variables and their purposes
REQUIRED_VARS = [
    ("APP_ENV", "Application environment"),
]

OPTIONAL_VARS = [
    ("EMAIL_SMTP_HOST", "SMTP server for email"),
    ("EMAIL_SMTP_USER", "SMTP username"),
    ("EMAIL_SMTP_PASS", "SMTP password"),
    ("WHATSAPP_API_KEY", "WhatsApp API key"),
    ("WHATSAPP_PHONE_NUMBER_ID", "WhatsApp phone number ID"),
    ("OPENAI_API_KEY", "OpenAI API key"),
    ("LINKEDIN_API_KEY", "LinkedIn API key"),
    ("SERPAPI_KEY", "SerpAPI key for research"),
]


def main():
    print("=" * 60)
    print("ENVIRONMENT VARIABLES CHECK")
    print("=" * 60)

    print("\n--- Required ---")
    all_ok = True
    for var, desc in REQUIRED_VARS:
        val = os.environ.get(var)
        if val:
            print(f"  ✅ {var}: set ({desc})")
        else:
            print(f"  ⚠️  {var}: NOT SET ({desc})")
            all_ok = False

    print("\n--- Optional (integrations) ---")
    for var, desc in OPTIONAL_VARS:
        val = os.environ.get(var)
        if val:
            display = val[:4] + "..." if len(val) > 8 else "***"
            print(f"  ✅ {var}: set ({display}) — {desc}")
        else:
            print(f"  ⬜ {var}: not set — {desc}")

    print("\n--- Safety Settings ---")
    safety_vars = [
        "EXTERNAL_SEND_ENABLED",
        "OUTBOUND_MODE",
        "OUTBOUND_REQUIRE_APPROVAL",
        "OUTBOUND_BLOCK_FAKE_CLAIMS",
        "EMAIL_SEND_ENABLED",
        "WHATSAPP_SEND_ENABLED",
    ]
    for var in safety_vars:
        val = os.environ.get(var, "(not set, using default)")
        print(f"  {var}: {val}")

    print("\n" + "=" * 60)
    if all_ok:
        print("All required variables are set.")
    else:
        print("Some required variables are missing!")
    print("=" * 60)


if __name__ == "__main__":
    main()
