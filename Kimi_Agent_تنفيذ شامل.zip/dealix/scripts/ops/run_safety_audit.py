#!/usr/bin/env python3
"""
scripts/ops/run_safety_audit.py

Run a comprehensive safety audit across all Dealix systems.
Checks all gates, suppression lists, rate limits, and configs.

Usage:
    python -m scripts.ops.run_safety_audit
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.client_os.policy_gate import PolicyGate


def main():
    print("=" * 60)
    print("DEALIX SAFETY AUDIT")
    print("=" * 60)

    findings = []

    # 1. Check external send gate
    print("\n[1] External Send Gate")
    gate = PolicyGate()
    external_ok = not gate.external_send_enabled()
    status = "✅ BLOCKED (safe)" if external_ok else "⚠️ ENABLED (risk)"
    print(f"    EXTERNAL_SEND_ENABLED: {status}")
    if not external_ok:
        findings.append("EXTERNAL_SEND_ENABLED is true — live sending active")

    # 2. Check approval requirement
    print("\n[2] Approval Gate")
    approval_ok = gate.approval_required()
    status = "✅ REQUIRED (safe)" if approval_ok else "⚠️ NOT REQUIRED (risk)"
    print(f"    OUTBOUND_REQUIRE_APPROVAL: {status}")
    if not approval_ok:
        findings.append("Outbound approval not required")

    # 3. Check fake claim blocking
    print("\n[3] Fake Claim Protection")
    fake_ok = gate.fake_claims_blocked()
    status = "✅ ENABLED (safe)" if fake_ok else "⚠️ DISABLED (risk)"
    print(f"    OUTBOUND_BLOCK_FAKE_CLAIMS: {status}")
    if not fake_ok:
        findings.append("Fake claim blocking is disabled")

    # 4. Check source URL requirement
    print("\n[4] Source URL Validation")
    url_ok = gate.source_url_required()
    status = "✅ REQUIRED (safe)" if url_ok else "⚠️ NOT REQUIRED (risk)"
    print(f"    OUTBOUND_REQUIRE_SOURCE_URL: {status}")
    if not url_ok:
        findings.append("Source URL not required for targets")

    # 5. Check channel configs
    print("\n[5] Channel Safety")
    email_enabled = os.environ.get("EMAIL_SEND_ENABLED", "false").lower() == "true"
    wa_enabled = os.environ.get("WHATSAPP_SEND_ENABLED", "false").lower() == "true"
    print(f"    Email send:    {'⚠️ ENABLED' if email_enabled else '✅ DISABLED'}")
    print(f"    WhatsApp send: {'⚠️ ENABLED' if wa_enabled else '✅ DISABLED'}")
    if email_enabled or wa_enabled:
        findings.append("One or more channels have live sending enabled")

    # 6. Check ledger directory
    print("\n[6] Ledger Storage")
    ledger_dir = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
    exists = os.path.isdir(ledger_dir)
    status = "✅ EXISTS" if exists else "⚠️ NOT FOUND"
    print(f"    Ledger dir ({ledger_dir}): {status}")
    if not exists:
        findings.append(f"Ledger directory '{ledger_dir}' not found")

    # Summary
    print("\n" + "=" * 60)
    if not findings:
        print("RESULT: ✅ ALL SAFE — No issues found")
    else:
        print(f"RESULT: ⚠️ {len(findings)} FINDING(S):")
        for f in findings:
            print(f"  - {f}")
    print("=" * 60)

    return len(findings)


if __name__ == "__main__":
    sys.exit(main())
