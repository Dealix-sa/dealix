#!/usr/bin/env python3
"""
scripts/ops/validate_all_configs.py

Validate all configuration files and modules across Dealix.

Usage:
    python -m scripts.ops.validate_all_configs
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)


def main():
    print("=" * 60)
    print("VALIDATE ALL CONFIGURATIONS")
    print("=" * 60)

    results = {"pass": 0, "fail": 0, "modules": []}

    # Test imports for all new modules
    modules_to_test = [
        ("app.ai.safe_content_filter", "AI Safe Content Filter"),
        ("app.ai.hallucination_detector", "AI Hallucination Detector"),
        ("app.ai.prompt_guard", "AI Prompt Guard"),
        ("app.ai.privacy_redactor", "AI Privacy Redactor"),
        ("app.ai.output_verifier", "AI Output Verifier"),
        ("app.ai.model_usage_logger", "AI Model Usage Logger"),
        ("app.outbound.draft_generator", "Outbound Draft Generator"),
        ("app.outbound.live_send", "Outbound Live Send"),
        ("app.outbound.rate_limiter", "Outbound Rate Limiter"),
        ("app.outbound.suppression_list", "Outbound Suppression List"),
        ("app.delivery.delivery_planner", "Delivery Planner"),
        ("app.delivery.sprint_manager", "Sprint Manager"),
        ("app.delivery.proof_reporter", "Proof Reporter"),
        ("app.commercial.proposal_manager", "Proposal Manager"),
        ("app.commercial.invoice_engine", "Invoice Engine"),
        ("app.commercial.pipeline", "Pipeline"),
        ("app.channels.email_smtp", "Email Channel"),
        ("app.channels.whatsapp_api", "WhatsApp Channel"),
        ("app.channels.linkedin_api", "LinkedIn Channel"),
    ]

    print(f"\nTesting {len(modules_to_test)} modules...\n")

    for module_name, label in modules_to_test:
        try:
            __import__(module_name)
            print(f"  ✅ {label}")
            results["pass"] += 1
            results["modules"].append({"name": label, "status": "pass"})
        except Exception as e:
            print(f"  ❌ {label}: {e}")
            results["fail"] += 1
            results["modules"].append({"name": label, "status": "fail", "error": str(e)})

    print("\n" + "=" * 60)
    print(f"RESULTS: {results['pass']} passed, {results['fail']} failed")
    print("=" * 60)

    return results["fail"]


if __name__ == "__main__":
    sys.exit(main())
