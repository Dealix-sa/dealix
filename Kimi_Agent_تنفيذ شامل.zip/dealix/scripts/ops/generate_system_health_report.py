#!/usr/bin/env python3
"""
scripts/ops/generate_system_health_report.py

Generate a comprehensive system health report.

Usage:
    python -m scripts.ops.generate_system_health_report [--output report.json]
"""

import sys
import os
import argparse
import json

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)


def main():
    parser = argparse.ArgumentParser(description="Generate health report")
    parser.add_argument("--output", help="Output JSON file")
    args = parser.parse_args()

    print("=" * 60)
    print("DEALIX SYSTEM HEALTH REPORT")
    print("=" * 60)

    from datetime import datetime

    report = {
        "system": "dealix",
        "timestamp": datetime.now().isoformat(),
        "status": "healthy",
        "components": {},
        "summary": {},
    }

    # Outbound
    try:
        from app.outbound import rate_limiter
        from app.outbound import suppression_list
        email_status = rate_limiter.can_send("email")
        components = {
            "outbound": {
                "status": "ok",
                "rate_limits": {
                    "email": f"{email_status.get('remaining', 0)}/{email_status.get('limit', 25)}",
                },
                "suppression_list_size": len(suppression_list.list_suppression()),
            }
        }
    except Exception as e:
        components = {"outbound": {"status": "error", "error": str(e)}}
        report["status"] = "degraded"

    # Delivery
    try:
        from app.delivery.delivery_status import get_all_active_projects
        projects = get_all_active_projects()
        components["delivery"] = {
            "status": "ok",
            "active_projects": len(projects),
        }
    except Exception as e:
        components["delivery"] = {"status": "error", "error": str(e)}
        report["status"] = "degraded"

    # Commercial
    try:
        from app.commercial.pipeline import get_full_pipeline
        pipe = get_full_pipeline()
        components["commercial"] = {
            "status": "ok",
            "pipeline": pipe,
        }
    except Exception as e:
        components["commercial"] = {"status": "error", "error": str(e)}
        report["status"] = "degraded"

    # AI Safety
    try:
        from app.ai.safe_content_filter import check_content_safety
        test = check_content_safety("Hello, this is a safe message.")
        components["ai_safety"] = {
            "status": "ok",
            "filter_test": test.passed,
        }
    except Exception as e:
        components["ai_safety"] = {"status": "error", "error": str(e)}

    # Safety settings
    safety = {
        "external_send_enabled": os.environ.get("EXTERNAL_SEND_ENABLED", "false").lower() == "true",
        "approval_required": os.environ.get("OUTBOUND_REQUIRE_APPROVAL", "true").lower() == "true",
        "fake_claims_blocked": os.environ.get("OUTBOUND_BLOCK_FAKE_CLAIMS", "true").lower() == "true",
        "email_send_enabled": os.environ.get("EMAIL_SEND_ENABLED", "false").lower() == "true",
        "whatsapp_send_enabled": os.environ.get("WHATSAPP_SEND_ENABLED", "false").lower() == "true",
    }
    components["safety"] = safety

    # Overall
    report["components"] = components
    report["summary"] = {
        "components_checked": len(components),
        "healthy": sum(1 for c in components.values() if isinstance(c, dict) and c.get("status") == "ok"),
        "errors": sum(1 for c in components.values() if isinstance(c, dict) and c.get("status") == "error"),
    }

    print(f"\nStatus: {report['status'].upper()}")
    print(f"Components: {report['summary']['healthy']}/{report['summary']['components_checked']} healthy")

    for name, info in components.items():
        status_icon = "✅" if info.get("status") == "ok" else "⚠️" if info.get("status") == "degraded" else "❌"
        print(f"\n  {status_icon} {name.upper()}")
        if isinstance(info, dict):
            for k, v in info.items():
                if k not in ("status", "pipeline"):
                    print(f"     {k}: {v}")

    print("\n" + "=" * 60)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print(f"Report saved to {args.output}")

    return 0 if report["status"] == "healthy" else 1


if __name__ == "__main__":
    sys.exit(main())
