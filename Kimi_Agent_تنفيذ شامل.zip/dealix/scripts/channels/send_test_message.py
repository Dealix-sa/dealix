#!/usr/bin/env python3
"""
scripts/channels/send_test_message.py

Send a test message through a channel (dry-run by default).

Usage:
    python -m scripts.channels.send_test_message --channel email --to test@example.com
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.channels.send_attempt import send


def main():
    parser = argparse.ArgumentParser(description="Send test message")
    parser.add_argument("--channel", choices=["email", "whatsapp", "linkedin"],
                        required=True, help="Channel to use")
    parser.add_argument("--to", required=True, help="Recipient address/ID")
    parser.add_argument("--subject", default="Dealix Test", help="Message subject")
    parser.add_argument("--body", default="This is a test message from Dealix.",
                        help="Message body")
    parser.add_argument("--live", action="store_true",
                        help="Attempt live send (requires LIVE_SEND_ENABLED=true)")
    args = parser.parse_args()

    print("=" * 50)
    print("SEND TEST MESSAGE")
    print("=" * 50)
    print(f"Channel: {args.channel}")
    print(f"To:      {args.to}")
    print(f"Subject: {args.subject}")
    print(f"Live:    {args.live}")
    print("-" * 50)

    result = send(args.channel, args.to, args.subject, args.body)

    print(f"\nResult: {result.get('status', 'unknown')}")
    if result.get("reason"):
        print(f"Reason: {result['reason']}")
    print("=" * 50)


if __name__ == "__main__":
    main()
