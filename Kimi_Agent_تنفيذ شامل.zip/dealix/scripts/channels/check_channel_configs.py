#!/usr/bin/env python3
"""
scripts/channels/check_channel_configs.py

Verify all channel configurations are valid and complete.

Usage:
    python -m scripts.channels.check_channel_configs
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.channels import email_smtp, whatsapp_api, linkedin_api


def main():
    print("=" * 50)
    print("CHANNEL CONFIGURATION CHECK")
    print("=" * 50)

    checks = [
        ("Email (SMTP)", email_smtp.check_config),
        ("WhatsApp", whatsapp_api.check_config),
        ("LinkedIn", linkedin_api.check_config),
    ]

    all_ok = True
    for name, check_fn in checks:
        config = check_fn()
        config_ok = config.get("configured", False) if isinstance(config, dict) else bool(config)
        status = "OK" if config_ok else "MISSING/DEFAULT"
        icon = "✓" if config_ok else "○"
        print(f"  [{icon}] {name:20s} — {status}")

    print("\n" + "=" * 50)
    print("Note: All channels default to dry-run for safety.")
    print("=" * 50)


if __name__ == "__main__":
    main()
