#!/usr/bin/env python3
"""
scripts/channels/handle_callbacks.py

Handle incoming callbacks/webhooks from channels.
Processes delivery receipts, bounces, and opt-out callbacks.

Usage:
    python -m scripts.channels.handle_callbacks --channel email --payload '{"event":"delivered"}'
"""

import sys
import os
import argparse
import json

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.channels import callback_handler


def main():
    parser = argparse.ArgumentParser(description="Handle channel callbacks")
    parser.add_argument("--channel", choices=["email", "whatsapp", "linkedin"],
                        required=True, help="Channel source")
    parser.add_argument("--payload", required=True, help="JSON payload from callback")
    parser.add_argument("--file", help="Read payload from file instead of --payload")
    args = parser.parse_args()

    payload = args.payload
    if args.file:
        with open(args.file, "r") as f:
            payload = f.read()

    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        print("ERROR: Invalid JSON payload")
        return

    print("=" * 50)
    print(f"HANDLE CALLBACK — {args.channel.upper()}")
    print("=" * 50)

    result = callback_handler.process(args.channel, data)
    print(f"\nStatus: {result.get('status', 'unknown')}")
    print("=" * 50)


if __name__ == "__main__":
    main()
