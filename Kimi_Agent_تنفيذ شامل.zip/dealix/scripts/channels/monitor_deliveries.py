#!/usr/bin/env python3
"""
scripts/channels/monitor_deliveries.py

Monitor delivery status across all channels.

Usage:
    python -m scripts.channels.monitor_deliveries
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import rate_limiter
from app.channels import email_smtp, whatsapp_api


def main():
    print("=" * 50)
    print("DELIVERY MONITOR")
    print("=" * 50)

    channels = ["email", "whatsapp", "linkedin"]
    for channel in channels:
        status = rate_limiter.can_send(channel)
        health = "healthy" if status.get("allowed") else "at_limit"
        icon = "🟢" if health == "healthy" else "🟡"
        print(f"\n{icon} {channel.upper()}")
        print(f"   Health:  {health}")
        print(f"   Remaining: {status.get('remaining', 0)}/{status.get('limit', 25)}")

    # Channel configs
    print("\n--- Channel Configs ---")
    email_cfg = email_smtp.check_config()
    wa_cfg = whatsapp_api.check_config()
    print(f"  Email:    {'✅ Configured' if email_cfg.get('configured') else '○ Default'}")
    print(f"  WhatsApp: {'✅ Configured' if wa_cfg.get('configured') else '○ Default'}")

    print("\n" + "=" * 50)


if __name__ == "__main__":
    main()
