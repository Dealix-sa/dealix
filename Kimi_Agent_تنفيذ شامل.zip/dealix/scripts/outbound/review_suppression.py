#!/usr/bin/env python3
"""
scripts/outbound/review_suppression.py

Review and manage the suppression list.

Usage:
    python -m scripts.outbound.review_suppression
    python -m scripts.outbound.review_suppression --add COMPANY_ID [--reason REASON]
    python -m scripts.outbound.review_suppression --remove COMPANY_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import suppression_list


def main():
    parser = argparse.ArgumentParser(description="Manage suppression list")
    parser.add_argument("--add", help="Add company to suppression list")
    parser.add_argument("--remove", help="Remove company from suppression list")
    parser.add_argument("--reason", default="opt_out_request", help="Reason for suppression")
    parser.add_argument("--list", action="store_true", help="List all suppressed contacts")
    args = parser.parse_args()

    if args.add:
        suppression_list.add_to_suppression(args.add, reason=args.reason)
        print(f"Added {args.add} to suppression list (reason: {args.reason})")
        return

    if args.remove:
        print(f"Note: Manual removal not implemented. Edit suppression_list.csv directly.")
        return

    if args.list or not (args.add or args.remove):
        contacts = suppression_list.list_suppression()
        print(f"\nSUPPRESSION LIST ({len(contacts)} contacts):")
        for c in contacts:
            print(f"  {c.get('company_id', '?')} — {c.get('reason', 'unknown')} "
                  f"({c.get('created_at', '?')})")


if __name__ == "__main__":
    main()
