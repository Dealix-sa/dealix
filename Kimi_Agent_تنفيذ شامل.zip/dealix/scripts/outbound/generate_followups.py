#!/usr/bin/env python3
"""
scripts/outbound/generate_followups.py

Generate follow-up drafts for prospects that haven't responded.

Usage:
    python -m scripts.outbound.generate_followups
    python -m scripts.outbound.generate_followups --days-since 7
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import draft_generator


def main():
    parser = argparse.ArgumentParser(description="Generate follow-up drafts")
    parser.add_argument("--days-since", type=int, default=7, help="Days since last contact")
    args = parser.parse_args()

    print("=" * 50)
    print(f"GENERATE FOLLOW-UPS (>{args.days_since} days)")
    print("=" * 50)

    followups = draft_generator.generate_all_pending()
    print(f"\nGenerated {len(followups)} follow-up drafts")
    for draft in followups:
        print(f"  [{draft.get('draft_id', '?')}] -> {draft.get('contact_id', '?')} "
              f"({draft.get('channel', '?')})")

    print("\n" + "=" * 50)


if __name__ == "__main__":
    main()
