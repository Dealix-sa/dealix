#!/usr/bin/env python3
"""
scripts/outbound/run_outbound_day.py

Daily outbound execution script.
Runs the full outbound pipeline: generate drafts, queue messages,
check approvals, and attempt sends (dry-run by default).

Usage:
    python -m scripts.outbound.run_outbound_day
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import draft_generator
from app.outbound import message_queue
from app.outbound.approval_gate import ApprovalGate, get_gate
from app.outbound.live_send import execute_send
from app.outbound import rate_limiter
from app.outbound import suppression_list
from app.outbound import outbound_logger
from app.ai.safe_content_filter import check_content_safety


def main():
    print("=" * 50)
    print("DEALIX — Daily Outbound Run")
    print("=" * 50)

    # 1. Generate drafts for pending prospects
    print("\n[1/4] Generating drafts...")
    drafts = draft_generator.generate_all_pending()
    print(f"      Found/Generated {len(drafts)} drafts")

    # 2. Safety-check and queue drafts
    print("\n[2/4] Safety-checking drafts...")
    safe_drafts = 0
    for draft in drafts:
        body = draft.get("body", "")
        safety = check_content_safety(body, context="outbound")
        if safety.passed:
            safe_drafts += 1
        else:
            print(f"      BLOCKED (safety): {draft.get('draft_id', '?')}")
    print(f"      {safe_drafts} drafts passed safety check")

    # 3. Check approvals
    print("\n[3/4] Checking approvals...")
    gate = get_gate()
    approved = 0
    pending = 0
    for draft in drafts:
        draft_id = draft.get("draft_id", "")
        if draft_id:
            can, reason = gate.can_send(draft_id)
            if can:
                approved += 1
            else:
                pending += 1
    print(f"      Approved: {approved} | Pending: {pending}")

    # 4. Attempt sends (will be dry-run unless LIVE_SEND_ENABLED=true)
    print("\n[4/4] Attempting sends (dry-run mode)...")
    sent_count = 0
    dry_run_count = 0
    blocked_count = 0

    for draft in drafts:
        draft_id = draft.get("draft_id", "")
        can, reason = gate.can_send(draft_id)
        if not can:
            continue

        channel = draft.get("channel", "email")
        rate_status = rate_limiter.can_send(channel)
        if not rate_status.get("allowed", False):
            print(f"      BLOCKED (rate limit): {draft_id} [{channel}]")
            continue

        result = execute_send(
            draft_id=draft_id,
            msg_id=draft.get("msg_id", ""),
            company_id=draft.get("company_id", ""),
            contact_id=draft.get("contact_id", ""),
            channel=channel,
            body_path=draft.get("body_path", ""),
            actor="system_batch",
        )

        if result.get("status") == "sent":
            sent_count += 1
        elif result.get("status") == "dry_run":
            dry_run_count += 1
        else:
            blocked_count += 1

    print(f"      Sent: {sent_count}, Dry-run: {dry_run_count}, Blocked: {blocked_count}")

    print("\n" + "=" * 50)
    print("Outbound day complete.")
    print("=" * 50)


if __name__ == "__main__":
    main()
