#!/usr/bin/env python3
"""
scripts/outbound/validate_templates.py

Validate all outbound message templates.
Checks for safety, required placeholders, and compliance.

Usage:
    python -m scripts.outbound.validate_templates
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.channels.template_manager import list_approved_templates, create_template
from app.ai.safe_content_filter import check_content_safety


def main():
    print("=" * 50)
    print("VALIDATE OUTBOUND TEMPLATES")
    print("=" * 50)

    templates = list_approved_templates()
    print(f"\nFound {len(templates)} approved templates")
    passed = 0
    failed = 0

    for tmpl in templates:
        name = tmpl.get("template_name", "?") if isinstance(tmpl, dict) else str(tmpl)
        content = tmpl.get("body", "")

        issues = []

        # Check required placeholders
        required = ["{{company}}", "{{contact_name}}"]
        for ph in required:
            if ph not in content:
                issues.append(f"missing {ph}")

        # Check safety
        safety = check_content_safety(content, context="outbound")
        if not safety.passed:
            issues.append(f"safety: {safety.risk_level.value}")

        # Check length
        if len(content) < 50:
            issues.append("too short (<50 chars)")
        if len(content) > 5000:
            issues.append("too long (>5000 chars)")

        if issues:
            failed += 1
            print(f"  [FAIL] {name}: {', '.join(issues)}")
        else:
            passed += 1
            print(f"  [PASS] {name}")

    print(f"\n{passed} passed, {failed} failed out of {len(templates)}")
    print("=" * 50)


if __name__ == "__main__":
    main()
