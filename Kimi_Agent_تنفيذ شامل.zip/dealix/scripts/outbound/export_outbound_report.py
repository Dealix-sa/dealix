#!/usr/bin/env python3
"""
scripts/outbound/export_outbound_report.py

Export outbound activity report for review.

Usage:
    python -m scripts.outbound.export_outbound_report
    python -m scripts.outbound.export_outbound_report --output report.csv
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import outbound_logger


def main():
    parser = argparse.ArgumentParser(description="Export outbound report")
    parser.add_argument("--output", default="outbound_report.csv", help="Output file path")
    args = parser.parse_args()

    print("=" * 50)
    print("EXPORT OUTBOUND REPORT")
    print("=" * 50)

    logs = outbound_logger.get_logs()
    print(f"\nExporting {len(logs)} log entries to {args.output}...")

    import csv
    if logs:
        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=logs[0].keys())
            writer.writeheader()
            writer.writerows(logs)

    print(f"Done. Report saved to {args.output}")
    print("=" * 50)


if __name__ == "__main__":
    main()
