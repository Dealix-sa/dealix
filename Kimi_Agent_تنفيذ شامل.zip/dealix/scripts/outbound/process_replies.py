#!/usr/bin/env python3
"""
scripts/outbound/process_replies.py

Process incoming replies from outbound messages.
Categorizes replies and generates follow-up tasks.

Usage:
    python -m scripts.outbound.process_replies
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import reply_processor


def main():
    print("=" * 50)
    print("PROCESS INBOUND REPLIES")
    print("=" * 50)

    # Process all pending replies from ledger
    replies = reply_processor.get_pending_replies()

    by_category = {}
    for r in replies:
        cat = r.get("category", "unknown")
        by_category[cat] = by_category.get(cat, 0) + 1

    print(f"\n{len(replies)} replies in system:")
    for cat, count in sorted(by_category.items()):
        print(f"  {cat}: {count}")

    interested = [r for r in replies if r.get("category") == "interested"]
    if interested:
        print(f"\n--- INTERESTED ({len(interested)}) ---")
        for r in interested[:5]:
            print(f"  [{r.get('reply_id', '?')}] {r.get('reply_content', '')[:80]}...")

    print("\n" + "=" * 50)


if __name__ == "__main__":
    main()
