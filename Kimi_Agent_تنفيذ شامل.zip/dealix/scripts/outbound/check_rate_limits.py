#!/usr/bin/env python3
"""
scripts/outbound/check_rate_limits.py

Check current rate limit status for all channels.

Usage:
    python -m scripts.outbound.check_rate_limits
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound import rate_limiter


def main():
    print("=" * 50)
    print("RATE LIMIT STATUS")
    print("=" * 50)

    channels = ["email", "whatsapp", "linkedin"]
    for channel in channels:
        status = rate_limiter.can_send(channel)
        remaining = status.get("remaining", 0)
        limit = status.get("limit", 25)
        used = limit - remaining
        pct = (used / limit * 100) if limit else 0
        bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
        allowed = "✓" if status.get("allowed") else "✗"
        print(f"  {allowed} {channel:10s} [{bar}] {used}/{limit} ({pct:.0f}%)")

    print("=" * 50)


if __name__ == "__main__":
    main()
