#!/usr/bin/env python3
"""
scripts/outbound/approve_and_send.py

Manual approval and send script.
Allows human operator to approve queued messages and trigger sends.

Usage:
    python -m scripts.outbound.approve_and_send --msg-id MSG_ID
    python -m scripts.outbound.approve_and_send --approve-all
    python -m scripts.outbound.approve_and_send --list-pending
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.outbound.approval_gate import ApprovalGate, get_gate
from app.outbound.live_send import execute_send
from app.outbound import rate_limiter


def main():
    parser = argparse.ArgumentParser(description="Approve and send outbound messages")
    parser.add_argument("--msg-id", help="Specific message ID to approve")
    parser.add_argument("--approve-all", action="store_true", help="Approve all pending messages")
    parser.add_argument("--list-pending", action="store_true", help="List pending messages")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without sending")
    args = parser.parse_args()

    gate = get_gate()

    if args.list_pending:
        print("\nPending messages (drafts with status != approved):")
        # List from drafts ledger
        import csv
        path = os.path.join(os.environ.get("DEALIX_LEDGER_DIR", "ledgers"), "outbound_drafts.csv")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8", newline="") as f:
                for row in csv.DictReader(f):
                    if row.get("status") in ("draft", "pending"):
                        print(f"  [{row.get('draft_id', '?')}] {row.get('channel', '?')} -> {row.get('contact_id', '?')}")
        return

    if args.msg_id:
        if args.dry_run:
            print(f"[DRY RUN] Would approve and attempt send: {args.msg_id}")
        else:
            can, reason = gate.can_send(args.msg_id)
            print(f"Approval check: {can} — {reason}")


if __name__ == "__main__":
    main()
