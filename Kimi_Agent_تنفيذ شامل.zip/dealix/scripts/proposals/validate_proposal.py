#!/usr/bin/env python3
"""
Validate a proposal before it goes to client.
Checks for fake claims, required sections, and governance.
"""

import sys
from pathlib import Path


def validate_proposal(proposal_path):
    """Validate a proposal file."""
    path = Path(proposal_path)
    if not path.exists():
        return False, "File not found"
    
    content = path.read_text(encoding="utf-8")
    
    # Check for fake claims
    blocked_phrases = [
        "نضمن",
        "نتائج مضمونة",
        "أرباح مضمونة",
        "100% نجاح",
        "نضاعف",
        "ضعف",
        "guaranteed",
        "guarantee",
    ]
    
    violations = []
    for phrase in blocked_phrases:
        if phrase.lower() in content.lower():
            violations.append(phrase)
    
    if violations:
        return False, f"Blocked phrases found: {violations}"
    
    # Check required sections
    required_sections = [
        "Governance",
        "Investment",
        "Next Steps",
    ]
    
    missing = []
    for section in required_sections:
        if section not in content:
            missing.append(section)
    
    if missing:
        return False, f"Missing sections: {missing}"
    
    return True, "Proposal valid"


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_proposal.py <proposal_path>")
        sys.exit(1)
    
    proposal_path = sys.argv[1]
    valid, msg = validate_proposal(proposal_path)
    
    status = "PASS" if valid else "FAIL"
    print(f"Proposal Validation: {status}")
    print(f"Message: {msg}")
    
    sys.exit(0 if valid else 1)


if __name__ == "__main__":
    main()
