#!/usr/bin/env python3
"""
Generate founder actions list based on current state.
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.storage import get_storage


def main():
    print("=" * 50)
    print("FOUNDER ACTIONS")
    print("=" * 50)
    
    storage = get_storage()
    
    companies = storage.read_all("companies")
    outreach = storage.read_all("outreach_log")
    intakes = storage.read_all("client_intakes")
    projects = storage.read_all("projects")
    
    verified = [c for c in companies if c.get("verification_status") == "verified"]
    drafts = [m for m in outreach if m.get("approval_status") == "draft"]
    pending_intakes = [i for i in intakes if i.get("intake_status") == "pending"]
    active_projects = [p for p in projects if p.get("status") == "active"]
    
    print(f"\nContext:")
    print(f"  Verified companies: {len(verified)}")
    print(f"  Pending drafts: {len(drafts)}")
    print(f"  Pending intakes: {len(pending_intakes)}")
    print(f"  Active projects: {len(active_projects)}")
    
    print(f"\nTop 10 Founder Actions:")
    
    actions = []
    if drafts:
        actions.append(("HIGH", f"Review {len(drafts)} outreach drafts pending approval"))
    if pending_intakes:
        actions.append(("HIGH", f"Follow up on {len(pending_intakes)} pending intakes"))
    if active_projects:
        actions.append(("MEDIUM", f"Check status of {len(active_projects)} active projects"))
    if len(verified) < 10:
        actions.append(("MEDIUM", "Research more target companies"))
    
    actions.extend([
        ("MEDIUM", "Review trust gates and compliance"),
        ("LOW", "Update sector priority map"),
        ("LOW", "Plan content for next week"),
        ("LOW", "Check partner pipeline"),
        ("LOW", "Update founder decision log"),
    ])
    
    for i, (priority, action) in enumerate(actions[:10], 1):
        print(f"  {i}. [{priority}] {action}")
    
    # Save to reports
    report_dir = Path("reports/business")
    report_dir.mkdir(parents=True, exist_ok=True)
    
    report_path = report_dir / "latest_founder_actions.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"# Founder Actions\nGenerated: {datetime.now().isoformat()}\n\n")
        for i, (priority, action) in enumerate(actions[:10], 1):
            f.write(f"{i}. [{priority}] {action}\n")
    
    print(f"\nSaved: {report_path}")
    print("\n" + "=" * 50)
    print("FOUNDER_ACTIONS_COMPLETE")
    print("=" * 50)


if __name__ == "__main__":
    main()
