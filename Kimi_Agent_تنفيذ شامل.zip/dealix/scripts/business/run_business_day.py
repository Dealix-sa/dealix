#!/usr/bin/env python3
"""
Run the business day — generate status report and founder actions.
"""

import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.client_os.storage import get_storage


def generate_business_status():
    storage = get_storage()
    
    companies = storage.read_all("companies")
    outreach = storage.read_all("outreach_log")
    intakes = storage.read_all("client_intakes")
    projects = storage.read_all("projects")
    proposals = storage.read_all("proposals")
    
    verified = [c for c in companies if c.get("verification_status") == "verified"]
    drafts = [m for m in outreach if m.get("approval_status") == "draft"]
    pending_intakes = [i for i in intakes if i.get("intake_status") == "pending"]
    active_projects = [p for p in projects if p.get("status") == "active"]
    
    report = f"""# Dealix Business Status
Generated: {datetime.now().isoformat()}

## Pipeline
- Total companies: {len(companies)}
- Verified: {len(verified)}
- Outreach drafts pending: {len(drafts)}
- Intakes: {len(intakes)} (pending: {len(pending_intakes)})
- Active projects: {len(active_projects)}
- Proposals: {len(proposals)}

## Products
- Revenue Command Room OS: Available
- WhatsApp Follow-up OS: Available
- Review & Reputation OS: Available
- Operations & Delivery OS: Available
- AI Trust & Compliance OS: Available
- Controlled Live Outbound OS: Available
- Company Diagnosis Sprint: Available
- Company Brain OS: Secondary service
- Custom Enterprise Systems: Available
- Strategic Partnership OS: Available

## Trust Status
- No external send by default: ENABLED
- Approval gates: ACTIVE
- Fake claims blocking: ACTIVE
- PDPL awareness: ACTIVE

## Founder Actions (Next 10)
"""
    
    actions = []
    if drafts:
        actions.append(f"1. Review {len(drafts)} outreach drafts pending approval")
    if pending_intakes:
        actions.append(f"2. Follow up on {len(pending_intakes)} pending intakes")
    if not active_projects and intakes:
        actions.append("3. Start project for completed intake")
    if len(verified) < 10:
        actions.append("4. Research more targets")
    actions.append("5. Check trust gates")
    actions.append("6. Update sector priority map")
    actions.append("7. Review weekly proof reports")
    actions.append("8. Plan next diagnostic sprint")
    actions.append("9. Check partner pipeline")
    actions.append("10. Update founder decision log")
    
    for action in actions[:10]:
        report += f"{action}\n"
    
    return report


def main():
    print("=" * 50)
    print("DEALIX BUSINESS DAY")
    print("=" * 50)
    
    report = generate_business_status()
    
    report_dir = Path("reports/business")
    report_dir.mkdir(parents=True, exist_ok=True)
    
    report_path = report_dir / "latest_business_status.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)
    
    print(f"\nReport saved: {report_path}")
    print("\n" + "=" * 50)
    print("BUSINESS_DAY_COMPLETE")
    print("=" * 50)


if __name__ == "__main__":
    main()
