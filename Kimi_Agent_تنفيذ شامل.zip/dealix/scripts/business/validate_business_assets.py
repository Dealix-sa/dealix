#!/usr/bin/env python3
"""
Validate all business assets exist and are non-empty.
"""

import sys
from pathlib import Path


def check_file(path, min_size=100):
    p = Path(path)
    if not p.exists():
        return False, "MISSING"
    if p.stat().st_size < min_size:
        return False, f"TOO_SMALL ({p.stat().st_size} bytes)"
    return True, "OK"


def main():
    print("=" * 50)
    print("BUSINESS ASSETS VALIDATION")
    print("=" * 50)

    required_files = {
        "Strategy": [
            "business/strategy/DEALIX_POSITIONING_AR.md",
            "business/strategy/DEALIX_POSITIONING_EN.md",
            "business/strategy/ICP_STRATEGY_AR.md",
            "business/strategy/COMPETITIVE_POSITIONING_AR.md",
        ],
        "Products": [
            "business/products/PRODUCT_CATALOG_AR.md",
            "business/products/PRODUCT_CATALOG_EN.md",
            "business/products/COMPANY_BRAIN_OS.md",
        ],
        "Offers": [
            "business/offers/OFFER_STACK_AR.md",
        ],
        "Pricing": [
            "business/pricing/PRICING_STRATEGY_AR.md",
            "business/pricing/UNIT_ECONOMICS.md",
        ],
        "GTM": [
            "business/gtm/GTM_MASTER_PLAN_AR.md",
            "business/gtm/SECTOR_PRIORITY_MAP_AR.md",
        ],
        "Sales": [
            "sales/README.md",
            "sales/SECTOR_PITCHES_AR.md",
        ],
        "Proposals": [
            "proposals/_templates/EXECUTIVE_PROPOSAL_AR.md",
            "proposals/_templates/DIAGNOSTIC_SPRINT_PROPOSAL_AR.md",
        ],
        "Trust": [
            "trust/README.md",
            "trust/PDPL_READINESS_CHECKLIST_AR.md",
            "trust/NO_FAKE_CLAIMS_POLICY.md",
            "trust/AI_USAGE_POLICY_AR.md",
        ],
        "Founder": [
            "founder/FOUNDER_DAILY_OS_AR.md",
            "founder/FOUNDER_30_60_90_PLAN_AR.md",
        ],
        "Content": [
            "content/CONTENT_STRATEGY_AR.md",
        ],
        "Partnerships": [
            "partnerships/PARTNERSHIP_STRATEGY_AR.md",
        ],
        "Research": [
            "research/SAUDI_AI_MARKET_NOTES.md",
        ],
    }

    all_ok = True
    total = 0
    passed = 0

    for category, files in required_files.items():
        print(f"\n[{category}]")
        for f in files:
            total += 1
            ok, msg = check_file(f)
            status = "PASS" if ok else "FAIL"
            print(f"  {status}: {f} — {msg}")
            if ok:
                passed += 1
            else:
                all_ok = False

    print("\n" + "=" * 50)
    print(f"RESULT: {passed}/{total} passed")
    print("=" * 50)

    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
