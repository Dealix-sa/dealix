#!/usr/bin/env python3
"""
scripts/delivery/run_delivery_day.py

Daily delivery operations script.
Runs sprint checks, generates proof reports, processes UAT,
and checks retainer opportunities.

Usage:
    python -m scripts.delivery.run_delivery_day
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery import sprint_manager
from app.delivery.delivery_status import get_all_active_projects, get_project_status
from app.delivery import proof_reporter
from app.delivery import uat_engine
from app.delivery import retainer_converter
from app.delivery import delivery_logger


def main():
    print("=" * 50)
    print("DEALIX — Daily Delivery Run")
    print("=" * 50)

    # 1. Check active projects
    print("\n[1/4] Checking active projects...")
    active_projects = get_all_active_projects()
    print(f"      {len(active_projects)} active projects")
    for p in active_projects[:5]:
        print(f"        - {p.get('project_name', '?')} ({p.get('status', '?')})")

    # 2. Check sprints
    print("\n[2/4] Checking sprints...")
    all_sprints = []
    for p in active_projects:
        sprints = sprint_manager.get_sprints(p.get("project_id", ""))
        all_sprints.extend(sprints)
    print(f"      {len(all_sprints)} active sprints")

    # 3. Check delivery health
    print("\n[3/4] Checking delivery health...")
    total_tasks = 0
    for p in active_projects:
        status = get_project_status(p.get("project_id", ""))
        tasks = status.get("tasks", {})
        total_tasks += tasks.get("total", 0)
    print(f"      {total_tasks} total tasks across {len(active_projects)} projects")

    # 4. Check retainer opportunities
    print("\n[4/4] Checking retainer opportunities...")
    ops = retainer_converter.identify_opportunities()
    print(f"      {len(ops)} retainer opportunities identified")

    print("\n" + "=" * 50)
    print("Delivery day complete.")
    print("=" * 50)


if __name__ == "__main__":
    main()
