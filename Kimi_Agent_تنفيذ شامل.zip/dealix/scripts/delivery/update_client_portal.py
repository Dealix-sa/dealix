#!/usr/bin/env python3
"""
scripts/delivery/update_client_portal.py

Update all client portals with latest project status.

Usage:
    python -m scripts.delivery.update_client_portal
    python -m scripts.delivery.update_client_portal --project PROJECT_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery.delivery_status import get_all_active_projects, get_project_status


def main():
    parser = argparse.ArgumentParser(description="Update client portal")
    parser.add_argument("--project", help="Update specific project")
    args = parser.parse_args()

    print("=" * 50)
    print("CLIENT PORTAL STATUS")
    print("=" * 50)

    if args.project:
        status = get_project_status(args.project)
        print(f"\nProject: {args.project}")
        print(f"Status:  {status.get('status', status.get('error', '?'))}")
    else:
        projects = get_all_active_projects()
        print(f"\n{len(projects)} active projects:\n")
        for p in projects:
            print(f"  [{p.get('project_id', '?')}] {p.get('project_name', '?')} — {p.get('current_phase', '?')}")

    print("=" * 50)


if __name__ == "__main__":
    main()
