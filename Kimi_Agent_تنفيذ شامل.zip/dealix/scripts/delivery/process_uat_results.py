#!/usr/bin/env python3
"""
scripts/delivery/process_uat_results.py

Process UAT feedback and update project status.

Usage:
    python -m scripts.delivery.process_uat_results
    python -m scripts.delivery.process_uat_results --project PROJECT_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery import uat_engine


def main():
    parser = argparse.ArgumentParser(description="Process UAT results")
    parser.add_argument("--project", help="Process specific project")
    args = parser.parse_args()

    print("=" * 50)
    print("UAT RESULTS")
    print("=" * 50)

    # List UAT entries
    all_uat = uat_engine.list_all()
    if args.project:
        all_uat = [u for u in all_uat if u.get("project_id") == args.project]

    passed = sum(1 for u in all_uat if u.get("status") == "passed")
    failed = sum(1 for u in all_uat if u.get("status") == "failed")
    pending = sum(1 for u in all_uat if u.get("status") == "pending")

    print(f"\n{len(all_uat)} UAT items:")
    print(f"  ✅ Passed:  {passed}")
    print(f"  ❌ Failed:  {failed}")
    print(f"  ⏳ Pending: {pending}")
    print("=" * 50)


if __name__ == "__main__":
    main()
