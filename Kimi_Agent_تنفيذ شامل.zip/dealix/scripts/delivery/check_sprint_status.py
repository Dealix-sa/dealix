#!/usr/bin/env python3
"""
scripts/delivery/check_sprint_status.py

Check status of all active sprints and flag blockers.

Usage:
    python -m scripts.delivery.check_sprint_status
    python -m scripts.delivery.check_sprint_status --project PROJECT_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery import sprint_manager


def main():
    parser = argparse.ArgumentParser(description="Check sprint status")
    parser.add_argument("--project", help="Check specific project")
    args = parser.parse_args()

    print("=" * 50)
    print("SPRINT STATUS")
    print("=" * 50)

    if args.project:
        sprints = sprint_manager.get_sprints(args.project)
        print(f"\n{len(sprints)} sprints for {args.project}:\n")
        for sp in sprints:
            _print_sprint(sp)
            print()
    else:
        # List all sprints from all projects
        from app.delivery.delivery_status import get_all_active_projects
        projects = get_all_active_projects()
        total = 0
        for p in projects:
            sprints = sprint_manager.get_sprints(p.get("project_id", ""))
            total += len(sprints)
        print(f"\n{total} total sprints across {len(projects)} active projects")

    print("=" * 50)


def _print_sprint(sp):
    print(f"  Sprint #{sp.get('sprint_number', '?')}: {sp.get('goal', '?')}")
    print(f"   Status:  {sp.get('status', '?')}")
    print(f"   Period:  {sp.get('start_date', '?')} → {sp.get('end_date', '?')}")


if __name__ == "__main__":
    main()
