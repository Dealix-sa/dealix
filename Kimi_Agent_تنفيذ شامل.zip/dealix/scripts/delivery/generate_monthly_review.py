#!/usr/bin/env python3
"""
scripts/delivery/generate_monthly_review.py

Generate monthly executive review of all deliveries.

Usage:
    python -m scripts.delivery.generate_monthly_review [--month YYYY-MM]
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery.delivery_status import get_all_active_projects


def main():
    parser = argparse.ArgumentParser(description="Generate monthly review")
    parser.add_argument("--month", help="Month in YYYY-MM format")
    parser.add_argument("--output", help="Output file path")
    args = parser.parse_args()

    print("=" * 50)
    print("DELIVERY SUMMARY")
    print("=" * 50)

    projects = get_all_active_projects()
    all_projects_path = os.path.join(os.environ.get("DEALIX_LEDGER_DIR", "ledgers"), "projects.csv")
    total_projects = 0
    if os.path.exists(all_projects_path):
        import csv
        with open(all_projects_path, "r", encoding="utf-8", newline="") as f:
            total_projects = len(list(csv.DictReader(f)))

    completed = total_projects - len(projects)

    print(f"\nPeriod:    {args.month or 'current'}")
    print(f"Total:     {total_projects} projects")
    print(f"Completed: {completed}")
    print(f"Active:    {len(projects)}")

    if projects:
        print(f"\n--- Active Projects ---")
        for p in projects[:10]:
            print(f"  [{p.get('project_id', '?')}] {p.get('project_name', '?')}")

    if args.output:
        import json
        report = {
            "month": args.month or "current",
            "total_projects": total_projects,
            "completed": completed,
            "active": len(projects),
        }
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        print(f"\nSaved to {args.output}")

    print("=" * 50)


if __name__ == "__main__":
    main()
