#!/usr/bin/env python3
"""
scripts/delivery/generate_proof_report.py

Generate a proof-of-value report for a specific project.

Usage:
    python -m scripts.delivery.generate_proof_report --project PROJECT_ID
"""

import sys
import os
import argparse

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery.delivery_status import get_project_status


def main():
    parser = argparse.ArgumentParser(description="Generate proof report")
    parser.add_argument("--project", required=True, help="Project ID")
    parser.add_argument("--output", help="Output file path")
    args = parser.parse_args()

    print("=" * 50)
    print(f"PROJECT STATUS — {args.project}")
    print("=" * 50)

    status = get_project_status(args.project)

    if "error" in status:
        print(f"\nError: {status['error']}")
        return

    print(f"\nProject:   {args.project}")
    print(f"Phase:     {status.get('phase', '?')}")
    print(f"Status:    {status.get('status', '?')}")
    print(f"Progress:  {status.get('progress_pct', 0)}%")

    tasks = status.get("tasks", {})
    print(f"\nTasks: {tasks.get('done', 0)}/{tasks.get('total', 0)} done")
    print(f"  In progress: {tasks.get('in_progress', 0)}")
    print(f"  Pending:     {tasks.get('pending', 0)}")

    uat = status.get("uat", {})
    if uat.get("total", 0) > 0:
        print(f"\nUAT: {uat.get('passed', 0)}/{uat.get('total', 0)} passed")

    if args.output:
        import json
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(status, f, ensure_ascii=False, indent=2)
        print(f"\nSaved to {args.output}")

    print("=" * 50)


if __name__ == "__main__":
    main()
