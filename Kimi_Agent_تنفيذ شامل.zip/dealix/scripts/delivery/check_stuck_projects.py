#!/usr/bin/env python3
"""
scripts/delivery/check_stuck_projects.py

Identify projects that are stuck or overdue and need escalation.

Usage:
    python -m scripts.delivery.check_stuck_projects
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery.escalation_tracker import check_stuck_projects, check_overdue_projects, generate_alert_report


def main():
    print("=" * 50)
    print("STUCK PROJECTS CHECK")
    print("=" * 50)

    stuck = check_stuck_projects()
    overdue = check_overdue_projects()

    if not stuck and not overdue:
        print("\n✅ No stuck or overdue projects found!")
        print("=" * 50)
        return

    if stuck:
        print(f"\n⚠️ {len(stuck)} stuck tasks:")
        for task in stuck[:10]:
            print(f"  [{task.get('task_id', '?')}] {task.get('title', '?')}")

    if overdue:
        print(f"\n⚠️ {len(overdue)} overdue projects:")
        for proj in overdue[:10]:
            print(f"  [{proj.get('project_id', '?')}] {proj.get('project_name', '?')}")

    print("\n" + "=" * 50)


if __name__ == "__main__":
    main()
