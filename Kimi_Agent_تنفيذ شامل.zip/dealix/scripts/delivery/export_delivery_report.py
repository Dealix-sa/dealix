#!/usr/bin/env python3
"""
scripts/delivery/export_delivery_report.py

Export comprehensive delivery report.

Usage:
    python -m scripts.delivery.export_delivery_report [--output report.csv]
"""

import sys
import os
import argparse
import csv

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery.delivery_status import get_all_active_projects


def main():
    parser = argparse.ArgumentParser(description="Export delivery report")
    parser.add_argument("--output", default="delivery_report.csv", help="Output file")
    args = parser.parse_args()

    print("=" * 50)
    print("EXPORT DELIVERY REPORT")
    print("=" * 50)

    projects = get_all_active_projects()

    if projects:
        with open(args.output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=projects[0].keys())
            writer.writeheader()
            writer.writerows(projects)

    print(f"\nExported {len(projects)} projects to {args.output}")
    print("=" * 50)


if __name__ == "__main__":
    main()
