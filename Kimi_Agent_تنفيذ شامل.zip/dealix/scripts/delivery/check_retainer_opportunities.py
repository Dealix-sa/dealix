#!/usr/bin/env python3
"""
scripts/delivery/check_retainer_opportunities.py

Identify and list retainer conversion opportunities.

Usage:
    python -m scripts.delivery.check_retainer_opportunities
"""

import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from app.delivery import retainer_converter


def main():
    print("=" * 50)
    print("RETAINER OPPORTUNITIES")
    print("=" * 50)

    ops = retainer_converter.identify_opportunities()

    print(f"\nFound {len(ops)} opportunities:\n")
    for op in ops:
        print(f"  Client: {op.get('client_id', '?')}")
        print(f"  Score:  {op.get('conversion_score', 0)}/100")
        print(f"  Signals: {', '.join(op.get('signals', []))}")
        print()

    print("=" * 50)


if __name__ == "__main__":
    main()
