# Weekly Proof Report Template

## Client: ___
## Project: ___
## Week: ___
## Prepared by: ___
## Date: ___

---

## What We Built This Week

1. ___
2. ___
3. ___

## What Changed

| Before | After |
|--------|-------|
| ___ | ___ |

## Measured Outputs

| Metric | Value | Change |
|--------|-------|--------|
| ___ | ___ | ___ |

## Decisions Made

1. ___

## Open Blockers

1. ___

## Risks

| Risk | Level | Mitigation |
|------|-------|------------|
| ___ | ___ | ___ |

## Next Week

1. ___
2. ___
3. ___

## Expansion Opportunity

___

## Client Approval

- [ ] Approved
- [ ] Comments: ___

**Client Signature:** ___ **Date:** ___
