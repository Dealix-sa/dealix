# Executive Proof Summary Template

## Client: ___
## Period: ___
## Prepared by: ___

---

## Health Score: ___/100

## Usage Review

- Active users: ___
- Workflows active: ___
- Data processed: ___
- System uptime: ___%

## Proof Summary

| Claim | Evidence | Status |
|-------|----------|--------|
| ___ | ___ | ___ |

## Expansion Opportunities

1. ___

## Renewal Recommendation

- [ ] Expand (score 80-100)
- [ ] Retain and improve (score 60-79)
- [ ] Risk (score 40-59)
- [ ] Intervention (score < 40)

## Next 30 Days

1. ___

## Client Feedback

___
