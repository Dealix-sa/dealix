# Case Study (Public)

## ⚠️ لا تستخدم اسم العميل إلا إذا يوجد إذن.

## Sector: ___

### The Problem
___

### The Solution
___

### Results
___

### What We Learned
___

---

**Rules:**
- No exaggerated numbers
- No guaranteed ROI claims
- No client name without permission
- Based on actual data
- Honest about limitations
