# Before / After Template

## Client: ___
## Workflow: ___
## Date: ___

---

### Metric 1: ___

**Before:** ___
**After:** ___
**Change:** ___

### Metric 2: ___

**Before:** ___
**After:** ___
**Change:** ___

### Metric 3: ___

**Before:** ___
**After:** ___
**Change:** ___

---

## Summary

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| ___ | ___ | ___ | ___ |

## Notes

- No exaggerated numbers
- No guaranteed ROI claims
- Based on actual data
- Client context included
