# Client Value Log

## Client: ___

| Date | Action | Value Created | Evidence |
|------|--------|--------------|----------|
| ___ | ___ | ___ | ___ |

## Value Summary

- Total actions: ___
- Total value: ___
- Client satisfaction: ___/10

## Notes

- Log every action
- Connect to value
- Collect evidence
- Review monthly
