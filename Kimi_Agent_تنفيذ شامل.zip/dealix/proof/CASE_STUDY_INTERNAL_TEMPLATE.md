# Case Study (Internal)

## Client: ___
## Sector: ___
## Product: ___
## Period: ___

---

### The Problem
___

### The Solution
___

### Implementation
___

### Results
___

### Learnings
___

### Next Steps
___

---

**Status:** Internal use only
**Permission for public:** No / Requested / Granted
