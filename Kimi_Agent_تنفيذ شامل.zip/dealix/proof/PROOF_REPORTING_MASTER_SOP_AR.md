# SOP تقارير الإثبات الرئيسي

## المبدأ

> "نثبت القيمة لا نعد بها."

## أنواع تقارير الإثبات

1. **Weekly Proof Report** — كل أسبوع
2. **Executive Proof Summary** — كل شهر
3. **Before/After Report** — عند milestone
4. **Case Study** — عند completion

## من يكتب

Delivery team + Client feedback.

## من يراجع

Founder قبل إرسال للعميل.

## توقيت

- Weekly: كل جمعة
- Monthly: أول كل شهر
- Milestone: عند completion
- Case study: بعد 30 يوم من launch

## Contents

### Weekly
- What we built
- What changed
- Measured outputs
- Decisions made
- Open blockers
- Risks
- Next week
- Expansion opportunity

### Monthly (Executive)
- Health score
- Usage metrics
- Proof summary
- Expansion opportunities
- Renewal recommendation

## Gates

لا retainer conversion إلا إذا proof report delivered.
لا case study public إلا إذا إذن العميل.
لا أرقام مبالغ فيها.
