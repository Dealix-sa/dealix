# Renewal Emails

## 30 Days Before Renewal

"السلام عليكم [Name],

الشهر القادم ينتهي الـ retainer.

هل تريدون:
1. تجديد بنفس النطاق
2. توسعة
3. مراجعة

أرسل لكم الـ executive review هذا الأسبوع."

## 7 Days Before Renewal

"السلام عليكم [Name],

تذكير: الـ retainer ينتهي بعد 7 أيام.

الـ executive review مرفق.
هل تريدون call قصير؟"

## Day of Renewal

"السلام عليكم [Name],

شكراً للثقة. الـ retainer مجدد.

نبدأ الشهر الجديد بـ [plan]."

## If At Risk

"السلام عليكم [Name],

ألاحظ أن الـ retainer ينتهي قريباً.

هل هناك شيء يمنع التجديد؟
أنا هنا لأساعد."
