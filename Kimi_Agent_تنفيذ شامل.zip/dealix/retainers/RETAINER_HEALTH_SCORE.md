# Retainer Health Score

## Factors

| Factor | Weight | Score |
|--------|--------|-------|
| Usage | 20% | /10 |
| Proof delivered | 20% | /10 |
| Executive engagement | 15% | /10 |
| Open blockers | 10% | /10 |
| Expansion potential | 10% | /10 |
| Renewal risk | 10% | /10 |
| Payment status | 10% | /10 |
| Stakeholder satisfaction | 5% | /10 |

## Classification

| Score | Status | Action |
|-------|--------|--------|
| 80-100 | Expand | Propose expansion |
| 60-79 | Retain and improve | Address gaps |
| 40-59 | Risk | Intervention needed |
| < 40 | Intervention | Urgent action |

## Monthly Review

Calculate health score monthly.
Update actions based on score.
Report to founder weekly.
