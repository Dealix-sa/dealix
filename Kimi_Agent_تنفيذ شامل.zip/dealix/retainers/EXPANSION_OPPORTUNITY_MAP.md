# Expansion Opportunity Map

## Current Client: ___
## Current Product: ___
## Current Phase: ___

---

## Potential Expansions

| Product | Fit | Value | Effort | Priority |
|---------|-----|-------|--------|----------|
| ___ | ___ | ___ | ___ | ___ |

## Expansion Triggers

- Client asks for more
- Proof report shows opportunity
- New pain identified
- Team growth
- New location/branch

## Expansion Conversation

"في الـ proof report لاحظنا [opportunity].
هل تريدون نستكشف [product]؟"

## Rules

- No expansion without proof
- Start with one workflow
- Same governance as original
- New acceptance criteria
