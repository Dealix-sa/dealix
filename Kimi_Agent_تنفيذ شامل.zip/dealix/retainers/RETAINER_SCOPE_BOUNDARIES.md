# Retainer Scope Boundaries

## Included

- System monitoring
- Weekly proof reports
- Monthly executive review
- Bug fixes
- Minor updates
- Support (within SLA)

## Not Included

- New workflows (expansion)
- Custom development
- Data migration
- Training new users (after initial)
- Integration with new systems

## Expansion = New Proposal

Any scope change requires:
1. New proposal
2. New acceptance criteria
3. New pricing
4. Client approval

## SLA

- Response: 4 hours
- Resolution: 48 hours (critical)
- Uptime: 99%
