# كتاب تحويل الـ Retainer

## المبدأ

> "لا تحول إلى retainer بدون proof report."

## التسلسل

1. Diagnostic Sprint (3-7 أيام)
2. Pilot OS (30-60 يوم)
3. Proof Report
4. Retainer Conversion
5. Managed OS (شهري)

## شروط التحويل

- [ ] Pilot OS delivered
- [ ] Proof report submitted
- [ ] Client satisfied
- [ ] Success metrics met (or on track)
- [ ] Expansion opportunity identified

## محادثة التحويل

"بناءً على الـ proof report، النظام يعمل.

هل تريدون:
1. الاستمرار بنفس النطاق (Managed OS)
2. التوسعة (إضافة workflows)
3. المراجعة الشهرية

الاستثمار: [X] ريال/شهر.

هل تريدون نبدأ الشهر القادم؟"

## الممانعة

### "لم نر نتيجة"
"أفهم. دعني أريك الـ proof report بالتفصيل.
[افتح report]

هل هناك شيء محدد تريد تحسينه؟"

### "السعر..."
"الـ Pilot أثبت القيمة. الـ Retainer يضمن استمرار.

هل تريدون نبدأ بـ 3 أشهر؟"

### "نريد نفكر"
"تماماً. متى نتحدث مرة أخرى؟
[حدد موعد محدد]"
