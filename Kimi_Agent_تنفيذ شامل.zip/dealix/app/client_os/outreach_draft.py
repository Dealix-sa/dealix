"""
Dealix Client OS — Outreach Draft

Generates Email / LinkedIn / WhatsApp message drafts.
Default status is always DRAFT. No sending.
Every draft requires approval.
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from app.client_os.storage import get_storage
from app.client_os.schemas import ApprovalStatus, Channel
from app.client_os.policy_gate import get_gate
from app.client_os.audit_log import log_outreach_draft


# Template frames for outreach messages — cautious, non-salesy
EMAIL_TEMPLATES = {
    "introduction": """السلام عليكم {contact_name}،

أتابع {company_name} من فترة وأقدر ما تقدمونه في قطاع {sector}.

{hypothesis_sentence}

في Dealix نشتغل مع شركات {sector} على أنظمة تشغيل ذكية تساعد في:
- تنظيم المتابعة مع العملاء
- تحسين سرعة الرد
- توثيق القرارات التشغيلية

ما أطلبه هو ١٥ دقيقة مكالمة قصيرة نستكشف فيها إذا كان فيه تطابق بين اللي تحتاجونه واللي نقدمه.

{unsubscribe_line}

مع التحية،
{sender_name}
Dealix — AI Operating Systems for Companies""",

    "followup": """السلام عليكم {contact_name}،

أرجع أتواصل بعد رسالتي السابقة.

{hypothesis_sentence}

نشتغل حاليًا مع شركات من نفس القطاع ونشوف نتائج ملموسة في:
- تقليل الوقت المستهلك في المتابعة اليدوية
- توحيد البيانات في مكان واحد
- تسريع اتخاذ القرار

لو تفضلون نحجز مكالمة قصيرة هذا الأسبوع أو الأسبوع الجاي؟

{unsubscribe_line}

مع التحية،
{sender_name}""",
}

WHATSAPP_TEMPLATES = {
    "introduction": """السلام عليكم {contact_name} 👋

أنا من Dealix، نشتغل على أنظمة تشغيل ذكية للشركات.

شفت {company_name} و أقدر اللي تقدمونه.

{hypothesis_short}

ممكن نحجز مكالمة ١٥ دقيقة نستكشف فيها إذا فيه تطابق؟

{opt_in_notice}""",
}

LINKEDIN_TEMPLATES = {
    "introduction": """Hi {contact_name},

I've been following {company_name}'s work in {sector_en} — impressive growth.

{hypothesis_en}

At Dealix, we build AI Operating Systems for companies like yours to streamline operations, follow-ups, and decision-making.

Would you be open to a brief 15-min exploration call this week or next?

Best,
{sender_name}""",
}


def translate_sector_en(sector: str) -> str:
    """Translate Arabic sector to English for LinkedIn."""
    mapping = {
        "تجارة تجزئة": "retail",
        "خدمات لوجستية": "logistics",
        "مطاعم": "hospitality",
        "رعاية صحية": "healthcare",
        "تدريب وتعليم": "education",
        "عقارات": "real estate",
        "سياحة وفنادق": "tourism",
        "تقنية": "technology",
        "خدمات مهنية": "professional services",
        "تجميل": "beauty & wellness",
        "سيارات": "automotive",
    }
    return mapping.get(sector, "your industry")


def generate_outreach_draft(
    company_id: str,
    contact_id: str = "",
    channel: str = Channel.EMAIL,
    template_type: str = "introduction",
    sender_name: str = "فريق Dealix",
) -> Dict[str, Any]:
    """
    Generate an outreach message draft. Always DRAFT status.

    Returns:
        Dict with draft message and policy check results
    """
    storage = get_storage()
    company = storage.read_by_id("companies", "company_id", company_id)

    if not company:
        return {"company_id": company_id, "error": "Company not found"}

    contact_name = "فريق العمل"
    if contact_id:
        contact = storage.read_by_id("contacts", "contact_id", contact_id)
        if contact:
            contact_name = contact.get("name", "فريق العمل")

    sector = company.get("sector", "")
    company_name = company.get("company_name", "")
    hypothesis = company.get("pain_hypothesis", "")

    # Build hypothesis sentence
    hypothesis_sentence = ""
    hypothesis_short = ""
    if hypothesis:
        sentences = hypothesis.split(" | ")
        if sentences:
            hypothesis_sentence = f"لاحظت أن {sentences[0]}"
            hypothesis_short = sentences[0][:100] + "..." if len(sentences[0]) > 100 else sentences[0]
    else:
        hypothesis_sentence = f"في شركات {sector} غالبًا يكون فيه تحديات في تنظيم المتابعة والرد على العملاء"
        hypothesis_short = f"تحديات في تنظيم المتابعة في قطاع {sector}"

    # Build the message body
    if channel == Channel.EMAIL:
        template = EMAIL_TEMPLATES.get(template_type, EMAIL_TEMPLATES["introduction"])
        unsubscribe_line = "إذا لا ترغب في استلام رسائلنا، أرسل 'إلغاء' وسنحترم رغبتك فوراً."
        body = template.format(
            contact_name=contact_name,
            company_name=company_name,
            sector=sector,
            hypothesis_sentence=hypothesis_sentence,
            sender_name=sender_name,
            unsubscribe_line=unsubscribe_line,
        )
        subject = f"استكشاف سريع — {company_name} × Dealix"

    elif channel == Channel.WHATSAPP:
        template = WHATSAPP_TEMPLATES.get(template_type, WHATSAPP_TEMPLATES["introduction"])
        opt_in_notice = "(نراسيكم لأنكم سمحتم بالتواصل عبر الواتساب)"
        body = template.format(
            contact_name=contact_name,
            company_name=company_name,
            hypothesis_short=hypothesis_short,
            opt_in_notice=opt_in_notice,
        )
        subject = ""

    elif channel == Channel.LINKEDIN:
        template = LINKEDIN_TEMPLATES.get(template_type, LINKEDIN_TEMPLATES["introduction"])
        sector_en = translate_sector_en(sector)
        hypothesis_en = f"I've noticed that companies in {sector_en} often face challenges in follow-up consistency and response speed"
        body = template.format(
            contact_name=contact_name,
            company_name=company_name,
            sector_en=sector_en,
            hypothesis_en=hypothesis_en,
            sender_name=sender_name,
        )
        subject = f"Quick exploration — {company_name}"
    else:
        return {"error": f"Unknown channel: {channel}"}

    # Policy gate checks
    gate = get_gate()
    clean, reason = gate.check_fake_claims(body)
    if not clean:
        body = f"[BLOCKED BY POLICY: {reason}]\n\n[DARAFT REQUIRES REVIEW]\n\n{body}"

    # Save body to file
    message_id = f"msg_{str(uuid.uuid4())[:8]}"
    body_path = f"ledgers/drafts/{message_id}_{channel}.txt"
    import os
    os.makedirs("ledgers/drafts", exist_ok=True)
    with open(body_path, "w", encoding="utf-8") as f:
        f.write(body)

    # Save to outreach_log
    now = datetime.now().isoformat()
    message = {
        "message_id": message_id,
        "company_id": company_id,
        "contact_id": contact_id,
        "channel": channel,
        "status": ApprovalStatus.DRAFT,
        "subject": subject,
        "body_path": body_path,
        "source_url": company.get("source_url", ""),
        "verification_status": company.get("verification_status", "unverified"),
        "approval_status": ApprovalStatus.DRAFT,
        "approved_by": "",
        "sent_at": "",
        "reply_status": "",
        "followup_due_at": "",
        "opt_out": "false",
        "created_at": now,
        "updated_at": now,
    }

    outreach_fields = [
        "message_id", "company_id", "contact_id", "channel", "status", "subject",
        "body_path", "source_url", "verification_status", "approval_status",
        "approved_by", "sent_at", "reply_status", "followup_due_at",
        "opt_out", "created_at", "updated_at"
    ]
    storage.append("outreach_log", message, outreach_fields)

    log_outreach_draft(message_id, f"Draft created for {company_name} via {channel}")

    return {
        "message_id": message_id,
        "company_id": company_id,
        "company_name": company_name,
        "channel": channel,
        "status": ApprovalStatus.DRAFT,
        "subject": subject,
        "body_preview": body[:200] + "..." if len(body) > 200 else body,
        "body_path": body_path,
        "approval_status": ApprovalStatus.DRAFT,
        "policy_check": "passed" if clean else "failed",
        "policy_reason": "" if clean else reason,
    }


def get_pending_drafts() -> List[Dict[str, str]]:
    """Get all drafts pending approval."""
    storage = get_storage()
    messages = storage.read_all("outreach_log")
    return [m for m in messages if m.get("approval_status") == ApprovalStatus.DRAFT]


def approve_draft(message_id: str, approved_by: str) -> Dict[str, Any]:
    """Approve a draft message for potential sending."""
    from app.client_os.audit_log import log_outreach_approval
    storage = get_storage()
    outreach_fields = [
        "message_id", "company_id", "contact_id", "channel", "status", "subject",
        "body_path", "source_url", "verification_status", "approval_status",
        "approved_by", "sent_at", "reply_status", "followup_due_at",
        "opt_out", "created_at", "updated_at"
    ]
    updates = {
        "approval_status": ApprovalStatus.APPROVED,
        "approved_by": approved_by,
        "status": ApprovalStatus.APPROVED,
        "updated_at": datetime.now().isoformat(),
    }
    storage.update_by_id("outreach_log", "message_id", message_id, updates, outreach_fields)
    log_outreach_approval(message_id, approved_by, "Draft approved for sending")
    return {"message_id": message_id, "status": "approved", "approved_by": approved_by}


def reject_draft(message_id: str, rejected_by: str, reason: str = "") -> Dict[str, Any]:
    """Reject a draft message."""
    storage = get_storage()
    outreach_fields = [
        "message_id", "company_id", "contact_id", "channel", "status", "subject",
        "body_path", "source_url", "verification_status", "approval_status",
        "approved_by", "sent_at", "reply_status", "followup_due_at",
        "opt_out", "created_at", "updated_at"
    ]
    updates = {
        "approval_status": ApprovalStatus.REJECTED,
        "approved_by": rejected_by,
        "status": ApprovalStatus.REJECTED,
        "updated_at": datetime.now().isoformat(),
    }
    storage.update_by_id("outreach_log", "message_id", message_id, updates, outreach_fields)
    return {"message_id": message_id, "status": "rejected", "reason": reason}
