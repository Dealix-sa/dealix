"""
Dealix Client OS — Qualification

Evaluates companies based on sector, website, contact availability, and pain signals.
Outputs confidence level and verification status.
"""

from typing import Dict, Any, List, Tuple
from app.client_os.schemas import ConfidenceLevel, VerificationStatus
from app.client_os.storage import get_storage


QUALIFIED_SECTORS = [
    "تجارة تجزئة",
    "خدمات لوجستية",
    "مطاعم",
    "رعاية صحية",
    "تدريب وتعليم",
    "عقارات",
    "سياحة وفنادق",
    "تقنية",
    "خدمات مهنية",
    "تجميل",
    "سيارات",
]


def assess_sector(sector: str) -> int:
    """Score based on sector alignment."""
    sector_normalized = sector.strip().lower()
    for qs in QUALIFIED_SECTORS:
        if qs.lower() in sector_normalized:
            return 30
    return 10


def assess_website(website: str) -> int:
    """Score based on website presence."""
    if website and website.startswith("http"):
        return 20
    return 0


def assess_contact_availability(company: Dict[str, str]) -> int:
    """Score based on available contact methods."""
    score = 0
    if company.get("public_email"):
        score += 15
    if company.get("phone"):
        score += 10
    if company.get("contact_page_url"):
        score += 10
    if company.get("linkedin_url"):
        score += 10
    return score


def assess_pain_signals(company: Dict[str, str]) -> int:
    """Score based on visible pain signals."""
    pain = company.get("visible_pain_signals", "")
    if not pain:
        return 0
    score = 15
    pain_indicators = [
        "تأخر", "شكوى", "سلبي", "مشكلة", "صعوبة", "فقدان",
        "delay", "complaint", "negative", "problem", "difficulty"
    ]
    for indicator in pain_indicators:
        if indicator.lower() in pain.lower():
            score += 5
    return min(score, 30)


def assess_source_url(company: Dict[str, str]) -> int:
    """Score based on source_url presence."""
    if company.get("source_url"):
        return 10
    return 0


def calculate_confidence(company: Dict[str, str]) -> Tuple[str, int]:
    """
    Calculate confidence score for a company.
    Returns (confidence_level, score).
    """
    score = 0
    score += assess_sector(company.get("sector", ""))
    score += assess_website(company.get("website", ""))
    score += assess_contact_availability(company)
    score += assess_pain_signals(company)
    score += assess_source_url(company)

    if score >= 80:
        return ConfidenceLevel.HIGH, score
    elif score >= 50:
        return ConfidenceLevel.MEDIUM, score
    else:
        return ConfidenceLevel.LOW, score


def qualify_company(company_id: str) -> Dict[str, Any]:
    """
    Qualify a single company and update its record.

    Returns:
        Dict with qualification results
    """
    storage = get_storage()
    company = storage.read_by_id("companies", "company_id", company_id)

    if not company:
        return {"company_id": company_id, "error": "Company not found"}

    confidence, score = calculate_confidence(company)

    # Determine verification status
    if confidence == ConfidenceLevel.HIGH and company.get("source_url"):
        verification = VerificationStatus.VERIFIED
    elif confidence == ConfidenceLevel.LOW:
        verification = VerificationStatus.UNVERIFIED
    else:
        verification = VerificationStatus.PENDING

    # Update company record
    from datetime import datetime
    updates = {
        "confidence": confidence,
        "verification_status": verification,
        "updated_at": datetime.now().isoformat()
    }
    storage.update_by_id("companies", "company_id", company_id, updates, [
        "company_id", "company_name", "sector", "city", "website", "source_url",
        "contact_page_url", "public_email", "phone", "linkedin_url", "instagram_url",
        "google_maps_url", "business_description", "visible_services",
        "visible_pain_signals", "confidence", "verification_status",
        "pain_hypothesis", "recommended_offer", "owner_decision",
        "created_at", "updated_at"
    ])

    return {
        "company_id": company_id,
        "company_name": company.get("company_name", ""),
        "confidence": confidence,
        "score": score,
        "verification_status": verification,
    }


def qualify_all_pending() -> List[Dict[str, Any]]:
    """Qualify all pending/unverified companies."""
    storage = get_storage()
    companies = storage.read_all("companies")
    results = []
    for company in companies:
        status = company.get("verification_status", "")
        if status in (VerificationStatus.UNVERIFIED, VerificationStatus.PENDING):
            result = qualify_company(company.get("company_id", ""))
            results.append(result)
    return results


def get_qualified_companies(min_confidence: str = ConfidenceLevel.MEDIUM) -> List[Dict[str, str]]:
    """Get companies meeting minimum confidence threshold."""
    storage = get_storage()
    companies = storage.read_all("companies")

    confidence_order = {ConfidenceLevel.HIGH: 3, ConfidenceLevel.MEDIUM: 2, ConfidenceLevel.LOW: 1}
    min_level = confidence_order.get(min_confidence, 2)

    qualified = []
    for company in companies:
        company_level = confidence_order.get(company.get("confidence", "low"), 0)
        if company_level >= min_level and company.get("verification_status") == VerificationStatus.VERIFIED:
            qualified.append(company)

    return qualified
