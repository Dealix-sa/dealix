"""
Dealix Client OS — Intake Engine

Builds client intake form capturing:
goal, users, data sources, current tools, pains, decision owner,
review owner, sensitive data, external send requirement, success metric.
"""

import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from app.client_os.storage import get_storage
from app.client_os.schemas import ClientIntake
from app.client_os.audit_log import log_intake_completed


INTAKE_FIELDS = [
    "client_id", "company_id", "client_name", "primary_contact",
    "sector", "goal", "main_pain", "current_tools", "data_sources",
    "decision_owner", "review_owner", "sensitive_data",
    "external_send_required", "success_metric", "intake_status",
    "created_at", "updated_at"
]

# Standard intake questions
INTAKE_QUESTIONS = [
    ("goal", "ما الهدف التجاري الرئيسي من هذا المشروع؟"),
    ("users", "من المستخدمون الرئيسيون للنظام؟ (عددهم، أدوارهم)"),
    ("data_sources", "أين توجد البيانات الحالية؟ (أنظمة، Excel، يدوي)"),
    ("current_tools", "ما الأدوات الحالية المستخدمة؟"),
    ("main_pain", "ما أكبر ألم أو تحدي تواجهونه؟"),
    ("decision_owner", "من يملك قرار الموافقة النهائي؟"),
    ("review_owner", "من يراجع ويعتمد المخرجات؟"),
    ("sensitive_data", "هل هناك بيانات حساسة أو سرية؟"),
    ("external_send", "هل يحتاج النظام إلى إرسال خارجي (واتساب، إيميل)؟"),
    ("success_metric", "ما مقياس النجاح الرئيسي؟"),
]


def create_intake(
    company_id: str,
    client_name: str = "",
    primary_contact: str = "",
    sector: str = "",
    goal: str = "",
    main_pain: str = "",
    current_tools: str = "",
    data_sources: str = "",
    decision_owner: str = "",
    review_owner: str = "",
    sensitive_data: str = "",
    external_send_required: str = "no",
    success_metric: str = "",
) -> Dict[str, Any]:
    """
    Create a new client intake record.

    Returns:
        Dict with intake data
    """
    storage = get_storage()

    client_id = f"client_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    intake = {
        "client_id": client_id,
        "company_id": company_id,
        "client_name": client_name,
        "primary_contact": primary_contact,
        "sector": sector,
        "goal": goal,
        "main_pain": main_pain,
        "current_tools": current_tools,
        "data_sources": data_sources,
        "decision_owner": decision_owner,
        "review_owner": review_owner,
        "sensitive_data": sensitive_data,
        "external_send_required": external_send_required,
        "success_metric": success_metric,
        "intake_status": "pending",
        "created_at": now,
        "updated_at": now,
    }

    storage.append("client_intakes", intake, INTAKE_FIELDS)

    return {
        "client_id": client_id,
        "company_id": company_id,
        "status": "pending",
        "questions_answered": len([v for v in [goal, main_pain, current_tools, decision_owner] if v]),
        "total_questions": len(INTAKE_QUESTIONS),
    }


def get_intake_questions() -> list:
    """Get the standard intake questions."""
    return INTAKE_QUESTIONS


def complete_intake(client_id: str) -> Dict[str, Any]:
    """Mark an intake as completed."""
    storage = get_storage()

    updates = {
        "intake_status": "completed",
        "updated_at": datetime.now().isoformat(),
    }
    storage.update_by_id("client_intakes", "client_id", client_id, updates, INTAKE_FIELDS)
    log_intake_completed(client_id, "Intake form completed")

    return {"client_id": client_id, "status": "completed"}


def get_intake(client_id: str) -> Optional[Dict[str, str]]:
    """Get a client intake record."""
    storage = get_storage()
    return storage.read_by_id("client_intakes", "client_id", client_id)


def get_pending_intakes() -> list:
    """Get all pending intakes."""
    storage = get_storage()
    intakes = storage.read_all("client_intakes")
    return [i for i in intakes if i.get("intake_status") == "pending"]


def get_intake_summary(client_id: str) -> Dict[str, Any]:
    """Get a summary of the intake for display."""
    intake = get_intake(client_id)
    if not intake:
        return {"client_id": client_id, "error": "Intake not found"}

    return {
        "client_id": client_id,
        "client_name": intake.get("client_name", ""),
        "company_id": intake.get("company_id", ""),
        "goal": intake.get("goal", ""),
        "main_pain": intake.get("main_pain", ""),
        "current_tools": intake.get("current_tools", ""),
        "decision_owner": intake.get("decision_owner", ""),
        "sensitive_data": intake.get("sensitive_data", "لا يوجد"),
        "external_send": intake.get("external_send_required", "no"),
        "success_metric": intake.get("success_metric", ""),
        "status": intake.get("intake_status", ""),
    }
