"""
Dealix Client OS — Client Success

Generates monthly review:
- health check
- usage review
- expansion opportunities
- renewal recommendation
- next 30 days
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List
from app.client_os.storage import get_storage
from app.client_os.audit_log import log_client_success_review, log_expansion_opportunity


RENEWAL_FIELDS = [
    "renewal_id", "client_id", "project_id", "health_score",
    "usage_review", "expansion_opportunities", "renewal_recommendation",
    "next_30_days", "created_at"
]


def calculate_health_score(project_id: str) -> int:
    """
    Calculate a health score (0-100) based on project status.
    """
    storage = get_storage()
    project = storage.read_by_id("projects", "project_id", project_id)
    if not project:
        return 0

    score = 50  # baseline

    # Acceptance status
    if project.get("acceptance_status") == "accepted":
        score += 20
    elif project.get("acceptance_status") == "pending":
        score += 5

    # Proof status
    if project.get("proof_status") == "submitted":
        score += 15
    elif project.get("proof_status") == "approved":
        score += 20

    # Task progress
    tasks = storage.read_all("tasks")
    project_tasks = [t for t in tasks if t.get("project_id") == project_id]
    if project_tasks:
        completed = sum(1 for t in project_tasks if t.get("status") == "completed")
        ratio = completed / len(project_tasks)
        score += int(ratio * 15)

    # Cap at 100
    return min(score, 100)


def generate_monthly_review(project_id: str) -> Dict[str, Any]:
    """
    Generate a monthly client success review.

    Returns:
        Dict with review data
    """
    storage = get_storage()
    project = storage.read_by_id("projects", "project_id", project_id)

    if not project:
        return {"project_id": project_id, "error": "Project not found"}

    client_id = project.get("client_id", "")

    # Calculate health score
    health_score = calculate_health_score(project_id)

    # Build usage review
    proof_reports = storage.read_all("proof_reports")
    project_proofs = [p for p in proof_reports if p.get("project_id") == project_id]

    if project_proofs:
        latest = project_proofs[-1]
        usage_review = f"""آخر تقرير إثبات: {latest.get('report_period', '')}
الإجراءات المكتملة: {latest.get('completed_actions', '')[:100]}
المخاطر المفتوحة: {latest.get('open_risks', '')}"""
    else:
        usage_review = "لا توجد تقارير إثبات بعد — النظام في مرحلة التفعيل"

    # Expansion opportunities
    expansion_opps = []
    if health_score > 70:
        expansion_opps.append("العميل راضٍ — فرصة لإضافة وحدات جديدة")
    if project.get("proof_status") == "submitted":
        expansion_opps.append("تقرير الإثبات مكتمل — يمكن اقتراح توسعة النطاق")
    if not expansion_opps:
        expansion_opps.append("مازلنا في مرحلة التقييم — لا توصي بالتوسعة حالياً")

    # Renewal recommendation
    if health_score >= 80:
        renewal_rec = "renew_recommended"
    elif health_score >= 50:
        renewal_rec = "renew_with_conditions"
    else:
        renewal_rec = "review_required"

    # Next 30 days
    next_30 = f"""- إكمال المهام المعلقة
- متابعة {project.get('next_action', 'الخطوات القادمة')}
- تحضير تقرير الإثبات القادم
- مراجعة الصحة: {health_score}/100"""

    renewal_id = f"renew_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    renewal = {
        "renewal_id": renewal_id,
        "client_id": client_id,
        "project_id": project_id,
        "health_score": str(health_score),
        "usage_review": usage_review,
        "expansion_opportunities": " | ".join(expansion_opps),
        "renewal_recommendation": renewal_rec,
        "next_30_days": next_30,
        "created_at": now,
    }

    storage.append("renewals", renewal, RENEWAL_FIELDS)

    # Update project with renewal opportunity
    project_updates = {
        "renewal_opportunity": " | ".join(expansion_opps),
        "updated_at": now,
    }
    storage.update_by_id("projects", "project_id", project_id, project_updates, [
        "project_id", "client_id", "project_name", "product_type",
        "status", "current_phase", "owner", "start_date",
        "target_launch_date", "acceptance_status", "proof_status",
        "renewal_opportunity", "next_action", "updated_at"
    ])

    log_client_success_review(client_id, f"Monthly review: health={health_score}, renewal={renewal_rec}")

    if expansion_opps and "فرصة" in expansion_opps[0]:
        log_expansion_opportunity(client_id, expansion_opps[0])

    return {
        "renewal_id": renewal_id,
        "project_id": project_id,
        "client_id": client_id,
        "health_score": health_score,
        "renewal_recommendation": renewal_rec,
        "expansion_opportunities": expansion_opps,
        "next_30_days": next_30,
    }


def get_renewal_history(client_id: str) -> list:
    """Get renewal history for a client."""
    storage = get_storage()
    renewals = storage.read_all("renewals")
    return [r for r in renewals if r.get("client_id") == client_id]


def get_health_trend(project_id: str) -> list:
    """Get health score trend over time."""
    storage = get_storage()
    renewals = storage.read_all("renewals")
    project_renewals = [r for r in renewals if r.get("project_id") == project_id]
    return [
        {
            "period": r.get("created_at", ""),
            "health_score": int(r.get("health_score", 0)),
        }
        for r in project_renewals
    ]
