"""
Dealix Client OS — Company Research

Reads target companies from CSV or sample data.
Validates source_url presence. Organizes company data.
Outputs to companies.csv.
"""

import uuid
import csv
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.client_os.storage import get_storage
from app.client_os.schemas import Company, ConfidenceLevel, VerificationStatus
from app.client_os.audit_log import log_company_research


SAMPLE_COMPANIES = [
    {
        "company_name": "مؤسسة النهضة للتجارة",
        "sector": "تجارة تجزئة",
        "city": "الرياض",
        "website": "https://alnahda-retail.sa",
        "source_url": "https://sam.gov.sa",
        "contact_page_url": "https://alnahda-retail.sa/contact",
        "public_email": "info@alnahda-retail.sa",
        "phone": "+966112345678",
        "business_description": "متاجر تجزئة للإلكترونيات",
        "visible_services": "بيع الإلكترونيات، صيانة",
        "visible_pain_signals": "تأخر الرد على الاستفسارات",
    },
    {
        "company_name": "شركة الأفق للخدمات اللوجستية",
        "sector": "خدمات لوجستية",
        "city": "جدة",
        "website": "https://alofok-logistics.com",
        "source_url": "https://mc.gov.sa",
        "contact_page_url": "https://alofok-logistics.com/contact-us",
        "public_email": "contact@alofok-logistics.com",
        "phone": "+966126543210",
        "business_description": "خدمات شحن وتخزين",
        "visible_services": "شحن، تخزين، توصيل",
        "visible_pain_signals": "شكاوى متكررة على التأخير",
    },
    {
        "company_name": "مطعم زعتر و زيتون",
        "sector": "مطاعم",
        "city": "الدمام",
        "website": "https://zaatar-zeitun.com",
        "source_url": "https://google.com/maps",
        "contact_page_url": "",
        "public_email": "",
        "phone": "+966138765432",
        "business_description": "مطعم ومقهى",
        "visible_services": "أطعمة شامية، قهوة",
        "visible_pain_signals": "مراجعات سلبية على جوجل",
    },
    {
        "company_name": "عيادة الصفوة الطبية",
        "sector": "رعاية صحية",
        "city": "الرياض",
        "website": "https://safwa-clinic.med.sa",
        "source_url": "https://sfda.gov.sa",
        "contact_page_url": "https://safwa-clinic.med.sa/booking",
        "public_email": "booking@safwa-clinic.med.sa",
        "phone": "+966119876543",
        "business_description": "عيادة متخصصة في الجلدية",
        "visible_services": "جلدية، تجميل، ليزر",
        "visible_pain_signals": "صعوبة حجز المواعيد",
    },
    {
        "company_name": "أكاديمية المستقبل للتدريب",
        "sector": "تدريب وتعليم",
        "city": "أبها",
        "website": "https://future-academy.sa",
        "source_url": "https://tvtc.gov.sa",
        "contact_page_url": "https://future-academy.sa/contact",
        "public_email": "info@future-academy.sa",
        "phone": "+966172345678",
        "business_description": "تدريب مهني وتقني",
        "visible_services": "دورات برمجة، إدارة",
        "visible_pain_signals": "عدم متابعة المتدربين",
    },
]

COMPANY_FIELDS = [
    "company_id", "company_name", "sector", "city", "website", "source_url",
    "contact_page_url", "public_email", "phone", "linkedin_url", "instagram_url",
    "google_maps_url", "business_description", "visible_services",
    "visible_pain_signals", "confidence", "verification_status",
    "pain_hypothesis", "recommended_offer", "owner_decision",
    "created_at", "updated_at"
]


def load_sample_companies() -> List[Dict[str, str]]:
    """Load sample companies for demonstration."""
    now = datetime.now().isoformat()
    companies = []
    for data in SAMPLE_COMPANIES:
        company = Company(
            company_id=f"comp_{str(uuid.uuid4())[:6]}",
            company_name=data["company_name"],
            sector=data["sector"],
            city=data["city"],
            website=data["website"],
            source_url=data["source_url"],
            contact_page_url=data.get("contact_page_url", ""),
            public_email=data.get("public_email", ""),
            phone=data.get("phone", ""),
            business_description=data.get("business_description", ""),
            visible_services=data.get("visible_services", ""),
            visible_pain_signals=data.get("visible_pain_signals", ""),
            confidence=ConfidenceLevel.MEDIUM.value,
            verification_status=VerificationStatus.PENDING.value,
            created_at=now,
            updated_at=now,
        )
        companies.append(company.to_csv_row())
    return companies


def read_targets_from_csv(filepath: str) -> List[Dict[str, str]]:
    """Read target companies from an external CSV file."""
    path = Path(filepath)
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        return list(reader)


def ingest_companies(source: Optional[str] = None, use_sample: bool = True) -> List[Dict[str, str]]:
    """
    Ingest companies into the ledger.

    Args:
        source: Path to external CSV file (optional)
        use_sample: Whether to use sample data if no source provided

    Returns:
        List of ingested company records
    """
    storage = get_storage()

    if source:
        new_companies = read_targets_from_csv(source)
    elif use_sample:
        new_companies = load_sample_companies()
    else:
        new_companies = []

    if not new_companies:
        return []

    existing = storage.read_all("companies")
    existing_ids = {row.get("company_id", "") for row in existing}

    added = []
    for company in new_companies:
        if company.get("company_id", "") not in existing_ids:
            storage.append("companies", company, COMPANY_FIELDS)
            log_company_research(company.get("company_id", ""), f"Ingested: {company.get('company_name', '')}")
            added.append(company)

    return added


def get_companies_by_status(verification_status: Optional[str] = None) -> List[Dict[str, str]]:
    """Get companies filtered by verification status."""
    storage = get_storage()
    companies = storage.read_all("companies")
    if verification_status:
        return [c for c in companies if c.get("verification_status") == verification_status]
    return companies


def update_company_verification(company_id: str, status: str, confidence: Optional[str] = None):
    """Update a company's verification status."""
    storage = get_storage()
    updates = {"verification_status": status, "updated_at": datetime.now().isoformat()}
    if confidence:
        updates["confidence"] = confidence
    storage.update_by_id("companies", "company_id", company_id, updates, COMPANY_FIELDS)
    log_company_research(company_id, f"Verification updated to {status}")
