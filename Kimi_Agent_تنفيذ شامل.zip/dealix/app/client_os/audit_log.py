"""
Dealix Client OS — Audit Log

Logs every significant action to ledgers/audit_log.csv
Immutable, append-only, timestamped.
"""

import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from app.client_os.storage import get_storage


AUDIT_FIELDNAMES = [
    "audit_id", "action", "entity_type", "entity_id",
    "actor", "details", "timestamp"
]


def log_action(
    action: str,
    entity_type: str,
    entity_id: str,
    actor: str = "system",
    details: str = ""
) -> Dict[str, str]:
    """Log an action to the audit ledger."""
    entry = {
        "audit_id": str(uuid.uuid4())[:8],
        "action": action,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "actor": actor,
        "details": details,
        "timestamp": datetime.now().isoformat(),
    }
    storage = get_storage()
    storage.append("audit_log", entry, AUDIT_FIELDNAMES)
    return entry


def log_company_research(company_id: str, details: str = ""):
    return log_action("company_research", "company", company_id, "system", details)


def log_outreach_draft(message_id: str, details: str = ""):
    return log_action("outreach_draft", "message", message_id, "system", details)


def log_outreach_approval(message_id: str, approved_by: str, details: str = ""):
    return log_action("outreach_approval", "message", message_id, approved_by, details)


def log_outreach_send(message_id: str, details: str = ""):
    return log_action("outreach_send", "message", message_id, "system", details)


def log_reply_received(reply_id: str, details: str = ""):
    return log_action("reply_received", "reply", reply_id, "system", details)


def log_meeting_booked(meeting_id: str, details: str = ""):
    return log_action("meeting_booked", "meeting", meeting_id, "system", details)


def log_intake_completed(client_id: str, details: str = ""):
    return log_action("intake_completed", "client", client_id, "system", details)


def log_diagnosis_completed(diagnosis_id: str, details: str = ""):
    return log_action("diagnosis_completed", "diagnosis", diagnosis_id, "system", details)


def log_blueprint_created(blueprint_id: str, details: str = ""):
    return log_action("blueprint_created", "blueprint", blueprint_id, "system", details)


def log_proposal_created(proposal_id: str, details: str = ""):
    return log_action("proposal_created", "proposal", proposal_id, "system", details)


def log_project_started(project_id: str, details: str = ""):
    return log_action("project_started", "project", project_id, "system", details)


def log_delivery_milestone(task_id: str, details: str = ""):
    return log_action("delivery_milestone", "task", task_id, "system", details)


def log_proof_report(proof_id: str, details: str = ""):
    return log_action("proof_report", "proof", proof_id, "system", details)


def log_client_success_review(client_id: str, details: str = ""):
    return log_action("client_success_review", "client", client_id, "system", details)


def log_policy_violation(entity_type: str, entity_id: str, details: str = ""):
    return log_action("policy_violation", entity_type, entity_id, "system", details)


def log_expansion_opportunity(client_id: str, details: str = ""):
    return log_action("expansion_opportunity", "client", client_id, "system", details)


def get_recent_audits(limit: int = 100) -> list:
    """Get recent audit entries."""
    storage = get_storage()
    entries = storage.read_all("audit_log")
    return entries[-limit:] if entries else []
