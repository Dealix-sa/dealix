"""
Dealix Client OS — Proposal Builder

Generates a Proposal Draft based on the Blueprint:
Executive Summary, Current Situation, Business Problem,
Proposed Operating System, Scope, Delivery Plan, Governance,
Success Metrics, Next Step

No default pricing unless explicitly in config.
"""

import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from app.client_os.storage import get_storage
from app.client_os.policy_gate import get_gate
from app.client_os.audit_log import log_proposal_created


PROPOSAL_FIELDS = [
    "proposal_id", "client_id", "project_id", "blueprint_id",
    "executive_summary", "current_situation", "business_problem",
    "proposed_os", "scope", "delivery_plan", "governance",
    "success_metrics", "next_step", "status", "created_at", "updated_at"
]


def generate_proposal(client_id: str) -> Dict[str, Any]:
    """
    Generate a Proposal Draft. Requires blueprint to exist first.

    Returns:
        Dict with complete proposal
    """
    storage = get_storage()

    # Gate check: blueprint must exist
    blueprint = None
    blueprints = storage.read_all("blueprints")
    for bp in blueprints:
        if bp.get("client_id") == client_id:
            blueprint = bp
            break

    if not blueprint:
        return {"client_id": client_id, "error": "No blueprint found — blueprint required before proposal"}

    intake = storage.read_by_id("client_intakes", "client_id", client_id)
    if not intake:
        return {"client_id": client_id, "error": "Intake not found"}

    # Get needs map
    needs_maps = storage.read_all("needs_maps")
    needs_map = None
    for nm in needs_maps:
        if nm.get("client_id") == client_id:
            needs_map = nm
            break

    company_id = intake.get("company_id", "")
    company = storage.read_by_id("companies", "company_id", company_id)
    company_name = company.get("company_name", "") if company else intake.get("client_name", "العميل")
    sector = intake.get("sector", "")
    goal = intake.get("goal", "")
    pain = intake.get("main_pain", "")
    tools = intake.get("current_tools", "")
    recommended_os = needs_map.get("recommended_os", "Dealix Operating System") if needs_map else "Dealix Operating System"

    proposal_id = f"prop_{str(uuid.uuid4())[:8]}"
    project_id = blueprint.get("project_id", "")
    blueprint_id = blueprint.get("blueprint_id", "")

    # Build proposal sections
    executive_summary = f"""هذا العرض يقدم نظام تشغيل ذكي مخصص لـ {company_name} في قطاع {sector}.

الهدف: {goal or "تحسين الكفاءة التشغيلية وتوحيد البيانات"}

النظام المقترح: {recommended_os}

القيمة المتوقعة: تبسيط العمليات، تسريع القرارات، وتحسين تجربة العملاء.

ملاحظة: الأرقام والتوقعات المذكورة هي تقديرات استكشافية وليست ضمانات."""

    current_situation = f"""حالياً، {company_name} تستخدم:
{tools or "أدوات متنوعة وربما يدوية في بعض العمليات"}

القطاع: {sector}
المخاوف الرئيسية: {pain or "تحتاج إلى استكشاف"}

{needs_map.get('hidden_need', '') if needs_map else ''}"""

    business_problem = f"""التحدي الرئيسي:
{pain or "عدم وجود نظام موحد لإدارة العمليات والمتابعة"}

الآثار:
- استهلاك وقت في مهام يمكن أتمتتها
- صعوبة في تتبع الأداء
- بيانات متفرقة
- قرارات تستند إلى معلومات جزئية

{needs_map.get('risks', '') if needs_map else ''}"""

    proposed_os = f"""{recommended_os}

المكونات:
{blueprint.get('workflow', 'سيتم تحديدها بناءً على الاحتياجات')}

دور الذكاء الاصطناعي:
{blueprint.get('ai_role', 'مساعدة في التحليل والتوليد — تحت إشراف بشري')}

المراجعة البشرية:
{blueprint.get('human_review_gates', 'كل إرسال خارجي يحتاج موافقة بشرية')}"""

    scope = f"""نطاق التنفيذ:

Phase 1: Intake & Diagnosis (أسبوع 1)
Phase 2: Blueprint & Approval (أسبوع 2)
Phase 3: Implementation (أسابيع 3-6)
Phase 4: UAT & Training (أسبوع 7)
Phase 5: Launch & Proof (أسبوع 8+)

ما هو ضمن النطاق:
- تخصيص النظام حسب الاحتياجات
- تدريب الفريق
- دعم فني

ما هو خارج النطاق:
- تغييرات في البنية التحتية
- تكاملات مع أنظمة غير متوافقة
- تطوير مخصوص خارج نطاق Operating System"""

    delivery_plan = f"""خطة التسليم:

الأسبوع 1: جمع البيانات والتشخيص
الأسبوع 2: بناء الـ Blueprint والموافقة
الأسابيع 3-4: تطوير النظام الأساسي
الأسابيع 5-6: الاختبار والتحسين
الأسبوع 7: UAT وتدريب المستخدمين
الأسبوع 8+: الإطلاق والمتابعة

سيتم تخصيص مدير مشروع من Dealix لمتابعة التنفيذ."""

    governance = f"""الحوكمة:

- كل إرسال خارجي يحتاج موافقة بشرية
- البيانات الحساسة محمية بضوابط وصول
- سجل تدقيق كامل لكل العمليات
- مراجعة دورية للأداء والامتثال
- حق العميل في الوصول إلى بياناته وحذفها
- لا مشاركة بيانات مع أطراف ثالثة"""

    success_metrics = f"""مقاييس النجاح:

{blueprint.get('acceptance_criteria', '')}

مقاييس تشغيلية:
{needs_map.get('success_metrics', '') if needs_map else '- تحسين وقت الرد\n- زيادة دقة البيانات\n- تقليل المهام اليدوية'}

ملاحظة: هذه المقاييس هي أهداف استكشافية وليست ضمانات.
النتائج الفعلية تعتمد على التزام الفريق وظروف التنفيذ."""

    next_step = f"""الخطوة التالية:

1. مراجعة هذا العرض والموافقة
2. تحديد موعد kickoff meeting
3. تفعيل بيئة العمل
4. البدء في Phase 1: Intake & Diagnosis

للموافقة أو الاستفسار: {intake.get('primary_contact', 'يرجى التواصل مع مدير المشروع')}"""

    # Policy check
    full_content = f"{executive_summary} {current_situation} {business_problem} {proposed_os}"
    gate = get_gate()
    clean, reason = gate.check_fake_claims(full_content)

    now = datetime.now().isoformat()

    proposal = {
        "proposal_id": proposal_id,
        "client_id": client_id,
        "project_id": project_id,
        "blueprint_id": blueprint_id,
        "executive_summary": executive_summary,
        "current_situation": current_situation,
        "business_problem": business_problem,
        "proposed_os": proposed_os,
        "scope": scope,
        "delivery_plan": delivery_plan,
        "governance": governance,
        "success_metrics": success_metrics,
        "next_step": next_step,
        "status": "draft",
        "created_at": now,
        "updated_at": now,
    }

    storage.append("proposals", proposal, PROPOSAL_FIELDS)
    log_proposal_created(proposal_id, f"Proposal for client {client_id}")

    return {
        "proposal_id": proposal_id,
        "client_id": client_id,
        "project_id": project_id,
        "blueprint_id": blueprint_id,
        "status": "draft",
        "policy_check": "passed" if clean else "failed",
        "policy_reason": "" if clean else reason,
    }


def approve_proposal(proposal_id: str, approved_by: str) -> Dict[str, Any]:
    """Approve a proposal."""
    storage = get_storage()
    updates = {
        "status": "approved",
        "updated_at": datetime.now().isoformat(),
    }
    storage.update_by_id("proposals", "proposal_id", proposal_id, updates, PROPOSAL_FIELDS)
    return {"proposal_id": proposal_id, "status": "approved", "approved_by": approved_by}
