"""
Dealix Client OS — Delivery Planner

Opens a project workspace with:
sprint plan, tasks, owners, UAT notes, test plan, acceptance criteria
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List
from app.client_os.storage import get_storage
from app.client_os.audit_log import log_project_started, log_delivery_milestone


PROJECT_FIELDS = [
    "project_id", "client_id", "project_name", "product_type",
    "status", "current_phase", "owner", "start_date",
    "target_launch_date", "acceptance_status", "proof_status",
    "renewal_opportunity", "next_action", "updated_at"
]

TASK_FIELDS = [
    "task_id", "project_id", "title", "owner", "status", "due_date", "created_at"
]


def create_project(
    client_id: str,
    project_name: str = "",
    product_type: str = "",
    owner: str = "",
) -> Dict[str, Any]:
    """
    Create a new client project.

    Returns:
        Dict with project data
    """
    storage = get_storage()
    intake = storage.read_by_id("client_intakes", "client_id", client_id)

    if not intake:
        return {"client_id": client_id, "error": "Intake not found"}

    project_id = f"proj_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    # Get proposal for context
    proposals = storage.read_all("proposals")
    proposal = None
    for p in proposals:
        if p.get("client_id") == client_id and p.get("status") == "approved":
            proposal = p
            break

    if not proposal:
        return {"client_id": client_id, "error": "No approved proposal found"}

    # Get blueprint
    blueprints = storage.read_all("blueprints")
    blueprint = None
    for bp in blueprints:
        if bp.get("client_id") == client_id:
            blueprint = bp
            break

    if not blueprint:
        return {"client_id": client_id, "error": "No blueprint found"}

    # Get needs map for product type
    needs_maps = storage.read_all("needs_maps")
    needs_map = None
    for nm in needs_maps:
        if nm.get("client_id") == client_id:
            needs_map = nm
            break

    project_name = project_name or f"مشروع {intake.get('client_name', client_id)}"
    product_type = product_type or (needs_map.get("recommended_os", "Dealix OS") if needs_map else "Dealix OS")

    project = {
        "project_id": project_id,
        "client_id": client_id,
        "project_name": project_name,
        "product_type": product_type,
        "status": "active",
        "current_phase": "delivery",
        "owner": owner or "Dealix Team",
        "start_date": now,
        "target_launch_date": "",
        "acceptance_status": "pending",
        "proof_status": "pending",
        "renewal_opportunity": "",
        "next_action": "بدء Sprint 1",
        "updated_at": now,
    }

    storage.append("projects", project, PROJECT_FIELDS)
    log_project_started(project_id, f"Project {project_name} started for client {client_id}")

    # Create default tasks
    tasks = create_default_tasks(project_id, blueprint)

    return {
        "project_id": project_id,
        "client_id": client_id,
        "project_name": project_name,
        "product_type": product_type,
        "current_phase": "delivery",
        "tasks_created": len(tasks),
    }


def create_default_tasks(project_id: str, blueprint: Dict[str, str]) -> List[Dict[str, Any]]:
    """Create default tasks for a project."""
    storage = get_storage()
    now = datetime.now().isoformat()

    default_tasks = [
        {"title": "إعداد البيئة والوصول", "owner": "فريق Dealix"},
        {"title": "جمع وتهيئة البيانات", "owner": "العميل + Dealix"},
        {"title": "تخصيص النظام الأساسي", "owner": "فريق Dealix"},
        {"title": "اختبار داخلي (Internal QA)", "owner": "QA Dealix"},
        {"title": "UAT مع العميل", "owner": "العميل"},
        {"title": "تدريب المستخدمين", "owner": "فريق Dealix"},
        {"title": "إطلاق النظام", "owner": "فريق Dealix"},
        {"title": "متابعة ما بعد الإطلاق", "owner": "فريق Dealix"},
    ]

    tasks = []
    for i, task_data in enumerate(default_tasks):
        task_id = f"task_{str(uuid.uuid4())[:6]}"
        task = {
            "task_id": task_id,
            "project_id": project_id,
            "title": task_data["title"],
            "owner": task_data["owner"],
            "status": "pending",
            "due_date": "",
            "created_at": now,
        }
        storage.append("tasks", task, TASK_FIELDS)
        tasks.append(task)

    return tasks


def update_task_status(task_id: str, status: str) -> Dict[str, Any]:
    """Update a task's status."""
    storage = get_storage()
    updates = {
        "status": status,
    }
    storage.update_by_id("tasks", "task_id", task_id, updates, TASK_FIELDS)
    log_delivery_milestone(task_id, f"Task status updated to {status}")
    return {"task_id": task_id, "status": status}


def get_project_tasks(project_id: str) -> List[Dict[str, str]]:
    """Get all tasks for a project."""
    storage = get_storage()
    tasks = storage.read_all("tasks")
    return [t for t in tasks if t.get("project_id") == project_id]


def get_project_summary(project_id: str) -> Dict[str, Any]:
    """Get project summary with task status."""
    storage = get_storage()
    project = storage.read_by_id("projects", "project_id", project_id)
    if not project:
        return {"project_id": project_id, "error": "Project not found"}

    tasks = get_project_tasks(project_id)
    status_counts = {}
    for task in tasks:
        s = task.get("status", "pending")
        status_counts[s] = status_counts.get(s, 0) + 1

    return {
        "project_id": project_id,
        "project_name": project.get("project_name", ""),
        "current_phase": project.get("current_phase", ""),
        "acceptance_status": project.get("acceptance_status", ""),
        "total_tasks": len(tasks),
        "task_status": status_counts,
        "next_action": project.get("next_action", ""),
    }
