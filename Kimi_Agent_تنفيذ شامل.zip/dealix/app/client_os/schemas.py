"""
Dealix Client OS — Schemas

Data models and validation for the Client Operating Loop.
Uses dataclasses for deterministic, serializable structures.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum
import csv
import json


class ConfidenceLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class VerificationStatus(str, Enum):
    UNVERIFIED = "unverified"
    PENDING = "pending"
    VERIFIED = "verified"
    FAILED = "failed"


class ApprovalStatus(str, Enum):
    DRAFT = "draft"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class OutboundMode(str, Enum):
    DRAFT_ONLY = "draft_only"
    CONTROLLED_LIVE = "controlled_live"


class Channel(str, Enum):
    EMAIL = "email"
    WHATSAPP = "whatsapp"
    LINKEDIN = "linkedin"


class ReplyCategory(str, Enum):
    INTERESTED = "interested"
    ASK_FOR_DETAILS = "ask_for_details"
    PRICE_QUESTION = "price_question"
    BOOK_MEETING = "book_meeting"
    NOT_NOW = "not_now"
    WRONG_PERSON = "wrong_person"
    OBJECTION = "objection"
    UNSUBSCRIBE = "unsubscribe"
    NO_FIT = "no_fit"
    UNKNOWN = "unknown"


class ProjectPhase(str, Enum):
    INTAKE = "intake"
    DIAGNOSIS = "diagnosis"
    BLUEPRINT = "blueprint"
    PROPOSAL = "proposal"
    DELIVERY = "delivery"
    UAT = "uat"
    PROOF = "proof"
    SUCCESS = "success"
    RENEWAL = "renewal"


@dataclass
class Company:
    company_id: str
    company_name: str
    sector: str = ""
    city: str = ""
    website: str = ""
    source_url: str = ""
    contact_page_url: str = ""
    public_email: str = ""
    phone: str = ""
    linkedin_url: str = ""
    instagram_url: str = ""
    google_maps_url: str = ""
    business_description: str = ""
    visible_services: str = ""
    visible_pain_signals: str = ""
    confidence: str = ConfidenceLevel.LOW
    verification_status: str = VerificationStatus.UNVERIFIED
    pain_hypothesis: str = ""
    recommended_offer: str = ""
    owner_decision: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_csv_row(self) -> Dict[str, str]:
        return {k: str(v) for k, v in asdict(self).items()}


@dataclass
class Contact:
    contact_id: str
    company_id: str
    name: str = ""
    title: str = ""
    email: str = ""
    phone: str = ""
    linkedin: str = ""
    is_decision_maker: bool = False
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class OutreachMessage:
    message_id: str
    company_id: str
    contact_id: str
    channel: str = Channel.EMAIL
    status: str = ApprovalStatus.DRAFT
    subject: str = ""
    body_path: str = ""
    source_url: str = ""
    verification_status: str = VerificationStatus.UNVERIFIED
    approval_status: str = ApprovalStatus.DRAFT
    approved_by: str = ""
    sent_at: str = ""
    reply_status: str = ""
    followup_due_at: str = ""
    opt_out: bool = False
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Reply:
    reply_id: str
    message_id: str
    company_id: str
    category: str = ReplyCategory.UNKNOWN
    content_summary: str = ""
    next_action: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Meeting:
    meeting_id: str
    company_id: str
    contact_id: str = ""
    scheduled_at: str = ""
    status: str = "pending"
    notes: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class ClientIntake:
    client_id: str
    company_id: str
    client_name: str = ""
    primary_contact: str = ""
    sector: str = ""
    goal: str = ""
    main_pain: str = ""
    current_tools: str = ""
    data_sources: str = ""
    decision_owner: str = ""
    review_owner: str = ""
    sensitive_data: str = ""
    external_send_required: str = "no"
    success_metric: str = ""
    intake_status: str = "pending"
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class DiagnosisLog:
    diagnosis_id: str
    client_id: str
    company_id: str
    revenue_assessment: str = ""
    followup_assessment: str = ""
    operations_assessment: str = ""
    reputation_assessment: str = ""
    data_assessment: str = ""
    team_assessment: str = ""
    ai_usage_assessment: str = ""
    governance_assessment: str = ""
    overall_risk_level: str = "medium"
    key_gaps: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class NeedsMap:
    needs_map_id: str
    client_id: str
    primary_need: str = ""
    secondary_needs: str = ""
    hidden_need: str = ""
    first_workflow: str = ""
    risks: str = ""
    recommended_os: str = ""
    success_metrics: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Blueprint:
    blueprint_id: str
    client_id: str
    project_id: str = ""
    workflow: str = ""
    users: str = ""
    inputs: str = ""
    outputs: str = ""
    data_model: str = ""
    ai_role: str = ""
    human_review_gates: str = ""
    reports: str = ""
    permissions: str = ""
    acceptance_criteria: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Proposal:
    proposal_id: str
    client_id: str
    project_id: str = ""
    blueprint_id: str = ""
    executive_summary: str = ""
    current_situation: str = ""
    business_problem: str = ""
    proposed_os: str = ""
    scope: str = ""
    delivery_plan: str = ""
    governance: str = ""
    success_metrics: str = ""
    next_step: str = ""
    status: str = ApprovalStatus.DRAFT
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Project:
    project_id: str
    client_id: str
    project_name: str = ""
    product_type: str = ""
    status: str = "active"
    current_phase: str = ProjectPhase.INTAKE
    owner: str = ""
    start_date: str = ""
    target_launch_date: str = ""
    acceptance_status: str = "pending"
    proof_status: str = "pending"
    renewal_opportunity: str = ""
    next_action: str = ""
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Task:
    task_id: str
    project_id: str
    title: str = ""
    owner: str = ""
    status: str = "pending"
    due_date: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class ProofReport:
    proof_id: str
    project_id: str
    client_id: str
    report_period: str = ""
    completed_actions: str = ""
    measured_outputs: str = ""
    open_risks: str = ""
    next_decisions: str = ""
    client_feedback: str = ""
    expansion_opportunity: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class Renewal:
    renewal_id: str
    client_id: str
    project_id: str
    health_score: int = 50
    usage_review: str = ""
    expansion_opportunities: str = ""
    renewal_recommendation: str = "pending"
    next_30_days: str = ""
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class AuditLogEntry:
    audit_id: str
    action: str
    entity_type: str
    entity_id: str
    actor: str = "system"
    details: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


def serialize_to_csv_rows(items: List[Any]) -> List[Dict[str, str]]:
    """Convert a list of dataclass instances to CSV-compatible dict rows."""
    if not items:
        return []
    return [item.to_csv_row() if hasattr(item, "to_csv_row") else {k: str(v) for k, v in asdict(item).items()} for item in items]
