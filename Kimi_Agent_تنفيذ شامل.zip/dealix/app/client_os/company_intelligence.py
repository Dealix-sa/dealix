"""
Dealix Client OS — Company Intelligence

Builds a Company Intelligence Brief summarizing:
- What the company does
- Potential customers
- Visible pain signals
- Best-fit Dealix OS
- Outreach angle
- Outreach risks
"""

import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime
from app.client_os.storage import get_storage
from app.client_os.audit_log import log_company_research


# Mapping of sectors to recommended Dealix OS offerings
SECTOR_OS_MAPPING = {
    "تجارة تجزئة": ["Revenue Command Room OS", "WhatsApp / Inbox Follow-up OS", "Review & Reputation OS"],
    "خدمات لوجستية": ["Operations & Delivery OS", "Revenue Command Room OS", "AI Trust & Compliance OS"],
    "مطاعم": ["Review & Reputation OS", "WhatsApp / Inbox Follow-up OS", "Revenue Command Room OS"],
    "رعاية صحية": ["AI Trust & Compliance OS", "Operations & Delivery OS", "Client Delivery OS"],
    "تدريب وتعليم": ["Client Delivery OS", "Revenue Command Room OS", "WhatsApp / Inbox Follow-up OS"],
    "عقارات": ["Revenue Command Room OS", "Controlled Live Outbound OS", "Review & Reputation OS"],
    "سياحة وفنادق": ["Review & Reputation OS", "Revenue Command Room OS", "Operations & Delivery OS"],
    "تقنية": ["AI Trust & Compliance OS", "Custom Enterprise Systems", "Company Brain OS"],
    "خدمات مهنية": ["Client Delivery OS", "Revenue Command Room OS", "AI Trust & Compliance OS"],
    "تجميل": ["Review & Reputation OS", "WhatsApp / Inbox Follow-up OS", "Revenue Command Room OS"],
    "سيارات": ["Revenue Command Room OS", "Operations & Delivery OS", "Review & Reputation OS"],
}


def identify_potential_customers(sector: str, description: str) -> List[str]:
    """Identify potential customer segments based on sector."""
    customer_map = {
        "تجارة تجزئة": ["المستهلك النهائي", "الشركات الصغيرة", "المقيمون المحليون"],
        "خدمات لوجستية": ["شركات التجارة الإلكترونية", "المصانع", "مستوردون"],
        "مطاعم": ["الزوار المحليون", "السياح", "شركات التوصيل"],
        "رعاية صحية": ["المرضى المحليون", "الشركات (تأمين)", "الزوار"],
        "تدريب وتعليم": ["الموظفون", "الباحثون عن عمل", "الشركات"],
        "عقارات": ["المشترون", "المستأجرون", "المستثمرون"],
        "سياحة وفنادق": ["السياح المحليون", "السياح الدوليون", "الشركات"],
        "تقنية": ["الشركات", "المطورون", "المؤسسات الحكومية"],
        "خدمات مهنية": ["الشركات الصغيرة", "الأفراد", "المؤسسات"],
        "تجميل": ["النساء", "الرجال", "صالونات التجميل"],
        "سيارات": ["أصحاب السيارات", "الشركات", "ورش الصيانة"],
    }
    return customer_map.get(sector, ["العملاء المحليون"])


def detect_outreach_risks(company: Dict[str, str]) -> List[str]:
    """Identify risks associated with outreach to this company."""
    risks = []

    if not company.get("public_email") and not company.get("contact_page_url"):
        risks.append("لا يوجد بريد إلكتروني عام أو صفحة تواصل — صعوبة في الوصول")

    if not company.get("source_url"):
        risks.append("لا يوجد مصدر للبيانات — صعوبة في التحقق")

    if "حكومي" in company.get("sector", ""):
        risks.append("قطاع حكومي — قد يحتاج مسار تواصل أطول")

    pain = company.get("visible_pain_signals", "")
    if pain and "شكوى" in pain:
        risks.append("الشركة تتلقى شكاوى — يجب أن يكون التواصل حساساً")

    if not company.get("website"):
        risks.append("لا يوجد موقع إلكتروني — قد تكون الشركة غير مهتمة بالتحول الرقمي")

    return risks if risks else ["مخاطر عادية — لا توجد مخاطر واضحة"]


def build_outreach_angle(company: Dict[str, str]) -> str:
    """Determine the best outreach angle for this company."""
    sector = company.get("sector", "")
    pain = company.get("visible_pain_signals", "")

    angles = []

    if "تأخر" in pain or "delay" in pain.lower():
        angles.append("تحسين سرعة الرد والمتابعة")

    if "شكوى" in pain or "complaint" in pain.lower():
        angles.append("إدارة الشكاوى والسمعة")

    if "صعوبة" in pain or "difficulty" in pain.lower():
        angles.append("تبسيط العمليات التشغيلية")

    if "سلبي" in pain or "negative" in pain.lower():
        angles.append("تحسين التقييمات والمراجعات")

    if not angles:
        angles.append("تحسين الإيرادات والكفاءة التشغيلية")

    return " + ".join(angles)


def generate_intelligence_brief(company_id: str) -> Dict[str, Any]:
    """
    Generate a complete Company Intelligence Brief.

    Returns:
        Dict containing all intelligence fields
    """
    storage = get_storage()
    company = storage.read_by_id("companies", "company_id", company_id)

    if not company:
        return {"company_id": company_id, "error": "Company not found"}

    sector = company.get("sector", "")
    description = company.get("business_description", "")

    # Build the brief
    brief = {
        "brief_id": f"brief_{str(uuid.uuid4())[:8]}",
        "company_id": company_id,
        "generated_at": datetime.now().isoformat(),
        "what_company_does": description or f"شركة تعمل في قطاع {sector}",
        "potential_customers": identify_potential_customers(sector, description),
        "visible_pain_signals": company.get("visible_pain_signals", "غير متوفر"),
        "recommended_os": SECTOR_OS_MAPPING.get(sector, ["Company Brain OS", "Custom Enterprise Systems"]),
        "outreach_angle": build_outreach_angle(company),
        "outreach_risks": detect_outreach_risks(company),
        "source_url": company.get("source_url", ""),
        "verification_status": company.get("verification_status", "unknown"),
        "confidence": company.get("confidence", "low"),
    }

    # Update company with recommended offer
    recommended = brief["recommended_os"][0] if brief["recommended_os"] else "Custom Solution"
    storage.update_by_id("companies", "company_id", company_id, {
        "recommended_offer": recommended,
        "updated_at": datetime.now().isoformat()
    }, [
        "company_id", "company_name", "sector", "city", "website", "source_url",
        "contact_page_url", "public_email", "phone", "linkedin_url", "instagram_url",
        "google_maps_url", "business_description", "visible_services",
        "visible_pain_signals", "confidence", "verification_status",
        "pain_hypothesis", "recommended_offer", "owner_decision",
        "created_at", "updated_at"
    ])

    log_company_research(company_id, f"Intelligence brief generated: {brief['brief_id']}")

    return brief


def get_all_intelligence_briefs() -> List[Dict[str, Any]]:
    """Get intelligence briefs for all qualified companies."""
    storage = get_storage()
    companies = storage.read_all("companies")
    briefs = []
    for company in companies:
        if company.get("verification_status") == "verified":
            brief = generate_intelligence_brief(company.get("company_id", ""))
            if "error" not in brief:
                briefs.append(brief)
    return briefs
