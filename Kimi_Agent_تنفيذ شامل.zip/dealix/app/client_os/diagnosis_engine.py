"""
Dealix Client OS — Diagnosis Engine

Produces a Company Diagnosis Report covering:
Revenue, Follow-up, Operations, Reputation, Data, Team, AI Usage, Governance
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List
from app.client_os.storage import get_storage
from app.client_os.policy_gate import get_gate
from app.client_os.audit_log import log_diagnosis_completed


DIAGNOSIS_FIELDS = [
    "diagnosis_id", "client_id", "company_id",
    "revenue_assessment", "followup_assessment", "operations_assessment",
    "reputation_assessment", "data_assessment", "team_assessment",
    "ai_usage_assessment", "governance_assessment",
    "overall_risk_level", "key_gaps", "created_at"
]

# Assessment templates
ASSESSMENT_TEMPLATES = {
    "revenue": {
        "strong": "نظام إيرادات واضح مع تتبع دوري ومؤشرات أداء محددة",
        "moderate": "هناك إيرادات لكن لا يوجد تتبع منظم أو توقعات واضحة",
        "weak": "لا يوجد نظام واضح لتتبع الإيرادات أو تحليلها",
    },
    "followup": {
        "strong": "نظام متابعة منظم مع ردود سريعة وقنوات تواصل متعددة",
        "moderate": "متابعة جزئية — بعض القنوات منظمة وبعضها عشوائي",
        "weak": "لا يوجد نظام متابعة — الردود عشوائية ومتوترة",
    },
    "operations": {
        "strong": "عمليات تشغيلية موثقة وأتمتة واضحة في معظم المهام",
        "moderate": "بعض العمليات منظمة وبعضها يعتمد على الجهد الفردي",
        "weak": "عمليات يدوية غير موثقة — يعتمد على الذاكرة الشخصية",
    },
    "reputation": {
        "strong": "حضور رقمي قوي مع إدارة نشطة للتقييمات والمراجعات",
        "moderate": "حضور رقمي جزئي — بعض المنصات مهملة",
        "weak": "حضور رقمي ضعيف — تقييمات سلبية غير مدارة",
    },
    "data": {
        "strong": "بيانات مركزية مع إدارة وصول وضوابط خصوصية",
        "moderate": "بيانات متفرقة — بعضها مركزي وبعضها محلي",
        "weak": "لا يوجد إدارة واضحة للبيانات — البيانات مهدرة أو مفقودة",
    },
    "team": {
        "strong": "فريق واضح الأدوار مع توزيع مهام محدد",
        "moderate": "فريق موجود لكن الأدوار متداخلة أحياناً",
        "weak": "فريق غير واضح — توزيع مهام غير منظم",
    },
    "ai": {
        "strong": "استخدام منتظم للأدوات الذكية مع تقييم مستمر",
        "moderate": "استخدام جزئي أو تجريبي للأدوات الذكية",
        "weak": "لا يوجد استخدام للأدوات الذكية — مقاومة للتغيير",
    },
    "governance": {
        "strong": "حوكمة واضحة مع سياسات خصوصية وامتثال",
        "moderate": "بعض السياسات موجودة لكن غير مطبقة بشكل كامل",
        "weak": "لا يوجد إطار حوكمة — مخاطر خصوصية وامتثال",
    },
}


def assess_dimension(answers: Dict[str, str], dimension: str) -> str:
    """Assess a single dimension based on intake answers."""
    score = 0
    pain = answers.get("main_pain", "").lower()
    tools = answers.get("current_tools", "").lower()

    dimension_indicators = {
        "revenue": ["إيراد", "مبيعات", "sales", "revenue", "تحويل", "conversion"],
        "followup": ["متابعة", "follow", "رد", "response", "تواصل", "communication"],
        "operations": ["تشغيل", "operation", "عملية", "process", "يدوي", "manual"],
        "reputation": ["سمعة", "reputation", "تقييم", "review", "شكوى", "complaint"],
        "data": ["بيانات", "data", "معلومات", "information", "تشتت", "scattered"],
        "team": ["فريق", "team", "موظف", "staff", "دوار", "roles"],
        "ai": ["ذكاء", "ai", "أتمتة", "automation", "تقني", "technical"],
        "governance": ["حوكمة", "governance", "خصوصية", "privacy", "امتثال", "compliance"],
    }

    indicators = dimension_indicators.get(dimension, [])
    for indicator in indicators:
        if indicator in pain or indicator in tools:
            score += 1

    if score >= 2:
        return "weak"
    elif score >= 1:
        return "moderate"
    else:
        return "strong"


def generate_diagnosis(client_id: str, answers: Dict[str, str] = None) -> Dict[str, Any]:
    """
    Generate a Company Diagnosis Report.

    Args:
        client_id: The client ID
        answers: Optional dict with intake answers for context

    Returns:
        Dict with complete diagnosis
    """
    storage = get_storage()
    intake = storage.read_by_id("client_intakes", "client_id", client_id)

    if not intake:
        return {"client_id": client_id, "error": "Intake not found"}

    # Gate check: intake must be completed
    if intake.get("intake_status") != "completed":
        return {"client_id": client_id, "error": "Intake not completed — diagnosis requires completed intake"}

    company_id = intake.get("company_id", "")
    sector = intake.get("sector", "")
    pain = intake.get("main_pain", "")
    tools = intake.get("current_tools", "")
    data_sources = intake.get("data_sources", "")

    # Build answers dict for assessment
    if answers is None:
        answers = {
            "main_pain": pain,
            "current_tools": tools,
            "data_sources": data_sources,
        }

    # Assess each dimension
    dimensions = {}
    for dim in ["revenue", "followup", "operations", "reputation", "data", "team", "ai", "governance"]:
        level = assess_dimension(answers, dim)
        dimensions[dim] = {
            "level": level,
            "assessment": ASSESSMENT_TEMPLATES[dim][level],
        }

    # Count weaknesses
    weaknesses = sum(1 for d in dimensions.values() if d["level"] == "weak")
    moderate = sum(1 for d in dimensions.values() if d["level"] == "moderate")

    if weaknesses >= 4:
        overall_risk = "high"
    elif weaknesses >= 2 or moderate >= 4:
        overall_risk = "medium"
    else:
        overall_risk = "low"

    # Identify key gaps
    gaps = []
    for dim, data in dimensions.items():
        if data["level"] in ("weak", "moderate"):
            arabic_names = {
                "revenue": "الإيرادات",
                "followup": "المتابعة",
                "operations": "التشغيل",
                "reputation": "السمعة",
                "data": "البيانات",
                "team": "الفريق",
                "ai": "استخدام الذكاء الاصطناعي",
                "governance": "الحوكمة",
            }
            gaps.append(f"{arabic_names.get(dim, dim)}: {data['assessment']}")

    diagnosis_id = f"diag_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    diagnosis = {
        "diagnosis_id": diagnosis_id,
        "client_id": client_id,
        "company_id": company_id,
        "revenue_assessment": dimensions["revenue"]["assessment"],
        "followup_assessment": dimensions["followup"]["assessment"],
        "operations_assessment": dimensions["operations"]["assessment"],
        "reputation_assessment": dimensions["reputation"]["assessment"],
        "data_assessment": dimensions["data"]["assessment"],
        "team_assessment": dimensions["team"]["assessment"],
        "ai_usage_assessment": dimensions["ai"]["assessment"],
        "governance_assessment": dimensions["governance"]["assessment"],
        "overall_risk_level": overall_risk,
        "key_gaps": " | ".join(gaps),
        "created_at": now,
    }

    storage.append("diagnosis_log", diagnosis, DIAGNOSIS_FIELDS)
    log_diagnosis_completed(diagnosis_id, f"Diagnosis completed for client {client_id}")

    return {
        "diagnosis_id": diagnosis_id,
        "client_id": client_id,
        "company_id": company_id,
        "dimensions": {k: v for k, v in dimensions.items()},
        "overall_risk": overall_risk,
        "key_gaps": gaps,
        "created_at": now,
    }


def get_diagnosis(client_id: str) -> Dict[str, Any]:
    """Get existing diagnosis for a client."""
    storage = get_storage()
    diagnoses = storage.read_all("diagnosis_log")
    for d in diagnoses:
        if d.get("client_id") == client_id:
            return d
    return {}
