"""
Dealix Client OS — Discovery Brief

Prepares a pre-call brief summarizing company info,
pain hypothesis, suggested questions, recommended offer, risks, and call goal.
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List
from app.client_os.storage import get_storage


# Suggested discovery questions by sector
SECTOR_QUESTIONS = {
    "تجارة تجزئة": [
        "كيف تديرون المتابعة مع العملاء بعد الاستفسار الأول؟",
        "كم من الوقت يستغرق الرد على رسائل العملاء؟",
        "هل لديكم نظام لتتبع رحلة العميل من الاستفسار إلى الشراء؟",
        "كيف تتعاملون مع التقييمات السلبية؟",
    ],
    "خدمات لوجستية": [
        "كيف يتابع العميل شحنته حالياً؟",
        "ما أكثر شكوى متكررة من العملاء؟",
        "هل لديكم نظام موحد للتواصل الداخلي؟",
        "كيف تديرون العلاقة مع الشركاء اللوجستيين؟",
    ],
    "مطاعم": [
        "كيف يحجز العميل حالياً؟ هل هناك أخطاء متكررة؟",
        "كيف تتعاملون مع تقييمات جوجل والمنصات الأخرى؟",
        "هل لديكم نظام لمتابعة طلبات التوصيل؟",
        "كم نسبة الغياب عن الحجوزات؟",
    ],
    "رعاية صحية": [
        "كيف يحجز المريض حالياً؟",
        "هل لديكم صعوبات في متابعة المواعيد؟",
        "كيف تديرون البيانات الحساسة؟",
        "هل هناك نظام لمتابعة المرضى بعد الزيارة؟",
    ],
    "تدريب وتعليم": [
        "كيف تتبعون تقدم المتدربين حالياً؟",
        "هل لديكم صعوبة في إدارة التسجيل؟",
        "كيف تتواصلون مع الخريجين؟",
        "هل هناك تحديات في جدولة البرامج؟",
    ],
    "عقارات": [
        "كيف تديرون المتابعة مع العملاء المحتملين؟",
        "هل لديكم نظام لتتبع المراحل التفاوضية؟",
        "كم متوسط وقت الرد على الاستفسار؟",
        "كيف تتواصلون مع العملاء بعد الإغلاق؟",
    ],
    "سياحة وفنادق": [
        "كيف تديرون المراجعات على المنصات المختلفة؟",
        "هل لديكم نظام لمتابعة تجربة النزيل؟",
        "كيف تتواصلون مع النزلاء قبل الوصول وبعد المغادرة؟",
        "ما أكثر شكوى متكررة؟",
    ],
}

DEFAULT_QUESTIONS = [
    "ما أكبر تحدي تواجهونه حالياً في التشغيل؟",
    "كيف تديرون المتابعة مع العملاء والشركاء؟",
    "هل لديكم نظام موحد للبيانات أم أن المعلومات متفرقة؟",
    "من يتخذ القرارات التشغيلية اليومية؟",
]


def generate_discovery_brief(company_id: str) -> Dict[str, Any]:
    """
    Generate a pre-call discovery brief.

    Returns:
        Dict with complete brief information
    """
    storage = get_storage()
    company = storage.read_by_id("companies", "company_id", company_id)

    if not company:
        return {"company_id": company_id, "error": "Company not found"}

    sector = company.get("sector", "")
    pain = company.get("pain_hypothesis", "")
    recommended = company.get("recommended_offer", "")

    # Get suggested questions
    questions = SECTOR_QUESTIONS.get(sector, DEFAULT_QUESTIONS)

    # Build call goal
    if pain:
        call_goal = f"التحقق من فرضية الألم والتأكد من الاحتياج الفعلي لـ {recommended or 'حلول Dealix'}"
    else:
        call_goal = "استكشاف الاحتياجات التشغيلية وفهم التحديات الرئيسية"

    # Assess risks
    risks = []
    if not company.get("source_url"):
        risks.append("لا يوجد مصدر موثق — يحتاج إلى التحقق")
    if not company.get("website"):
        risks.append("لا يوجد موقع إلكتروني — قد يكون العميل غير مهتم بالتحول الرقمي")
    if not risks:
        risks.append("مخاطر عادية — لا توجد مخاطر واضحة")

    brief = {
        "brief_id": f"db_{str(uuid.uuid4())[:8]}",
        "company_id": company_id,
        "company_name": company.get("company_name", ""),
        "sector": sector,
        "company_summary": company.get("business_description", f"شركة في قطاع {sector}"),
        "pain_hypothesis": pain or "يحتاج إلى استكشاف",
        "suggested_questions": questions,
        "recommended_offer": recommended or "استكشافي — يحدد بعد المكالمة",
        "risks": risks,
        "call_goal": call_goal,
        "prepared_at": datetime.now().isoformat(),
    }

    return brief
