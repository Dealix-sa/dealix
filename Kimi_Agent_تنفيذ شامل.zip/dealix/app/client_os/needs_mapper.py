"""
Dealix Client OS — Needs Mapper

Produces a Needs Map:
- primary need
- secondary needs
- hidden need
- first workflow
- risks
- recommended OS
- success metrics
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List
from app.client_os.storage import get_storage
from app.client_os.audit_log import log_action


NEEDS_MAP_FIELDS = [
    "needs_map_id", "client_id", "primary_need", "secondary_needs",
    "hidden_need", "first_workflow", "risks", "recommended_os",
    "success_metrics", "created_at"
]

# Sector to recommended OS mapping
SECTOR_OS_RECOMMENDATION = {
    "تجارة تجزئة": {
        "primary": "Revenue Command Room OS",
        "secondary": ["WhatsApp / Inbox Follow-up OS", "Review & Reputation OS"],
        "workflow": "متابعة العميل من الاستفسار إلى الشراء",
    },
    "خدمات لوجستية": {
        "primary": "Operations & Delivery OS",
        "secondary": ["Revenue Command Room OS", "AI Trust & Compliance OS"],
        "workflow": "تتبع الشحنة وإشعار العميل تلقائياً",
    },
    "مطاعم": {
        "primary": "Review & Reputation OS",
        "secondary": ["WhatsApp / Inbox Follow-up OS", "Revenue Command Room OS"],
        "workflow": "حجز المواعيد وإدارة التقييمات",
    },
    "رعاية صحية": {
        "primary": "AI Trust & Compliance OS",
        "secondary": ["Operations & Delivery OS", "Client Delivery OS"],
        "workflow": "حجز المواعيد ومتابعة المريض",
    },
    "تدريب وتعليم": {
        "primary": "Client Delivery OS",
        "secondary": ["Revenue Command Room OS", "WhatsApp / Inbox Follow-up OS"],
        "workflow": "تتبع تقدم المتدرب وإشعاره",
    },
    "عقارات": {
        "primary": "Revenue Command Room OS",
        "secondary": ["Controlled Live Outbound OS", "Review & Reputation OS"],
        "workflow": "متابعة العميل المحتمل من الاستفسار إلى الإغلاق",
    },
    "سياحة وفنادق": {
        "primary": "Review & Reputation OS",
        "secondary": ["Revenue Command Room OS", "Operations & Delivery OS"],
        "workflow": "متابعة تجربة النزيل قبل وبعد الإقامة",
    },
    "تقنية": {
        "primary": "Custom Enterprise Systems",
        "secondary": ["AI Trust & Compliance OS", "Company Brain OS"],
        "workflow": "إدارة المشاريع والقرارات اليومية",
    },
    "خدمات مهنية": {
        "primary": "Client Delivery OS",
        "secondary": ["Revenue Command Room OS", "AI Trust & Compliance OS"],
        "workflow": "إدارة المواعيد ومتابعة الحالات",
    },
    "تجميل": {
        "primary": "Review & Reputation OS",
        "secondary": ["WhatsApp / Inbox Follow-up OS", "Revenue Command Room OS"],
        "workflow": "حجز المواعيد ومتابعة التقييمات",
    },
    "سيارات": {
        "primary": "Revenue Command Room OS",
        "secondary": ["Operations & Delivery OS", "Review & Reputation OS"],
        "workflow": "حجز الصيانة ومتابعة العميل",
    },
}


def generate_needs_map(client_id: str) -> Dict[str, Any]:
    """
    Generate a Needs Map based on intake and diagnosis.

    Returns:
        Dict with complete needs map
    """
    storage = get_storage()
    intake = storage.read_by_id("client_intakes", "client_id", client_id)

    if not intake:
        return {"client_id": client_id, "error": "Intake not found"}

    # Get diagnosis for context
    diagnoses = storage.read_all("diagnosis_log")
    diagnosis = None
    for d in diagnoses:
        if d.get("client_id") == client_id:
            diagnosis = d
            break

    sector = intake.get("sector", "")
    goal = intake.get("goal", "")
    pain = intake.get("main_pain", "")
    tools = intake.get("current_tools", "")
    sensitive = intake.get("sensitive_data", "")

    # Get sector recommendations
    sector_rec = SECTOR_OS_RECOMMENDATION.get(sector, {
        "primary": "Company Brain OS",
        "secondary": ["Custom Enterprise Systems"],
        "workflow": "تحليل العمليات وتحسينها",
    })

    # Determine primary need
    primary_need = goal or f"تحسين {sector_rec['primary']}"

    # Secondary needs
    secondary_needs = sector_rec["secondary"]

    # Hidden need — inferred from diagnosis or pain
    if diagnosis:
        weak_dimensions = []
        for dim in ["revenue", "followup", "operations", "reputation", "data", "team", "ai", "governance"]:
            if diagnosis.get(f"{dim}_assessment", "").startswith("لا يوجد") or "ضعيف" in diagnosis.get(f"{dim}_assessment", ""):
                weak_dimensions.append(dim)
        if weak_dimensions:
            hidden_need = f"ربما هناك حاجة ضمنية لتحسين: {', '.join(weak_dimensions[:2])}"
        else:
            hidden_need = "تحليق أعمق في البيانات لاكتشاف فرص غير واضحة"
    else:
        hidden_need = "يحتاج إلى تشخيص أعمق"

    # First workflow
    first_workflow = sector_rec["workflow"]

    # Risks
    risks = []
    if "يدوي" in tools or "manual" in tools.lower():
        risks.append("التحول من النظام اليدوي قد يواجه مقاومة من الفريق")
    if sensitive and sensitive != "لا يوجد":
        risks.append(f"بيانات حساسة: {sensitive} — تحتاج ضوابط خصوصية")
    if not risks:
        risks.append("مخاطر تنفيذ عادية — فريق Dealix جاهز للتعامل معها")

    # Success metrics
    success_metrics = [
        "تقليل وقت الرد على العملاء بنسبة 50%",
        "زيادة معدل التحويل من استفسار إلى عميل",
        "توحيد البيانات في لوحة تحكم واحدة",
    ]
    custom_metric = intake.get("success_metric", "")
    if custom_metric:
        success_metrics.insert(0, custom_metric)

    needs_map_id = f"nm_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    needs_map = {
        "needs_map_id": needs_map_id,
        "client_id": client_id,
        "primary_need": primary_need,
        "secondary_needs": " | ".join(secondary_needs),
        "hidden_need": hidden_need,
        "first_workflow": first_workflow,
        "risks": " | ".join(risks),
        "recommended_os": sector_rec["primary"],
        "success_metrics": " | ".join(success_metrics),
        "created_at": now,
    }

    storage.append("needs_maps", needs_map, NEEDS_MAP_FIELDS)
    log_action("needs_map_created", "needs_map", needs_map_id, "system", f"Needs map for client {client_id}")

    return {
        "needs_map_id": needs_map_id,
        "client_id": client_id,
        "primary_need": primary_need,
        "secondary_needs": secondary_needs,
        "hidden_need": hidden_need,
        "first_workflow": first_workflow,
        "risks": risks,
        "recommended_os": sector_rec["primary"],
        "success_metrics": success_metrics,
    }
