"""
Dealix Client OS — Pain Hypothesis

Creates pain hypotheses using cautious, non-assertive language.
Avoids guaranteed claims. Uses probabilistic framing.
"""

from typing import Dict, Any, List
from app.client_os.storage import get_storage


# Blocked phrases that must never appear
BLOCKED_PHRASES = [
    "واضح أنكم تفشلون",
    "نضمن زيادة المبيعات",
    "راح نرفع الإيراد بنسبة",
    "نضمن نتائج",
    "نتائج مضمونة",
    "100% نجاح",
    "نضاعف إيراداتك",
    "أرباح مضمونة",
    "ضعف أرباحك",
]

# Safe hypothesis phrases
HYPOTHESIS_FRAMES = [
    "غالبًا",
    "قد يكون",
    "في شركات هذا القطاع",
    "نحتاج نتحقق في مكالمة قصيرة",
    "من الشائع في هذا القطاع",
    "من الممكن",
    "يبدو أن",
    "في كثير من الحالات المشابهة",
]

# Sector-specific hypothesis templates
SECTOR_PAIN_TEMPLATES = {
    "تجارة تجزئة": [
        "{frame} أن التأخر في الرد على استفسارات العملاء يؤثر على معدل التحويل",
        "{frame} أن إدارة المتابعة عبر واتساب تحتاج إلى تنظيم أفضل",
        "{frame} أن التقييمات الإيجابية تلعب دوراً في قرارات الشراء",
    ],
    "خدمات لوجستية": [
        "{frame} أن صعوبة تتبع الشحنات تسبب إزعاجاً للعملاء",
        "{frame} أن التأخير في التواصل يؤثر على العلاقة مع الشركاء",
        "{frame} أن العمليات اليدوية تستهلك وقتًا يمكن توجيهه للنمو",
    ],
    "مطاعم": [
        "{frame} أن إدارة الحجوزات يدوياً تسبب أخطاء وتضارب",
        "{frame} أن الرد على التقييمات السلبية يحتاج سرعة وأسلوب محدد",
        "{frame} أن متابعة طلبات التوصيل تحتاج إلى نظام موحد",
    ],
    "رعاية صحية": [
        "{frame} أن إدارة مواعيد المرضى تحتاج إلى أتمتة لتقليل الغياب",
        "{frame} أن التعامل مع البيانات الحساسة يحتاج ضوابط خصوصية",
        "{frame} أن متابعة المرضى بعد الزيارة تؤثر على رضاهم",
    ],
    "تدريب وتعليم": [
        "{frame} أن تتبع تقدم المتدربين يحتاج إلى نظام مركزي",
        "{frame} أن التواصل مع الخريجين يفقد بعد إنهاء البرنامج",
        "{frame} أن إدارة التسجيل يدوياً يسبب أخطاء",
    ],
    "عقارات": [
        "{frame} أن إدارة المتابعة مع العملاء المحتملين تحتاج تنظيماً",
        "{frame} أن تتبع المراحل التفاوضية يحتاج إلى توثيق",
        "{frame} أن الرد السريع على الاستفسارات يؤثر على معدل الإغلاق",
    ],
    "سياحة وفنادق": [
        "{frame} أن إدارة المراجعات على منصات متعددة تحتاج جهد موحد",
        "{frame} أن تجربة النزيل تبدأ من أول تواصل",
        "{frame} أن المتابعة بعد المغادرة تفتح فرصاً للتجديد",
    ],
    "تقنية": [
        "{frame} أن تتبع المشاريع التقنية يحتاج إلى شفافية أكبر",
        "{frame} أن إدارة البيانات تحتاج إلى حوكمة وضوابط",
        "{frame} أن القرارات اليومية تستفيد من رؤية موحدة للبيانات",
    ],
    "خدمات مهنية": [
        "{frame} أن إدارة المواعيد والمتابعة مع العملاء تحتاج تنظيماً",
        "{frame} أن التوثيق الداخلي يستهلك وقتاً يمكن تقليصه",
        "{frame} أن تتبع حالات العملاء يحتاج إلى نظام مركزي",
    ],
    "تجميل": [
        "{frame} أن إدارة حجوزات المواعيد تحتاج إلى أتمتة",
        "{frame} أن التقييمات والصور قبل/بعد تؤثر على قرارات العملاء",
        "{frame} أن متابعة العملاء بعد الخدمة تفتح فرصاً للتجديد",
    ],
    "سيارات": [
        "{frame} أن إدارة حجوزات الصيانة تحتاج إلى تنظيم أفضل",
        "{frame} أن التواصل مع العملاء بعد الخدمة يؤثر على ولائهم",
        "{frame} أن تتبع قطع الغيار والمخزون يحتاج إلى دقة أكبر",
    ],
}


def validate_hypothesis_language(text: str) -> tuple:
    """Validate that hypothesis text doesn't contain blocked phrases."""
    for phrase in BLOCKED_PHRASES:
        if phrase.lower() in text.lower():
            return False, f"Blocked phrase detected: {phrase}"
    return True, "Language is compliant"


def generate_pain_hypothesis(company_id: str) -> Dict[str, Any]:
    """
    Generate a pain hypothesis for a company using safe, cautious language.

    Returns:
        Dict with hypothesis and validation status
    """
    storage = get_storage()
    company = storage.read_by_id("companies", "company_id", company_id)

    if not company:
        return {"company_id": company_id, "error": "Company not found"}

    sector = company.get("sector", "")
    pain_signals = company.get("visible_pain_signals", "")

    # Get templates for this sector
    templates = SECTOR_PAIN_TEMPLATES.get(sector, [
        "{frame} أن هناك فرصة لتحسين العمليات التشغيلية",
        "{frame} أن التواصل مع العملاء يحتاج إلى تنظيم أفضل",
    ])

    import random
    frame = random.choice(HYPOTHESIS_FRAMES)

    # Select 2 relevant templates
    selected_templates = random.sample(templates, min(2, len(templates)))

    hypotheses = []
    for template in selected_templates:
        hypothesis = template.format(frame=frame)
        valid, reason = validate_hypothesis_language(hypothesis)
        if valid:
            hypotheses.append(hypothesis)
        else:
            # Fallback to safe language
            hypotheses.append(f"{frame} أن هناك مجال للتحسين في العمليات التشغيلية")

    # Add pain signal reference if available
    if pain_signals:
        signal_hypothesis = f"{frame} أن '{pain_signals}' قد يكون مؤشراً على فرصة للتحسين"
        valid, _ = validate_hypothesis_language(signal_hypothesis)
        if valid:
            hypotheses.append(signal_hypothesis)

    full_hypothesis = " | ".join(hypotheses)

    # Update company record
    from datetime import datetime
    company_fields = [
        "company_id", "company_name", "sector", "city", "website", "source_url",
        "contact_page_url", "public_email", "phone", "linkedin_url", "instagram_url",
        "google_maps_url", "business_description", "visible_services",
        "visible_pain_signals", "confidence", "verification_status",
        "pain_hypothesis", "recommended_offer", "owner_decision",
        "created_at", "updated_at"
    ]
    storage.update_by_id("companies", "company_id", company_id, {
        "pain_hypothesis": full_hypothesis,
        "updated_at": datetime.now().isoformat()
    }, company_fields)

    return {
        "company_id": company_id,
        "company_name": company.get("company_name", ""),
        "pain_hypothesis": full_hypothesis,
        "hypotheses": hypotheses,
        "language_validated": True,
        "frame_used": frame,
    }


def batch_generate_hypotheses() -> List[Dict[str, Any]]:
    """Generate pain hypotheses for all qualified companies."""
    storage = get_storage()
    companies = storage.read_all("companies")
    results = []
    for company in companies:
        if company.get("verification_status") in ("verified", "pending"):
            result = generate_pain_hypothesis(company.get("company_id", ""))
            if "error" not in result:
                results.append(result)
    return results
