"""
Dealix Client OS — Blueprint Builder

Produces a System Blueprint covering:
workflow, users, inputs, outputs, data model, AI role,
human review gates, reports, permissions, acceptance criteria
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List
from app.client_os.storage import get_storage
from app.client_os.audit_log import log_blueprint_created


BLUEPRINT_FIELDS = [
    "blueprint_id", "client_id", "project_id",
    "workflow", "users", "inputs", "outputs",
    "data_model", "ai_role", "human_review_gates",
    "reports", "permissions", "acceptance_criteria",
    "created_at", "updated_at"
]


def generate_blueprint(client_id: str, project_id: str = "") -> Dict[str, Any]:
    """
    Generate a System Blueprint based on needs map and diagnosis.

    Returns:
        Dict with complete blueprint
    """
    storage = get_storage()
    intake = storage.read_by_id("client_intakes", "client_id", client_id)

    if not intake:
        return {"client_id": client_id, "error": "Intake not found"}

    # Get needs map
    needs_maps = storage.read_all("needs_maps")
    needs_map = None
    for nm in needs_maps:
        if nm.get("client_id") == client_id:
            needs_map = nm
            break

    if not needs_map:
        return {"client_id": client_id, "error": "Needs map not found — generate needs map first"}

    sector = intake.get("sector", "")
    goal = intake.get("goal", "")
    primary_need = needs_map.get("primary_need", "")
    recommended_os = needs_map.get("recommended_os", "Custom Enterprise Systems")
    first_workflow = needs_map.get("first_workflow", "")

    # Build blueprint components
    blueprint_id = f"bp_{str(uuid.uuid4())[:8]}"
    if not project_id:
        project_id = f"proj_{str(uuid.uuid4())[:8]}"

    # Workflow
    workflow = f"""1. {first_workflow}
2. جمع البيانات من المصادر المحددة
3. معالجة البيانات بواسطة النظام
4. توليد التقارير والإشعارات
5. مراجعة بشرية للقرارات الحساسة
6. إرسال للعميل عبر القنوات المعتمدة
7. قياس النتائج وتحسين الأداء"""

    # Users
    users = f"""- مدير النظام: صلاحيات كاملة
- مستخدم تشغيلي: إدخال بيانات ومتابعة
- مراجع: مراجعة تقارير والموافقة
- عميل نهائي: استلام إشعارات وتقارير"""

    # Inputs
    inputs = f"""- بيانات العملاء من: {intake.get('data_sources', 'المصادر المحددة')}
- إشعارات وطلبات جديدة
- تحديثات دورية من الفريق"""

    # Outputs
    outputs = f"""- تقارير أداء دورية
- إشعارات تلقائية للعملاء
- لوحة تحكم مركزية
- سجل تدقيق كامل"""

    # Data Model
    data_model = f"""- clients: معلومات العملاء الأساسية
- interactions: سجل التفاعلات
- reports: التقارير المولدة
- audit_log: سجل العمليات
- users: المستخدمون والصلاحيات"""

    # AI Role
    ai_role = f"""- تصنيف الرسائل والاستفسارات تلقائياً
- توليد ملخصات للتقارير
- اقتراح إجراءات بناءً على الأنماط
- مساعدة في صياغة الردود (تحتاج موافقة بشرية)"""

    # Human Review Gates
    human_gates = f"""- الموافقة على الردود الخارجية قبل الإرسال
- مراجعة التقارير الشهرية
- التحقق من البيانات الحساسة
- قرارات التوسعة أو التغيير في النطاق"""

    # Reports
    reports = f"""- تقرير يومي: ملخص النشاط
- تقرير أسبوعي: الأداء والمقاييس
- تقرير شهري: تحليل شامل + توصيات"""

    # Permissions
    permissions = f"""- ADMIN: كامل الصلاحيات
- OPERATOR: إدخال + عرض
- REVIEWER: عرض + موافقة
- CLIENT: عرض التقارير فقط"""

    # Acceptance Criteria
    acceptance_criteria = f"""[ ] النظام يعمل بدون أخطاء فنية
[ ] البيانات تتدفق بشكل صحيح بين جميع الأجزاء
[ ] التقارير تولد بشكل دقيق
[ ] الإشعارات ترسل في الوقت المحدد
[ ] المراجعة البشرية تعمل عند كل نقطة gate
[ ] الفريق تم تدريبه على استخدام النظام
[ ] العميل وافق على النتائج"""

    now = datetime.now().isoformat()

    blueprint = {
        "blueprint_id": blueprint_id,
        "client_id": client_id,
        "project_id": project_id,
        "workflow": workflow,
        "users": users,
        "inputs": inputs,
        "outputs": outputs,
        "data_model": data_model,
        "ai_role": ai_role,
        "human_review_gates": human_gates,
        "reports": reports,
        "permissions": permissions,
        "acceptance_criteria": acceptance_criteria,
        "created_at": now,
        "updated_at": now,
    }

    storage.append("blueprints", blueprint, BLUEPRINT_FIELDS)
    log_blueprint_created(blueprint_id, f"Blueprint for client {client_id}, project {project_id}")

    return {
        "blueprint_id": blueprint_id,
        "project_id": project_id,
        "client_id": client_id,
        "recommended_os": recommended_os,
        "workflow_summary": first_workflow,
        "acceptance_criteria": acceptance_criteria,
        "created_at": now,
    }


def get_blueprint(client_id: str) -> Dict[str, Any]:
    """Get blueprint for a client."""
    storage = get_storage()
    blueprints = storage.read_all("blueprints")
    for bp in blueprints:
        if bp.get("client_id") == client_id:
            return bp
    return {}
