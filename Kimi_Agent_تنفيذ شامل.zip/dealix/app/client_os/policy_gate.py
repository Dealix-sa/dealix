"""
Dealix Client OS — Policy Gate

Enforces governance rules across the client operating loop.
No uncontrolled external send. No fake claims. No bypass.
"""

import os
from typing import Dict, Any, Optional, Tuple


def get_env_bool(key: str, default: bool = False) -> bool:
    val = os.environ.get(key, "true" if default else "false").lower()
    return val in ("true", "1", "yes", "on")


def get_env_str(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


class PolicyGate:
    """
    Central policy enforcement for Dealix Client OS.
    Every external action must pass through here first.
    """

    # ---- Outbound Safety Defaults ----
    EXTERNAL_SEND_ENABLED = get_env_bool("EXTERNAL_SEND_ENABLED", False)
    EMAIL_SEND_ENABLED = get_env_bool("EMAIL_SEND_ENABLED", False)
    WHATSAPP_SEND_ENABLED = get_env_bool("WHATSAPP_SEND_ENABLED", False)
    WHATSAPP_ALLOW_LIVE_SEND = get_env_bool("WHATSAPP_ALLOW_LIVE_SEND", False)
    OUTBOUND_MODE = get_env_str("OUTBOUND_MODE", "draft_only")
    OUTBOUND_REQUIRE_APPROVAL = get_env_bool("OUTBOUND_REQUIRE_APPROVAL", True)
    OUTBOUND_REQUIRE_VERIFIED_TARGET = get_env_bool("OUTBOUND_REQUIRE_VERIFIED_TARGET", True)
    OUTBOUND_REQUIRE_SOURCE_URL = get_env_bool("OUTBOUND_REQUIRE_SOURCE_URL", True)
    OUTBOUND_BLOCK_FAKE_CLAIMS = get_env_bool("OUTBOUND_BLOCK_FAKE_CLAIMS", True)
    OUTBOUND_BLOCK_GUARANTEED_ROI = get_env_bool("OUTBOUND_BLOCK_GUARANTEED_ROI", True)

    # ---- Thresholds ----
    EMAIL_DAILY_LIMIT = int(get_env_str("EMAIL_DAILY_LIMIT", "25"))
    WHATSAPP_DAILY_LIMIT = int(get_env_str("WHATSAPP_DAILY_LIMIT", "50"))

    # ---- Fake Claim Detection ----
    BLOCKED_PHRASES = [
        "نضمن زيادة المبيعات",
        "نضاعف إيراداتك",
        "نضمن",
        "راح نرفع الإيراد بنسبة",
        "نضمن نتائج",
        "نتائج مضمونة",
        "100% نجاح",
        "نتائج 100% مضمونة",
        "زيادة مبيعاتك فوراً",
        "ارباح مضمونة",
        "أرباح مضمونة",
        "ضعف ارباحك",
    ]

    def can_send_externally(self, message: Dict[str, Any]) -> Tuple[bool, str]:
        """Check if a message can be sent externally. Returns (allowed, reason)."""

        if not self.EXTERNAL_SEND_ENABLED:
            return False, "EXTERNAL_SEND_ENABLED is false — all external sending is disabled by default"

        if self.OUTBOUND_MODE != "controlled_live":
            return False, f"OUTBOUND_MODE is {self.OUTBOUND_MODE} — must be 'controlled_live'"

        if self.OUTBOUND_REQUIRE_APPROVAL and message.get("approval_status") != "approved":
            return False, "Message not approved — approval_status must be 'approved'"

        if self.OUTBOUND_REQUIRE_VERIFIED_TARGET and message.get("verification_status") != "verified":
            return False, "Target not verified — verification_status must be 'verified'"

        if self.OUTBOUND_REQUIRE_SOURCE_URL and not message.get("source_url"):
            return False, "Missing source_url — required for all outbound"

        if message.get("opt_out"):
            return False, "Contact opted out — cannot send"

        channel = message.get("channel", "email")

        if channel == "email" and not self.EMAIL_SEND_ENABLED:
            return False, "EMAIL_SEND_ENABLED is false"

        if channel == "whatsapp":
            if not self.WHATSAPP_SEND_ENABLED:
                return False, "WHATSAPP_SEND_ENABLED is false"
            if not self.WHATSAPP_ALLOW_LIVE_SEND:
                return False, "WHATSAPP_ALLOW_LIVE_SEND is false"
            if message.get("opt_in") != "true":
                return False, "WhatsApp requires opt-in consent"

        # Check suppression list
        from app.client_os.storage import get_storage
        ledger = get_storage()
        suppressed = ledger.read_all("suppression_list")
        contact_id = message.get("contact_id", "")
        company_id = message.get("company_id", "")
        for entry in suppressed:
            if entry.get("contact_id") == contact_id or entry.get("company_id") == company_id:
                return False, "Target is in suppression list"

        return True, "Policy check passed"

    def check_fake_claims(self, content: str) -> Tuple[bool, str]:
        """Check if content contains fake/guaranteed claims. Returns (clean, reason)."""
        if not self.OUTBOUND_BLOCK_FAKE_CLAIMS:
            return True, "Fake claim blocking disabled"

        if not self.OUTBOUND_BLOCK_GUARANTEED_ROI:
            return True, "Guaranteed ROI blocking disabled"

        for phrase in self.BLOCKED_PHRASES:
            if phrase.lower() in content.lower():
                return False, f"Blocked phrase detected: '{phrase}'"

        return True, "Content is clean"

    def check_intake_before_diagnosis(self, client_id: str) -> Tuple[bool, str]:
        """Ensure client has completed intake before diagnosis."""
        from app.client_os.storage import get_storage
        ledger = get_storage()
        intakes = ledger.read_all("client_intakes")
        for intake in intakes:
            if intake.get("client_id") == client_id and intake.get("intake_status") == "completed":
                return True, "Intake completed"
            if intake.get("client_id") == client_id:
                return False, "Intake exists but not completed"
        return False, "No intake found for client"

    def check_blueprint_before_proposal(self, client_id: str) -> Tuple[bool, str]:
        """Ensure blueprint exists before proposal."""
        from app.client_os.storage import get_storage
        ledger = get_storage()
        blueprints = ledger.read_all("blueprints")
        for bp in blueprints:
            if bp.get("client_id") == client_id:
                return True, "Blueprint exists"
        return False, "No blueprint found — blueprint required before proposal"

    def check_acceptance_before_delivery(self, project_id: str) -> Tuple[bool, str]:
        """Ensure acceptance criteria exist before delivery."""
        from app.client_os.storage import get_storage
        ledger = get_storage()
        projects = ledger.read_all("projects")
        for proj in projects:
            if proj.get("project_id") == project_id:
                if proj.get("acceptance_status") == "accepted":
                    return True, "Acceptance criteria accepted"
                return False, f"Acceptance status: {proj.get('acceptance_status', 'pending')}"
        return False, "Project not found"

    def check_project_before_proof(self, project_id: str) -> Tuple[bool, str]:
        """Ensure project exists before proof report."""
        from app.client_os.storage import get_storage
        ledger = get_storage()
        projects = ledger.read_all("projects")
        for proj in projects:
            if proj.get("project_id") == project_id:
                return True, "Project exists"
        return False, "No project found — proof report requires active project"

    def check_whatsapp_compliance(self, contact: Dict[str, Any]) -> Tuple[bool, str]:
        """Check WhatsApp-specific compliance requirements."""
        if not self.WHATSAPP_SEND_ENABLED:
            return False, "WhatsApp sending disabled"

        if not self.WHATSAPP_ALLOW_LIVE_SEND:
            return False, "WhatsApp live send not allowed"

        if contact.get("opt_in") != "true":
            return False, "WhatsApp requires explicit opt-in"

        return True, "WhatsApp compliant"

    def validate_source_url(self, company: Dict[str, Any]) -> Tuple[bool, str]:
        """Validate that a company has a source URL."""
        if self.OUTBOUND_REQUIRE_SOURCE_URL and not company.get("source_url"):
            return False, "Company missing source_url"
        return True, "Source URL present"


gate = PolicyGate()


def get_gate() -> PolicyGate:
    return gate
