"""
Dealix Client Operating Loop OS

End-to-end client lifecycle management:
Target Research -> Company Intelligence -> Pain Hypothesis -> Outreach Draft ->
Human Approval -> Controlled Send -> Reply Classification -> Meeting Booking ->
Client Intake -> Company Diagnosis -> Needs Map -> Solution Blueprint ->
Proposal Draft -> Client Project Workspace -> Delivery Plan -> UAT ->
Proof Report -> Monthly Client Success -> Expansion / Renewal

Part of: Dealix — AI Operating Systems for Companies
"""

__version__ = "1.0.0"
__all__ = [
    "schemas",
    "storage",
    "company_research",
    "qualification",
    "company_intelligence",
    "pain_hypothesis",
    "outreach_draft",
    "reply_classifier",
    "discovery_brief",
    "intake_engine",
    "diagnosis_engine",
    "needs_mapper",
    "blueprint_builder",
    "proposal_builder",
    "delivery_planner",
    "proof_reporter",
    "client_success",
    "policy_gate",
    "audit_log",
]
