"""
Dealix Client OS — Reply Classifier

Classifies replies into categories and suggests next actions.
Deterministic keyword-based classification (no external API).
"""

import uuid
from datetime import datetime
from typing import Dict, Any, List, Tuple
from app.client_os.storage import get_storage
from app.client_os.schemas import ReplyCategory
from app.client_os.audit_log import log_reply_received


# Keyword mappings for classification
CLASSIFICATION_KEYWORDS = {
    ReplyCategory.INTERESTED: [
        "مهتم", "أحب نعرف أكثر", "ممكن نتواصل", "نرغب", "نبي نعرف",
        "interested", "would like to know", "let's connect", "keen to learn",
        "tell me more", "yes", "موافق", "نعم", "أوافق",
    ],
    ReplyCategory.ASK_FOR_DETAILS: [
        "تفاصيل", "معلومات أكثر", "وثيقة", "عرض تقديمي", "بروفايل",
        "details", "more information", "brochure", "proposal", "deck",
        "profile", "catalogue", "ما هو", "كيف", "شنو",
    ],
    ReplyCategory.PRICE_QUESTION: [
        "سعر", "تكلفة", "مبلغ", "رسوم", "بكم", "كم",
        "price", "cost", "pricing", "budget", "how much", "fee",
        "package", "package price", "استثمار", "investment",
    ],
    ReplyCategory.BOOK_MEETING: [
        "احجز", "مكالمة", "اجتماع", "موعد", "لقاء", "نتقابل",
        "book", "meeting", "call", "schedule", "appointment", "zoom",
        "teams", "google meet", "available", "متى", "when", "وقت", "time",
    ],
    ReplyCategory.NOT_NOW: [
        "لاحقاً", "مو الآن", "بعدين", " مش الوقت", "مشغولين",
        "later", "not now", "busy", "next quarter", "next month", "next year",
        "maybe later", "not the right time", "postpone", "delay", "تأجيل",
    ],
    ReplyCategory.WRONG_PERSON: [
        "مو أنا", "غلط", "شخص آخر", "مو اختصاصي", " different person",
        "wrong person", "not me", "not my department", " different department",
        "contact someone else", "reach out to", "not responsible",
    ],
    ReplyCategory.OBJECTION: [
        "مش محتاجين", "عندنا نظام", "مقتنعين", "ما نبي", "رفض",
        "not interested", "have a system", "already using", "not needed",
        "no budget", "no need", "happy with current", "not convinced",
        "skeptical", "doubt", "not sure", "ليس متأكد",
    ],
    ReplyCategory.UNSUBSCRIBE: [
        "إلغاء", "أشيل", "ما أبي", "حذف", "stop", "unsubscribe",
        "remove me", "delete", "don't contact", "لا تراسلني", "قائمة سوداء",
        "blacklist", "opt out", "out", "غير مهتم نهائياً",
    ],
    ReplyCategory.NO_FIT: [
        "ما يناسبنا", "قطاع مختلف", "مو زين", "not a fit", "not suitable",
        "different industry", "too small", "too big", "not relevant",
        "outside scope", "doesn't apply", "غير مناسب",
    ],
}

NEXT_ACTIONS = {
    ReplyCategory.INTERESTED: "send_discovery_brief_and_book_meeting",
    ReplyCategory.ASK_FOR_DETAILS: "send_details_and_followup",
    ReplyCategory.PRICE_QUESTION: "schedule_call_before_pricing",
    ReplyCategory.BOOK_MEETING: "send_meeting_link_and_confirm",
    ReplyCategory.NOT_NOW: "set_followup_30_days",
    ReplyCategory.WRONG_PERSON: "ask_for_correct_contact",
    ReplyCategory.OBJECTION: "send_case_study_and_soft_followup",
    ReplyCategory.UNSUBSCRIBE: "add_to_suppression_list",
    ReplyCategory.NO_FIT: "archive_and_note_reason",
    ReplyCategory.UNKNOWN: "flag_for_human_review",
}


def classify_reply(content: str) -> Tuple[str, float]:
    """
    Classify reply content into a category.
    Returns (category, confidence_score).
    """
    content_lower = content.lower().strip()

    scores = {}
    for category, keywords in CLASSIFICATION_KEYWORDS.items():
        score = 0
        for keyword in keywords:
            if keyword.lower() in content_lower:
                score += 1
        if score > 0:
            scores[category] = score

    if not scores:
        return ReplyCategory.UNKNOWN, 0.0

    # Pick highest scoring category
    best_category = max(scores, key=scores.get)
    total_keywords = len(CLASSIFICATION_KEYWORDS[best_category])
    confidence = min(scores[best_category] / max(total_keywords * 0.3, 1), 1.0)

    return best_category, confidence


def process_reply(
    message_id: str,
    company_id: str,
    reply_content: str,
) -> Dict[str, Any]:
    """
    Process an incoming reply: classify and determine next action.

    Returns:
        Dict with classification results and recommended action
    """
    storage = get_storage()

    category, confidence = classify_reply(reply_content)
    next_action = NEXT_ACTIONS.get(category, "flag_for_human_review")

    reply_id = f"reply_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    # Save to replies ledger
    reply_record = {
        "reply_id": reply_id,
        "message_id": message_id,
        "company_id": company_id,
        "category": category,
        "content_summary": reply_content[:200],
        "next_action": next_action,
        "created_at": now,
    }
    reply_fields = ["reply_id", "message_id", "company_id", "category", "content_summary", "next_action", "created_at"]
    storage.append("replies", reply_record, reply_fields)

    # Update outreach_log reply_status
    outreach_fields = [
        "message_id", "company_id", "contact_id", "channel", "status", "subject",
        "body_path", "source_url", "verification_status", "approval_status",
        "approved_by", "sent_at", "reply_status", "followup_due_at",
        "opt_out", "created_at", "updated_at"
    ]
    storage.update_by_id("outreach_log", "message_id", message_id, {
        "reply_status": category,
        "updated_at": now,
    }, outreach_fields)

    log_reply_received(reply_id, f"Reply classified as {category} for message {message_id}")

    return {
        "reply_id": reply_id,
        "message_id": message_id,
        "company_id": company_id,
        "category": category,
        "confidence": round(confidence, 2),
        "next_action": next_action,
        "content_preview": reply_content[:150],
    }


def get_replies_by_category(category: str) -> List[Dict[str, str]]:
    """Get all replies of a specific category."""
    storage = get_storage()
    replies = storage.read_all("replies")
    return [r for r in replies if r.get("category") == category]


def get_pending_human_review() -> List[Dict[str, str]]:
    """Get replies flagged for human review."""
    return get_replies_by_category(ReplyCategory.UNKNOWN)


def get_interested_replies() -> List[Dict[str, str]]:
    """Get replies indicating interest."""
    interested_categories = [
        ReplyCategory.INTERESTED,
        ReplyCategory.BOOK_MEETING,
        ReplyCategory.ASK_FOR_DETAILS,
    ]
    storage = get_storage()
    replies = storage.read_all("replies")
    return [r for r in replies if r.get("category") in interested_categories]
