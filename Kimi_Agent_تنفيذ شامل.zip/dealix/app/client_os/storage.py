"""
Dealix Client OS — Storage Layer

CSV-based source of truth for all ledgers.
Deterministic, auditable, human-readable.
"""

import csv
import os
from pathlib import Path
from typing import List, Dict, Any, Optional


def _resolve_ledger_dir() -> Path:
    """Resolve ledger directory relative to project root."""
    env_dir = os.environ.get("DEALIX_LEDGER_DIR", "")
    if env_dir:
        path = Path(env_dir)
        if path.is_absolute():
            return path
        # Relative to project root (2 levels up from this file: app/client_os/)
        project_root = Path(__file__).resolve().parents[2]
        return project_root / path
    # Default: project_root/ledgers
    return Path(__file__).resolve().parents[2] / "ledgers"


LEDGER_DIR = _resolve_ledger_dir()


class LedgerStorage:
    """Generic CSV ledger storage with schema awareness."""

    def __init__(self, ledger_dir: Optional[Path] = None):
        self.ledger_dir = Path(ledger_dir) if ledger_dir else LEDGER_DIR
        self.ledger_dir.mkdir(parents=True, exist_ok=True)

    def _get_path(self, name: str) -> Path:
        return self.ledger_dir / f"{name}.csv"

    def read_all(self, name: str) -> List[Dict[str, str]]:
        path = self._get_path(name)
        if not path.exists():
            return []
        with open(path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            return list(reader)

    def write_all(self, name: str, rows: List[Dict[str, str]], fieldnames: List[str]):
        path = self._get_path(name)
        with open(path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def append(self, name: str, row: Dict[str, str], fieldnames: List[str]):
        path = self._get_path(name)
        file_exists = path.exists() and path.stat().st_size > 0
        with open(path, "a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerow(row)

    def read_by_id(self, name: str, id_field: str, entity_id: str) -> Optional[Dict[str, str]]:
        rows = self.read_all(name)
        for row in rows:
            if row.get(id_field) == entity_id:
                return row
        return None

    def update_by_id(self, name: str, id_field: str, entity_id: str, updates: Dict[str, str], fieldnames: List[str]):
        rows = self.read_all(name)
        for row in rows:
            if row.get(id_field) == entity_id:
                row.update(updates)
                break
        self.write_all(name, rows, fieldnames)


# Singleton for convenience
storage = LedgerStorage()


def get_storage() -> LedgerStorage:
    return storage
