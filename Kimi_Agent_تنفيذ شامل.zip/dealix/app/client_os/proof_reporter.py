"""
Dealix Client OS — Proof Reporter

Generates proof report:
- What was done
- What changed
- Measurable outputs
- Risks
- Next week decisions
- Expansion opportunities
"""

import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from app.client_os.storage import get_storage
from app.client_os.policy_gate import get_gate
from app.client_os.audit_log import log_proof_report


PROOF_FIELDS = [
    "proof_id", "project_id", "client_id", "report_period",
    "completed_actions", "measured_outputs", "open_risks",
    "next_decisions", "client_feedback", "expansion_opportunity",
    "created_at"
]


def generate_proof_report(
    project_id: str,
    report_period: str = "",
    completed_actions: str = "",
    measured_outputs: str = "",
    open_risks: str = "",
    next_decisions: str = "",
    client_feedback: str = "",
    expansion_opportunity: str = "",
) -> Dict[str, Any]:
    """
    Generate a proof report for a project.

    Returns:
        Dict with proof report data
    """
    storage = get_storage()

    # Gate check: project must exist
    gate = get_gate()
    passed, reason = gate.check_project_before_proof(project_id)
    if not passed:
        return {"project_id": project_id, "error": reason}

    project = storage.read_by_id("projects", "project_id", project_id)
    if not project:
        return {"project_id": project_id, "error": "Project not found"}

    client_id = project.get("client_id", "")

    # Auto-generate from project data if not provided
    if not completed_actions:
        tasks = storage.read_all("tasks")
        project_tasks = [t for t in tasks if t.get("project_id") == project_id]
        completed = [t.get("title", "") for t in project_tasks if t.get("status") == "completed"]
        pending = [t.get("title", "") for t in project_tasks if t.get("status") == "pending"]

        if completed:
            completed_actions = " | ".join(completed)
        else:
            completed_actions = "جاري العمل على المهام — سيتم التحديث قريباً"

    if not measured_outputs:
        measured_outputs = "النظام قيد التفعيل — سيتم قياس المخرجات بعد UAT"

    if not open_risks:
        open_risks = "لا توجد مخاطر حرجة مفتوحة حالياً"

    if not next_decisions:
        next_decisions = "انتظار اكتمال UAT والموافقة على الإطلاق"

    if not report_period:
        now = datetime.now()
        report_period = f"{now.year}-W{now.isocalendar()[1]}"

    proof_id = f"proof_{str(uuid.uuid4())[:8]}"
    now = datetime.now().isoformat()

    proof_report = {
        "proof_id": proof_id,
        "project_id": project_id,
        "client_id": client_id,
        "report_period": report_period,
        "completed_actions": completed_actions,
        "measured_outputs": measured_outputs,
        "open_risks": open_risks,
        "next_decisions": next_decisions,
        "client_feedback": client_feedback or "لم يتم تقديم ملاحظات بعد",
        "expansion_opportunity": expansion_opportunity or "قيد التقييم",
        "created_at": now,
    }

    storage.append("proof_reports", proof_report, PROOF_FIELDS)

    # Update project proof_status
    project_updates = {
        "proof_status": "submitted",
        "updated_at": now,
    }
    storage.update_by_id("projects", "project_id", project_id, project_updates, [
        "project_id", "client_id", "project_name", "product_type",
        "status", "current_phase", "owner", "start_date",
        "target_launch_date", "acceptance_status", "proof_status",
        "renewal_opportunity", "next_action", "updated_at"
    ])

    log_proof_report(proof_id, f"Proof report for project {project_id}")

    return {
        "proof_id": proof_id,
        "project_id": project_id,
        "client_id": client_id,
        "report_period": report_period,
        "status": "submitted",
    }


def get_proof_reports(project_id: str) -> list:
    """Get all proof reports for a project."""
    storage = get_storage()
    reports = storage.read_all("proof_reports")
    return [r for r in reports if r.get("project_id") == project_id]


def get_latest_proof_report(project_id: str) -> Optional[Dict[str, str]]:
    """Get the latest proof report for a project."""
    reports = get_proof_reports(project_id)
    if not reports:
        return None
    return reports[-1]
