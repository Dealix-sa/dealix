"""
Contract Engine — contract from proposal, sign-off, lock terms.
"""
from app.delivery.contract_manager import create_contract, sign_contract


def generate_from_proposal(proposal_id: str) -> dict:
    import os, csv
    path = os.path.join(os.environ.get("DEALIX_LEDGER_DIR", "ledgers"), "proposals.csv")
    if not os.path.exists(path):
        return {"error": "No proposals found"}
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("proposal_id") == proposal_id and row.get("status") == "approved":
                return create_contract(proposal_id, row.get("client_id", ""), row.get("content", ""))
    return {"error": "Proposal not found or not approved"}
