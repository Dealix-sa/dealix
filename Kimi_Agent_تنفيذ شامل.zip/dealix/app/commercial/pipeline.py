"""
Commercial Pipeline — proposals → contracts → invoices → payments.
"""
import os, csv
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


def get_full_pipeline() -> dict:
    proposals = _read_all("proposals")
    contracts = _read_all("contracts")
    invoices = _read_all("invoices")
    payments = _read_all("payments")

    return {
        "proposals": {"total": len(proposals), "draft": sum(1 for p in proposals if p.get("status") == "draft"), "approved": sum(1 for p in proposals if p.get("status") == "approved")},
        "contracts": {"total": len(contracts), "signed": sum(1 for c in contracts if c.get("status") == "signed")},
        "invoices": {"total": len(invoices), "paid": sum(1 for i in invoices if i.get("status") == "paid"), "pending": sum(1 for i in invoices if i.get("status") == "issued")},
        "payments": {"total": len(payments)},
    }


def _read_all(name):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))
