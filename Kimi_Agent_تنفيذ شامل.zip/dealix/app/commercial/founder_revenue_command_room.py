"""
Founder Revenue Command Room — HTML view of pipeline.
"""
from app.commercial.pipeline import get_full_pipeline


def generate_html() -> str:
    pipe = get_full_pipeline()
    html = """<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>Revenue Command Room — Dealix</title>
<style>
body { font-family: -apple-system, system-ui, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
.header { background: #16213e; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
.grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
.card { background: white; border-radius: 8px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; }
.card h2 { margin: 10px 0; font-size: 36px; color: #16213e; }
.card p { color: #666; margin: 0; }
.funnel { background: #e94560; color: white; padding: 15px; border-radius: 8px; margin-top: 20px; }
</style>
</head>
<body>
<div class="header">
<h1>Founder Revenue Command Room</h1>
<p>Real-time view of the commercial pipeline</p>
</div>
<div class="grid">
<div class="card">
<p>Proposals</p>
<h2>""" + str(pipe["proposals"]["total"]) + """</h2>
<p>Draft: """ + str(pipe["proposals"]["draft"]) + """ | Approved: """ + str(pipe["proposals"]["approved"]) + """</p>
</div>
<div class="card">
<p>Contracts</p>
<h2>""" + str(pipe["contracts"]["total"]) + """</h2>
<p>Signed: """ + str(pipe["contracts"]["signed"]) + """</p>
</div>
<div class="card">
<p>Invoices</p>
<h2>""" + str(pipe["invoices"]["total"]) + """</h2>
<p>Paid: """ + str(pipe["invoices"]["paid"]) + """ | Pending: """ + str(pipe["invoices"]["pending"]) + """</p>
</div>
<div class="card">
<p>Payments</p>
<h2>""" + str(pipe["payments"]["total"]) + """</h2>
</div>
</div>
<div class="funnel">
<h3>Conversion Funnel</h3>
<p>Proposal → Contract → Invoice → Payment</p>
</div>
</body>
</html>"""
    return html


def save_html(output_path: str = "reports/ops/revenue_command_room.html"):
    import os
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(generate_html())
    return output_path
