"""
Proposal Manager — proposals, versioning, approval.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["proposal_id", "client_id", "version", "content", "status", "approved_by", "approved_at", "created_at"]


def create_proposal(client_id: str, content: str, created_by: str = "system") -> dict:
    import uuid
    pid = f"prop_{uuid.uuid4().hex[:8]}"
    entry = {"proposal_id": pid, "client_id": client_id, "version": "1",
             "content": content, "status": "draft", "approved_by": "",
             "approved_at": "", "created_at": datetime.now().isoformat()}
    # Ensure all FIELDS are present
    for f in FIELDS:
        if f not in entry:
            entry[f] = ""
    _write("proposals", entry, FIELDS)
    return {"proposal_id": pid, "status": "draft"}


def approve_proposal(proposal_id: str, approved_by: str) -> dict:
    _update("proposals", "proposal_id", proposal_id,
            {"status": "approved", "approved_by": approved_by, "approved_at": datetime.now().isoformat()})
    return {"proposal_id": proposal_id, "status": "approved"}


def list_pending_approvals():
    path = os.path.join(LEDGER_DIR, "proposals.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("status") == "draft"]


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    # Collect all fieldnames including new ones from updates
    all_fields = set(FIELDS)
    for r in rows:
        all_fields.update(r.keys())
    all_fields.update(updates.keys())
    fieldnames = [f for f in FIELDS if f in all_fields] + sorted(all_fields - set(FIELDS))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
