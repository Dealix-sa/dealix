"""
Invoice Engine — invoice from contract, payment tracking.
"""
from app.delivery.invoice_generator import generate_invoice, mark_paid


def generate_from_contract(contract_id: str, amount: str) -> dict:
    import os, csv
    path = os.path.join(os.environ.get("DEALIX_LEDGER_DIR", "ledgers"), "contracts.csv")
    if not os.path.exists(path):
        return {"error": "No contracts found"}
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("contract_id") == contract_id and row.get("status") == "signed":
                return generate_invoice(contract_id, row.get("client_id", ""), amount)
    return {"error": "Contract not found or not signed"}
