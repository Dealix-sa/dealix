# Dealix Commercial — Proposals → Contracts → Invoices → Payments
