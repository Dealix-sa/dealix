"""
Payment Tracker — payment status per invoice.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["payment_id", "invoice_id", "amount", "method", "status", "paid_at"]


def record_payment(invoice_id: str, amount: str, method: str = "bank_transfer") -> dict:
    import uuid
    entry = {"payment_id": f"pay_{uuid.uuid4().hex[:8]}", "invoice_id": invoice_id,
             "amount": amount, "method": method, "status": "received",
             "paid_at": datetime.now().isoformat()}
    path = os.path.join(LEDGER_DIR, "payments.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            w.writeheader()
        w.writerow(entry)

    from app.delivery.invoice_generator import mark_paid
    mark_paid(invoice_id)
    return {"status": "payment_recorded"}


def get_unpaid_invoices():
    path = os.path.join(LEDGER_DIR, "invoices.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("status") != "paid"]
