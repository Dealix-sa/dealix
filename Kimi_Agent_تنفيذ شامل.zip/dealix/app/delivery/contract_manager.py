"""
Contract Manager — contract generation from proposal terms.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["contract_id", "proposal_id", "client_id", "terms", "status", "signed_by", "signed_at", "created_at"]


def create_contract(proposal_id: str, client_id: str, terms: str) -> dict:
    import uuid
    cid = f"cont_{uuid.uuid4().hex[:8]}"
    entry = {"contract_id": cid, "proposal_id": proposal_id, "client_id": client_id,
             "terms": terms, "status": "draft", "signed_by": "", "signed_at": "", "created_at": datetime.now().isoformat()}
    _write("contracts", entry, FIELDS)
    return {"contract_id": cid, "status": "draft"}


def sign_contract(contract_id: str, signed_by: str):
    _update("contracts", "contract_id", contract_id,
            {"status": "signed", "signed_by": signed_by, "signed_at": datetime.now().isoformat()})
    return {"contract_id": contract_id, "status": "signed"}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
