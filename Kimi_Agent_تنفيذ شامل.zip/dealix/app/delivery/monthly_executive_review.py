"""
Monthly Executive Review — health score, usage, expansion.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["review_id", "client_id", "project_id", "period", "health_score",
          "usage_summary", "expansion_opps", "renewal_recommendation", "next_30_days",
          "created_at"]


def create_review(client_id: str, project_id: str, period: str = "") -> dict:
    import uuid
    rid = f"review_{uuid.uuid4().hex[:8]}"
    if not period:
        period = datetime.now().strftime("%Y-%m")
    entry = {"review_id": rid, "client_id": client_id, "project_id": project_id,
             "period": period, "health_score": "", "usage_summary": "",
             "expansion_opps": "", "renewal_recommendation": "", "next_30_days": "",
             "created_at": datetime.now().isoformat()}
    _write("monthly_reviews", entry, FIELDS)
    return {"review_id": rid, "status": "created"}


def update_review(review_id: str, **kwargs):
    _update("monthly_reviews", "review_id", review_id, kwargs)
    return {"review_id": review_id, "status": "updated"}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
