"""
Proof Reporter — what was built, what changed, measurable outputs.
"""
import os, csv
from datetime import datetime, timedelta
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["report_id", "project_id", "period", "completed_actions", "measured_outputs",
          "blockers", "risks", "decisions", "next_week", "expansion_opportunity",
          "client_approved", "created_at"]


def create_proof_report(project_id: str, period: str = "") -> dict:
    import uuid
    rid = f"proof_{uuid.uuid4().hex[:8]}"
    if not period:
        today = datetime.now()
        period = f"Week of {today.strftime('%Y-%m-%d')}"
    entry = {"report_id": rid, "project_id": project_id, "period": period,
             "completed_actions": "", "measured_outputs": "", "blockers": "",
             "risks": "", "decisions": "", "next_week": "", "expansion_opportunity": "",
             "client_approved": "false", "created_at": datetime.now().isoformat()}
    _write("proof_reports", entry, FIELDS)
    return {"report_id": rid, "status": "created"}


def update_report(report_id: str, **kwargs):
    _update("proof_reports", "report_id", report_id, kwargs)
    return {"report_id": report_id, "status": "updated"}


def client_approve(report_id: str):
    _update("proof_reports", "report_id", report_id, {"client_approved": "true"})
    return {"report_id": report_id, "status": "client_approved"}


def get_reports(project_id: str):
    path = os.path.join(LEDGER_DIR, "proof_reports.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("project_id") == project_id]


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
