"""
Delivery Command Room — HTML command room for delivery projects.
"""
import os, csv
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


def generate_html() -> str:
    projects = []
    path = os.path.join(LEDGER_DIR, "projects.csv")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", newline="") as f:
            projects = list(csv.DictReader(f))

    active = [p for p in projects if p.get("status") == "active"]

    html = """<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>Delivery Command Room — Dealix</title>
<style>
body { font-family: -apple-system, system-ui, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
.header { background: #1a1a2e; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 15px; }
.card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.card h3 { margin-top: 0; color: #1a1a2e; }
.status { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
.status-active { background: #d4edda; color: #155724; }
.status-pending { background: #fff3cd; color: #856404; }
.status-completed { background: #cce5ff; color: #004085; }
</style>
</head>
<body>
<div class="header">
<h1>Delivery Command Room</h1>
<p>Active Projects: """ + str(len(active)) + """ | All Projects: """ + str(len(projects)) + """</p>
</div>
<div class="grid">
"""

    for p in projects:
        phase = p.get("current_phase", "unknown")
        status = p.get("status", "unknown")
        status_class = f"status-{status}" if status in ("active", "pending", "completed") else "status-active"
        html += f"""
<div class="card">
<h3>{p.get("project_name", "Untitled")}</h3>
<p><span class="status {status_class}">{status}</span> | Phase: {phase}</p>
<p>Owner: {p.get("owner", "")}</p>
<p>Started: {p.get("start_date", "")}</p>
</div>
"""

    html += """
</div>
</body>
</html>"""
    return html


def save_html(output_path: str = "reports/delivery/command_room.html"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(generate_html())
    return output_path
