"""
UAT Engine — acceptance criteria, sign-off workflow.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["test_id", "project_id", "test_name", "description", "status", "tested_by", "tested_at", "notes"]


def add_test(project_id: str, test_name: str, description: str) -> dict:
    import uuid
    tid = f"test_{uuid.uuid4().hex[:8]}"
    entry = {"test_id": tid, "project_id": project_id, "test_name": test_name,
             "description": description, "status": "pending", "tested_by": "", "tested_at": "", "notes": ""}
    _write("uat_tests", entry, FIELDS)
    return {"test_id": tid, "status": "pending"}


def mark_test_passed(test_id: str, tested_by: str, notes: str = ""):
    _update("uat_tests", "test_id", test_id, {"status": "passed", "tested_by": tested_by, "tested_at": datetime.now().isoformat(), "notes": notes})
    return {"test_id": test_id, "status": "passed"}


def mark_test_failed(test_id: str, tested_by: str, notes: str = ""):
    _update("uat_tests", "test_id", test_id, {"status": "failed", "tested_by": tested_by, "tested_at": datetime.now().isoformat(), "notes": notes})
    return {"test_id": test_id, "status": "failed"}


def get_uat_summary(project_id: str) -> dict:
    path = os.path.join(LEDGER_DIR, "uat_tests.csv")
    if not os.path.exists(path):
        return {"total": 0, "passed": 0, "failed": 0, "pending": 0}
    tests = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        tests = [r for r in csv.DictReader(f) if r.get("project_id") == project_id]
    total = len(tests)
    passed = sum(1 for t in tests if t.get("status") == "passed")
    failed = sum(1 for t in tests if t.get("status") == "failed")
    pending = sum(1 for t in tests if t.get("status") == "pending")
    return {"total": total, "passed": passed, "failed": failed, "pending": pending, "all_passed": passed > 0 and failed == 0 and pending == 0}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
