"""
Client Portal — shared view showing sprint progress, UAT, proof reports.
"""
import os, csv
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


def get_client_view(client_id: str) -> dict:
    projects = []
    path = os.path.join(LEDGER_DIR, "projects.csv")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", newline="") as f:
            projects = [r for r in csv.DictReader(f) if r.get("client_id") == client_id]

    tasks = []
    task_path = os.path.join(LEDGER_DIR, "tasks.csv")
    if os.path.exists(task_path):
        with open(task_path, "r", encoding="utf-8", newline="") as f:
            tasks = list(csv.DictReader(f))

    proofs = []
    proof_path = os.path.join(LEDGER_DIR, "proof_reports.csv")
    if os.path.exists(proof_path):
        with open(proof_path, "r", encoding="utf-8", newline="") as f:
            proofs = list(csv.DictReader(f))

    reviews = []
    review_path = os.path.join(LEDGER_DIR, "monthly_reviews.csv")
    if os.path.exists(review_path):
        with open(review_path, "r", encoding="utf-8", newline="") as f:
            reviews = list(csv.DictReader(f))

    return {
        "client_id": client_id,
        "projects": projects,
        "tasks": tasks,
        "proof_reports": proofs,
        "monthly_reviews": reviews,
    }


def get_project_details(project_id: str) -> dict:
    from app.delivery.delivery_status import get_project_status
    from app.delivery.uat_engine import get_uat_summary
    status = get_project_status(project_id)
    uat = get_uat_summary(project_id)
    return {"project_id": project_id, **status, "uat_summary": uat}
