"""
Delivery Status — real-time project status dashboard data.
"""
import os, csv
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


def get_project_status(project_id: str) -> dict:
    project = _find("projects", "project_id", project_id)
    if not project:
        return {"error": "Project not found"}

    tasks = []
    path = os.path.join(LEDGER_DIR, "tasks.csv")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8", newline="") as f:
            tasks = [r for r in csv.DictReader(f) if r.get("project_id") == project_id]

    total = len(tasks)
    done = sum(1 for t in tasks if t.get("status") in ("completed", "done"))
    in_progress = sum(1 for t in tasks if t.get("status") == "in_progress")
    pending = sum(1 for t in tasks if t.get("status") == "pending")

    uat = {"total": 0, "passed": 0, "failed": 0}
    uat_path = os.path.join(LEDGER_DIR, "uat_tests.csv")
    if os.path.exists(uat_path):
        with open(uat_path, "r", encoding="utf-8", newline="") as f:
            tests = [r for r in csv.DictReader(f) if r.get("project_id") == project_id]
            uat["total"] = len(tests)
            uat["passed"] = sum(1 for t in tests if t.get("status") == "passed")
            uat["failed"] = sum(1 for t in tests if t.get("status") == "failed")

    return {
        "project_id": project_id,
        "phase": project.get("current_phase", "unknown"),
        "status": project.get("status", "unknown"),
        "tasks": {"total": total, "done": done, "in_progress": in_progress, "pending": pending},
        "uat": uat,
        "progress_pct": round((done / total) * 100, 1) if total else 0,
    }


def get_all_active_projects():
    path = os.path.join(LEDGER_DIR, "projects.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("status") == "active"]


def _find(name, key, value):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get(key) == value:
                return row
    return None
