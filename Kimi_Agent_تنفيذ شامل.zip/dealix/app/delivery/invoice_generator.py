"""
Invoice Generator — from signed proposal terms.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["invoice_id", "contract_id", "client_id", "amount", "status", "issued_at", "paid_at"]


def generate_invoice(contract_id: str, client_id: str, amount: str) -> dict:
    import uuid
    iid = f"inv_{uuid.uuid4().hex[:8]}"
    entry = {"invoice_id": iid, "contract_id": contract_id, "client_id": client_id,
             "amount": amount, "status": "issued", "issued_at": datetime.now().isoformat(), "paid_at": ""}
    _write("invoices", entry, FIELDS)
    return {"invoice_id": iid, "status": "issued", "amount": amount}


def mark_paid(invoice_id: str):
    _update("invoices", "invoice_id", invoice_id, {"status": "paid", "paid_at": datetime.now().isoformat()})
    return {"invoice_id": invoice_id, "status": "paid"}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
