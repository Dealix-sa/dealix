"""
Escalation Tracker — flags stuck projects and alerts founder.
"""
import os, csv
from datetime import datetime, timedelta
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


def check_stuck_projects(days_threshold: int = 7) -> list:
    stuck = []
    path = os.path.join(LEDGER_DIR, "tasks.csv")
    if not os.path.exists(path):
        return stuck
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("status") == "pending":
                created = row.get("created_at", "")
                if created:
                    try:
                        dt = datetime.fromisoformat(created)
                        if datetime.now() - dt > timedelta(days=days_threshold):
                            stuck.append(row)
                    except:
                        pass
    return stuck


def check_overdue_projects():
    overdue = []
    path = os.path.join(LEDGER_DIR, "projects.csv")
    if not os.path.exists(path):
        return overdue
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            target = row.get("target_date", "")
            if target and row.get("status") == "active":
                try:
                    if datetime.now().date() > datetime.fromisoformat(target).date():
                        overdue.append(row)
                except:
                    pass
    return overdue


def generate_alert_report() -> dict:
    stuck = check_stuck_projects()
    overdue = check_overdue_projects()
    return {
        "stuck_tasks": len(stuck),
        "overdue_projects": len(overdue),
        "alerts": stuck + overdue,
        "generated_at": datetime.now().isoformat()
    }
