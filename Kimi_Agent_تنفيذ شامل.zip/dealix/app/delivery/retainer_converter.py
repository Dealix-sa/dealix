"""
Retainer Converter — pilot → managed OS conversion.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["conversion_id", "client_id", "project_id", "from_phase", "to_phase",
          "proof_report_id", "client_satisfied", "converted_at", "monthly_value"]


def initiate_conversion(client_id: str, project_id: str, proof_report_id: str) -> dict:
    import uuid
    cid = f"conv_{uuid.uuid4().hex[:8]}"
    entry = {"conversion_id": cid, "client_id": client_id, "project_id": project_id,
             "from_phase": "pilot", "to_phase": "managed_os", "proof_report_id": proof_report_id,
             "client_satisfied": "", "converted_at": "", "monthly_value": ""}
    _write("retainer_conversions", entry, FIELDS)
    return {"conversion_id": cid, "status": "initiated"}


def complete_conversion(conversion_id: str, client_satisfied: str, monthly_value: str = "") -> dict:
    _update("retainer_conversions", "conversion_id", conversion_id,
            {"client_satisfied": client_satisfied, "converted_at": datetime.now().isoformat(), "monthly_value": monthly_value})
    return {"conversion_id": conversion_id, "status": "completed"}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
