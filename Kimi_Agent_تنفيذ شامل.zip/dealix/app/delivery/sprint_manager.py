"""
Sprint Manager — Sprint 1, Sprint 2 with task ownership.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["sprint_id", "project_id", "sprint_number", "goal", "start_date", "end_date", "status"]


def create_sprint(project_id: str, sprint_number: int, goal: str, start_date: str, end_date: str) -> dict:
    import uuid
    sid = f"sprint_{uuid.uuid4().hex[:8]}"
    entry = {"sprint_id": sid, "project_id": project_id, "sprint_number": sprint_number,
             "goal": goal, "start_date": start_date, "end_date": end_date,
             "status": "active"}
    _write("sprints", entry, FIELDS)
    return {"sprint_id": sid, "status": "active"}


def close_sprint(sprint_id: str):
    _update("sprints", "sprint_id", sprint_id, {"status": "completed"})
    return {"sprint_id": sprint_id, "status": "completed"}


def get_sprints(project_id: str):
    path = os.path.join(LEDGER_DIR, "sprints.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("project_id") == project_id]


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
