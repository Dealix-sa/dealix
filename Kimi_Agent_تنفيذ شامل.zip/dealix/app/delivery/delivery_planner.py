"""
Delivery Planner — client workspace, sprints, ownership.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
PROJECT_FIELDS = ["project_id", "client_id", "project_name", "status", "current_phase", "owner", "start_date", "target_date", "acceptance_status", "updated_at"]
TASK_FIELDS = ["task_id", "project_id", "title", "owner", "status", "due_date", "created_at"]


def create_project(client_id: str, project_name: str, owner: str = "Dealix") -> dict:
    import uuid
    pid = f"proj_{uuid.uuid4().hex[:8]}"
    entry = {"project_id": pid, "client_id": client_id, "project_name": project_name,
             "status": "active", "current_phase": "intake", "owner": owner,
             "start_date": datetime.now().isoformat(), "target_date": "",
             "acceptance_status": "pending", "updated_at": datetime.now().isoformat()}
    _write("projects", entry, PROJECT_FIELDS)
    return {"project_id": pid, "status": "active", "phase": "intake"}


def add_task(project_id: str, title: str, owner: str, due_date: str = "") -> dict:
    import uuid
    tid = f"task_{uuid.uuid4().hex[:8]}"
    entry = {"task_id": tid, "project_id": project_id, "title": title, "owner": owner,
             "status": "pending", "due_date": due_date, "created_at": datetime.now().isoformat()}
    _write("tasks", entry, TASK_FIELDS)
    return {"task_id": tid, "status": "pending"}


def update_task_status(task_id: str, status: str):
    _update("tasks", "task_id", task_id, {"status": status})
    return {"task_id": task_id, "status": status}


def get_project_tasks(project_id: str):
    path = os.path.join(LEDGER_DIR, "tasks.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("project_id") == project_id]


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
