"""
Onboarding — client welcome, workspace access, first sprint planning.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["onboarding_id", "client_id", "project_id", "step", "status", "completed_at"]

ONBOARDING_STEPS = [
    "welcome_kit_sent",
    "workspace_access_granted",
    "stakeholder_meeting_scheduled",
    "data_access_confirmed",
    "first_sprint_planned",
    "training_session_1",
    "acceptance_criteria_signed",
]


def start_onboarding(client_id: str, project_id: str) -> dict:
    import uuid
    results = []
    for step in ONBOARDING_STEPS:
        oid = f"ob_{uuid.uuid4().hex[:6]}"
        entry = {"onboarding_id": oid, "client_id": client_id, "project_id": project_id,
                 "step": step, "status": "pending", "completed_at": ""}
        _write("onboarding_steps", entry, FIELDS)
        results.append({"step": step, "status": "pending"})
    return {"client_id": client_id, "steps": results, "total": len(ONBOARDING_STEPS)}


def complete_step(onboarding_id: str):
    _update("onboarding_steps", "onboarding_id", onboarding_id,
            {"status": "completed", "completed_at": datetime.now().isoformat()})
    return {"onboarding_id": onboarding_id, "status": "completed"}


def get_onboarding_progress(project_id: str):
    path = os.path.join(LEDGER_DIR, "onboarding_steps.csv")
    if not os.path.exists(path):
        return {"total": 0, "completed": 0, "pending": 0}
    steps = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        steps = [r for r in csv.DictReader(f) if r.get("project_id") == project_id]
    total = len(steps)
    completed = sum(1 for s in steps if s.get("status") == "completed")
    return {"total": total, "completed": completed, "pending": total - completed, "progress_pct": round((completed / total) * 100, 1) if total else 0}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update(name, key, value, updates):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
