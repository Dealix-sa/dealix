"""
Delivery Logger — records every delivery action.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["log_id", "project_id", "action", "actor", "details", "timestamp"]


def log(project_id: str, action: str, actor: str = "system", details: str = ""):
    import uuid
    entry = {"log_id": f"dlog_{uuid.uuid4().hex[:8]}", "project_id": project_id, "action": action,
             "actor": actor, "details": details, "timestamp": datetime.now().isoformat()}
    path = os.path.join(LEDGER_DIR, "delivery_log.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def get_logs(project_id: str):
    path = os.path.join(LEDGER_DIR, "delivery_log.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r.get("project_id") == project_id]
