# app/ai/hallucination_detector.py
"""
Hallucination Detector — flags potential AI hallucinations in generated content.

Detects patterns commonly associated with AI-generated fabrications:
- Unverifiable statistics
- Confident claims without sources
- Inconsistent facts
- Unsupported specific numbers
"""

import re
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any


class HallucinationRisk(str, Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class HallucinationCheck:
    risk_level: HallucinationRisk
    flags: List[str] = field(default_factory=list)
    confidence: float = 0.0  # 0.0 to 1.0
    suggested_action: str = ""


# Patterns that suggest hallucination
SUSPICIOUS_PATTERNS = {
    "unverifiable_stat": [
        r"\b\d{1,3}(,\d{3})*\s+(studies|researchers|scientists)\b",
        r"\b\d+\.?\d*\s*%(\s+of\s+all)?\s+\w+\b.*(?!(according to|source|cited))",
        r"بحسب\s+دراسة\s+غير\s+محددة",
        r"إحصائية\s+تشير\s+إلى",
    ],
    "unsupported_specific": [
        r"في\s+عام\s+\d{4}.*(?!(وفق|بحسب|مصدر))",
        r"سوق\s+تقدر\s+قيمته\s+بـ\s+\d+.*(?!(دراسة|تقرير|مصدر))",
    ],
    "over_confident": [
        r"^(بالتأكيد|بكل\s+ثقة|بدون\s+شك)",
        r"^(certainly|definitely|absolutely|without doubt)",
        r"everyone knows",
        r"من\s+المعروف\s+للجميع",
    ],
    "vague_source": [
        r"دراسات\s+تشير\s+إلى",
        r"أبحاث\s+تؤكد",
        r"studies show",
        r"research suggests",
        r"experts say",
        r"(بعض|عدد\s+من)\s+(الخبراء|الباحثين)",
    ],
    "invented_detail": [
        r"مثلاً.*اسم\s+شخص\s+غير\s+معروف",
        r"على\s+سبيل\s+المثال.*شركة\s+XYZ",
        r"for example.*Company XYZ",
        r"John Doe.*(said|reported|found)",
    ]
}


def detect_hallucination(text: str, context: Optional[Dict[str, Any]] = None) -> HallucinationCheck:
    """
    Analyze text for potential hallucination patterns.

    Args:
        text: The AI-generated text to analyze
        context: Optional context dict with known facts for verification

    Returns:
        HallucinationCheck with risk level and flags
    """
    flags = []
    confidence_scores = []

    for category, patterns in SUSPICIOUS_PATTERNS.items():
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                flags.append(f"{category}: found pattern '{pattern}'")
                confidence_scores.append(0.3)

    # Check for numbers that contradict provided context
    if context and "known_facts" in context:
        for fact_name, fact_value in context["known_facts"].items():
            text_numbers = re.findall(rf"\b{re.escape(str(fact_value))}\b", text)
            if not text_numbers and fact_name.lower() in text.lower():
                flags.append(f"missing_expected: '{fact_name}' not found with expected value")
                confidence_scores.append(0.2)

    # Count suspicious sentences
    sentences = re.split(r'[.!?\n]+', text)
    suspicious_sentence_count = 0
    for sentence in sentences:
        sentence = sentence.strip()
        if len(sentence) > 10:
            # Check for specific unsourced numbers
            if re.search(r'\b\d{2,}\b', sentence) and not re.search(r'(source|according to|بحسب|مصدر)', sentence.lower()):
                suspicious_sentence_count += 1

    if suspicious_sentence_count > 3:
        flags.append(f"many_unsourced_numbers: {suspicious_sentence_count} sentences with unsourced numbers")
        confidence_scores.append(min(0.1 * suspicious_sentence_count, 0.5))

    # Calculate overall confidence
    confidence = min(sum(confidence_scores), 1.0) if confidence_scores else 0.0

    # Determine risk level
    if confidence >= 0.7:
        risk = HallucinationRisk.HIGH
        action = "REJECT: High hallucination risk. Requires human review and fact-checking."
    elif confidence >= 0.4:
        risk = HallucinationRisk.MEDIUM
        action = "REVIEW: Potential hallucinations detected. Verify facts before sending."
    elif confidence >= 0.15:
        risk = HallucinationRisk.LOW
        action = "NOTE: Minor flags. Review if content is for external delivery."
    else:
        risk = HallucinationRisk.NONE
        action = "PASS: No hallucination indicators detected."

    return HallucinationCheck(
        risk_level=risk,
        flags=flags,
        confidence=round(confidence, 2),
        suggested_action=action,
    )


def add_source_requirement(text: str) -> str:
    """
    Add source requirement markers to text that contains unsourced claims.
    Returns text with [CITATION NEEDED] markers inserted.
    """
    lines = text.split('\n')
    result_lines = []

    for line in lines:
        # Check for unsourced statistics
        if re.search(r'\b\d{2,}(\.\d+)?\s*%?\b', line):
            if not re.search(r'(source|according to|بحسب|مصدر|cited from)', line, re.IGNORECASE):
                line += " [CITATION NEEDED]"
        result_lines.append(line)

    return '\n'.join(result_lines)


def get_hallucination_stats(checks: List[HallucinationCheck]) -> Dict[str, Any]:
    """Aggregate hallucination check statistics."""
    total = len(checks)
    by_risk = {}
    all_flags = []
    for check in checks:
        by_risk[check.risk_level.value] = by_risk.get(check.risk_level.value, 0) + 1
        all_flags.extend(check.flags)

    high_risk_count = by_risk.get(HallucinationRisk.HIGH.value, 0)
    return {
        "total_checked": total,
        "high_risk_count": high_risk_count,
        "high_risk_rate": round(high_risk_count / total, 2) if total else 0,
        "by_risk_level": by_risk,
        "total_flags": len(all_flags),
        "avg_confidence": round(sum(c.confidence for c in checks) / total, 2) if total else 0,
    }
