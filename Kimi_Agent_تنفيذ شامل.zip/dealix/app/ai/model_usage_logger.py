# app/ai/model_usage_logger.py
"""
Model Usage Logger — tracks all AI model usage for auditability and cost control.

Logs every model call with:
- Timestamp
- Model name
- Input/output tokens (estimated if not available)
- Cost estimate
- Success/failure status
- Associated task
"""

import os
import csv
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict


@dataclass
class ModelUsage:
    """Record of a single model usage."""
    id: str
    timestamp: str
    model_name: str
    task: str  # e.g., "draft_generation", "content_review"
    input_tokens: int
    output_tokens: int
    estimated_cost_usd: float
    success: bool
    duration_ms: Optional[int] = None
    error_message: Optional[str] = None
    metadata: Optional[str] = None  # JSON string for extensibility


# Cost per 1K tokens (approximate, update as needed)
COST_RATES = {
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-4o": {"input": 0.005, "output": 0.015},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
    "claude-3-opus": {"input": 0.015, "output": 0.075},
    "claude-3-sonnet": {"input": 0.003, "output": 0.015},
    "default": {"input": 0.01, "output": 0.03},
}


def _get_ledger_path() -> Path:
    """Resolve the model usage ledger path."""
    project_root = Path(__file__).resolve().parents[2]
    ledger_dir = project_root / "ledgers"
    ledger_dir.mkdir(parents=True, exist_ok=True)
    return ledger_dir / "model_usage_log.csv"


def estimate_tokens(text: str) -> int:
    """
    Rough token estimation: ~4 characters per token for English,
    ~2 characters per token for Arabic.
    """
    if not text:
        return 0

    # Split by Arabic vs non-Arabic
    arabic_chars = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
    other_chars = len(text) - arabic_chars

    arabic_tokens = arabic_chars // 2
    other_tokens = other_chars // 4

    return max(1, arabic_tokens + other_tokens)


def estimate_cost(model_name: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate cost in USD for a model call."""
    rates = COST_RATES.get(model_name, COST_RATES["default"])
    input_cost = (input_tokens / 1000) * rates["input"]
    output_cost = (output_tokens / 1000) * rates["output"]
    return round(input_cost + output_cost, 4)


def log_model_usage(
    model_name: str,
    task: str,
    input_text: str,
    output_text: str,
    success: bool = True,
    duration_ms: Optional[int] = None,
    error_message: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> ModelUsage:
    """
    Log a model usage event.

    Args:
        model_name: Name of the model used
        task: Task identifier (e.g., "draft_generation")
        input_text: The input sent to the model
        output_text: The output received from the model
        success: Whether the call succeeded
        duration_ms: Duration in milliseconds
        error_message: Error message if failed
        metadata: Additional metadata dict

    Returns:
        The logged ModelUsage record
    """
    input_tokens = estimate_tokens(input_text)
    output_tokens = estimate_tokens(output_text)
    cost = estimate_cost(model_name, input_tokens, output_tokens)

    usage = ModelUsage(
        id=str(uuid.uuid4())[:8],
        timestamp=datetime.now().isoformat(),
        model_name=model_name,
        task=task,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        estimated_cost_usd=cost,
        success=success,
        duration_ms=duration_ms,
        error_message=error_message,
        metadata=json.dumps(metadata) if metadata else None,
    )

    ledger_path = _get_ledger_path()
    file_exists = ledger_path.exists()

    with open(ledger_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "id", "timestamp", "model_name", "task", "input_tokens",
            "output_tokens", "estimated_cost_usd", "success",
            "duration_ms", "error_message", "metadata"
        ])
        if not file_exists:
            writer.writeheader()
        writer.writerow(asdict(usage))

    return usage


def get_usage_summary(days: int = 30) -> Dict[str, Any]:
    """
    Get usage summary for the last N days.

    Args:
        days: Number of days to include

    Returns:
        Dict with summary statistics
    """
    ledger_path = _get_ledger_path()
    if not ledger_path.exists():
        return {
            "total_calls": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_estimated_cost_usd": 0.0,
            "success_rate": 0.0,
            "by_task": {},
            "by_model": {},
        }

    total_calls = 0
    total_input_tokens = 0
    total_output_tokens = 0
    total_cost = 0.0
    successes = 0
    by_task = {}
    by_model = {}

    with open(ledger_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_calls += 1
            total_input_tokens += int(row.get("input_tokens", 0))
            total_output_tokens += int(row.get("output_tokens", 0))
            total_cost += float(row.get("estimated_cost_usd", 0))
            if row.get("success", "true").lower() == "true":
                successes += 1

            task = row.get("task", "unknown")
            by_task[task] = by_task.get(task, 0) + 1

            model = row.get("model_name", "unknown")
            by_model[model] = by_model.get(model, 0) + 1

    return {
        "total_calls": total_calls,
        "total_input_tokens": total_input_tokens,
        "total_output_tokens": total_output_tokens,
        "total_estimated_cost_usd": round(total_cost, 4),
        "success_rate": round(successes / total_calls, 2) if total_calls else 0,
        "by_task": by_task,
        "by_model": by_model,
    }


def get_recent_usage(limit: int = 50) -> List[ModelUsage]:
    """Get recent model usage records."""
    ledger_path = _get_ledger_path()
    if not ledger_path.exists():
        return []

    records = []
    with open(ledger_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append(ModelUsage(**row))

    return records[-limit:]


def generate_usage_report() -> str:
    """Generate a human-readable usage report."""
    summary = get_usage_summary()

    lines = [
        "=" * 50,
        "DEALIX MODEL USAGE REPORT",
        "=" * 50,
        f"Total API Calls:     {summary['total_calls']}",
        f"Total Input Tokens:  {summary['total_input_tokens']:,}",
        f"Total Output Tokens: {summary['total_output_tokens']:,}",
        f"Est. Cost (USD):     ${summary['total_estimated_cost_usd']:.4f}",
        f"Success Rate:        {summary['success_rate']:.0%}",
        "-" * 50,
        "Usage by Task:",
    ]
    for task, count in sorted(summary['by_task'].items(), key=lambda x: -x[1]):
        lines.append(f"  {task}: {count}")

    lines.append("-" * 50)
    lines.append("Usage by Model:")
    for model, count in sorted(summary['by_model'].items(), key=lambda x: -x[1]):
        lines.append(f"  {model}: {count}")

    lines.append("=" * 50)
    return "\n".join(lines)
