# app/ai/prompt_guard.py
"""
Prompt Guard — protects against prompt injection and jailbreak attempts.

Detects and blocks malicious user inputs that attempt to:
- Override system instructions
- Extract system prompts
- Trigger unintended behavior
- Bypass safety controls
"""

import re
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


class ThreatLevel(str, Enum):
    SAFE = "safe"
    SUSPICIOUS = "suspicious"
    MALICIOUS = "malicious"


@dataclass
class GuardResult:
    threat_level: ThreatLevel
    blocked: bool
    detected_patterns: List[str] = field(default_factory=list)
    action: str = ""
    sanitized_input: Optional[str] = None


# Known injection patterns
INJECTION_PATTERNS = {
    "instruction_override": [
        r"ignore\s+(previous|above|all)\s+instructions",
        r"تجاهل\s+(التعليمات|الأوامر)\s+(السابقة|الأعلى)",
        r"forget\s+everything\s+(before|above)",
        r"انسَ\s+كل\s+ما\s+سبق",
        r"system\s+prompt",
        r"promptyouare",
        r"\[system\s*\(|\(system\s*\)",
        r"you are now",
        r"أنت\s+الآن\s+(مساعد|نظام|روبوت)",
        r"from now on you",
        r"من\s+الآن\s+فصاعداً\s+أنت",
    ],
    "delimiter_manipulation": [
        r"```\s*system",
        r"---\s*system\s*---",
        r"<\s*system\s*>",
        r"\[\s*SYSTEM\s*\]",
        r"<<\s*SYS\s*>>",
        r"###\s*(SYSTEM|INSTRUCTION|SYSTEM PROMPT)",
    ],
    "role_play_exploit": [
        r" pretend\s+to\s+be\s+",
        r"act\s+as\s+(if\s+you\s+are|though\s+you)",
        r"تظاهر\s+أنك\s+",
        r"أنت\s+تتظاهر\s+بأنك\s+",
        r"DAN\s*(mode|prompt)",
        r"jailbreak",
        r"do anything now",
    ],
    "data_extraction": [
        r"(print|echo|show|display)\s+(the\s+)?(system|your\s+)?(prompt|instructions|config)",
        r"(اطبع|أعرض|اكتب)\s+(تعليمات|أوامر)\s+(النظام|السيستم)",
        r"what\s+are\s+your\s+instructions",
        r"ما\s+هي\s+تعليماتك",
        r"repeat\s+(the\s+words\s+)?(above|before|previous)",
    ],
    "encoding_trick": [
        r"base64\s+(decode|encoded)",
        r"rot13",
        r"hex\s+decode",
        r"逆转",
        r"反转",
    ],
}


def scan_input(user_input: str, context: str = "outbound") -> GuardResult:
    """
    Scan user input for prompt injection attempts.

    Args:
        user_input: The raw user input to scan
        context: Usage context (outbound, internal, system)

    Returns:
        GuardResult with threat assessment
    """
    detected = []
    threat_score = 0
    sanitized = user_input

    for category, patterns in INJECTION_PATTERNS.items():
        for pattern in patterns:
            matches = re.findall(pattern, user_input, re.IGNORECASE)
            if matches:
                detected.append(f"{category}: {pattern}")
                if category == "instruction_override":
                    threat_score += 3
                elif category == "delimiter_manipulation":
                    threat_score += 3
                elif category == "role_play_exploit":
                    threat_score += 2
                elif category == "data_extraction":
                    threat_score += 2
                else:
                    threat_score += 1

    # Determine threat level
    if threat_score >= 4:
        threat = ThreatLevel.MALICIOUS
        blocked = True
        action = "BLOCK: Prompt injection detected. Input rejected."
    elif threat_score >= 2:
        threat = ThreatLevel.SUSPICIOUS
        blocked = True
        action = "REVIEW: Suspicious patterns detected. Input blocked pending review."
    elif threat_score >= 1:
        threat = ThreatLevel.SUSPICIOUS
        blocked = False
        action = "WARN: Minor suspicious patterns. Sanitized and allowed."
    else:
        threat = ThreatLevel.SAFE
        blocked = False
        action = "PASS: No injection patterns detected."

    # Sanitize: remove control characters and normalize
    if threat != ThreatLevel.SAFE:
        sanitized = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f]', '', user_input)
        sanitized = sanitized.replace('\\x00', '')

    return GuardResult(
        threat_level=threat,
        blocked=blocked,
        detected_patterns=detected,
        action=action,
        sanitized_input=sanitized,
    )


def sanitize_for_prompt(user_input: str) -> str:
    """
    Basic sanitization for any user input before it enters a prompt.
    Removes control characters and normalizes whitespace.
    """
    # Remove null bytes and control chars
    cleaned = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f]', '', user_input)
    # Remove potential prompt delimiters
    cleaned = re.sub(r'```\s*system\s*.*?```', '[BLOCKED]', cleaned, flags=re.IGNORECASE | re.DOTALL)
    # Normalize whitespace
    cleaned = re.sub(r'\s+', ' ', cleaned)
    return cleaned.strip()


def get_guard_stats(results: List[GuardResult]) -> Dict[str, Any]:
    """Aggregate prompt guard statistics."""
    total = len(results)
    blocked = sum(1 for r in results if r.blocked)
    by_threat = {}
    all_patterns = []
    for r in results:
        by_threat[r.threat_level.value] = by_threat.get(r.threat_level.value, 0) + 1
        all_patterns.extend(r.detected_patterns)
    return {
        "total_scanned": total,
        "blocked": blocked,
        "allowed": total - blocked,
        "block_rate": round(blocked / total, 2) if total else 0,
        "by_threat_level": by_threat,
        "total_patterns_detected": len(all_patterns),
    }
