# app/ai/output_verifier.py
"""
Output Verifier — validates AI-generated output quality and compliance.

Verifies that outputs meet Dealix standards:
- Format compliance (JSON, markdown, etc.)
- Required field presence
- Length constraints
- Language detection
- Brand voice consistency
"""

import re
import json
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any


class VerificationStatus(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"


@dataclass
class VerificationResult:
    status: VerificationStatus
    checks: List[Dict[str, Any]] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class OutputVerifier:
    """Validates AI-generated outputs against defined schemas and rules."""

    def __init__(self, rules: Optional[Dict[str, Any]] = None):
        self.rules = rules or {}

    def verify(self, output: str, expected_format: str = "text",
               required_fields: Optional[List[str]] = None,
               max_length: Optional[int] = None,
               min_length: Optional[int] = None) -> VerificationResult:
        """
        Run all verification checks on an output.

        Args:
            output: The AI-generated output to verify
            expected_format: Expected format (text, json, markdown, html)
            required_fields: Fields that must be present
            max_length: Maximum allowed length
            min_length: Minimum required length

        Returns:
            VerificationResult with status and details
        """
        checks = []
        errors = []
        warnings = []

        # Check 1: Empty output
        if not output or not output.strip():
            errors.append("Output is empty")
            return VerificationResult(
                status=VerificationStatus.FAIL,
                checks=[{"check": "empty", "passed": False}],
                errors=errors,
            )

        # Check 2: Length constraints
        length = len(output)
        if max_length and length > max_length:
            errors.append(f"Output length ({length}) exceeds maximum ({max_length})")
            checks.append({"check": "max_length", "passed": False, "value": length})
        else:
            checks.append({"check": "max_length", "passed": True})

        if min_length and length < min_length:
            errors.append(f"Output length ({length}) below minimum ({min_length})")
            checks.append({"check": "min_length", "passed": False, "value": length})
        else:
            checks.append({"check": "min_length", "passed": True})

        # Check 3: Format validation
        format_ok = self._check_format(output, expected_format)
        checks.append({"check": "format", "passed": format_ok, "expected": expected_format})
        if not format_ok:
            errors.append(f"Output does not match expected format: {expected_format}")

        # Check 4: Required fields
        if required_fields:
            missing = self._check_required_fields(output, required_fields, expected_format)
            checks.append({"check": "required_fields", "passed": len(missing) == 0, "missing": missing})
            if missing:
                errors.append(f"Missing required fields: {missing}")

        # Check 5: Arabic/English balance (if text)
        if expected_format == "text":
            has_arabic = bool(re.search(r'[\u0600-\u06FF]', output))
            has_english = bool(re.search(r'[a-zA-Z]', output))
            checks.append({"check": "language", "passed": True,
                          "arabic": has_arabic, "english": has_english})

        # Check 6: Brand safety
        brand_violations = self._check_brand_safety(output)
        checks.append({"check": "brand_safety", "passed": len(brand_violations) == 0,
                      "violations": brand_violations})
        if brand_violations:
            warnings.append(f"Brand safety notes: {brand_violations}")

        # Determine overall status
        if errors:
            status = VerificationStatus.FAIL
        elif warnings:
            status = VerificationStatus.WARN
        else:
            status = VerificationStatus.PASS

        return VerificationResult(
            status=status,
            checks=checks,
            errors=errors,
            warnings=warnings,
        )

    def _check_format(self, output: str, expected_format: str) -> bool:
        """Check if output matches expected format."""
        if expected_format == "json":
            try:
                json.loads(output)
                return True
            except (json.JSONDecodeError, ValueError):
                return False
        elif expected_format == "markdown":
            # Basic markdown check: has some markdown syntax
            return bool(re.search(r'(#{1,6}\s|\*\*|__|\[.*?\]\(.*?\)|```)', output))
        elif expected_format == "html":
            return bool(re.search(r'<[a-zA-Z][^>]*>', output))
        else:
            # text format: just needs non-empty content
            return len(output.strip()) > 0

    def _check_required_fields(self, output: str, fields: List[str],
                                fmt: str) -> List[str]:
        """Check if required fields are present in output."""
        missing = []
        if fmt == "json":
            try:
                data = json.loads(output)
                for field in fields:
                    if field not in data:
                        missing.append(field)
            except (json.JSONDecodeError, ValueError):
                # If not valid JSON, check as text
                for field in fields:
                    if field not in output:
                        missing.append(field)
        else:
            for field in fields:
                if field not in output:
                    missing.append(field)
        return missing

    def _check_brand_safety(self, output: str) -> List[str]:
        """Check for brand safety issues."""
        violations = []
        # Check for competitor mentions with negative framing
        negative_patterns = [
            r"(شركة|نظام|منصة)\s+\w+\s+(سيء|ضعيف|فاشل|قديم)",
            r"\b(terrible|awful|worst)\s+(competitor|alternative)\b",
        ]
        for pattern in negative_patterns:
            if re.search(pattern, output, re.IGNORECASE):
                violations.append(f"Potentially negative framing: {pattern}")
        return violations


def verify_json_output(output: str, schema: Dict[str, Any]) -> VerificationResult:
    """
    Convenience function to verify JSON output against a schema.

    Args:
        output: JSON string to verify
        schema: Expected schema with field requirements

    Returns:
        VerificationResult
    """
    verifier = OutputVerifier()
    required = list(schema.get("required", []))
    return verifier.verify(
        output=output,
        expected_format="json",
        required_fields=required,
    )


def get_verification_stats(results: List[VerificationResult]) -> Dict[str, Any]:
    """Aggregate verification statistics."""
    total = len(results)
    passed = sum(1 for r in r.status == VerificationStatus.PASS for r in results)
    failed = sum(1 for r in r.status == VerificationStatus.FAIL for r in results)
    warned = sum(1 for r in r.status == VerificationStatus.WARN for r in results)
    return {
        "total": total,
        "passed": passed,
        "failed": failed,
        "warned": warned,
        "pass_rate": round(passed / total, 2) if total else 0,
    }
