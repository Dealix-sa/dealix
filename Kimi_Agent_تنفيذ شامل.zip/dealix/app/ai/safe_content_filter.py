# app/ai/safe_content_filter.py
"""
Safe Content Filter — blocks unsafe content before outbound delivery.

Ensures all AI-generated content meets safety standards before reaching
external channels (email, WhatsApp, LinkedIn).
"""

import os
import re
from enum import Enum
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field


class RiskLevel(str, Enum):
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class FilterResult:
    passed: bool
    risk_level: RiskLevel
    flagged_categories: List[str] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    cleaned_text: Optional[str] = None


# Risk priority for ordering
RISK_PRIORITY = {
    RiskLevel.SAFE: 0,
    RiskLevel.LOW: 1,
    RiskLevel.MEDIUM: 2,
    RiskLevel.HIGH: 3,
    RiskLevel.CRITICAL: 4,
}

# Blocked phrase patterns (Arabic + English)
BLOCKED_PHRASES = {
    "hate_speech": [
        r"\b(hate|kill|destroy)\b",
        r"\b(killing|terrorist|terrorism)\b",
    ],
    "discrimination": [
        r"\b(inferior|superior race)\b",
    ],
    "self_harm": [
        r"\b(suicide|self.?harm|hurt myself)\b",
    ],
    "violence": [
        r"\b(violence|attack|bomb)\b",
    ],
    "guarantee_misleading": [
        r"نضمن.*(نتائج|ارباح|نجاح)",
        r"نضاعف.*(مبيعات|ارباح)",
        r"مضمونة.*100%",
        r"100%.*(نجاح|ضمان)",
        r"guaranteed\s+(roi|results|success)",
        r"guarantee\s+(roi|results|success)",
        r"double\s+your\s+(sales|revenue)\s+guaranteed",
    ],
    "fake_urgency": [
        r"لمدة\s+24\s+ساعة فقط",
        r"العرض\s+ينتهي\s+اليوم",
        r"limited\s+time\s+only",
        r"act\s+now\s+or\s+lose",
    ]
}


def check_content_safety(text: str, context: str = "outbound") -> FilterResult:
    """
    Check content for unsafe patterns across all categories.

    Args:
        text: The content to check
        context: Where this content will be used (outbound, internal, client)

    Returns:
        FilterResult with pass/fail status and details
    """
    flagged_categories = []
    reasons = []
    highest_risk = RiskLevel.SAFE
    cleaned_text = text

    for category, patterns in BLOCKED_PHRASES.items():
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                flagged_categories.append(category)
                reasons.append(f"{category}: matched '{pattern}'")
                if category in ["hate_speech", "violence"]:
                    if RISK_PRIORITY[RiskLevel.CRITICAL] > RISK_PRIORITY[highest_risk]:
                        highest_risk = RiskLevel.CRITICAL
                elif category == "guarantee_misleading":
                    if RISK_PRIORITY[RiskLevel.HIGH] > RISK_PRIORITY[highest_risk]:
                        highest_risk = RiskLevel.HIGH
                elif RISK_PRIORITY[RiskLevel.MEDIUM] > RISK_PRIORITY[highest_risk]:
                    highest_risk = RiskLevel.MEDIUM
                break

    # Context-specific rules
    if context == "outbound":
        # Outbound has stricter rules
        if "fake_urgency" in flagged_categories:
            highest_risk = RiskLevel.HIGH
            reasons.append("outbound context: fake urgency not allowed")

    passed = highest_risk not in (RiskLevel.HIGH, RiskLevel.CRITICAL)

    return FilterResult(
        passed=passed,
        risk_level=highest_risk,
        flagged_categories=list(set(flagged_categories)),
        reasons=reasons,
        cleaned_text=cleaned_text,
    )


def clean_content(text: str) -> str:
    """Apply basic content cleaning."""
    # Remove excessive exclamation marks
    cleaned = re.sub(r"!{3,}", "!", text)
    # Remove excessive caps
    cleaned = re.sub(r"([A-Z]){4,}", lambda m: m.group(0).title(), cleaned)
    return cleaned.strip()


def get_safety_stats(results: List[FilterResult]) -> Dict[str, Any]:
    """Aggregate safety statistics from multiple filter results."""
    total = len(results)
    passed = sum(1 for r in results if r.passed)
    by_risk = {}
    for r in results:
        by_risk[r.risk_level.value] = by_risk.get(r.risk_level.value, 0) + 1
    all_categories = []
    for r in results:
        all_categories.extend(r.flagged_categories)
    return {
        "total_checked": total,
        "passed": passed,
        "failed": total - passed,
        "pass_rate": round(passed / total, 2) if total else 0,
        "by_risk_level": by_risk,
        "top_flagged_categories": list(set(all_categories))[:10],
    }
