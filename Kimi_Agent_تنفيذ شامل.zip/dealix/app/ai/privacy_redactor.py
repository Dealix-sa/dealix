# app/ai/privacy_redactor.py
"""
Privacy Redactor — automatically redacts PII and sensitive data from text.

Protects client and contact privacy by removing or masking:
- Email addresses
- Phone numbers
- National IDs / passport numbers
- Credit card numbers
- API keys and tokens
- Passwords
"""

import re
import hashlib
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any


class RedactionMethod(str, Enum):
    MASK = "mask"           # Replace with ***
    HASH = "hash"           # Replace with hash
    REMOVE = "remove"       # Delete entirely
    TOKENIZE = "tokenize"   # Replace with [TYPE_N]


@dataclass
class RedactionResult:
    redacted_text: str
    redactions: List[Dict[str, str]] = field(default_factory=list)
    redaction_count: int = 0


# PII patterns
PII_PATTERNS = {
    "email": {
        "pattern": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "method": RedactionMethod.TOKENIZE,
    },
    "phone": {
        "pattern": r'\b(?:\+?966|0)?5\d{8}\b|\b(?:\+?971|0)?5\d{8}\b|\b\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b',
        "method": RedactionMethod.TOKENIZE,
    },
    "national_id": {
        "pattern": r'\b\d{10}\b',
        "method": RedactionMethod.MASK,
    },
    "credit_card": {
        "pattern": r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
        "method": RedactionMethod.MASK,
    },
    "api_key": {
        "pattern": r'\b(sk-[a-zA-Z0-9]{20,}|api[_-]?key[_-]?[:\s]*[a-zA-Z0-9]{16,})\b',
        "method": RedactionMethod.MASK,
        "flags": re.IGNORECASE,
    },
    "password": {
        "pattern": r'\b(password|pass|pwd)\s*[:=]\s*\S+',
        "method": RedactionMethod.MASK,
        "flags": re.IGNORECASE,
    },
    "token": {
        "pattern": r'\b[a-zA-Z0-9_-]{20,}\.[a-zA-Z0-9_-]{20,}\.[a-zA-Z0-9_-]{20,}\b',
        "method": RedactionMethod.HASH,
    },
}


def _apply_redaction(match: re.Match, pii_type: str, method: RedactionMethod,
                     counter: Dict[str, int]) -> str:
    """Apply the appropriate redaction method to a match."""
    original = match.group(0)
    counter[pii_type] = counter.get(pii_type, 0) + 1
    index = counter[pii_type]

    if method == RedactionMethod.MASK:
        if len(original) > 8:
            return original[:2] + "***" + original[-2:]
        return "****"
    elif method == RedactionMethod.HASH:
        short_hash = hashlib.sha256(original.encode()).hexdigest()[:8]
        return f"[HASH:{short_hash}]"
    elif method == RedactionMethod.REMOVE:
        return "[REDACTED]"
    else:  # TOKENIZE
        return f"[{pii_type.upper()}_{index}]"


def redact_pii(text: str, custom_patterns: Optional[Dict[str, Any]] = None,
               method_override: Optional[RedactionMethod] = None) -> RedactionResult:
    """
    Redact PII from text.

    Args:
        text: Input text potentially containing PII
        custom_patterns: Optional additional patterns to redact
        method_override: Override all methods with this one

    Returns:
        RedactionResult with redacted text and details
    """
    patterns = {**PII_PATTERNS, **(custom_patterns or {})}
    result_text = text
    redactions = []
    counter = {}

    for pii_type, config in patterns.items():
        pattern = config["pattern"]
        method = method_override or config.get("method", RedactionMethod.MASK)
        flags = config.get("flags", 0)

        def replacement(m, pt=pii_type, mt=method):
            redacted = _apply_redaction(m, pt, mt, counter)
            redactions.append({
                "type": pt,
                "original": m.group(0),
                "replacement": redacted,
                "position": (m.start(), m.end()),
            })
            return redacted

        result_text = re.sub(pattern, replacement, result_text, flags=flags)

    return RedactionResult(
        redacted_text=result_text,
        redactions=redactions,
        redaction_count=len(redactions),
    )


def redact_client_data(text: str, client_name: Optional[str] = None) -> str:
    """
    Convenience function to redact all common client-sensitive data.
    Optionally also redacts the client's own name if provided.
    """
    result = redact_pii(text)
    final_text = result.redacted_text

    if client_name and len(client_name) > 2:
        # Redact client name occurrences (case insensitive)
        final_text = re.sub(
            re.escape(client_name),
            "[CLIENT_NAME]",
            final_text,
            flags=re.IGNORECASE
        )

    return final_text


def get_redaction_stats(results: List[RedactionResult]) -> Dict[str, Any]:
    """Aggregate redaction statistics."""
    total = len(results)
    total_redactions = sum(r.redaction_count for r in results)
    by_type = {}
    for r in results:
        for red in r.redactions:
            t = red["type"]
            by_type[t] = by_type.get(t, 0) + 1
    return {
        "total_documents": total,
        "total_redactions": total_redactions,
        "avg_per_document": round(total_redactions / total, 1) if total else 0,
        "by_type": by_type,
    }
