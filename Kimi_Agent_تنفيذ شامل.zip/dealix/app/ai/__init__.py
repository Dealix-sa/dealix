# app/ai/__init__.py
"""
AI Safety & Control Layer for Dealix.

This package provides safety filters, hallucination detection, prompt guards,
privacy redaction, output verification, and model usage logging.

All AI outputs pass through this layer before reaching external channels.
"""
