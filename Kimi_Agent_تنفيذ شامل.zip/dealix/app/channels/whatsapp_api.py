"""
WhatsApp Business API adapter.
Defaults to dry_run. Template-only mode by default.
"""
import os
DRY_RUN = os.environ.get("LIVE_SEND_ENABLED", "false").lower() != "true"
WHATSAPP_API_KEY = os.environ.get("WHATSAPP_API_KEY", "")
WHATSAPP_PHONE_ID = os.environ.get("WHATSAPP_PHONE_NUMBER_ID", "")


def send_whatsapp(to: str, body: str, template_id: str = "", draft_id: str = "") -> dict:
    if DRY_RUN:
        return {"status": "dry_run", "to": to, "channel": "whatsapp", "draft_id": draft_id}
    if not WHATSAPP_API_KEY:
        return {"status": "error", "reason": "WhatsApp API key not configured"}
    # Actual WhatsApp Cloud API call would go here
    return {"status": "sent", "to": to, "channel": "whatsapp"}


def check_config() -> dict:
    return {
        "configured": bool(WHATSAPP_API_KEY and WHATSAPP_PHONE_ID),
        "phone_id": WHATSAPP_PHONE_ID,
        "dry_run": DRY_RUN
    }
