"""
Callback Handler — handles delivery/failure callbacks from providers.
Placeholder for webhook handlers.
"""
from app.outbound.message_queue import update_status


def handle_delivery_callback(msg_id: str, channel: str, status: str, details: dict = None) -> dict:
    if status == "delivered":
        update_status(msg_id, "delivered")
    elif status == "failed":
        error = details.get("error", "") if details else ""
        update_status(msg_id, "failed", error)
    elif status == "bounced":
        update_status(msg_id, "bounced", details.get("error", "bounced") if details else "bounced")
    return {"msg_id": msg_id, "status": status, "processed": True}
