"""
Email SMTP adapter.
Defaults to dry_run. No real connection without LIVE_SEND_ENABLED.
"""
import os
DRY_RUN = os.environ.get("LIVE_SEND_ENABLED", "false").lower() != "true"

SMTP_HOST = os.environ.get("EMAIL_SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("EMAIL_SMTP_PORT", 587))
SMTP_USER = os.environ.get("EMAIL_SMTP_USER", "")
SMTP_PASS = os.environ.get("EMAIL_SMTP_PASS", "")


def send_email(to: str, subject: str, body: str, draft_id: str = "") -> dict:
    if DRY_RUN:
        return {"status": "dry_run", "to": to, "channel": "email", "draft_id": draft_id}
    if not all([SMTP_HOST, SMTP_USER, SMTP_PASS]):
        return {"status": "error", "reason": "SMTP not configured"}
    try:
        import smtplib
        from email.mime.text import MIMEText
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = SMTP_USER
        msg["To"] = to
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.send_message(msg)
        return {"status": "sent", "to": to, "channel": "email"}
    except Exception as e:
        return {"status": "error", "reason": str(e)}


def check_config() -> dict:
    return {
        "configured": all([SMTP_HOST, SMTP_USER, SMTP_PASS]),
        "host": SMTP_HOST,
        "port": SMTP_PORT,
        "user": SMTP_USER[:5] + "..." if SMTP_USER else "",
        "dry_run": DRY_RUN
    }
