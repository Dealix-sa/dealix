"""
LinkedIn API adapter.
Defaults to dry_run.
"""
import os
DRY_RUN = os.environ.get("LIVE_SEND_ENABLED", "false").lower() != "true"
LINKEDIN_ACCESS_TOKEN = os.environ.get("LINKEDIN_ACCESS_TOKEN", "")


def send_linkedin_message(to_urn: str, body: str, draft_id: str = "") -> dict:
    if DRY_RUN:
        return {"status": "dry_run", "to": to_urn, "channel": "linkedin", "draft_id": draft_id}
    if not LINKEDIN_ACCESS_TOKEN:
        return {"status": "error", "reason": "LinkedIn access token not configured"}
    return {"status": "sent", "to": to_urn, "channel": "linkedin"}


def check_config() -> dict:
    return {
        "configured": bool(LINKEDIN_ACCESS_TOKEN),
        "dry_run": DRY_RUN
    }
