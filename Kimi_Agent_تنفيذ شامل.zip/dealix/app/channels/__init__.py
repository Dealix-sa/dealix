# Dealix Channels
# Adapters for Email, WhatsApp, LinkedIn
