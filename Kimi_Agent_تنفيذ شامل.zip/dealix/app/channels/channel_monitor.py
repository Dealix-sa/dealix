"""
Channel Monitor — status check for all channels.
"""
from app.channels.email_smtp import check_config as email_config
from app.channels.whatsapp_api import check_config as whatsapp_config
from app.channels.linkedin_api import check_config as linkedin_config


def check_all() -> dict:
    return {
        "email": email_config(),
        "whatsapp": whatsapp_config(),
        "linkedin": linkedin_config(),
        "overall": "ready" if any([email_config()["configured"], whatsapp_config()["configured"], linkedin_config()["configured"]]) else "not_configured"
    }


def get_sendable_channels() -> list:
    configs = check_all()
    return [ch for ch, cfg in configs.items() if isinstance(cfg, dict) and cfg.get("configured")]
