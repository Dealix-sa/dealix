"""
Send Attempt — unified send entry point for all channels.
"""
from app.channels.email_smtp import send_email
from app.channels.whatsapp_api import send_whatsapp
from app.channels.linkedin_api import send_linkedin_message


def send(channel: str, to: str, subject: str, body: str, draft_id: str = "") -> dict:
    if channel == "email":
        return send_email(to, subject, body, draft_id)
    elif channel == "whatsapp":
        return send_whatsapp(to, body, draft_id=draft_id)
    elif channel == "linkedin":
        return send_linkedin_message(to, body, draft_id)
    else:
        return {"status": "error", "reason": f"Unknown channel: {channel}"}
