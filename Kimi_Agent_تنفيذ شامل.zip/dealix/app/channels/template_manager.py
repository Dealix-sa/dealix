"""
Template Manager — approved message templates per channel.
"""
import os, csv
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["template_id", "channel", "template_name", "subject", "body", "status", "created_at"]


def create_template(channel: str, name: str, subject: str, body: str, status: str = "pending") -> dict:
    import uuid
    tid = f"tmpl_{uuid.uuid4().hex[:8]}"
    entry = {"template_id": tid, "channel": channel, "template_name": name,
             "subject": subject, "body": body, "status": status,
             "created_at": __now()}
    path = os.path.join(LEDGER_DIR, "message_templates.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            w.writeheader()
        w.writerow(entry)
    return {"template_id": tid, "status": status}


def list_approved_templates(channel: str = None):
    path = os.path.join(LEDGER_DIR, "message_templates.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = [r for r in csv.DictReader(f) if r.get("status") == "approved"]
    if channel:
        rows = [r for r in rows if r.get("channel") == channel]
    return rows


def approve_template(template_id: str, approved_by: str) -> dict:
    rows = []
    path = os.path.join(LEDGER_DIR, "message_templates.csv")
    if not os.path.exists(path):
        return {"error": "Not found"}
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get("template_id") == template_id:
            r["status"] = "approved"
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    return {"template_id": template_id, "status": "approved"}


def __now():
    from datetime import datetime
    return datetime.now().isoformat()
