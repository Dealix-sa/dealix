"""
Opt-in Handler — manages opt-in/opt-out across channels.
"""
from app.outbound.opt_in_consent import record_consent, revoke_consent, check_consent


def handle_opt_in(company_id: str, contact_id: str, channel: str) -> dict:
    return record_consent(company_id, contact_id, channel, method="explicit")


def handle_opt_out(company_id: str, contact_id: str, channel: str) -> dict:
    revoke_consent(company_id, contact_id, channel)
    from app.outbound.suppression_list import add_to_suppression
    add_to_suppression(company_id, contact_id, reason="opt_out")
    return {"status": "opted_out"}


def check_opt_in(company_id: str, contact_id: str, channel: str) -> dict:
    return check_consent(company_id, contact_id, channel)
