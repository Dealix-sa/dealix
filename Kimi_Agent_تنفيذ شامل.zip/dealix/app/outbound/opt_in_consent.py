"""
Opt-in Consent — every contact must explicitly opt-in.
No cold send on any channel.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["consent_id", "company_id", "contact_id", "channel", "consent_given", "consent_method", "consent_date", "revoked", "revoked_date", "created_at"]


def record_consent(company_id: str, contact_id: str, channel: str, method: str = "explicit"):
    import uuid
    entry = {"consent_id": f"cons_{uuid.uuid4().hex[:8]}", "company_id": company_id, "contact_id": contact_id,
             "channel": channel, "consent_given": "true", "consent_method": method,
             "consent_date": datetime.now().isoformat(), "revoked": "false", "revoked_date": "",
             "created_at": datetime.now().isoformat()}
    _write("opt_in_consent", entry, FIELDS)
    return {"status": "consent_recorded"}


def check_consent(company_id: str, contact_id: str, channel: str) -> dict:
    path = os.path.join(LEDGER_DIR, "opt_in_consent.csv")
    if not os.path.exists(path):
        return {"has_consent": False, "reason": "No consent records"}
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if (row.get("company_id") == company_id and row.get("contact_id") == contact_id
                    and row.get("channel") == channel):
                if row.get("revoked") == "true":
                    return {"has_consent": False, "reason": "Consent revoked"}
                if row.get("consent_given") == "true":
                    return {"has_consent": True, "consent_date": row.get("consent_date", "")}
    return {"has_consent": False, "reason": "No consent found"}


def revoke_consent(company_id: str, contact_id: str, channel: str):
    rows = []
    path = os.path.join(LEDGER_DIR, "opt_in_consent.csv")
    if not os.path.exists(path):
        return {"status": "not_found"}
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        if (row.get("company_id") == company_id and row.get("contact_id") == contact_id
                and row.get("channel") == channel):
            row["revoked"] = "true"
            row["revoked_date"] = datetime.now().isoformat()
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    return {"status": "revoked"}


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)
