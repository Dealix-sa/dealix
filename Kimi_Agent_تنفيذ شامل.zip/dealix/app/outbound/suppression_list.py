"""
Suppression List — auto-excluded from all sends.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["suppression_id", "company_id", "contact_id", "email", "phone", "reason", "created_at"]


def add_to_suppression(company_id: str, contact_id: str = "", email: str = "", phone: str = "", reason: str = "opt_out"):
    import uuid
    entry = {"suppression_id": f"supp_{uuid.uuid4().hex[:8]}", "company_id": company_id, "contact_id": contact_id, "email": email, "phone": phone, "reason": reason, "created_at": datetime.now().isoformat()}
    _write("suppression_list", entry, FIELDS)
    return {"status": "added", "company_id": company_id}


def is_suppressed(company_id: str, contact_id: str = "", email: str = "", phone: str = "") -> bool:
    path = os.path.join(LEDGER_DIR, "suppression_list.csv")
    if not os.path.exists(path):
        return False
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if (row.get("company_id") == company_id or row.get("contact_id") == contact_id or
                row.get("email") == email or row.get("phone") == phone):
                return True
    return False


def list_suppression():
    path = os.path.join(LEDGER_DIR, "suppression_list.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)
