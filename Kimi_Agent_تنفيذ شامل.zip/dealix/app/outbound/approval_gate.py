"""
Approval Gate — Human in the loop.
No message leaves without explicit approval.
"""
import os
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


class ApprovalGate:
    def can_send(self, draft_id: str, actor: str = "system") -> tuple:
        import csv
        path = os.path.join(LEDGER_DIR, "outbound_drafts.csv")
        if not os.path.exists(path):
            return False, "No drafts ledger found"
        with open(path, "r", encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                if row.get("draft_id") == draft_id:
                    if row.get("status") == "approved":
                        return True, "Approved"
                    if row.get("status") == "rejected":
                        return False, "Draft rejected"
                    if row.get("status") == "draft":
                        return False, "Draft not approved yet"
                    if row.get("opt_out") == "true":
                        return False, "Contact opted out"
                    return False, "Unknown status"
        return False, "Draft not found"

    def check_fake_claims(self, text: str) -> tuple:
        BLOCKED = [
            "نضمن", "نضاعف", "ضعف", "مضمونة", "مضمون",
            "100%", "نتائج مضمونة", "ارباح مضمونة",
            "guarantee", "guaranteed", "double revenue", "100% success"
        ]
        for phrase in BLOCKED:
            if phrase.lower() in text.lower():
                return False, f"Blocked phrase: {phrase}"
        return True, "Clean"


def get_gate():
    return ApprovalGate()
