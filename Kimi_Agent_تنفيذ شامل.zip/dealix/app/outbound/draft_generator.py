"""
Outbound Draft Generator — Arabic & English.
Generates compliant drafts only.
"""
import uuid, os
from datetime import datetime
from typing import Dict, Any, Optional

LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
DRAFTS_DIR = os.path.join(LEDGER_DIR, "drafts")
os.makedirs(DRAFTS_DIR, exist_ok=True)

DRAFT_FIELDS = [
    "draft_id", "company_id", "contact_id", "channel", "template_id",
    "subject", "body_path", "status", "created_by", "approved_by",
    "approved_at", "source_url", "opt_out", "created_at"
]

SAFE_TEMPLATES = {
    "intro_ar": """السلام عليكم {name}،

أتابع {company_name} من فترة وأقدر ما تقدمونه في {sector}.

في Dealix نشتغل مع شركات {sector} على أنظمة تشغيل ذكية تساعد في تنظيم المتابعة وتحسين سرعة الرد.

ما أطلبه هو ١٥ دقيقة مكالمة قصيرة نستكشف فيها إذا كان فيه تطابق.

مع التحية،
فريق Dealix
---
إذا لا ترغب في استلام رسائلنا أرسل 'إلغاء'.""",

    "intro_en": """Hi {name},

I've been following {company_name}'s work in {sector} — impressive.

At Dealix we build AI Operating Systems for {sector} companies to streamline follow-ups and improve response speed.

Would you be open to a brief 15-min exploration call?

Best,
Dealix Team
---
Reply STOP to unsubscribe.""",

    "followup_ar": """السلام عليكم {name}،

أرجع أتواصل بعد رسالتي السابقة.

{context}

هل تفضلون نحجز مكالمة قصيرة هذا الأسبوع؟

مع التحية،
فريق Dealix
---
إذا لا ترغب في استلام رسائلنا أرسل 'إلغاء'.""",

    "followup_en": """Hi {name},

Quick follow-up on my previous message.

{context}

Worth a quick 10-minute call this week?

Best,
Dealix Team
---
Reply STOP to unsubscribe.""",
}


def generate_draft(company_id: str, contact_id: str, channel: str,
                   template_id: str = "intro_ar", context: str = "",
                   created_by: str = "system") -> Dict[str, Any]:
    template = SAFE_TEMPLATES.get(template_id, SAFE_TEMPLATES["intro_ar"])
    draft_id = f"draft_{uuid.uuid4().hex[:8]}"
    body = template.format(name="", company_name="", sector="", context=context)
    body_path = os.path.join(DRAFTS_DIR, f"{draft_id}.txt")
    with open(body_path, "w", encoding="utf-8") as f:
        f.write(body)
    entry = {
        "draft_id": draft_id, "company_id": company_id, "contact_id": contact_id,
        "channel": channel, "template_id": template_id,
        "subject": "", "body_path": body_path, "status": "draft",
        "created_by": created_by, "approved_by": "", "approved_at": "",
        "source_url": "", "opt_out": "false",
        "created_at": datetime.now().isoformat()
    }
    _write_csv("outbound_drafts", entry, DRAFT_FIELDS)
    return {"draft_id": draft_id, "status": "draft", "body_preview": body[:200], "body_path": body_path}


def list_pending_drafts():
    return _read_csv("outbound_drafts", status="draft")


def approve_draft(draft_id: str, approved_by: str) -> Dict[str, Any]:
    _update_csv("outbound_drafts", "draft_id", draft_id, {
        "status": "approved", "approved_by": approved_by,
        "approved_at": datetime.now().isoformat()
    })
    return {"draft_id": draft_id, "status": "approved", "approved_by": approved_by}


def reject_draft(draft_id: str, reason: str) -> Dict[str, Any]:
    _update_csv("outbound_drafts", "draft_id", draft_id, {
        "status": "rejected"
    })
    return {"draft_id": draft_id, "status": "rejected", "reason": reason}


def _read_csv(name, **filters):
    import csv
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    if filters:
        for k, v in filters.items():
            rows = [r for r in rows if r.get(k) == v]
    return rows


def _write_csv(name, entry, fieldnames):
    import csv
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _update_csv(name, key, value, updates):
    import csv
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
