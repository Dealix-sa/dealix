"""
Rate Limiter — never exceed channel limits.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")

LIMITS = {
    "email": int(os.environ.get("EMAIL_DAILY_LIMIT", 25)),
    "whatsapp": int(os.environ.get("WHATSAPP_DAILY_LIMIT", 50)),
    "linkedin": int(os.environ.get("LINKEDIN_DAILY_LIMIT", 20)),
}


def get_sent_today(channel: str) -> int:
    path = os.path.join(LEDGER_DIR, "message_queue.csv")
    if not os.path.exists(path):
        return 0
    today = datetime.now().strftime("%Y-%m-%d")
    count = 0
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("channel") == channel:
                sent_at = row.get("sent_at", "")
                if sent_at.startswith(today) and row.get("status") in ("sent", "delivered"):
                    count += 1
    return count


def can_send(channel: str) -> dict:
    sent = get_sent_today(channel)
    limit = LIMITS.get(channel, 25)
    remaining = max(0, limit - sent)
    return {"channel": channel, "sent_today": sent, "limit": limit, "remaining": remaining, "allowed": sent < limit}


def list_all_remaining():
    return {ch: can_send(ch) for ch in LIMITS}
