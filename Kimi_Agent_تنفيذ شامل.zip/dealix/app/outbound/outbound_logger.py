"""
Outbound Logger — logs every send attempt with audit trail.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["log_id", "draft_id", "msg_id", "company_id", "channel", "status", "actor", "error", "timestamp"]


def log_send_attempt(draft_id: str, msg_id: str, company_id: str, channel: str,
                     status: str, actor: str = "system", error: str = ""):
    import uuid
    entry = {"log_id": f"log_{uuid.uuid4().hex[:8]}", "draft_id": draft_id, "msg_id": msg_id,
             "company_id": company_id, "channel": channel, "status": status, "actor": actor,
             "error": error, "timestamp": datetime.now().isoformat()}
    path = os.path.join(LEDGER_DIR, "outbound_log.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            w.writeheader()
        w.writerow(entry)
    return {"status": "logged"}


def get_logs(company_id: str = None, channel: str = None):
    path = os.path.join(LEDGER_DIR, "outbound_log.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    if company_id:
        rows = [r for r in rows if r.get("company_id") == company_id]
    if channel:
        rows = [r for r in rows if r.get("channel") == channel]
    return rows
