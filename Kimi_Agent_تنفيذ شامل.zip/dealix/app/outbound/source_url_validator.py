"""
Source URL Validator — every target must have source_url.
"""
import csv, os
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")


def validate_source_url(company_id: str) -> dict:
    path = os.path.join(LEDGER_DIR, "companies.csv")
    if not os.path.exists(path):
        return {"company_id": company_id, "has_source_url": False, "reason": "Companies ledger not found"}
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("company_id") == company_id:
                url = row.get("source_url", "").strip()
                if url:
                    return {"company_id": company_id, "has_source_url": True, "source_url": url}
                return {"company_id": company_id, "has_source_url": False, "reason": "Missing source_url"}
    return {"company_id": company_id, "has_source_url": False, "reason": "Company not found"}


def list_targets_without_source_url():
    path = os.path.join(LEDGER_DIR, "companies.csv")
    if not os.path.exists(path):
        return []
    missing = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            if not row.get("source_url", "").strip():
                missing.append(row)
    return missing
