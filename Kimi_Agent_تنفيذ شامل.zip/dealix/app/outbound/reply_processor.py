"""
Reply Processor — reads replies, generates follow-ups.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["reply_id", "msg_id", "company_id", "channel", "reply_content", "category",
          "sentiment", "next_action", "follow_up_due", "created_at"]

REPLY_CATEGORIES = {
    "interested": {"keywords": ["مهتم", "interested", "yes", "نعم", "ممكن", "موافق"], "next": "schedule_meeting"},
    "details": {"keywords": ["تفاصيل", "details", "more info", "معلومات", "عروض"], "next": "send_details"},
    "not_interested": {"keywords": ["not interested", "لا أهتم", "no thanks", "غير مهتم"], "next": "archive"},
    "opt_out": {"keywords": ["stop", "إلغاء", "unsubscribe", "quit"], "next": "opt_out"},
    "objection": {"keywords": ["expensive", "غالي", "later", "لاحقاً", "think"], "next": "objection_response"},
}


def process_reply(msg_id: str, company_id: str, channel: str, content: str) -> dict:
    import uuid
    content_lower = content.lower()
    category = "unknown"
    next_action = "human_review"
    sentiment = "neutral"

    for cat, data in REPLY_CATEGORIES.items():
        for kw in data["keywords"]:
            if kw.lower() in content_lower:
                category = cat
                next_action = data["next"]
                break

    if category in ("interested", "details"):
        sentiment = "positive"
    elif category in ("not_interested", "opt_out"):
        sentiment = "negative"
    elif category == "objection":
        sentiment = "neutral"

    reply_id = f"reply_{uuid.uuid4().hex[:8]}"
    follow_up_due = ""
    if next_action in ("schedule_meeting", "send_details"):
        from datetime import timedelta
        follow_up_due = (datetime.now() + timedelta(days=2)).isoformat()

    entry = {"reply_id": reply_id, "msg_id": msg_id, "company_id": company_id,
             "channel": channel, "reply_content": content[:500], "category": category,
             "sentiment": sentiment, "next_action": next_action,
             "follow_up_due": follow_up_due, "created_at": datetime.now().isoformat()}
    _write("replies", entry, FIELDS)

    if category == "opt_out":
        from app.outbound.suppression_list import add_to_suppression
        add_to_suppression(company_id, reason="opt_out_reply")

    return {"reply_id": reply_id, "category": category, "next_action": next_action, "sentiment": sentiment}


def get_pending_replies():
    path = os.path.join(LEDGER_DIR, "replies.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)
