"""
Channel Router — routes messages to correct channel adapter.
"""
from typing import Dict, Any


class ChannelRouter:
    def route(self, channel: str, draft_id: str) -> Dict[str, Any]:
        channels = {
            "email": {"adapter": "email_smtp", "needs_unsubscribe": True},
            "whatsapp": {"adapter": "whatsapp_api", "needs_opt_in": True},
            "linkedin": {"adapter": "linkedin_api", "needs_connection": True},
        }
        ch = channels.get(channel, {})
        if not ch:
            return {"error": f"Unknown channel: {channel}"}
        return {"channel": channel, **ch, "status": "routed"}


def get_router():
    return ChannelRouter()
