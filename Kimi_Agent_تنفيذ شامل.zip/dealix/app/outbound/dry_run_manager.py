"""
Dry Run Manager — tracks what WOULD have been sent.
All modes default to dry_run.
"""
import os, csv
from datetime import datetime
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")
FIELDS = ["dry_run_id", "draft_id", "msg_id", "company_id", "channel", "would_send_at", "gates_passed", "created_at"]


def record_dry_run(draft_id: str, msg_id: str, company_id: str, channel: str, gates_passed: list):
    import uuid
    entry = {"dry_run_id": f"dry_{uuid.uuid4().hex[:8]}", "draft_id": draft_id, "msg_id": msg_id,
             "company_id": company_id, "channel": channel, "would_send_at": datetime.now().isoformat(),
             "gates_passed": "|".join(gates_passed), "created_at": datetime.now().isoformat()}
    path = os.path.join(LEDGER_DIR, "dry_run_log.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            w.writeheader()
        w.writerow(entry)
    return {"status": "dry_run_recorded"}


def get_dry_run_summary():
    path = os.path.join(LEDGER_DIR, "dry_run_log.csv")
    if not os.path.exists(path):
        return {"total": 0, "by_channel": {}}
    channels = {}
    total = 0
    with open(path, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            total += 1
            ch = row.get("channel", "unknown")
            channels[ch] = channels.get(ch, 0) + 1
    return {"total": total, "by_channel": channels}
