"""
Dealix Outbound Engine

Controlled, gated, human-approved live outbound system.
Never sends without explicit approval.
"""
