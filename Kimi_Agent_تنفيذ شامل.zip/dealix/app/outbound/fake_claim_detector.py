"""
Fake Claim Detector — blocks every draft with promises or fake claims.
"""

BLOCKED_PHRASES = [
    "نضمن", "نضاعف", "ضعف", "مضمونة", "مضمون",
    "100% نجاح", "ارباح مضمونة", "ضعف ارباحك",
    "نرفع إيراداتك", "زيادة مبيعاتك فوراً",
    "guarantee", "guaranteed", "double revenue",
    "100% success", "guaranteed results", "immediate roi",
    "triple", "10x", "5x", "multiply revenue",
]


def scan(text: str) -> dict:
    violations = []
    for phrase in BLOCKED_PHRASES:
        if phrase.lower() in text.lower():
            violations.append(phrase)
    return {
        "clean": len(violations) == 0,
        "violations": violations,
        "action": "block" if violations else "pass"
    }


def validate_draft_file(body_path: str) -> dict:
    try:
        with open(body_path, "r", encoding="utf-8") as f:
            text = f.read()
        return scan(text)
    except Exception as e:
        return {"clean": False, "violations": [], "action": "block", "error": str(e)}
