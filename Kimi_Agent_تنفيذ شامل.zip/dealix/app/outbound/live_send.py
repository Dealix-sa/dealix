"""
Live Send — executes send only after all gates pass.
All modes default to dry_run.
"""
import os
DRY_RUN = os.environ.get("LIVE_SEND_ENABLED", "false").lower() != "true"

from app.outbound.approval_gate import get_gate
from app.outbound.suppression_list import is_suppressed
from app.outbound.source_url_validator import validate_source_url
from app.outbound.opt_in_consent import check_consent
from app.outbound.rate_limiter import can_send
from app.outbound.fake_claim_detector import validate_draft_file
from app.outbound.outbound_logger import log_send_attempt
from app.outbound.message_queue import update_status


def execute_send(draft_id: str, msg_id: str, company_id: str, contact_id: str,
                 channel: str, body_path: str, actor: str = "system") -> dict:
    # Gate 1: Approval
    gate = get_gate()
    ok, reason = gate.can_send(draft_id, actor)
    if not ok:
        log_send_attempt(draft_id, msg_id, company_id, channel, "blocked_gate", actor, reason)
        update_status(msg_id, "blocked", reason)
        return {"status": "blocked", "gate": "approval", "reason": reason}

    # Gate 2: Fake claims
    check = validate_draft_file(body_path)
    if not check["clean"]:
        log_send_attempt(draft_id, msg_id, company_id, channel, "blocked_fake_claims", actor, str(check["violations"]))
        update_status(msg_id, "blocked", f"Fake claims: {check['violations']}")
        return {"status": "blocked", "gate": "fake_claims", "violations": check["violations"]}

    # Gate 3: Source URL
    src = validate_source_url(company_id)
    if not src["has_source_url"]:
        log_send_attempt(draft_id, msg_id, company_id, channel, "blocked_no_source", actor)
        update_status(msg_id, "blocked", "No source_url")
        return {"status": "blocked", "gate": "source_url"}

    # Gate 4: Suppression
    if is_suppressed(company_id, contact_id):
        log_send_attempt(draft_id, msg_id, company_id, channel, "blocked_suppression", actor)
        update_status(msg_id, "blocked", "Suppressed")
        return {"status": "blocked", "gate": "suppression"}

    # Gate 5: Opt-in
    consent = check_consent(company_id, contact_id, channel)
    if not consent["has_consent"]:
        log_send_attempt(draft_id, msg_id, company_id, channel, "blocked_no_consent", actor)
        update_status(msg_id, "blocked", "No opt-in consent")
        return {"status": "blocked", "gate": "opt_in"}

    # Gate 6: Rate limit
    rate = can_send(channel)
    if not rate["allowed"]:
        log_send_attempt(draft_id, msg_id, company_id, channel, "blocked_rate_limit", actor)
        update_status(msg_id, "blocked", f"Rate limit: {rate['sent_today']}/{rate['limit']}")
        return {"status": "blocked", "gate": "rate_limit"}

    # Gate 7: Dry run (default)
    if DRY_RUN:
        log_send_attempt(draft_id, msg_id, company_id, channel, "dry_run", actor)
        update_status(msg_id, "dry_run")
        return {"status": "dry_run", "reason": "LIVE_SEND_ENABLED=false (default)"}

    # Actual send would go here (only if LIVE_SEND_ENABLED=true)
    log_send_attempt(draft_id, msg_id, company_id, channel, "sent", actor)
    update_status(msg_id, "sent")
    return {"status": "sent", "channel": channel}


def is_dry_run() -> bool:
    return DRY_RUN
