"""
Message Queue — pending, approved, rejected, sent.
"""
import os, csv
from typing import Dict, Any, List
LEDGER_DIR = os.environ.get("DEALIX_LEDGER_DIR", "ledgers")

QUEUE_FIELDS = ["msg_id", "draft_id", "company_id", "channel", "status", "priority", "scheduled_at", "sent_at", "delivered_at", "error_log", "created_at"]


def enqueue(draft_id: str, company_id: str, channel: str, priority: str = "normal") -> Dict[str, Any]:
    import uuid
    msg_id = f"msg_{uuid.uuid4().hex[:8]}"
    entry = {"msg_id": msg_id, "draft_id": draft_id, "company_id": company_id, "channel": channel, "status": "pending", "priority": priority, "scheduled_at": "", "sent_at": "", "delivered_at": "", "error_log": "", "created_at": __now()}
    _write("message_queue", entry, QUEUE_FIELDS)
    return {"msg_id": msg_id, "status": "pending"}


def list_queue(status: str = None) -> List[Dict[str, str]]:
    rows = _read("message_queue")
    if status:
        rows = [r for r in rows if r.get("status") == status]
    return rows


def update_status(msg_id: str, status: str, error: str = ""):
    updates = {"status": status}
    if status == "sent":
        updates["sent_at"] = __now()
    if status == "delivered":
        updates["delivered_at"] = __now()
    if error:
        updates["error_log"] = error
    _update("message_queue", "msg_id", msg_id, updates)
    return {"msg_id": msg_id, "status": status}


def retry(msg_id: str) -> Dict[str, Any]:
    _update("message_queue", "msg_id", msg_id, {"status": "pending", "error_log": "", "scheduled_at": __now()})
    return {"msg_id": msg_id, "status": "pending"}


def __now():
    from datetime import datetime
    return datetime.now().isoformat()


def _write(name, entry, fieldnames):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    with open(path, "a", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            w.writeheader()
        w.writerow(entry)


def _read(name):
    path = os.path.join(LEDGER_DIR, f"{name}.csv")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _update(name, key, value, updates):
    rows = _read(name)
    for r in rows:
        if r.get(key) == value:
            r.update(updates)
    if rows:
        path = os.path.join(LEDGER_DIR, f"{name}.csv")
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
