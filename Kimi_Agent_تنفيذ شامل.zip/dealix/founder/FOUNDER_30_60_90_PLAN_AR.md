# خطة 30-60-90 يوم

## 30 يوم: Foundation

### Product
- [ ] Product catalog published
- [ ] Pricing finalized
- [ ] Offer stack defined

### Sales
- [ ] 50 targets researched
- [ ] 20 outreach sent
- [ ] 5 meetings booked
- [ ] 1 diagnostic sprint

### Trust
- [ ] All trust policies written
- [ ] PDPL checklist ready
- [ ] Approval gates configured

### Operations
- [ ] Client template ready
- [ ] Delivery SOP written
- [ ] Proof report template ready

## 60 يوم: Traction

### Product
- [ ] 2 diagnostic sprints delivered
- [ ] 1 pilot OS launched
- [ ] Case studies started

### Sales
- [ ] 150 targets in pipeline
- [ ] 40 meetings completed
- [ ] 3 diagnostic sprints sold
- [ ] Sector playbook for #1 sector

### Trust
- [ ] First audit completed
- [ ] No violations
- [ ] Client data handling SOP followed

### Operations
- [ ] 1 client in delivery
- [ ] Proof reports generated
- [ ] UAT completed

## 90 يوم: Scale

### Product
- [ ] 5 diagnostic sprints delivered
- [ ] 2 pilot OS active
- [ ] 1 managed OS launched

### Sales
- [ ] 300 targets in pipeline
- [ ] 60 meetings completed
- [ ] Repeatable sector pitch
- [ ] Partner outreach started

### Trust
- [ ] Zero incidents
- [ ] All clients PDPL-ready
- [ ] AI usage policy enforced

### Operations
- [ ] 3 clients in delivery
- [ ] Weekly proof reports automated
- [ ] Client success reviews monthly

## Metrics

| Metric | 30d | 60d | 90d |
|--------|-----|-----|-----|
| Targets | 50 | 150 | 300 |
| Meetings | 5 | 40 | 60 |
| Diagnostics | 1 | 3 | 5 |
| Pilots | 0 | 1 | 2 |
| Managed | 0 | 0 | 1 |
| Revenue | 10K | 55K | 155K |
