# Daily Top 10 Actions Template

## Date: ___

### Priority 1 — MUST DO (moves needle)
1. ___

### Priority 2 — SHOULD DO (progress)
2. ___
3. ___
4. ___

### Priority 3 — NICE TO DO (maintenance)
5. ___
6. ___
7. ___

### Priority 4 — IF TIME
8. ___
9. ___
10. ___

---

### Default Actions (if no specific plan)

1. Research 20 new targets
2. Review 5 outreach drafts
3. Approve and send 3 messages
4. Follow up on yesterday's replies
5. Book 1 meeting
6. Update ledgers
7. Post 1 LinkedIn content
8. Check active project status
9. Update founder decision log
10. Plan tomorrow

### Rules
- At least 3 actions must be revenue-generating
- At least 1 action must be ledger-updating
- No day without outreach
- No day without content
