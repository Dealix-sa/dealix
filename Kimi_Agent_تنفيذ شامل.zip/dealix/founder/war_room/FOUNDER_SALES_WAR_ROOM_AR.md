# غرفة الحرب المبيعات — Founder Sales War Room

## الهدف

تحويل المؤسس من عامل إلى قائد مبيعات يومي.

## المكونات

1. Daily Sales Scorecard
2. Top 10 Actions
3. Pipeline Review
4. Follow-up Commands
5. Objection Log
6. Closing Decision Rules
7. Deal Review Template

## مبدأ

> "كل يوم بدون outreach هو يوم بدون فرص."

## الروتين

### الصباح (15 دقيقة)
1. افتح DAILY_SALES_SCORECARD.md
2. املأ yesterday's results
3. اختر Today's Top 3
4. راجع PIPELINE_REVIEW.md

### منتصف اليوم (4-6 ساعات)
1. Outreach block (1-2h)
2. Meeting block (1-3h)
3. Follow-up block (30m)

### آخر اليوم (15 دقيقة)
1. املأ scorecard
2. سجل decisions
3. خطط الغد

## القواعد

- لا تعرض نظام كامل قبل إثبات workflow واحد.
- لا تقبل عميل بدون صاحب قرار واضح.
- لا تقبل مشروع بدون بيانات أو access واضح.
- لا تبيع AI عام؛ بيع operating outcome.
- لا تقدم وعود ROI.
- لا ترسل proposal بدون blueprint.
- لا تبدأ delivery بدون acceptance criteria.
- لا تحول إلى retainer بدون proof report.

## Metrics

| Metric | Weekly Target |
|--------|--------------|
| Targets | 100 |
| Outreach | 15 |
| Meetings | 2-3 |
| Proposals | 1 |
| Deals | 0.5-1 |
