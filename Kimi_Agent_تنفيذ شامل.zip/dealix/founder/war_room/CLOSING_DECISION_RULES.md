# قواعد إغلاق الصفقة — Closing Decision Rules

## Golden Rules

1. **لا تعرض نظام كامل قبل إثبات workflow واحد**
2. **لا تقبل عميل بدون صاحب قرار واضح**
3. **لا تقبل مشروع بدون بيانات أو access واضح**
4. **لا تبيع AI عام؛ بيع operating outcome**
5. **لا تقدم وعود ROI**
6. **لا ترسل proposal بدون blueprint**
7. **لا تبدأ delivery بدون acceptance criteria**
8. **لا تحول إلى retainer بدون proof report**

## Deal Acceptance Checklist

لا تقبل الصفقة إلا إذا:

- [ ] يوجد صاحب قرار
- [ ] يوجد ألم واضح
- [ ] يوجد أول workflow محدد
- [ ] يوجد data source واضح
- [ ] يوجد review owner
- [ ] يوجد success metric
- [ ] يوجد timeline
- [ ] يوجد scope واضح
- [ ] يوجد acceptance criteria
- [ ] لا توجد وعود ROI وهمية
- [ ] لا يوجد طلب إرسال خارجي غير محكوم

## Pricing Rules

- Diagnostic Sprint: Fixed price, non-negotiable
- Pilot OS: Fixed price, payment 50/50
- Managed OS: Monthly, paid in advance
- Custom: Project-based, 30/40/30
- No discount > 20% without founder approval
- No free work

## Red Flags (Walk Away)

- No decision maker identified
- Wants guaranteed ROI
- Wants to start without intake
- No budget clarity after 2 meetings
- Refuses to sign proposal
- Asks for free pilot
- Wants to bypass approval gates
- Wants us to store sensitive data without DPA

## Green Flags (Fast Track)

- Clear pain identified
- Decision maker engaged
- Budget discussed openly
- Timeline clear
- Data available
- Previous system failed
- Referral from existing client

## Next Step Messages

### After Discovery Call
```
Thank you for the conversation. Based on what you shared,
I recommend we start with a Company Diagnosis Sprint.

I'll send the proposal within 24 hours.
```

### After Proposal Sent
```
The proposal is ready. Can we schedule 15 minutes
this week to walk through it?
```

### After Acceptance
```
Welcome to Dealix. Your kickoff is scheduled for [DATE].
Intake form attached. Please complete before the meeting.
```

### After Rejection
```
I understand. Can you share what would make this work?
I'm happy to revisit when the timing is better.
```
