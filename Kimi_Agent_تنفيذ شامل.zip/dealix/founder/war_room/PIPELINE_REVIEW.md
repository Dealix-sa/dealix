# Pipeline Review

## Current Pipeline

### Stage: Target
| Company | Sector | Source | Score | Next Action |
|---------|--------|--------|-------|-------------|
| | | | | |

### Stage: Qualified
| Company | Sector | Pain | Score | Next Action |
|---------|--------|------|-------|-------------|
| | | | | |

### Stage: Outreach Sent
| Company | Sector | Date | Channel | Status |
|---------|--------|------|---------|--------|
| | | | | |

### Stage: Meeting Booked
| Company | Date | Type | Notes |
|---------|------|------|-------|
| | | | |

### Stage: Proposal Sent
| Company | Product | Value | Sent Date | Status |
|---------|---------|-------|-----------|--------|
| | | | | |

### Stage: Negotiation
| Company | Product | Value | Blocker |
|---------|---------|-------|---------|
| | | | |

### Stage: Closed Won
| Company | Product | Value | Close Date |
|---------|---------|-------|------------|
| | | | |

### Stage: Closed Lost
| Company | Reason | Lost Date | Learnings |
|---------|--------|-----------|-----------|
| | | | |

## Pipeline Health
- Total pipeline value: ___ SAR
- Win rate: ___%
- Average deal size: ___ SAR
- Sales cycle: ___ days
- Top source: ___
