# Daily Sales Scorecard

## Date: ___

### Yesterday's Results
- Targets researched: ___
- Qualified targets: ___
- Drafts generated: ___
- Messages approved: ___
- Manual sends: ___
- Replies: ___
- Meetings booked: ___
- Proposals sent: ___
- Deals won: ___
- Deals lost: ___

### Today's Plan
- [ ] Outreach block (1-2h)
- [ ] Meeting block (1-3h)
- [ ] Follow-up block (30m)
- [ ] Content (1 LinkedIn post)
- [ ] Ledger update

### Pipeline Status
| Stage | Count | Value (SAR) |
|-------|-------|-------------|
| Target | ___ | - |
| Qualified | ___ | - |
| Outreach sent | ___ | - |
| Meeting booked | ___ | - |
| Proposal sent | ___ | ___ |
| Negotiation | ___ | ___ |
| Closed won | ___ | ___ |
| Closed lost | ___ | ___ |

### Top Blocker
___

### Top Opportunity
___

### Founder Decision Today
___

### Next 10 Actions
1. ___
2. ___
3. ___
4. ___
5. ___
6. ___
7. ___
8. ___
9. ___
10. ___

### Notes
___
