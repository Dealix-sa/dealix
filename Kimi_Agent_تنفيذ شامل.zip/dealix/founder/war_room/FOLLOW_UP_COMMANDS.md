# أوامر المتابعة — Follow-up Commands

## القواعد العامة

1. كل follow-up يجب أن يكون له context
2. لا spam — فاصل 2-3 أيام
3. كل follow-up يقدم قيمة
4. اربط بالألم الأصلي

## Follow-up Sequence

### Day 1 (Initial outreach)
- Channel: Email or LinkedIn
- Content: Value-first introduction
- Goal: Get attention

### Day 3 (First follow-up)
- Content: "Quick follow-up — thought this might help"
- Add: Relevant insight or sector stat
- Goal: Stay top of mind

### Day 7 (Second follow-up)
- Content: "Still relevant?"
- Add: Case example (no client name)
- Goal: Create urgency

### Day 14 (Third follow-up)
- Content: "Final follow-up"
- Add: "If not now, happy to reconnect in [quarter]"
- Goal: Close loop

### Day 30 (Nurture)
- Content: Sector insight or content piece
- No ask — just value
- Goal: Stay visible

## Templates

### Follow-up 1
```
Hi [Name],

Quick follow-up on my message about [pain].

I recently helped a [sector] company [result context].

Worth a 10-minute conversation?

[Unsubscribe]
```

### Follow-up 2
```
Hi [Name],

Still thinking about [pain]?

Here's what I'm seeing in [sector] right now: [insight].

Happy to share more if helpful.

[Unsubscribe]
```

### Follow-up 3 (Final)
```
Hi [Name],

This is my final follow-up.

If [pain] is not a priority right now, I completely understand.

Happy to reconnect in [quarter] if things change.

[Unsubscribe]
```

## LinkedIn Follow-up

- Keep shorter
- Reference their post or activity
- No hard sell
- End with question

## WhatsApp Follow-up

- Only after opt-in
- Shorter than email
- Personal tone
- Arabic preferred
