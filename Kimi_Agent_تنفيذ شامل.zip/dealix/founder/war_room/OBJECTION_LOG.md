# سجل الاعتراضات — Objection Log

## Common Objections

### " expensive"
- **Response**: "The diagnostic sprint is a fixed fee. No surprises. Let's start there and see if there's value."
- **Prevention**: Always anchor with diagnostic price first

### "We already have a system"
- **Response**: "Great. What system? [Listen] Most systems handle one part. Dealix connects the whole loop. Worth a 10-min exploration?"
- **Prevention**: Ask about current tools in discovery

### "We need to think about it"
- **Response**: "Of course. What specifically needs thinking? [Listen] Can I send you a one-pager on [specific topic]?"
- **Prevention**: Create urgency with pain

### "Not the right time"
- **Response**: "I understand. What would make it the right time? [Listen] Can I check back in [specific time]?"
- **Prevention**: Focus on cost of waiting

### "We do this manually"
- **Response**: "And how's that working? [Listen] What would you do with the time saved?"
- **Prevention**: Quantify manual effort

### "AI is not trustworthy"
- **Response**: "I agree. That's why we use human-in-the-loop. AI suggests, human approves. No blind automation."
- **Prevention**: Lead with trust framework

### "We need approval from..."
- **Response**: "Who needs to approve? [Listen] Can we schedule a 15-min call with them?"
- **Prevention**: Identify decision maker early

### "We tried something similar"
- **Response**: "What happened? [Listen] What was missing? How would you do it differently?"
- **Prevention**: Differentiate early

### "Just send me information"
- **Response**: "Happy to. What specifically would help? [Listen] Actually, can I ask 2 quick questions to send the right info?"
- **Prevention**: Don't send generic info

## Objection Template

```
## Objection: [TEXT]
Date: ___
Sector: ___
Client: ___

Response given: ___

Outcome: ___

Learnings: ___

Improved response: ___
```

## Rules

- Every objection is logged
- Every objection gets an improved response
- Monthly review of objection patterns
- Update sector pitches based on objections
