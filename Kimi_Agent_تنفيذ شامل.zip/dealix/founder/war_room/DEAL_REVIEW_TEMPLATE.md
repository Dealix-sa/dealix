# Deal Review Template

## Deal: [CLIENT_NAME] — [PRODUCT]

###基本信息
- Client: ___
- Sector: ___
- Product: ___
- Value: ___ SAR
- Start date: ___
- Expected close: ___

### Discovery
- Pain identified: ___
- Current tools: ___
- Decision maker: ___
- Budget: ___
- Timeline: ___

### Qualification
- ICP fit: ___/10
- Pain clarity: ___/10
- Decision access: ___/10
- Budget clarity: ___/10
- Data availability: ___/10
- **Total score: ___/50**

### Proposal
- Product recommended: ___
- Scope: ___
- Price: ___ SAR
- Payment terms: ___
- Timeline: ___

### Status
- Current stage: ___
- Next action: ___
- Blocker: ___
- Expected close: ___

### Risk
- [ ] No decision maker
- [ ] Budget unclear
- [ ] Timeline unclear
- [ ] Scope creep risk
- [ ] Technical risk
- [ ] Competitive risk

### Decision
- Proceed / Pause / Walk away
- Why: ___
