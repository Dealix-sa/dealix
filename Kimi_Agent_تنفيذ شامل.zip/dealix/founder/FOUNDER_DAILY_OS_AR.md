# نظام التشغيل اليومي للمؤسس

## الصباح (30-60 دقيقة)

### 1. فحص Command Room
```bash
make business-day
# أو
python scripts/business/run_business_day.py
```
- Revenue pipeline
- Active clients
- Blockers
- Founder actions

### 2. اختيار 10 Actions
- من command room
- من المتابعات المعلقة
- من الموافقات المطلوبة

### 3. مراجعة Targets
- من led new companies
- تأهيل جديد
- outreach drafts

### 4. الموافقة على الرسائل
- outreach drafts pending approval
- لا موافقة بدون قراءة

### 5. متابعة الردود
- interested replies
- meetings لتحديد

## منتصف اليوم

### مكالمات
- Discovery calls
- Follow-up calls
- Client check-ins

### عروض
- Proposal reviews
- Client presentations

### Follow-ups
- Email follow-ups
- LinkedIn messages
- WhatsApp (approved only)

## آخر اليوم

### تحديث Ledgers
- تحديث companies
- تحديث deals pipeline
- تحديث tasks

### Proof Notes
- ما تم اليوم
- ملاحظات العملاء
- قرارات

### Decisions Log
- أي قرار تم اتخاذه
- لماذا
- من
- متى

### Blockers
- ما يمنع التقدم
- من يحلها
- متى

### خطة الغد
- أهم 3 أولويات
- المواعيد
- المتابعات

## Weekly Review

### الأحد
- خطة الأسبوع
- أولويات
- المواعيد

### الجمعة
- مراجعة الأسبوع
- what worked / what didn't
- founder decision log
-下周 priorities
