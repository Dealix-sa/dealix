# PDPL Readiness Checklist

## Personal Data Protection Law — Saudi Arabia

## Controller Obligations

- [ ] تحديد المتحكم في البيانات
- [ ] تحديد الغرض من جمع البيانات
- [ ] إشعار أصحاب البيانات
- [ ] الحصول على consent صريح
- [ ] تسجيل أنشطة المعالجة
- [ ] تعيين مسؤول حماية البيانات (DPO)

## Data Processing

- [ ] لا جمع بيانات زائدة
- [ ] حد أدنى من البيانات (data minimization)
- [ ] تخزين آمن
- [ ] فترة الاحتفاز محددة
- [ ] حذف آمن عند انتهاء الغرض

## Data Subject Rights

- [ ] Right to access
- [ ] Right to correction
- [ ] Right to destruction
- [ ] Right to withdraw consent

## Cross-Border Transfer

- [ ] لا نقل بيانات شخصية خارج السعودية إلا بموافقة

## AI-Specific

- [ ] لا قرارات آليّة تؤثر على أصحاب البيانات بدون إشراف
- [ ] إشعار واضح عند استخدام AI
- [ ] human review for sensitive outputs

## Dealix Specific

- [ ] بيانات العملاء (our clients) = controller responsibility
- [ ] بيانات عملاء العملاء (end customers) = we process on behalf
- [ ] DPA (Data Processing Agreement) مع كل عميل
- [ ] Audit trail for all data access
- [ ] No training on client data without explicit consent
