# No Fake Claims Policy

## Principle

Dealix never makes claims we cannot prove.

## Prohibited Claims

- "We guarantee X% increase in sales"
- "Your revenue will double"
- "100% success rate"
- "Guaranteed results"
- "Immediate ROI"
- Specific percentages without context

## Allowed Language

- "Based on our experience with similar companies..."
- "Our clients have reported..."
- "The system is designed to..."
- "You may see improvements in..."
- "We will track and report..."

## Proof Requirements

Every claim in a proposal must be backed by:
1. Data from the client's own system
2. Industry benchmarks (with source)
3. Case studies (real, with client permission)

## Enforcement

- policy_gate.py blocks all outbound with fake claims
- validate_proposal.py checks for prohibited language
- Human review is required for all proposals
