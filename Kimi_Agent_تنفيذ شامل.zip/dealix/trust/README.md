# Trust & Compliance System

Policies and procedures for safe, PDPL-compliant, AI-governed operations.

## Core Principles

1. No external send by default
2. No WhatsApp cold automation without opt-in
3. No fake ROI or guaranteed claims
4. No fake testimonials
5. Source URL required for all targets
6. Unsubscribe required for email
7. Suppression list respected
8. Human approval before sensitive actions
9. Audit log for major actions
10. No secrets in repo
11. PDPL-aware data handling
12. No blind automation

## Files

| File | Purpose |
|------|---------|
| `PDPL_READINESS_CHECKLIST_AR.md` | PDPL compliance checklist |
| `AI_USAGE_POLICY_AR.md` | AI governance policy |
| `CLIENT_DATA_HANDLING_SOP_AR.md` | Data handling procedures |
| `HUMAN_APPROVAL_GATES.md` | Approval gate definitions |
| `NO_FAKE_CLAIMS_POLICY.md` | No fake claims enforcement |
| `NO_FAKE_TESTIMONIALS_POLICY.md` | Testimonial authenticity |
| `SENSITIVE_DATA_POLICY.md` | Sensitive data handling |
| `CONTROLLED_LIVE_OUTBOUND_POLICY.md` | Outbound safety policy |
| `DSAR_SOP_AR.md` | Data Subject Access Request |
| `INCIDENT_RESPONSE_AR.md` | Security incident response |
| `AI_OUTPUT_REVIEW_LOG.md` | AI output review tracking |
