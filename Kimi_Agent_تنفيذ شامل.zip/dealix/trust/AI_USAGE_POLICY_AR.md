# سياسة استخدام الذكاء الاصطناعي

## المبدأ

AI في Dealix هو مساعد، لا بديل عن الحكم البشري.

## قواعد الاستخدام

1. **Human-in-the-loop**: كل إجراء مهم يحتاج موافقة بشرية
2. **No blind automation**: لا أتمتة بدون مراجعة
3. **Data minimization**: نستخدم أقل البيانات الممكنة
4. **No training on client data**: بدون consent صريح
5. **Audit trail**: كل استخدام AI مسجل

## ما يجوز لـ AI فعله

- تصنيف وتلخيص
- مسودات ردود (للمراجعة)
- توليد تقارير
- تحليل أنماط
- اقتراح إجراءات

## ما لا يجوز لـ AI فعله بدون موافقة

- إرسال رسائل خارجية
- اتخاذ قرارات مالية
- الوصول لبيانات حساسة
- حذف أو تعديل بيانات
- وعد العميل بشيء

## AI Security

- OWASP Top 10 for LLM compliance
- Prompt injection prevention
- Output sanitization
- Rate limiting
- Access controls

## Review Process

All AI outputs must be reviewed before:
- External send
- Client-facing reports
- Decision recommendations
- Sensitive data handling
