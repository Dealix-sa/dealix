"""Tests for outbound approval gate."""

import pytest
from app.outbound.approval_gate import ApprovalGate, get_gate


class TestApprovalGate:
    def test_gate_can_be_created(self):
        gate = ApprovalGate()
        assert gate is not None

    def test_can_send_returns_tuple(self):
        gate = ApprovalGate()
        result = gate.can_send("nonexistent-draft")
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_can_send_blocks_unknown_draft(self):
        gate = ApprovalGate()
        allowed, reason = gate.can_send("nonexistent-draft")
        assert allowed is False

    def test_check_fake_claims_blocks_guarantee(self):
        gate = ApprovalGate()
        clean, reason = gate.check_fake_claims("نضمن لك النجاح")
        assert clean is False
        assert "Blocked" in reason

    def test_check_fake_claims_passes_safe(self):
        gate = ApprovalGate()
        clean, reason = gate.check_fake_claims("Hello, we offer services.")
        assert clean is True

    def test_get_gate_returns_instance(self):
        gate = get_gate()
        assert isinstance(gate, ApprovalGate)
