"""Tests for ops safety audit."""

import pytest
import os


class TestOpsSafety:
    def test_external_send_disabled_by_default(self):
        """EXTERNAL_SEND_ENABLED must default to false."""
        val = os.environ.get("EXTERNAL_SEND_ENABLED", "false").lower()
        assert val == "false", "EXTERNAL_SEND_ENABLED should be false for safety"

    def test_approval_required_default(self):
        """OUTBOUND_REQUIRE_APPROVAL must default to true."""
        val = os.environ.get("OUTBOUND_REQUIRE_APPROVAL", "true").lower()
        assert val == "true", "Approval should be required by default"

    def test_fake_claims_blocked_default(self):
        """OUTBOUND_BLOCK_FAKE_CLAIMS must default to true."""
        val = os.environ.get("OUTBOUND_BLOCK_FAKE_CLAIMS", "true").lower()
        assert val == "true", "Fake claims should be blocked by default"

    def test_email_disabled_by_default(self):
        val = os.environ.get("EMAIL_SEND_ENABLED", "false").lower()
        assert val == "false"

    def test_whatsapp_disabled_by_default(self):
        val = os.environ.get("WHATSAPP_SEND_ENABLED", "false").lower()
        assert val == "false"

    def test_safety_env_vars_exist(self):
        """All safety env vars should have safe defaults."""
        safety_checks = [
            ("EXTERNAL_SEND_ENABLED", "false"),
            ("OUTBOUND_REQUIRE_APPROVAL", "true"),
            ("OUTBOUND_BLOCK_FAKE_CLAIMS", "true"),
            ("OUTBOUND_REQUIRE_SOURCE_URL", "true"),
            ("EMAIL_SEND_ENABLED", "false"),
            ("WHATSAPP_SEND_ENABLED", "false"),
        ]
        for var, expected_default in safety_checks:
            actual = os.environ.get(var, expected_default).lower()
            assert actual == expected_default, f"{var} should default to {expected_default}"
