"""Tests for delivery system core."""

import pytest
from app.delivery.delivery_planner import create_project, add_task, get_project_tasks
from app.delivery.sprint_manager import create_sprint, get_sprints
from app.delivery.delivery_status import get_project_status, get_all_active_projects
from app.delivery.escalation_tracker import check_stuck_projects, check_overdue_projects, generate_alert_report


class TestDeliveryCore:
    def test_create_project(self):
        result = create_project("test-client-001", "Test Project", owner="test_owner")
        assert result is not None
        assert result.get("project_id", "").startswith("proj_")
        assert result.get("status") == "active"

    def test_add_task(self):
        result = add_task("test-proj-001", "Test Task", "test_owner")
        assert result is not None
        assert result.get("task_id", "").startswith("task_")

    def test_get_project_tasks_returns_list(self):
        tasks = get_project_tasks("test-proj-001")
        assert isinstance(tasks, list)

    def test_create_sprint(self):
        result = create_sprint("test-proj-001", 1, "Test Sprint", "2024-01-01", "2024-01-14")
        assert result is not None
        assert result.get("sprint_id", "").startswith("sprint_")

    def test_get_sprints_returns_list(self):
        sprints = get_sprints("test-proj-001")
        assert isinstance(sprints, list)

    def test_project_status_returns_dict(self):
        status = get_project_status("test-proj-001")
        assert isinstance(status, dict)
        assert "error" in status or "tasks" in status

    def test_get_active_projects_returns_list(self):
        projects = get_all_active_projects()
        assert isinstance(projects, list)

    def test_stuck_projects_returns_list(self):
        stuck = check_stuck_projects()
        assert isinstance(stuck, list)

    def test_overdue_projects_returns_list(self):
        overdue = check_overdue_projects()
        assert isinstance(overdue, list)

    def test_alert_report_has_fields(self):
        report = generate_alert_report()
        assert "stuck_tasks" in report
        assert "overdue_projects" in report
        assert "generated_at" in report
