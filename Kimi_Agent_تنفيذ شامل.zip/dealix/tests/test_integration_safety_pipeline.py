"""Integration test: full safety pipeline from content generation to send."""

import pytest
import os
from app.ai.safe_content_filter import check_content_safety
from app.ai.hallucination_detector import detect_hallucination
from app.ai.prompt_guard import scan_input
from app.ai.privacy_redactor import redact_pii
from app.outbound.live_send import execute_send, is_dry_run
from app.outbound import rate_limiter
from app.outbound import suppression_list


class TestIntegrationSafetyPipeline:
    def test_unsafe_content_blocked_by_safety_filter(self):
        """Content with fake claims should be blocked by safety filter."""
        unsafe_text = "نضمن لك نتائج مضمونة 100%"
        safety = check_content_safety(unsafe_text, context="outbound")
        assert safety.passed is False

    def test_safe_content_passes_all_checks(self):
        """Safe content should pass all safety checks."""
        safe_text = "Hello, I'd like to discuss how our services might help your business."

        # Content filter
        safety = check_content_safety(safe_text, context="outbound")
        assert safety.passed is True

        # Hallucination check
        hall = detect_hallucination(safe_text)
        assert hall.risk_level.value in ("none", "low")

        # Prompt guard
        guard = scan_input(safe_text)
        assert guard.blocked is False

    def test_pii_redacted_before_logging(self):
        """PII should be redacted before any logging."""
        text_with_pii = "Contact john@example.com or call +966501234567"
        result = redact_pii(text_with_pii)
        assert "john@example.com" not in result.redacted_text
        assert "+966501234567" not in result.redacted_text
        assert result.redaction_count >= 2

    def test_suppressed_contact_blocked(self):
        """Suppressed contacts should be blocked from sends."""
        suppression_list.add_to_suppression("suppressed-company-001", contact_id="suppressed-contact-001", reason="opt_out")
        assert suppression_list.is_suppressed("suppressed-company-001") is True

    def test_rate_limits_return_valid_dict(self):
        """Rate limits should return valid status."""
        result = rate_limiter.can_send("email")
        assert isinstance(result, dict)
        assert "remaining" in result
        assert "allowed" in result
        assert result["limit"] == 25  # default

    def test_dry_run_mode_is_default(self):
        """Without LIVE_SEND_ENABLED=true, the system is in dry-run mode."""
        os.environ["LIVE_SEND_ENABLED"] = "false"
        assert is_dry_run() is True

    def test_unapproved_draft_is_blocked(self):
        """A non-existent draft should be blocked at the approval gate."""
        os.environ["LIVE_SEND_ENABLED"] = "false"
        result = execute_send(
            draft_id="nonexistent_draft",
            msg_id="m1", company_id="c1",
            contact_id="con1", channel="email", body_path="test.txt"
        )
        assert result["status"] == "blocked"
        assert result["gate"] == "approval"

    def test_end_to_end_safe_pipeline(self):
        """Full pipeline: safe content passes all checks."""
        text = "We provide AI operating systems for companies looking to scale."

        # Step 1: Content safety
        safety = check_content_safety(text, context="outbound")
        assert safety.passed is True

        # Step 2: Hallucination check
        hall = detect_hallucination(text)
        assert hall.risk_level.value in ("none", "low")

        # Step 3: Prompt guard (if user-generated)
        guard = scan_input(text)
        assert guard.blocked is False

        # Step 4: PII check
        privacy = redact_pii(text)
        assert privacy.redaction_count == 0

        # All clear
        assert True
