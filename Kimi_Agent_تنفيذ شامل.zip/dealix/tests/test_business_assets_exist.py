"""
Test: Business assets exist
Ensures all business files are created.
"""

from pathlib import Path


def test_strategy_files_exist():
    files = [
        "business/strategy/DEALIX_POSITIONING_AR.md",
        "business/strategy/DEALIX_POSITIONING_EN.md",
        "business/strategy/COMPANY_NARRATIVE_AR.md",
        "business/strategy/MARKET_THESIS_SAUDI_AI_OS_AR.md",
        "business/strategy/ICP_STRATEGY_AR.md",
        "business/strategy/COMPETITIVE_POSITIONING_AR.md",
        "business/strategy/STRATEGIC_MOATS_AR.md",
        "business/strategy/CATEGORY_DESIGN_AR.md",
        "business/strategy/FOUNDER_DECISION_RULES_AR.md",
        "business/strategy/ICP_QUALIFICATION_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_product_catalog_exists():
    files = [
        "business/products/PRODUCT_CATALOG_AR.md",
        "business/products/PRODUCT_CATALOG_EN.md",
        "business/products/CLIENT_DELIVERY_OS.md",
        "business/products/COMPANY_DIAGNOSIS_SPRINT.md",
        "business/products/COMPANY_BRAIN_OS.md",
        "business/products/CONTROLLED_LIVE_OUTBOUND_OS.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_pricing_exists():
    files = [
        "business/pricing/PRICING_STRATEGY_AR.md",
        "business/pricing/UNIT_ECONOMICS.md",
        "business/pricing/MARGIN_MODEL.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_gtm_exists():
    files = [
        "business/gtm/GTM_MASTER_PLAN_AR.md",
        "business/gtm/SECTOR_PRIORITY_MAP_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_sales_assets_exist():
    files = [
        "sales/README.md",
        "sales/SECTOR_PITCHES_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_proposal_templates_exist():
    files = [
        "proposals/_templates/EXECUTIVE_PROPOSAL_AR.md",
        "proposals/_templates/DIAGNOSTIC_SPRINT_PROPOSAL_AR.md",
        "proposals/_templates/MANAGED_OS_PROPOSAL_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_trust_assets_exist():
    files = [
        "trust/README.md",
        "trust/PDPL_READINESS_CHECKLIST_AR.md",
        "trust/NO_FAKE_CLAIMS_POLICY.md",
        "trust/AI_USAGE_POLICY_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_founder_os_exists():
    files = [
        "founder/FOUNDER_DAILY_OS_AR.md",
        "founder/FOUNDER_30_60_90_PLAN_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_content_strategy_exists():
    assert Path("content/CONTENT_STRATEGY_AR.md").exists()


def test_partnerships_exists():
    assert Path("partnerships/PARTNERSHIP_STRATEGY_AR.md").exists()


def test_research_exists():
    assert Path("research/SAUDI_AI_MARKET_NOTES.md").exists()
