"""
Test: Prospecting pack is complete.
"""
from pathlib import Path


def test_prospecting_files_exist():
    files = [
        "gtm/prospecting/PROSPECTING_OPERATING_MODEL_AR.md",
        "gtm/prospecting/TARGET_RESEARCH_SOP_AR.md",
        "gtm/prospecting/TARGET_VERIFICATION_SOP_AR.md",
        "gtm/prospecting/SECTOR_TARGETING_RULES_AR.md",
        "gtm/prospecting/100_TARGET_DAY_TEMPLATE.csv",
        "gtm/prospecting/PROSPECT_SCORING_MODEL.md",
        "gtm/prospecting/OUTREACH_APPROVAL_CHECKLIST.md",
        "gtm/prospecting/MANUAL_SEND_SOP_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_prospect_scoring_model_has_points():
    path = Path("gtm/prospecting/PROSPECT_SCORING_MODEL.md")
    content = path.read_text()
    assert "100" in content
    assert "priority" in content.lower() and ("a" in content.lower() or "b" in content.lower())


def test_target_template_has_header():
    path = Path("gtm/prospecting/100_TARGET_DAY_TEMPLATE.csv")
    content = path.read_text()
    assert "company_name" in content
    assert "sector" in content
    assert "source_url" in content
