"""
Test: Client intake required before diagnosis
No diagnosis without completed intake.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.policy_gate import get_gate


def test_diagnosis_requires_intake():
    """Diagnosis should fail without completed intake."""
    gate = get_gate()

    # Non-existent client
    passed, reason = gate.check_intake_before_diagnosis("nonexistent_client")
    assert not passed, "Should fail for non-existent client"
    assert "intake" in reason.lower()
