"""
Test: No external send without approval
All external sends require explicit approval.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.policy_gate import get_gate


def test_default_mode_is_draft_only():
    """Default outbound mode must be draft_only."""
    gate = get_gate()
    assert gate.OUTBOUND_MODE == "draft_only", "Default mode must be draft_only"
    assert not gate.EXTERNAL_SEND_ENABLED, "External send must be disabled by default"


def test_unapproved_message_blocked():
    """Unapproved messages cannot be sent."""
    gate = get_gate()

    # Verify that external send is disabled by default
    assert not gate.EXTERNAL_SEND_ENABLED, "External send must be off in test"

    # Also verify approval gate logic directly
    assert gate.OUTBOUND_REQUIRE_APPROVAL, "Approval should be required"

    unapproved = {
        "message_id": "msg1",
        "approval_status": "draft",
        "verification_status": "verified",
        "source_url": "https://example.com",
        "opt_out": False,
        "channel": "email",
    }
    passed, reason = gate.can_send_externally(unapproved)
    assert not passed, "Unapproved message should be blocked"


def test_approved_message_still_blocked_by_default():
    """Even approved messages blocked when EXTERNAL_SEND_ENABLED=false."""
    gate = get_gate()
    assert not gate.EXTERNAL_SEND_ENABLED, "External send must be off in test"
