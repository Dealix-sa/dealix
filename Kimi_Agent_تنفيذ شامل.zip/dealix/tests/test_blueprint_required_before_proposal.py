"""
Test: Blueprint required before proposal
No proposal without existing blueprint.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.policy_gate import get_gate


def test_proposal_requires_blueprint():
    """Proposal should fail without blueprint."""
    gate = get_gate()

    # Non-existent client
    passed, reason = gate.check_blueprint_before_proposal("nonexistent_client")
    assert not passed, "Should fail for non-existent blueprint"
    assert "blueprint" in reason.lower()
