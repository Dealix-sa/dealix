"""Tests for AI model usage logger."""

import pytest
from app.ai.model_usage_logger import (
    estimate_tokens, estimate_cost, log_model_usage,
    get_usage_summary, COST_RATES
)


class TestModelUsageLogger:
    def test_estimate_tokens_english(self):
        tokens = estimate_tokens("Hello world")
        assert tokens > 0

    def test_estimate_tokens_arabic(self):
        tokens = estimate_tokens("مرحبا بالعالم")
        assert tokens > 0

    def test_estimate_cost_known_model(self):
        cost = estimate_cost("gpt-4", 1000, 500)
        expected = (1000 / 1000 * 0.03) + (500 / 1000 * 0.06)
        assert cost == round(expected, 4)

    def test_estimate_cost_default_model(self):
        cost = estimate_cost("unknown-model", 1000, 500)
        assert cost > 0

    def test_log_model_usage(self):
        usage = log_model_usage(
            model_name="gpt-4",
            task="test",
            input_text="Hello",
            output_text="Hi there",
            success=True,
        )
        assert usage.model_name == "gpt-4"
        assert usage.task == "test"
        assert usage.success is True
        assert usage.input_tokens > 0
        assert usage.estimated_cost_usd > 0

    def test_usage_summary_returns_dict(self):
        summary = get_usage_summary()
        assert isinstance(summary, dict)
        assert "total_calls" in summary
        assert "total_estimated_cost_usd" in summary

    def test_failed_usage_logged(self):
        usage = log_model_usage(
            model_name="gpt-4",
            task="test_fail",
            input_text="test",
            output_text="",
            success=False,
            error_message="Timeout",
        )
        assert usage.success is False
        assert usage.error_message == "Timeout"
