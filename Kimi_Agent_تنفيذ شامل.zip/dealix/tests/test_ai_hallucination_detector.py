"""Tests for AI hallucination detector."""

import pytest
from app.ai.hallucination_detector import detect_hallucination, add_source_requirement, HallucinationRisk


class TestHallucinationDetector:
    def test_safe_text(self):
        result = detect_hallucination("This is a general statement about our product.")
        assert result.risk_level == HallucinationRisk.NONE
        assert result.confidence < 0.15

    def test_unverifiable_stat_detected(self):
        text = "According to 15,000 studies, our product is the best."
        result = detect_hallucination(text)
        assert result.risk_level in (HallucinationRisk.LOW, HallucinationRisk.MEDIUM, HallucinationRisk.HIGH)
        assert len(result.flags) > 0

    def test_vague_source_detected(self):
        text = "Studies show that AI improves productivity."
        result = detect_hallucination(text)
        assert any("vague_source" in f for f in result.flags)

    def test_over_confident_detected(self):
        text = "Certainly, this will work for every company."
        result = detect_hallucination(text)
        assert result.confidence > 0
        assert any("over_confident" in f for f in result.flags)

    def test_add_source_requirement(self):
        text = "Sales increased by 50% last year."
        marked = add_source_requirement(text)
        assert "CITATION NEEDED" in marked

    def test_context_verification(self):
        text = "The company revenue was $10M."
        context = {"known_facts": {"revenue": "$5M"}}
        result = detect_hallucination(text, context=context)
        assert result.risk_level != HallucinationRisk.NONE
