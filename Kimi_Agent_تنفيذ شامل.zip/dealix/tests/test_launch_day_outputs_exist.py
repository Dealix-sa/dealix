"""
Test: Launch day scripts produce outputs.
"""
import subprocess
import sys
from pathlib import Path


def test_launch_validate_runs():
    result = subprocess.run(
        [sys.executable, "scripts/launch/validate_launch_assets.py"],
        capture_output=True, text=True
    )
    assert result.returncode == 0, f"validate_launch_assets failed: {result.stdout}"


def test_generate_launch_report():
    result = subprocess.run(
        [sys.executable, "scripts/launch/generate_launch_report.py"],
        capture_output=True, text=True
    )
    assert result.returncode == 0
    assert Path("reports/launch/latest_launch_status.md").exists()


def test_generate_founder_brief():
    result = subprocess.run(
        [sys.executable, "scripts/launch/generate_daily_founder_brief.py"],
        capture_output=True, text=True
    )
    assert result.returncode == 0
    assert Path("reports/launch/latest_founder_brief.md").exists()


def test_generate_30_days_plan():
    result = subprocess.run(
        [sys.executable, "scripts/launch/generate_first_30_days_plan.py"],
        capture_output=True, text=True
    )
    assert result.returncode == 0
    assert Path("reports/launch/latest_gtm_actions.md").exists()
