"""
Test: Suppression list blocks send
Suppressed contacts cannot receive messages.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.storage import get_storage


def test_suppression_list_exists():
    """Suppression list ledger must exist."""
    storage = get_storage()
    suppressed = storage.read_all("suppression_list")
    assert isinstance(suppressed, list), "Suppression list should be readable"


def test_can_add_to_suppression_list():
    """Can add entries to suppression list."""
    storage = get_storage()
    entry = {
        "suppression_id": "supp_test_001",
        "company_id": "comp_test",
        "contact_id": "cont_test",
        "email": "test@example.com",
        "phone": "",
        "reason": "opt-out",
        "created_at": "2024-01-01T00:00:00",
    }
    fields = ["suppression_id", "company_id", "contact_id", "email", "phone", "reason", "created_at"]
    storage.append("suppression_list", entry, fields)

    suppressed = storage.read_all("suppression_list")
    assert len(suppressed) > 0, "Entry should be added"
