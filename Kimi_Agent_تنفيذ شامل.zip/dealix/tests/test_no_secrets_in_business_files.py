"""
Test: No secrets in business files
"""

import re
from pathlib import Path


def test_no_secrets():
    """Check for API keys, tokens, or secrets in business files."""
    secret_patterns = [
        r'sk-[a-zA-Z0-9]{20,}',
        r'[a-zA-Z0-9_-]*api_key[a-zA-Z0-9_-]*\s*=\s*[\'"][^\'"]+[\'"]',
        r'[a-zA-Z0-9_-]*token[a-zA-Z0-9_-]*\s*=\s*[\'"][^\'"]+[\'"]',
        r'[a-zA-Z0-9_-]*password[a-zA-Z0-9_-]*\s*=\s*[\'"][^\'"]+[\'"]',
        r'DATABASE_URL\s*=\s*postgres://[^:]+:[^@]+@',
    ]
    
    dirs_to_check = [
        "business/", "sales/", "trust/", "founder/",
        "content/", "partnerships/", "research/", "proposals/",
    ]
    
    violations = []
    for dir_path in dirs_to_check:
        for file in Path(dir_path).rglob("*.md"):
            content = file.read_text(encoding="utf-8")
            for pattern in secret_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                for match in matches:
                    # Allow placeholders
                    if "placeholder" in match.lower() or "example" in match.lower():
                        continue
                    if "your-" in match.lower() or "xxx" in match.lower():
                        continue
                    violations.append(f"{file}: {match[:30]}...")
    
    assert not violations, f"Potential secrets found: {violations}"
