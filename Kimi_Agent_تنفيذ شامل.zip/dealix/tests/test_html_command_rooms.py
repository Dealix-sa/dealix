"""Tests for HTML command rooms."""

import pytest
from app.commercial.founder_revenue_command_room import generate_html as revenue_html
from app.delivery.delivery_command_room import generate_html as delivery_html


class TestHtmlCommandRooms:
    def test_revenue_command_room_generates_html(self):
        html = revenue_html()
        assert "<!DOCTYPE html>" in html
        assert "Founder Revenue Command Room" in html
        assert "</html>" in html

    def test_revenue_command_room_has_cards(self):
        html = revenue_html()
        assert "Proposals" in html
        assert "Contracts" in html
        assert "Invoices" in html
        assert "Payments" in html

    def test_revenue_command_room_rtl(self):
        html = revenue_html()
        assert 'dir="rtl"' in html

    def test_delivery_command_room_generates_html(self):
        html = delivery_html()
        assert "<!DOCTYPE html>" in html
        assert "Delivery Command Room" in html
        assert "</html>" in html

    def test_delivery_command_room_rtl(self):
        html = delivery_html()
        assert 'dir="rtl"' in html

    def test_delivery_command_room_has_grid(self):
        html = delivery_html()
        assert "grid" in html.lower() or "card" in html.lower()
