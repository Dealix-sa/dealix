"""
Test: Proof report generation
Proof reports require active project.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.proof_reporter import generate_proof_report
from app.client_os.policy_gate import get_gate


def test_proof_requires_project():
    """Proof report should fail without project."""
    result = generate_proof_report("nonexistent_project")
    assert "error" in result, "Should fail for non-existent project"


def test_proof_gate_check():
    """Policy gate should block proof without project."""
    gate = get_gate()
    passed, reason = gate.check_project_before_proof("nonexistent_project")
    assert not passed, "Should fail for non-existent project"
    assert "project" in reason.lower()
