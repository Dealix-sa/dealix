"""
Test: Product catalog is complete
"""

from pathlib import Path


def test_all_products_listed():
    path = Path("business/products/PRODUCT_CATALOG_AR.md")
    content = path.read_text()
    
    required_products = [
        "Revenue Command Room OS",
        "WhatsApp",
        "Review & Reputation OS",
        "Operations & Delivery OS",
        "AI Trust & Compliance OS",
        "Controlled Live Outbound OS",
        "Company Diagnosis Sprint",
        "Company Brain OS",
        "Custom Enterprise Systems",
        "Strategic Partnership OS",
    ]
    
    for product in required_products:
        assert product in content, f"Missing product: {product}"


def test_company_brain_is_secondary():
    path = Path("business/products/PRODUCT_CATALOG_AR.md")
    content = path.read_text()
    
    # Must mention secondary positioning
    secondary_indicators = ["secondary", "ثانوية", "NOT the primary identity"]
    assert any(indicator in content for indicator in secondary_indicators), \
        "Company Brain OS must be positioned as secondary"
