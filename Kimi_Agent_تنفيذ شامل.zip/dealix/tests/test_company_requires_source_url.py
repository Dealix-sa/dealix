"""
Test: Company requires source_url
No company without source_url becomes approved.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.storage import get_storage
from app.client_os.policy_gate import get_gate


def test_company_without_source_url_blocked():
    """Companies without source_url cannot be approved for outreach."""
    gate = get_gate()

    # Company without source_url
    company_no_source = {"company_id": "test1", "source_url": ""}
    passed, reason = gate.validate_source_url(company_no_source)
    assert not passed, "Company without source_url should be blocked"
    assert "source_url" in reason.lower()

    # Company with source_url
    company_with_source = {"company_id": "test2", "source_url": "https://example.com"}
    passed, reason = gate.validate_source_url(company_with_source)
    assert passed, "Company with source_url should pass"


def test_message_without_source_url_blocked():
    """Messages without source_url cannot be sent."""
    gate = get_gate()

    # First verify that external send is disabled by default (primary gate)
    assert not gate.EXTERNAL_SEND_ENABLED, "External send must be off in test"

    # Test source_url validation directly via the dedicated method
    company_no_source = {"company_id": "test1", "source_url": ""}
    passed, reason = gate.validate_source_url(company_no_source)
    assert not passed, "Company without source_url should be blocked"
    assert "source_url" in reason.lower()

    # Test that message with all correct settings still blocked by default mode
    message_no_source = {
        "message_id": "msg1",
        "approval_status": "approved",
        "verification_status": "verified",
        "source_url": "",
        "opt_out": False,
    }
    passed, reason = gate.can_send_externally(message_no_source)
    assert not passed, "Message without source_url should be blocked"
    # The first gate is EXTERNAL_SEND_ENABLED which is false in tests
