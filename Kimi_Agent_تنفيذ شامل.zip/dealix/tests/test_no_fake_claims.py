"""
Test: No fake claims
Policy gate blocks fake or guaranteed claims.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.policy_gate import get_gate


def test_fake_roi_blocked():
    """Fake ROI claims should be blocked."""
    gate = get_gate()

    fake_claims = [
        "نضمن زيادة المبيعات 200%",
        "أرباح مضمونة",
        "نتائج 100% مضمونة",
        "نضاعف إيراداتك",
    ]
    for claim in fake_claims:
        clean, reason = gate.check_fake_claims(claim)
        assert not clean, f"Should block fake claim: {claim}"
        assert "blocked" in reason.lower()


def test_guaranteed_roi_blocked():
    """Guaranteed ROI claims should be blocked."""
    gate = get_gate()

    # Check that the setting is enabled
    assert gate.OUTBOUND_BLOCK_GUARANTEED_ROI, "Guaranteed ROI blocking should be enabled"

    guaranteed = "نضمن عائد استثمار 500%"
    clean, reason = gate.check_fake_claims(guaranteed)
    assert not clean, "Should block guaranteed ROI"
