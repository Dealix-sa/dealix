"""
Test: Go-live pack is complete.
"""
from pathlib import Path


def test_go_live_files_exist():
    files = [
        "ops/go_live/PRODUCTION_READINESS_CHECKLIST.md",
        "ops/go_live/OUTBOUND_SAFETY_CHECKLIST.md",
        "ops/go_live/INCIDENT_RESPONSE_LITE.md",
        "ops/go_live/ENVIRONMENT_VARIABLES_AUDIT.md",
        "ops/go_live/DATABASE_READINESS_CHECKLIST.md",
        "ops/go_live/DOMAIN_EMAIL_DNS_CHECKLIST.md",
        "ops/go_live/BACKUP_RESTORE_CHECKLIST.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_outbound_safety_has_defaults():
    path = Path("ops/go_live/OUTBOUND_SAFETY_CHECKLIST.md")
    content = path.read_text()
    assert "EXTERNAL_SEND_ENABLED=false" in content
    assert "OUTBOUND_MODE=draft_only" in content
    assert "WHATSAPP_ALLOW_LIVE_SEND=false" in content
