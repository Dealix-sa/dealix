"""Tests that all new modules can be imported successfully."""

import pytest


class TestModuleImports:
    def test_ai_modules_import(self):
        from app.ai import safe_content_filter
        from app.ai import hallucination_detector
        from app.ai import prompt_guard
        from app.ai import privacy_redactor
        from app.ai import output_verifier
        from app.ai import model_usage_logger
        assert True

    def test_outbound_modules_import(self):
        from app.outbound import draft_generator
        from app.outbound import live_send
        from app.outbound import rate_limiter
        from app.outbound import suppression_list
        from app.outbound import approval_gate
        from app.outbound import fake_claim_detector
        assert True

    def test_delivery_modules_import(self):
        from app.delivery import delivery_planner
        from app.delivery import sprint_manager
        from app.delivery import proof_reporter
        from app.delivery import uat_engine
        from app.delivery import escalation_tracker
        assert True

    def test_commercial_modules_import(self):
        from app.commercial import proposal_manager
        from app.commercial import invoice_engine
        from app.commercial import pipeline
        from app.commercial import contract_engine
        assert True

    def test_channel_modules_import(self):
        from app.channels import email_smtp
        from app.channels import whatsapp_api
        from app.channels import linkedin_api
        from app.channels import send_attempt
        assert True

    def test_policy_gate_available(self):
        from app.client_os.policy_gate import PolicyGate
        gate = PolicyGate()
        assert gate is not None
