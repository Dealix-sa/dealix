"""Tests for commercial pipeline."""

import pytest
from app.commercial.pipeline import get_full_pipeline
from app.commercial.proposal_manager import create_proposal, approve_proposal, list_pending_approvals
from app.commercial.invoice_engine import generate_from_contract


class TestCommercialPipeline:
    def test_pipeline_returns_dict(self):
        result = get_full_pipeline()
        assert isinstance(result, dict)
        assert "proposals" in result
        assert "contracts" in result
        assert "invoices" in result
        assert "payments" in result

    def test_create_proposal(self):
        result = create_proposal("test-client", "Test proposal content")
        assert result is not None
        assert result.get("proposal_id", "").startswith("prop_")
        assert result.get("status") == "draft"

    def test_approve_proposal(self):
        prop = create_proposal("test-client", "Test content")
        pid = prop["proposal_id"]
        result = approve_proposal(pid, "test_approver")
        assert result["status"] == "approved"

    def test_list_pending_returns_list(self):
        result = list_pending_approvals()
        assert isinstance(result, list)

    def test_invoice_from_missing_contract(self):
        result = generate_from_contract("nonexistent-contract", "1000")
        assert "error" in result
