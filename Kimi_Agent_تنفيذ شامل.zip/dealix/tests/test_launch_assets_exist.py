"""
Test: Launch assets exist.
"""
from pathlib import Path


def test_launch_dir_exists():
    assert Path("launch").is_dir()


def test_launch_master_plan_ar_exists():
    assert Path("launch/DEALIX_MARKET_LAUNCH_MASTER_PLAN_AR.md").exists()


def test_launch_master_plan_en_exists():
    assert Path("launch/DEALIX_MARKET_LAUNCH_MASTER_PLAN_EN.md").exists()


def test_first_30_days_plan_exists():
    assert Path("launch/FIRST_30_DAYS_ACTION_PLAN_AR.md").exists()


def test_first_7_days_plan_exists():
    assert Path("launch/FIRST_7_DAYS_ACTION_PLAN_AR.md").exists()


def test_first_90_days_plan_exists():
    assert Path("launch/FIRST_90_DAYS_ACTION_PLAN_AR.md").exists()


def test_launch_gates_exists():
    assert Path("launch/LAUNCH_GATES.md").exists()


def test_launch_metrics_exists():
    assert Path("launch/LAUNCH_METRICS.md").exists()


def test_launch_blockers_exists():
    assert Path("launch/LAUNCH_BLOCKERS.md").exists()


def test_launch_daily_routine_exists():
    assert Path("launch/FOUNDER_LAUNCH_DAILY_ROUTINE_AR.md").exists()


def test_launch_decision_log_exists():
    assert Path("launch/LAUNCH_DECISION_LOG.md").exists()


def test_launch_scripts_exist():
    scripts = [
        "scripts/launch/validate_launch_assets.py",
        "scripts/launch/generate_launch_report.py",
        "scripts/launch/generate_daily_founder_brief.py",
        "scripts/launch/generate_first_30_days_plan.py",
        "scripts/launch/run_launch_day.py",
        "scripts/launch/validate_prospecting_pack.py",
        "scripts/launch/validate_demo_pack.py",
        "scripts/launch/validate_closing_pack.py",
        "scripts/launch/validate_proof_pack.py",
        "scripts/launch/validate_retainer_pack.py",
    ]
    for s in scripts:
        assert Path(s).exists(), f"Missing: {s}"
