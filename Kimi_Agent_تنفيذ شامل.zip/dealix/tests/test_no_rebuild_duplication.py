"""
Test: No rebuild duplication — existing systems preserved.
"""
from pathlib import Path


def test_client_os_modules_still_exist():
    """Client OS modules not rebuilt — preserved."""
    modules = [
        "app/client_os/schemas.py",
        "app/client_os/storage.py",
        "app/client_os/policy_gate.py",
        "app/client_os/audit_log.py",
        "app/client_os/company_research.py",
        "app/client_os/qualification.py",
    ]
    for mod in modules:
        assert Path(mod).exists(), f"Client OS module missing: {mod}"


def test_business_assets_still_exist():
    """Business OS preserved."""
    assets = [
        "business/strategy/DEALIX_POSITIONING_AR.md",
        "business/products/PRODUCT_CATALOG_AR.md",
        "business/offers/OFFER_STACK_AR.md",
        "trust/PDPL_READINESS_CHECKLIST_AR.md",
    ]
    for a in assets:
        assert Path(a).exists(), f"Business asset missing: {a}"


def test_no_duplicate_product_catalogs():
    """Only one product catalog per language."""
    ar_catalogs = list(Path("business").rglob("PRODUCT_CATALOG_AR.md"))
    en_catalogs = list(Path("business").rglob("PRODUCT_CATALOG_EN.md"))
    assert len(ar_catalogs) == 1, f"Duplicate AR catalogs: {ar_catalogs}"
    assert len(en_catalogs) == 1, f"Duplicate EN catalogs: {en_catalogs}"


def test_company_brain_is_secondary_everywhere():
    """Company Brain OS positioned as secondary in all docs."""
    files_to_check = [
        "business/products/COMPANY_BRAIN_OS.md",
        "business/products/PRODUCT_CATALOG_AR.md",
        "demo/COMPANY_BRAIN_OS_DEMO_AR.md",
    ]
    for f in files_to_check:
        path = Path(f)
        if path.exists():
            content = path.read_text().lower()
            has_secondary = "secondary" in content or "ثانوية" in content or "not the primary" in content
            assert has_secondary, f"{f} must position Company Brain OS as secondary"
