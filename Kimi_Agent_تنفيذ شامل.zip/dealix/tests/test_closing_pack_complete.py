"""
Test: Closing pack is complete.
"""
from pathlib import Path


def test_closing_files_exist():
    files = [
        "closing/CLOSING_PLAYBOOK_AR.md",
        "closing/DEAL_ACCEPTANCE_CHECKLIST.md",
        "closing/DECISION_MEETING_SCRIPT_AR.md",
        "closing/PROPOSAL_REVIEW_SCRIPT_AR.md",
        "closing/PRICE_OBJECTION_SCRIPT_AR.md",
        "closing/SECURITY_PRIVACY_OBJECTION_SCRIPT_AR.md",
        "closing/WHY_DEALIX_NOW_AR.md",
        "closing/WHY_NOT_CHATBOT_AR.md",
        "closing/WHY_NOT_CRM_AR.md",
        "closing/NEXT_STEP_MESSAGES_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_deal_acceptance_has_gates():
    path = Path("closing/DEAL_ACCEPTANCE_CHECKLIST.md")
    content = path.read_text()
    assert "صاحب قرار" in content or "decision maker" in content.lower()
    assert "success metric" in content.lower()
    assert "acceptance criteria" in content.lower()
