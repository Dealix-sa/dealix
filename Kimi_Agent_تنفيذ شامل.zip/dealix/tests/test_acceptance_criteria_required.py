"""
Test: Acceptance criteria required
Delivery requires acceptance criteria.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.policy_gate import get_gate


def test_delivery_requires_acceptance():
    """Delivery should check for acceptance criteria."""
    gate = get_gate()

    # Non-existent project
    passed, reason = gate.check_acceptance_before_delivery("nonexistent_project")
    assert not passed, "Should fail for non-existent project"
    assert "acceptance" in reason.lower() or "project" in reason.lower()
