"""
Test: Client OS outputs exist
Ensures all expected output files are created.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
import tempfile


def test_app_client_os_modules_exist():
    """All required modules exist in app/client_os/."""
    modules = [
        "schemas.py",
        "storage.py",
        "company_research.py",
        "qualification.py",
        "company_intelligence.py",
        "pain_hypothesis.py",
        "outreach_draft.py",
        "reply_classifier.py",
        "discovery_brief.py",
        "intake_engine.py",
        "diagnosis_engine.py",
        "needs_mapper.py",
        "blueprint_builder.py",
        "proposal_builder.py",
        "delivery_planner.py",
        "proof_reporter.py",
        "client_success.py",
        "policy_gate.py",
        "audit_log.py",
    ]
    for mod in modules:
        path = Path(f"app/client_os/{mod}")
        assert path.exists(), f"Missing module: {path}"


def test_scripts_client_os_exist():
    """All runner scripts exist."""
    scripts = [
        "run_target_research.py",
        "run_outreach_day.py",
        "run_reply_review.py",
        "run_client_intake.py",
        "run_client_diagnosis.py",
        "run_client_blueprint.py",
        "run_client_proposal.py",
        "run_client_delivery_day.py",
        "run_client_success_day.py",
        "run_client_os_day.py",
    ]
    for script in scripts:
        path = Path(f"scripts/client_os/{script}")
        assert path.exists(), f"Missing script: {path}"


def test_ledgers_exist():
    """All ledger CSVs exist with headers."""
    ledgers = [
        "companies.csv",
        "contacts.csv",
        "outreach_log.csv",
        "replies.csv",
        "meetings.csv",
        "client_intakes.csv",
        "diagnosis_log.csv",
        "needs_maps.csv",
        "blueprints.csv",
        "proposals.csv",
        "projects.csv",
        "tasks.csv",
        "proof_reports.csv",
        "renewals.csv",
        "suppression_list.csv",
        "audit_log.csv",
    ]
    for ledger in ledgers:
        path = Path(f"ledgers/{ledger}")
        assert path.exists(), f"Missing ledger: {path}"
        content = path.read_text()
        assert content.strip(), f"Empty ledger: {path}"


def test_docs_exist():
    """All documentation files exist."""
    docs = [
        "CLIENT_OPERATING_LOOP_AR.md",
        "CLIENT_INTAKE_SOP_AR.md",
        "CLIENT_DIAGNOSIS_SOP_AR.md",
        "CLIENT_BLUEPRINT_SOP_AR.md",
        "CLIENT_DELIVERY_SOP_AR.md",
        "CLIENT_SUCCESS_SOP_AR.md",
        "HUMAN_APPROVAL_MODEL_AR.md",
        "CLIENT_DATA_HANDLING_MODEL_AR.md",
    ]
    for doc in docs:
        path = Path(f"docs/client_os/{doc}")
        assert path.exists(), f"Missing doc: {path}"


def test_client_templates_exist():
    """All client template files exist with content."""
    templates = [
        "00_intake/intake_form.md",
        "00_intake/stakeholder_map.md",
        "00_intake/access_checklist.md",
        "01_diagnosis/current_state.md",
        "01_diagnosis/pain_map.md",
        "01_diagnosis/needs_map.md",
        "01_diagnosis/risk_register.md",
        "02_solution/system_blueprint.md",
        "02_solution/workflow_map.md",
        "02_solution/data_model.md",
        "02_solution/acceptance_criteria.md",
        "03_delivery/sprint_plan.md",
        "03_delivery/implementation_log.md",
        "03_delivery/test_plan.md",
        "03_delivery/uat_notes.md",
        "04_training/user_guide.md",
        "04_training/admin_guide.md",
        "04_training/sop.md",
        "05_proof/weekly_report.md",
        "05_proof/before_after.md",
        "05_proof/next_30_days.md",
    ]
    for tmpl in templates:
        path = Path(f"clients/_template/{tmpl}")
        assert path.exists(), f"Missing template: {path}"
        content = path.read_text()
        assert len(content) > 100, f"Template too short: {path}"


def test_env_example_exists():
    """.env.example exists with safety defaults."""
    path = Path(".env.example")
    assert path.exists(), "Missing .env.example"
    content = path.read_text()
    assert "EXTERNAL_SEND_ENABLED=false" in content
    assert "OUTBOUND_MODE=draft_only" in content
    assert "WHATSAPP_ALLOW_LIVE_SEND=false" in content


def test_makefile_exists():
    """Makefile exists with client targets."""
    path = Path("Makefile")
    assert path.exists(), "Missing Makefile"
    content = path.read_text()
    assert "client-os-day:" in content
    assert "client-diagnose:" in content
    assert "client-blueprint:" in content
    assert "client-proposal:" in content
