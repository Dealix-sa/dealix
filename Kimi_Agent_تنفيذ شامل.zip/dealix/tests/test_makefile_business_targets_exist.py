"""
Test: Makefile has business targets
"""

from pathlib import Path


def test_makefile_has_business_targets():
    path = Path("Makefile")
    content = path.read_text()
    
    targets = [
        "business-validate:",
        "business-day:",
        "founder-actions:",
        "company-full-day:",
    ]
    
    for target in targets:
        assert target in content, f"Missing Makefile target: {target}"
