"""
Test: Proof pack is complete.
"""
from pathlib import Path


def test_proof_files_exist():
    files = [
        "proof/PROOF_REPORTING_MASTER_SOP_AR.md",
        "proof/BEFORE_AFTER_TEMPLATE.md",
        "proof/WEEKLY_PROOF_REPORT_TEMPLATE.md",
        "proof/EXECUTIVE_PROOF_SUMMARY_TEMPLATE.md",
        "proof/DELIVERY_ACCEPTANCE_TEMPLATE.md",
        "proof/CLIENT_VALUE_LOG.md",
        "proof/CASE_STUDY_INTERNAL_TEMPLATE.md",
        "proof/CASE_STUDY_PUBLIC_TEMPLATE.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_case_study_public_no_exaggeration():
    path = Path("proof/CASE_STUDY_PUBLIC_TEMPLATE.md")
    content = path.read_text()
    assert "No exaggerated numbers" in content or "no exaggerated" in content.lower()
    assert "لا" in content
