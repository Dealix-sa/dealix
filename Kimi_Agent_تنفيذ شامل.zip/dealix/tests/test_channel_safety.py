"""Tests for channel safety configurations."""

import pytest
import os
from app.channels.email_smtp import send_email, check_config
from app.channels.whatsapp_api import send_whatsapp, check_config as wa_check_config
from app.channels.send_attempt import send as send_attempt


class TestChannelSafety:
    def test_email_is_dry_run_by_default(self):
        """Email sending should be dry-run by default."""
        result = send_email("test@example.com", "Test", "Body")
        assert result["status"] == "dry_run"

    def test_email_config_returns_dict(self):
        result = check_config()
        assert isinstance(result, dict)
        assert "dry_run" in result

    def test_whatsapp_is_dry_run_by_default(self):
        result = send_whatsapp("+966501234567", "Test message")
        assert result["status"] in ("dry_run", "simulated", "disabled")

    def test_whatsapp_config_returns_dict(self):
        result = wa_check_config()
        assert isinstance(result, dict)

    def test_send_attempt_routes_email(self):
        result = send_attempt("email", "test@example.com", "Test Subject", "Test body")
        assert "status" in result

    def test_send_attempt_routes_whatsapp(self):
        result = send_attempt("whatsapp", "+966501234567", "", "Test message")
        assert "status" in result

    def test_send_unknown_channel(self):
        result = send_attempt("unknown", "test", "", "body")
        assert result["status"] == "error"
