"""
Test: Trust policies exist and have content.
"""

from pathlib import Path


def test_trust_policies_have_content():
    policies = [
        "trust/PDPL_READINESS_CHECKLIST_AR.md",
        "trust/NO_FAKE_CLAIMS_POLICY.md",
        "trust/AI_USAGE_POLICY_AR.md",
        "trust/README.md",
    ]
    for policy in policies:
        path = Path(policy)
        assert path.exists(), f"Missing policy: {policy}"
        content = path.read_text()
        assert len(content) > 200, f"Policy too short: {policy}"


def test_no_fake_claims_policy_blocks_guarantees():
    path = Path("trust/NO_FAKE_CLAIMS_POLICY.md")
    content = path.read_text().lower()
    assert "guarantee" in content or "fake" in content
    assert "prohibited" in content or "blocked" in content or "not allowed" in content
