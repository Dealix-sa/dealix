"""Tests for AI output verifier."""

import pytest
from app.ai.output_verifier import OutputVerifier, VerificationStatus, verify_json_output


class TestOutputVerifier:
    def test_empty_output_fails(self):
        verifier = OutputVerifier()
        result = verifier.verify("")
        assert result.status == VerificationStatus.FAIL

    def test_valid_text_passes(self):
        verifier = OutputVerifier()
        result = verifier.verify("This is a valid response.", expected_format="text")
        assert result.status == VerificationStatus.PASS

    def test_max_length_enforced(self):
        verifier = OutputVerifier()
        result = verifier.verify("A" * 100, expected_format="text", max_length=50)
        assert result.status == VerificationStatus.FAIL
        assert any("max_length" in str(c) for c in result.checks)

    def test_min_length_enforced(self):
        verifier = OutputVerifier()
        result = verifier.verify("Hi", expected_format="text", min_length=10)
        assert result.status == VerificationStatus.FAIL

    def test_json_format_validation(self):
        verifier = OutputVerifier()
        result = verifier.verify('{"key": "value"}', expected_format="json")
        assert result.status == VerificationStatus.PASS

    def test_invalid_json_fails(self):
        verifier = OutputVerifier()
        result = verifier.verify("not json", expected_format="json")
        assert result.status == VerificationStatus.FAIL

    def test_required_fields_check(self):
        verifier = OutputVerifier()
        result = verifier.verify(
            '{"name": "test", "value": 123}',
            expected_format="json",
            required_fields=["name", "value"]
        )
        assert result.status == VerificationStatus.PASS

    def test_missing_required_field(self):
        verifier = OutputVerifier()
        result = verifier.verify(
            '{"name": "test"}',
            expected_format="json",
            required_fields=["name", "missing_field"]
        )
        assert result.status == VerificationStatus.FAIL

    def test_verify_json_output_convenience(self):
        result = verify_json_output('{"id": "123"}', {"required": ["id"]})
        assert result.status == VerificationStatus.PASS
