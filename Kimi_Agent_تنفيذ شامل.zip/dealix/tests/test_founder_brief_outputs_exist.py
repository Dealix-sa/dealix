"""
Test: Founder brief outputs exist after generation.
"""
from pathlib import Path


def test_founder_brief_template_exists():
    assert Path("founder/war_room/DAILY_SALES_SCORECARD.md").exists()


def test_founder_war_room_exists():
    assert Path("founder/war_room/FOUNDER_SALES_WAR_ROOM_AR.md").exists()


def test_closing_decision_rules_exists():
    assert Path("founder/war_room/CLOSING_DECISION_RULES.md").exists()
    content = Path("founder/war_room/CLOSING_DECISION_RULES.md").read_text()
    assert "no fake claims" in content.lower() or "لا تقدم" in content
    assert "blueprint" in content.lower()
