"""
Test: Makefile client targets exist
Makefile must contain all required client OS targets.
"""

from pathlib import Path


def test_makefile_has_client_targets():
    """Makefile contains all client OS targets."""
    path = Path("Makefile")
    assert path.exists(), "Makefile must exist"
    content = path.read_text()

    required_targets = [
        "client-os-day:",
        "client-targets:",
        "client-outreach:",
        "client-replies:",
        "client-diagnose:",
        "client-blueprint:",
        "client-proposal:",
        "client-delivery-day:",
        "client-success-day:",
    ]

    for target in required_targets:
        assert target in content, f"Makefile missing target: {target}"
