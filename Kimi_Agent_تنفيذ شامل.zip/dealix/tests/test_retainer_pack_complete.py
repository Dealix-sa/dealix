"""
Test: Retainer pack is complete.
"""
from pathlib import Path


def test_retainer_files_exist():
    files = [
        "retainers/RETAINER_CONVERSION_PLAYBOOK_AR.md",
        "retainers/MANAGED_OS_RETAINER_MODEL_AR.md",
        "retainers/MONTHLY_EXECUTIVE_REVIEW_TEMPLATE.md",
        "retainers/EXPANSION_OPPORTUNITY_MAP.md",
        "retainers/RENEWAL_EMAILS_AR.md",
        "retainers/RETAINER_SCOPE_BOUNDARIES.md",
        "retainers/RETAINER_HEALTH_SCORE.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_retainer_health_score_has_scale():
    path = Path("retainers/RETAINER_HEALTH_SCORE.md")
    content = path.read_text()
    assert "expand" in content.lower()
    assert "intervention" in content.lower()
    assert "80-100" in content or "80" in content
