"""Tests for outbound safety gates."""

import pytest
import os
from app.outbound.live_send import execute_send, is_dry_run
from app.outbound import rate_limiter
from app.outbound import suppression_list
from app.outbound.fake_claim_detector import scan as detect_fake_claims


class TestOutboundGates:
    def test_dry_run_mode_is_active_by_default(self):
        """Dry-run mode should be active by default."""
        os.environ["LIVE_SEND_ENABLED"] = "false"
        assert is_dry_run() is True

    def test_unapproved_draft_is_blocked(self):
        """A draft that doesn't exist/isn't approved should be blocked at approval gate."""
        os.environ["LIVE_SEND_ENABLED"] = "false"
        result = execute_send(
            draft_id="nonexistent_draft_12345",
            msg_id="m1", company_id="c1",
            contact_id="con1", channel="email", body_path="test.txt"
        )
        assert result["status"] == "blocked"
        assert result["gate"] == "approval"

    def test_rate_limiter_returns_dict(self):
        result = rate_limiter.can_send("email")
        assert isinstance(result, dict)
        assert "remaining" in result
        assert "allowed" in result

    def test_rate_limiter_has_default_limit(self):
        result = rate_limiter.can_send("email")
        assert result["limit"] == 25  # default

    def test_rate_limiter_tracks_sent(self):
        result = rate_limiter.can_send("email")
        assert result["sent_today"] >= 0

    def test_suppression_add_and_check(self):
        suppression_list.add_to_suppression("test-company-001", contact_id="test-contact-001", reason="opt_out")
        assert suppression_list.is_suppressed("test-company-001") is True

    def test_suppression_list_returns_list(self):
        result = suppression_list.list_suppression()
        assert isinstance(result, list)

    def test_fake_claim_detection(self):
        result = detect_fake_claims("نضمن لك نتائج مضمونة")
        assert result["clean"] is False

    def test_fake_claim_clean_passes(self):
        result = detect_fake_claims("We offer professional services.")
        assert result["clean"] is True

    def test_guaranteed_roi_detected(self):
        result = detect_fake_claims("guaranteed ROI within 30 days")
        assert result["clean"] is False
