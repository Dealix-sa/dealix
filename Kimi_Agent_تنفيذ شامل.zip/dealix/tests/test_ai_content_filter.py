"""Tests for AI safe content filter."""

import pytest
from app.ai.safe_content_filter import check_content_safety, clean_content, get_safety_stats, RiskLevel


class TestSafeContentFilter:
    def test_safe_content_passes(self):
        result = check_content_safety("Hello, this is a safe message about our services.")
        assert result.passed is True
        assert result.risk_level == RiskLevel.SAFE

    def test_guarantee_claim_blocked(self):
        result = check_content_safety("نضمن لك نتائج مضمونة 100%")
        assert result.passed is False
        assert result.risk_level == RiskLevel.HIGH
        assert "guarantee_misleading" in result.flagged_categories

    def test_guaranteed_roi_blocked(self):
        result = check_content_safety("We guarantee ROI in 30 days")
        assert result.passed is False
        assert "guarantee_misleading" in result.flagged_categories

    def test_fake_urgency_flagged(self):
        result = check_content_safety("العرض ينتهي اليوم! لمدة 24 ساعة فقط")
        assert "fake_urgency" in result.flagged_categories

    def test_clean_content(self):
        cleaned = clean_content("HELLO!!! This is!!! TOO MUCH!!!")
        assert "!!!" not in cleaned or cleaned.count("!") <= 3

    def test_safety_stats(self):
        results = [
            check_content_safety("safe message"),
            check_content_safety("نضمن النجاح"),
        ]
        stats = get_safety_stats(results)
        assert stats["total_checked"] == 2
        assert stats["passed"] == 1
        assert stats["failed"] == 1
