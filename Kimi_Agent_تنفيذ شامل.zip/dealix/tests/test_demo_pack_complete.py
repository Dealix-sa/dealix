"""
Test: Demo pack is complete.
"""
from pathlib import Path


def test_demo_files_exist():
    files = [
        "demo/DEALIX_DEMO_README.md",
        "demo/COMPANY_DIAGNOSIS_DEMO_AR.md",
        "demo/REVENUE_COMMAND_ROOM_DEMO_AR.md",
        "demo/WHATSAPP_FOLLOWUP_OS_DEMO_AR.md",
        "demo/REVIEW_REPUTATION_OS_DEMO_AR.md",
        "demo/COMPANY_BRAIN_OS_DEMO_AR.md",
        "demo/AI_TRUST_COMPLIANCE_DEMO_AR.md",
        "demo/DEMO_TALK_TRACK_AR.md",
        "demo/DEMO_OBJECTION_HANDLING_AR.md",
    ]
    for f in files:
        assert Path(f).exists(), f"Missing: {f}"


def test_company_brain_demo_is_secondary():
    path = Path("demo/COMPANY_BRAIN_OS_DEMO_AR.md")
    content = path.read_text()
    assert "secondary" in content.lower() or "ثانوية" in content
    assert "وليس العرض الرئيسي" in content or "not the main" in content.lower() or "ثانوية" in content


def test_primary_products_in_demos():
    path = Path("demo/DEALIX_DEMO_README.md")
    content = path.read_text()
    assert "Company Diagnosis Sprint" in content
    assert "Revenue Command Room" in content
    assert "WhatsApp" in content
