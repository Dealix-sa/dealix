"""Tests for AI privacy redactor."""

import pytest
from app.ai.privacy_redactor import redact_pii, redact_client_data, RedactionMethod


class TestPrivacyRedactor:
    def test_email_redacted(self):
        result = redact_pii("Contact me at john@example.com please.")
        assert "john@example.com" not in result.redacted_text
        assert "[EMAIL_1]" in result.redacted_text
        assert result.redaction_count >= 1

    def test_phone_redacted(self):
        result = redact_pii("Call me at +966501234567")
        assert "+966501234567" not in result.redacted_text
        assert result.redaction_count >= 1

    def test_credit_card_redacted(self):
        result = redact_pii("Card: 4111-1111-1111-1111")
        assert "4111-1111-1111-1111" not in result.redacted_text
        assert "***" in result.redacted_text  # masked format keeps first/last 2 chars

    def test_api_key_redacted(self):
        result = redact_pii("Key: sk-abcdefghijklmnopqrstuvwxyz1234")
        assert "sk-abcdefghijklmnopqrstuvwxyz1234" not in result.redacted_text

    def test_client_name_redacted(self):
        result_text = redact_client_data("Meeting with Acme Corp tomorrow", client_name="Acme Corp")
        assert "Acme Corp" not in result_text
        assert "[CLIENT_NAME]" in result_text

    def test_no_pii_unchanged(self):
        result = redact_pii("Hello, this is a safe message.")
        assert result.redacted_text == "Hello, this is a safe message."
        assert result.redaction_count == 0

    def test_custom_mask_method(self):
        result = redact_pii("Email: test@example.com", method_override=RedactionMethod.MASK)
        assert "test@example.com" not in result.redacted_text
