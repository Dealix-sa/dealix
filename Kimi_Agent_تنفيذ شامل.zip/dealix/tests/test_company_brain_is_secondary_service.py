"""
Test: Company Brain OS is secondary service
Company Brain OS must be documented as secondary, not primary identity.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def test_company_brain_os_documented_as_secondary():
    """Company Brain OS product doc states it is secondary."""
    path = Path("business/products/COMPANY_BRAIN_OS.md")
    assert path.exists(), "Company Brain OS product doc should exist"
    content = path.read_text()

    # Must contain secondary positioning
    assert "secondary" in content.lower(), "Must describe Company Brain OS as secondary"
    assert "NOT the primary identity" in content, "Must explicitly state it is NOT primary identity"


def test_dealix_identity_preserved():
    """Dealix identity remains AI Operating Systems for Companies."""
    # Check in client OS init
    path = Path("app/client_os/__init__.py")
    content = path.read_text()
    assert "AI Operating Systems" in content, "Must reference Dealix identity"

    # Check in docs
    doc_path = Path("docs/client_os/CLIENT_OPERATING_LOOP_AR.md")
    if doc_path.exists():
        doc_content = doc_path.read_text()
        assert "AI Operating Systems" in doc_content, "Docs must reference Dealix identity"


def test_product_catalog_clarifies_positioning():
    """Product catalog must clarify Company Brain OS position."""
    path = Path("business/products/CLIENT_OPERATING_LOOP_OS.md")
    assert path.exists(), "Client Operating Loop product doc should exist"
    content = path.read_text()

    assert "Company Brain OS" in content, "Must reference Company Brain OS"
    assert "secondary" in content.lower() or "add-on" in content.lower(), "Must clarify it is not primary"
