"""Tests that all script modules can be imported."""

import pytest


class TestScriptImports:
    def test_outbound_scripts_import(self):
        from scripts.outbound import run_outbound_day
        from scripts.outbound import approve_and_send
        from scripts.outbound import check_rate_limits
        from scripts.outbound import process_replies
        from scripts.outbound import generate_followups
        from scripts.outbound import review_suppression
        from scripts.outbound import validate_templates
        from scripts.outbound import export_outbound_report
        assert True

    def test_channels_scripts_import(self):
        from scripts.channels import check_channel_configs
        from scripts.channels import send_test_message
        from scripts.channels import monitor_deliveries
        from scripts.channels import handle_callbacks
        assert True

    def test_delivery_scripts_import(self):
        from scripts.delivery import run_delivery_day
        from scripts.delivery import check_sprint_status
        from scripts.delivery import generate_proof_report
        from scripts.delivery import process_uat_results
        from scripts.delivery import check_retainer_opportunities
        from scripts.delivery import generate_monthly_review
        from scripts.delivery import check_stuck_projects
        from scripts.delivery import update_client_portal
        from scripts.delivery import export_delivery_report
        assert True

    def test_commercial_scripts_import(self):
        from scripts.commercial import run_commercial_day
        from scripts.commercial import check_proposals_pending
        from scripts.commercial import generate_invoice_from_contract
        from scripts.commercial import track_payments
        assert True

    def test_ops_scripts_import(self):
        from scripts.ops import run_safety_audit
        from scripts.ops import check_env_variables
        from scripts.ops import validate_all_configs
        from scripts.ops import generate_system_health_report
        assert True
