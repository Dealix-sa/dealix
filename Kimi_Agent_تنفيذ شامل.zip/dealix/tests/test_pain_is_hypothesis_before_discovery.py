"""
Test: Pain is hypothesis before discovery
Pain hypothesis uses cautious language, not claims.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
os.environ["DEALIX_LEDGER_DIR"] = "ledgers"

from app.client_os.pain_hypothesis import validate_hypothesis_language


def test_no_guaranteed_claims():
    """Hypotheses must not contain guaranteed claims."""
    blocked_phrases = [
        "نضمن زيادة المبيعات",
        "نضاعف إيراداتك",
        "نضمن نتائج",
        "100% نجاح",
        "أرباح مضمونة",
    ]
    for phrase in blocked_phrases:
        clean, reason = validate_hypothesis_language(phrase)
        assert not clean, f"Should block: {phrase}"
        assert "blocked" in reason.lower()


def test_cautious_language_passes():
    """Cautious hypothesis language should pass."""
    safe_phrases = [
        "غالبًا ما يكون هناك مجال للتحسين",
        "قد يكون التحدي في المتابعة",
        "في شركات هذا القطاع نحتاج نتحقق",
        "من الممكن أن يكون هناك فرصة",
    ]
    for phrase in safe_phrases:
        clean, reason = validate_hypothesis_language(phrase)
        assert clean, f"Should allow: {phrase} — {reason}"
