# Prospect Scoring Model

## Scoring (out of 100)

| Factor | Points | Criteria |
|--------|--------|----------|
| Sector fit | 20 | In priority sectors |
| Communication channel | 15 | Has email or phone or contact page |
| Pain signals | 15 | Visible pain in reviews/description |
| Decision maker potential | 15 | Has named contact or decision maker |
| Digital presence | 10 | Has website or Google Maps |
| Sprint readiness | 10 | Can start diagnostic sprint quickly |
| Retainer potential | 10 | Suitable for ongoing managed OS |
| Access ease | 5 | Easy to reach, responsive |

## Classification

| Score | Priority | Action |
|-------|----------|--------|
| 80-100 | A | Outreach immediately |
| 60-79 | B | Outreach this week |
| 40-59 | Nurture | Add to nurture sequence |
| < 40 | Discard | Archive |

## Scorecard Template

```
Company: ___
Sector fit (20): ___
Communication (15): ___
Pain signals (15): ___
Decision maker (15): ___
Digital presence (10): ___
Sprint readiness (10): ___
Retainer potential (10): ___
Access ease (5): ___

TOTAL: ___/100
Priority: A / B / Nurture / Discard
```

## Automation

Score is calculated by `app/client_os/qualification.py`.
Human review required for priority A and priority B targets.
