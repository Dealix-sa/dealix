# Checklist موافقة Outreach

## قبل الموافقة

- [ ] Draft جاهز
- [ ] source_url موجود
- [ ] Company verified
- [ ] Pain hypothesis relevant
- [ ] Language safe (no fake claims)
- [ ] Channel appropriate
- [ ] Opt-out included (email)
- [ ] Personalization present
- [ ] Next step clear

## أثناء الموافقة

- [ ] قرأت الـ draft بالكامل
- [ ] التحققت من source_url
- [ ] التحققت من pain hypothesis
- [ ] التحققت من عدم وجود fake claims
- [ ] أضفت personalization إذا لزم
- [ ] حددت next step

## بعد الموافقة

- [ ] سجلت approval في ledgers
- [ ] حددت follow-up date
- [ ] أضفت إلى tracker

## Rejection Reasons

- Fake claims detected
- Source URL missing
- Company not verified
- Pain not relevant
- Channel inappropriate
- Language needs revision

## Gate

لا يتم إرسال outreach إلا إذا:
- Approval checklist كامل
- approved_by logged
- source_url present
- No red flags
