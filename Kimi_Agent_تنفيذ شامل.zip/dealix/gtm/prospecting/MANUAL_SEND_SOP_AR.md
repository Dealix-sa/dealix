# إجراء الإرسال اليدوي

## الخطوات

### 1. راجع الـ Draft
- افتح body_path من outreach_log
- اقرأ بالكامل
- تأكد من personalization

### 2. تحقق من القائمة
- تأكد أن الـ contact ليس في suppression list
- تأكد من opt-in (واتساب)

### 3. انسخ والصق
- انسخ من الـ draft
- الصق في channel (email/LinkedIn/WhatsApp)

### 4. أضف لمسة شخصية
- أضف اسم المرسل
- أضف reference محدد
- لا تغير الـ core message

### 5. أرسل
- Send
- سجل وقت الإرسال

### 6. سجل
```csv
message_id,sent_at,approved_by
```

## القواعد

- إرسال يدوي فقط — no auto-send
- لا تعديل على الـ draft الأساسي
- سجل كل إرسال
- احترم rate limits

## Rate Limits

- Email: 25/day
- WhatsApp: 50/day (approved only)
- LinkedIn: 20/day

## WhatsApp خاص

- تأكد من opt-in
- لا cold WhatsApp
- ابدأ بـ template فقط
- احترم "إلغاء"
