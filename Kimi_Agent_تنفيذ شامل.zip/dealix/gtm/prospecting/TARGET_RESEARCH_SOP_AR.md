# إجراء البحث عن Targets

## الخطوات

### 1. اختر القطاع
- استخدم SECTOR_PRIORITY_MAP_AR.md
- ابدأ بالقطاع الأعلى أولوية

### 2. اختر المصدر
- Google Maps: للعيادات، المطاعم، المعارض
- LinkedIn: لـ B2B services
- SAMA: للشركات المالية
- CITC: لشركات الاتصالات

### 3. اجمع البيانات
```
company_name
sector
city
website
source_url
contact_page_url
public_email
phone
```

### 4. سجل في ledger
```csv
company_id,company_name,sector,city,website,source_url,...
```

### 5. شغّل التأهيل
```bash
python scripts/client_os/run_target_research.py
```

### 6. راجع النتائج
- confidence >= medium
- verification_status
- source_url present

### 7. وافق أو رفض
- Update owner_decision field

## القواعد

- لا target بدون source_url
- لا target في suppression list
- لا target أقل من 40 score
- سجل كل شيء في ledgers
