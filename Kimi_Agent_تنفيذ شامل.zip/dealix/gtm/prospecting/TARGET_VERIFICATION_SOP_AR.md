# إجراء التحقق من Targets

## الخطوات

### 1. تحقق من الموقع
- افتح website
- تأكد من أنه يعمل
- تحقق من sector

### 2. تحقق من التواصل
- contact_page_url موجودة؟
- public_email أو phone موجود؟

### 3. تحقق من القطاع
- هل sector ضمن ICP؟
- هل visible_services مناسبة؟

### 4. تحقق من الألم
- هل visible_pain_signals موجودة؟
- هل التقييمات تكشف عن ألم؟

### 5. حدد الحالة
- verified: موثق ومناسب
- pending: يحتاج مراجعة
- unverified: غير كافٍ
- discard: لا يناسب

### 6. سجل
```csv
company_id,verification_status,confidence
```

## Gates

لا يتم outreach إلا إذا:
- verification_status = verified
- confidence >= medium
- source_url موجود
- Not in suppression list
