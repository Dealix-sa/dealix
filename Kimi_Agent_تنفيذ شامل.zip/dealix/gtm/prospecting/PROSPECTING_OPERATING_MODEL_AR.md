# نموذج تشغيل الاستهداف

## المبدأ

500 target مؤهل > 5000 target عشوائي.

## العملية

### 1. جمع (Collect)
- مصادر موثقة: Google Maps, LinkedIn, SAMA, CITC
- لا scraping غير قانوني
- source_url مطلوب لكل target

### 2. تأهيل (Qualify)
- ICP checklist
- Prospect scoring model
- Red flag check

### 3. تحقيق (Verify)
- Website check
- Contact validation
- Sector confirmation

### 4. تصنيف (Score)
- Score من 100
- Priority A/B/Nurture/Discard

### 5. توصية (Recommend)
- أفضل منتج لكل target
- زاوية الرسالة
- channel الأفضل

## الأدوات

- `app/client_os/company_research.py`
- `app/client_os/qualification.py`
- `ledgers/companies.csv`
- `gtm/prospecting/PROSPECT_SCORING_MODEL.md`

## Metrics

- Daily: 20 targets
- Weekly: 100 targets
- Monthly: 400 targets

## Quality Gates

- source_url موجود
- ICP score >= 40
- Not in suppression list
- Red flag = 0
