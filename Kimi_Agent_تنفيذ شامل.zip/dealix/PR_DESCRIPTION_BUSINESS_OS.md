## Summary
Adds a complete Business Operating System for Dealix, covering strategy, product catalog, GTM, sales, pricing, delivery, trust, customer success, partnerships, content, founder daily operations, reports, ledgers, scripts, and tests.

## Business Purpose
Dealix remains positioned as AI Operating Systems for Companies.
This PR turns the business side of Dealix into a structured operating layer:
- Productized services
- Sales assets
- GTM playbooks
- Delivery SOPs
- Client success system
- Trust and compliance policies
- Revenue machine
- Founder daily OS
- Business command room

## What changed
- Added business strategy files (10 strategy docs AR + EN)
- Added product catalog (AR + EN, all 11 products)
- Added offer stack, pricing strategy, unit economics, margin model
- Added GTM system (master plan + sector priority map)
- Added sales assets (sector pitches for 10 sectors)
- Added proposal templates (Executive, Diagnostic Sprint, Managed OS)
- Added trust/compliance policies (PDPL, AI usage, No fake claims)
- Added partnership system
- Added content engine strategy
- Added founder operating system (daily + 30-60-90 plan)
- Added market research notes
- Added business scripts (validate, day runner, founder actions)
- Added proposal validation script
- Added reports/business outputs
- Added 17 new tests
- Updated Makefile with business targets

## Safety
- No secrets
- No external send by default
- No fake ROI
- No fake testimonials
- Human approval gates preserved
- Company Brain OS remains secondary service
- Dealix identity preserved

## Validation
- python -m compileall app scripts (clean)
- python -m pytest -q (44/44 passing)
- make business-validate (25/25 assets passed)
- make business-day (working)
- make founder-actions (working)
- Secrets scan (clean)

## Merge readiness
Ready to merge only if tests pass and no existing behavior is broken.
