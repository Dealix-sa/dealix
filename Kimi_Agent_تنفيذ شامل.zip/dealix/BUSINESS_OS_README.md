# Dealix Business Operating System

**Dealix — AI Operating Systems for Companies**

Complete business layer covering strategy, products, sales, delivery, trust, pricing, GTM, customer success, partnerships, content, and founder operations.

## Quick Start

```bash
# Validate all business assets
make business-validate

# Run business day
make business-day

# Generate founder actions
make founder-actions

# Run everything
make company-full-day

# Run tests
make test
```

## Structure

```
business/
  strategy/          — Market positioning, ICP, competitive moats
  products/          — Product catalog (10+ OS products)
  offers/            — Offer stack, qualification matrix
  pricing/           — Pricing strategy, unit economics
  gtm/               — Go-to-market plans, sector priorities
  customer_success/  — Onboarding, reviews, renewals

sales/
  SECTOR_PITCHES_AR.md  — Pitches for 10 sectors

proposals/
  _templates/        — Executive, Diagnostic, Managed OS templates

trust/
  PDPL checklist, AI policy, No fake claims, Approval gates

founder/
  Daily OS, 30-60-90 plan

content/
  Content strategy

partnerships/
  Partnership strategy

research/
  Saudi AI market notes

scripts/business/
  validate_business_assets.py
  run_business_day.py
  generate_founder_actions.py

scripts/proposals/
  validate_proposal.py
```

## Identity

**Dealix is:** AI Operating Systems for Companies

**Company Brain OS is:** A secondary/advanced service within Dealix, NOT the company identity.

## Safety

- No external send by default
- No WhatsApp cold automation
- No fake ROI or guaranteed claims
- PDPL-aware data handling
- Human approval gates on all sensitive actions

## Validation

```bash
python -m pytest tests/ -q
make business-validate
make business-day
make founder-actions
```
