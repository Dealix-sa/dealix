# استراتيجية الشراكات

## أنواع الشراكات

### 1. وكالة تسويق
- تبيع Dealix لعملائها
- Revenue share: 20-30%
- Ideal: agencies with 10+ clients in target sectors

### 2. شركة استشارات
- تحتاج delivery engine
- Revenue share: 15-25%
- Ideal: consulting firms doing implementation

### 3. شركة لوجستية
- تحتاج Growth OS
- Revenue share: 15-20%
- Ideal: logistics with B2C delivery

### 4. مزود تقنية
- يحتاج AI layer
- Integration partnership
- Ideal: ERP or POS providers

### 5. Vertical Partner
- يبني قطاع كامل مع Dealix
- Revenue share: 30-40%
- Ideal: sector expert with network

## Qualification

- [ ] 10+ clients في القطاع المستهدف
- [ ] Sales team موجود
- [ ] Dealix alignment مع product
- [ ] No conflict of interest
- [ ] Credit/background check

## Partnership Process

1. **Introduction**: 1-2 meetings
2. **Due diligence**: Check clients, team, reputation
3. **Agreement**: Partnership agreement signed
4. **Training**: Team trained on Dealix
5. **Co-selling**: First 3 deals together
6. **Independent**: Partner sells independently

## Revenue Share Model

| Tier | Partner Type | Share | Min Deals/Quarter |
|------|-------------|-------|-------------------|
| Referral | Any | 10% | N/A |
| Reseller | Agency | 20% | 2 |
| Strategic | Vertical | 30% | 5 |

## Rules

- No exclusive partnerships in first 6 months
- All deals must be in ledgers
- Partner must follow trust policies
- No white-label without approval
- Quarterly review
