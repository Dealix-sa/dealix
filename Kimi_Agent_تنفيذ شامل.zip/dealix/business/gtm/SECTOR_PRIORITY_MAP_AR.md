# خريطة أولوية القطاعات

## الترتيب

### 1. العيادات والرعاية الصحية
**لماذا**: ألم واضح، مواعيد، متابعة، تقييمات
**المنتج**: WhatsApp Follow-up + Review OS
**سعر Diagnostic**: 10,000 SAR

### 2. العقارات
**لماذا**: متابعة عملاء، عروض، تقييمات
**المنتج**: Revenue Command Room + WhatsApp Follow-up
**سعر Diagnostic**: 15,000 SAR

### 3. التدريب والاستشارات
**لماذا**: أسرع دورة بيع، متابعة طلاب
**المنتج**: Operations + Follow-up OS
**سعر Diagnostic**: 10,000 SAR

### 4. اللوجستيات
**لماذا**: تتبع شحنات، شكاوى، عمليات
**المنتج**: Operations + Delivery OS
**سعر Diagnostic**: 15,000 SAR

### 5. المطاعم والضيافة
**لماذا**: حجوزات، تقييمات، حجم
**المنتج**: Review + WhatsApp Follow-up
**سعر Diagnostic**: 5,000 SAR

## Gates

لا ندخل قطاع جديد إلا إذا:
- [ ] 3+ success stories في القطاع السابق
- [ ] Playbook مكتمل
- [ ] Case study نشرت
- [ ] ICP واضح
