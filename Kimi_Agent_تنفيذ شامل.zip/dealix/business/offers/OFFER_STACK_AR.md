# شريحة العروض — Offer Stack

## المستويات

### 1. Diagnostic Sprint (مدخل البيع)
- **المدة**: 3-7 أيام
- **السعر**: 5,000-15,000 ريال
- **القيمة**: خريطة واضحة للمشاكل والحلول
- **المخرج**: Pain map + 30-day plan
- **التحويل**: 30% إلى Pilot OS

### 2. Pilot OS (تجربة محدودة)
- **المدة**: 30-60 يوم
- **السعر**: 15,000-35,000 ريال
- **القيمة**: نظام يعمل على workflow واحد
- **المخرج**: Working system + proof report
- **التحويل**: 60% إلى Managed OS

### 3. Managed OS Retainer (التشغيل المستمر)
- **المدة**: شهري/سنوي
- **السعر**: 5,000-20,000 ريال/شهر
- **القيمة**: تشغيل كامل + تحديث + proof
- **المخرج**: Monthly proof report + expansion
- **التجديد**: هدف 80%

### 4. Custom Build (مشاريع مخصصة)
- **المدة**: 2-6 أشهر
- **السعر**: 50,000-500,000+ ريال
- **القيمة**: نظام مخصص كامل
- **المخرج**: Enterprise system + training
- **التوسع**: modules إضافية

### 5. Strategic Partnership (شراكات)
- **المدة**: سنوي
- **السعر**: حسب الشريك
- **القيمة**: Joint GTM + shared revenue
- **المخرج**: Co-branded system
- **النوع**: Agency, Consultant, Tech, Vertical

## Qualification Matrix

| Factor | Diagnostic | Pilot | Managed | Custom | Partner |
|--------|-----------|-------|---------|--------|---------|
| Budget | Low | Medium | Monthly | High | Variable |
| Decision Speed | Fast | Medium | Slow | Slow | Slow |
| Pain Clarity | High | Medium | Medium | Custom | Medium |
| ICP Fit | All | Qualified | Best | Enterprise | Strategic |

## Risk Rules

- لا custom build بدون pilot أو diagnostic
- لا partnership بدون 3 أشهر relationship
- لا managed OS بدون proof من pilot
- سعر Diagnostic ثابت وسهل
