# تأهيل ICP — ICP Qualification

## Checklist

- [ ] 10-200 موظف
- [ ] مقر السعودية
- [ ] يستخدم واتساب مع العملاء
- [ ] لديه تقييمات على Google أو منصات
- [ ] يبيع عبر علاقات (B2C أو B2B services)
- [ ] لا CRM فعال
- [ ] Revenue 2M-100M ريال سنوياً

## Red Flags (رفض مباشر)

- [ ] أقل من 5 موظفين (ما عدا العيادات)
- [ ] لا يستخدم واتساب
- [ ] CRM متكامل فعلاً
- [ ] يطلب نتيجة مضمونة
- [ ] لا يملك قرار
- [ ] لا budget

## Yellow Flags (تحذير)

- [ ] حكومي (يحتاج مسار خاص)
- [ ] multinational (قرار خارج السعودية)
- [ ] يريد كل شيء فوراً
- [ ] no data available

## Qualification Score

| Factor | Weight | Score |
|--------|--------|-------|
| Sector fit | 25% | /10 |
| Size fit | 20% | /10 |
| Pain match | 25% | /10 |
| Decision maker access | 15% | /10 |
| Budget clarity | 15% | /10 |

**Total /10**: Score >= 7 = qualified

## Gate

لا يتم إرسال outreach إلا إذا:
- source_url موجود
- qualification score >= 7
- not in suppression_list
- red flag = 0
