# قواعد قرار المؤسس — Founder Decision Rules

## Daily Rules

1. **لا أتمتة عمياء**: كل إرسال خارجي يحتاج موافقة
2. **لا وعود مضمونة**: نقول "قد يساعد" لا "نضمن النتيجة"
3. **العميل يملك بياناته**: لا نحتفظ ببيانات بدون إذن
4. **Proof أولاً**: قبل التوسع، نثبّت القيمة
5. **Sector focus**: نفوز بقطاع قبل الانتقال لقطاع جديد

## Weekly Rules

1. **مراجعة ledgers**: هل البيانات محدثة؟
2. **Review clients**: من يحتاج attention؟
3. **Check trust gates**: هل هناك مخالفات؟
4. **Founder actions**: هل الـ 10 actions واضحة؟

## Monthly Rules

1. **Unit economics**: هل كل منتج مربح؟
2. **Client health**: scores لكل عميل
3. **Team capacity**: هل نستطيع تسليم ما نبيع؟
4. **Market signals**: أي قطاع يفتح؟

## Decision Matrix

| الوضع | القرار |
|-------|--------|
| عميل يريد AI بدون حوكمة | رفض أو educat |
| عميل يريد نتيجة مضمونة | توضيح + proof-based |
| شريك يريد white-label | تقييم حالة بحالة |
| عميل حساس (bank/gov) | مسار enterprise منفصل |
| فرصة خارج ICP | رفص مهذب |
| عميل غير ملتزم بالUAT | pause لا cancel |

## Red Lines

- لا fake ROI
- no fake testimonials
- no uncontrolled send
- no sensitive data on personal devices
- no verbal-only agreements
- no work without signed proposal

## Definition of Done

كل قرار يجب أن يكون:
- [ ] مسجل في decisions_log
- [ ] مرتبط بـ client/project إذا كان عملياتي
- [ ] متضمن trade-offs
- [ ] محدد owner و deadline
