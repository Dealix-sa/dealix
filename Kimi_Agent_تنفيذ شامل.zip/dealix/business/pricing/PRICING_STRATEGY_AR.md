# استراتيجية التسعير

## المبدأ

Value-based pricing — نسعر حسب القيمة لا حسب الساعات.

## المستويات

### Diagnostic Sprint
- **سعر ثابت**: 5,000-15,000 ريال
- **لا يتفاوض** — سعر ثابت يسهل القرار

### Pilot OS
- **سعر ثابت**: 15,000-35,000 ريال
- حسب عدد الـ workflows

### Managed OS Retainer
- **شهري**: 5,000-20,000 ريال/شهر
- حسب:
  - عدد الـ users
  - عدد الـ workflows
  - حجم البيانات
  - SLA level

### Custom Build
- **مشروع**: 50,000-500,000+ ريال
- بناءً على scope ومدة التنفيذ

## Discount Rules

- سنوي: 10% خصم
- 12-month commitment: 15% خصم
- لا خصم أكثر من 20% إلا بموافقة مؤسس
- لا free work

## Payment Terms

- Diagnostic: 100% مقدم
- Pilot: 50% مقدم + 50% عند delivery
- Managed: شهري مقدم
- Custom: 30% مقدم + 40% عند UAT + 30% عند launch
