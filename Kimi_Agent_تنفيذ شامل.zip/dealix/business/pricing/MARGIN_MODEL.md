# Margin Model

## Revenue Model

```
Revenue = (Diagnostic x Volume) + (Pilot x Volume) + (Managed MRR x Clients) + (Custom x Volume) + (Partnership Revenue Share)
```

## Cost Structure

### Direct Costs
- Delivery team time
- Tools & infrastructure
- AI API costs
- WhatsApp Business API

### Indirect Costs
- Sales & marketing
- R&D
- G&A

## Target Margins

| Product | Gross Margin | Notes |
|---------|-------------|-------|
| Diagnostic | 70% | High margin, low cost |
| Pilot | 55% | Requires delivery effort |
| Managed OS | 60% | Recurring, scalable |
| Custom | 40% | High effort, variable |
| Partnership | 30% | Shared revenue |

## Blended Margin Target: 55%

## Breakeven Analysis

Monthly fixed costs: TBD (depends on team size)
Breakeven clients: TBD

## Notes

- No pricing in code
- All pricing in business/pricing/
- Price changes require founder approval
- No automatic discounts
