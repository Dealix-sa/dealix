# Unit Economics

## Assumptions

| Metric | Value | Notes |
|--------|-------|-------|
| Diagnostic price | 10,000 SAR | Average |
| Pilot price | 25,000 SAR | Average |
| Managed monthly | 10,000 SAR | Average |
| Diagnostic to Pilot | 30% | Conversion |
| Pilot to Managed | 60% | Conversion |
| Managed churn | 10%/month | Target < 10% |
| Gross margin | 60% | Target |

## Unit Economics per Customer Journey

### Diagnostic Only
- Revenue: 10,000
- Cost: 3,000
- Margin: 7,000 (70%)

### Diagnostic -> Pilot
- Revenue: 10,000 + 25,000 = 35,000
- Cost: 3,000 + 12,000 = 15,000
- Margin: 20,000 (57%)

### Full Journey: Diagnostic -> Pilot -> Managed (12 months)
- Revenue: 10,000 + 25,000 + (10,000 x 12) = 155,000
- Cost: 3,000 + 12,000 + (4,000 x 12) = 63,000
- Margin: 92,000 (59%)
- LTV: ~155,000 SAR (first year)

## CAC Targets

| Channel | Target CAC | Notes |
|---------|-----------|-------|
| Outbound | < 5,000 SAR | Email, LinkedIn |
| Partners | < 3,000 SAR | Revenue share |
| Content | < 2,000 SAR | Organic |
| Referrals | < 1,000 SAR | Best channel |

## LTV / CAC Ratio

Target: LTV/CAC > 5

Example:
- LTV = 155,000 SAR (first year)
- CAC = 5,000 SAR
- Ratio = 31 (excellent)

## Break-even

Target: Month 3 of Managed OS
