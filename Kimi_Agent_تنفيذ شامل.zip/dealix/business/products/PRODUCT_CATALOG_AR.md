# كتالوج منتجات Dealix

## المنتجات الأساسية

### 1. Revenue Command Room OS

**المشكلة**: الشركات عندها leads، محادثات، عروض، ومتابعات، لكن لا يوجد نظام يومي يحدد من يحتاج متابعة، أي فرصة ساخنة، وأين تضيع الإيرادات.

**التسليم**:
- Lead ledger
- Follow-up queue
- Proposal queue
- Daily CEO report
- Command dashboard
- Owner لكل فرصة
- Next action لكل فرصة
- Weekly proof report

**السعر**: حسب الحجم — انظر PRICING_STRATEGY_AR.md

---

### 2. WhatsApp / Inbox Follow-up OS

**المشكلة**: واتساب والإيميل يتحولان إلى مقبرة فرص بسبب الردود المتأخرة وعدم وجود ذاكرة متابعة.

**التسليم**:
- تصنيف المحادثات
- مسودات ردود
- follow-up day 1/3/7/14
- hot leads queue
- تقرير يومي
- human review before sending

**السعر**: حسب الحجم

---

### 3. Review & Reputation OS

**المشكلة**: التقييمات والشكاوى موجودة، لكنها لا تتحول إلى تحسين تشغيلي.

**التسليم**:
- Review classification
- Complaint themes
- Reply drafts
- Branch/service issue map
- Reputation weekly report
- Improvement recommendations

**السعر**: حسب الحجم

---

### 4. Operations & Delivery OS

**المشكلة**: الشركة تبيع، لكن التسليم غير مرئي، والمهام تضيع، والعميل لا يرى proof.

**التسليم**:
- Intake workflow
- Task ownership
- SLA tracking
- Delivery status
- Proof vault
- Weekly delivery report

**السعر**: حسب الحجم

---

### 5. Client Delivery OS

**المشكلة**: العملاء يحتاجون تسليم منظم مع proof.

**التسليم**:
- Client workspace
- Sprint plan
- UAT notes
- Proof reports
- Training guides
- Monthly review

**السعر**: حسب الحجم

---

### 6. AI Trust & Compliance OS

**المشكلة**: AI يستخدم داخل الشركة بدون سياسة، صلاحيات، أو حماية بيانات.

**التسليم**:
- AI usage policy
- Human approval gates
- Data handling SOP
- PDPL readiness checklist
- No fake claims policy
- AI output review log

**السعر**: حسب الحجم

---

### 7. Controlled Live Outbound OS

**المشكلة**: الشركات تحتاج تواصل خارجي، لكن الإرسال العشوائي يضر السمعة والدومين والرقم.

**التسليم**:
- Email/WhatsApp draft queue
- Approval gates
- Rate limits
- Opt-out
- Suppression list
- Reply tracking
- No uncontrolled send

**السعر**: حسب الحجم

---

### 8. Company Diagnosis Sprint

**المشكلة**: الشركة لا تعرف أين تبدأ.

**التسليم**:
- Current state map
- Pain map
- Bottleneck report
- First workflow recommendation
- Risk register
- 30-day action plan

**المدة**: 3-7 أيام

**السعر**: سعر ثابت — انظر DIAGNOSTIC_SPRINT_OFFER_AR.md

---

### 9. Company Brain OS

**المشكلة**: الإدارة تحتاج قرار يومي مبني على الإشارات، لا تقارير كثيرة.

**التسليم**:
- Daily decision brief
- Future radar
- Risk/opportunity register
- Weekly CEO memo
- Assumptions log
- Scenario analysis
- Next 10 actions

**مهم**: Company Brain OS خدمة متقدمة ثانوية تركب فوق Revenue OS / Command Room / Delivery OS. **ليست هوية الشركة**.

**السعر**: حسب الحجم

---

### 10. Custom Enterprise Systems

**المشكلة**: الأدوات الجاهزة لا تكفي لبعض الشركات.

**التسليم**:
- Custom portals
- Proposal builder
- Client portal
- Vendor OS
- Compliance workflow
- Executive reporting
- Knowledge base
- Agent operations

**السعر**: مشروع مخصص

---

### 11. Strategic Partnership OS

**المشكلة**: بعض الشركات تحتاج Dealix كشريك نمو وتشغيل، لا كمورد فقط.

**التسليم**:
- Joint GTM
- Partner dashboard
- Revenue share model
- Co-branded system
- Sector OS
- Distribution playbook

**السعر**: حسب الشريك

---

## ملاحظات

- كل منتج يباع كـ stand-alone أو كـ bundle
- Company Brain OS لا تباع standalone إلا بعد 2+ منتج
- Diagnostic Sprint هو مدخل البيع الرئيسي
- Custom Enterprise يتطلب proposal مخصص
- Strategic Partnership يتطلب due diligence

## Company Brain OS Positioning

**NOT the primary identity of Dealix.**
**Dealix remains: AI Operating Systems for Companies.**

Company Brain OS is a secondary/advanced service layer.
