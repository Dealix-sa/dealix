# Company Diagnosis Sprint
## Entry-Level Sales Offering

---

## What It Is

A 3-7 day rapid diagnostic engagement that gives prospects a clear picture of their current state and a concrete 30-day plan.

## Deliverables

1. **Current State Assessment** — 8-dimension evaluation
2. **Pain Map** — Prioritized pain points
3. **First Workflow** — Recommended initial automation
4. **30-Day Plan** — Concrete next steps

## Duration

3-7 business days, depending on client availability.

## Process

### Day 1: Intake
- Complete intake form
- Stakeholder mapping
- Access checklist

### Days 2-4: Diagnosis
- Revenue analysis
- Follow-up audit
- Operations review
- Reputation scan
- Data assessment
- Team evaluation
- AI readiness check
- Governance review

### Day 5: Synthesis
- Build pain map
- Identify quick wins
- Design first workflow

### Days 6-7: Delivery
- Present findings
- Deliver 30-day plan
- Discuss expansion

## Pricing

Fixed-fee sprint. Custom quote based on company size and sector.

## Outcomes

- Client gets actionable insights
- Dealix gets qualified pipeline
- Clear path to full OS implementation
- No commitment required beyond the sprint

## Notes

- This is a **sales entry point**, not the full OS
- Results use assumptions and confidence levels
- No guaranteed ROI claims
- Company Brain OS may be mentioned as an add-on
