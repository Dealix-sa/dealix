# Dealix Product Catalog

## Core Products

1. **Revenue Command Room OS** — Daily revenue dashboard with lead tracking, follow-up queues, and CEO reports
2. **WhatsApp / Inbox Follow-up OS** — Automated conversation classification, reply drafts, and follow-up scheduling
3. **Review & Reputation OS** — Review classification, complaint analysis, and reputation improvement
4. **Operations & Delivery OS** — Task ownership, SLA tracking, and delivery visibility
5. **Client Delivery OS** — Client workspace, sprint plans, UAT, and proof reports
6. **AI Trust & Compliance OS** — AI usage policy, PDPL readiness, and human approval gates
7. **Controlled Live Outbound OS** — Draft queue, approval gates, rate limits, opt-out handling
8. **Company Diagnosis Sprint** — 3-7 day assessment: current state, pain map, 30-day plan
9. **Company Brain OS** — Daily decision brief, risk radar, CEO memo (secondary service)
10. **Custom Enterprise Systems** — Tailored portals, workflows, and integrations
11. **Strategic Partnership OS** — Joint GTM, revenue share, co-branded systems

## Important

Company Brain OS is **NOT the primary identity** of Dealix.
Dealix remains **AI Operating Systems for Companies**.
