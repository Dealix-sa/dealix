# Company Brain OS
## Secondary / Advanced Service

---

## What It Is

Company Brain OS is a **secondary, advanced service** within the Dealix ecosystem. It sits on top of the Command Room, Revenue OS, and Delivery OS.

## What It Is NOT

- **NOT** the primary identity of Dealix. Company Brain OS is NOT the primary identity.
- **NOT** a standalone product
- **NOT** a replacement for other OS modules

## Primary Identity Remains

**Dealix — AI Operating Systems for Companies**

## What It Provides

1. **Daily Decision Summary** — Key decisions for the day based on data
2. **Future Radar** — Early signals and trend detection
3. **Weekly Memo** — Summary of performance and recommendations

## How It Works

- Consumes data from other Dealix OS modules
- Uses assumptions and confidence levels
- Does **not** provide deterministic predictions
- Requires human judgment for final decisions

## Position in the Ecosystem

```
Company Brain OS (layer on top)
    ↓
Revenue Command Room OS
WhatsApp / Inbox Follow-up OS
Review & Reputation OS
Operations & Delivery OS
Client Delivery OS
AI Trust & Compliance OS
Controlled Live Outbound OS
    ↓
Client Data (foundation)
```

## When to Offer

- After client has at least 2 OS modules active
- When client asks for analytics/insights
- As part of expansion, not initial sale

## Language Principles

- Uses "likely", "suggests", "based on patterns"
- Never claims certainty
- Always includes confidence levels
- Surfaces assumptions explicitly

## Integration

- Reads from ledgers/
- Consumes proof reports
- Analyzes client success data
- Outputs summaries to reports/
