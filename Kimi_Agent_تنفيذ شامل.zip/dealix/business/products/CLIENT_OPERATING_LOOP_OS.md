# Client Operating Loop OS
## Dealix Internal Operating Machine

---

## What It Is

The Client Operating Loop OS is Dealix's internal machine for managing the complete client lifecycle — from first contact to renewal.

It is **not** a product sold directly. It is the **operating backbone** of Dealix.

## Lifecycle Covered

```
Target Research → Company Intelligence → Pain Hypothesis → Outreach Draft
→ Human Approval → Controlled Send → Reply Classification → Meeting Booking
→ Client Intake → Company Diagnosis → Needs Map → Solution Blueprint
→ Proposal Draft → Client Project Workspace → Delivery Plan → UAT
→ Proof Report → Monthly Client Success → Expansion / Renewal
```

## Key Principles

1. **No uncontrolled send** — All external communication requires human approval
2. **No fake claims** — Pain hypotheses use cautious language, not guarantees
3. **Audit trail** — Every action is logged
4. **Gate-based** — Each phase has entry requirements
5. **Deterministic** — No external API dependencies by default

## Integration with Other Dealix OS Products

- Uses **Revenue Command Room OS** for pipeline tracking
- Uses **WhatsApp / Inbox Follow-up OS** for client communication
- Uses **Review & Reputation OS** for reputation data
- Uses **AI Trust & Compliance OS** for governance
- Uses **Controlled Live Outbound OS** for outreach (with approval gates)
- Uses **Company Brain OS** as a secondary service for insights

## Machine Components

| Module | Purpose |
|--------|---------|
| company_research.py | Ingest and validate targets |
| qualification.py | Score and verify companies |
| company_intelligence.py | Build intelligence briefs |
| pain_hypothesis.py | Generate cautious pain hypotheses |
| outreach_draft.py | Create message drafts |
| reply_classifier.py | Classify inbound replies |
| discovery_brief.py | Pre-call preparation |
| intake_engine.py | Client intake forms |
| diagnosis_engine.py | 8-dimension diagnosis |
| needs_mapper.py | Map client needs |
| blueprint_builder.py | Build system blueprint |
| proposal_builder.py | Generate proposal drafts |
| delivery_planner.py | Project delivery management |
| proof_reporter.py | Proof of value reports |
| client_success.py | Monthly reviews & renewals |
| policy_gate.py | Central governance enforcement |
| audit_log.py | Immutable action logging |

## Company Brain OS Position

Company Brain OS is a **secondary service** within the Client Operating Loop. It provides:
- Daily decision summaries
- Future radar signals
- Weekly memos

But it is **not** the primary identity of Dealix. Dealix remains **AI Operating Systems for Companies**.
