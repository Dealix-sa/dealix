# Dealix Business Operating System

**Part of:** Dealix — AI Operating Systems for Companies

This directory contains the complete business layer for Dealix:
- Strategy & positioning
- Product catalog & service ladder
- Go-to-market system
- Pricing & unit economics
- Customer success
- Sales assets
- Trust & compliance

## Quick Navigation

| Directory | Purpose |
|-----------|---------|
| `strategy/` | Market positioning, ICP, competitive moats |
| `products/` | Product catalog for all 10+ OS products |
| `offers/` | Offer stack, qualification matrix, risk rules |
| `pricing/` | Pricing strategy, unit economics, margins |
| `gtm/` | Go-to-market plans, sector priorities, channel playbooks |
| `customer_success/` | Onboarding, reviews, renewals, expansion |

## Running the Business OS

```bash
# Validate all business assets
make business-validate

# Run the business day
make business-day

# Generate founder actions
make founder-actions

# Run everything
make company-full-day
```
