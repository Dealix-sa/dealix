# رسائل الخطوة التالية

## After Discovery Call

"شكراً للمكالمة المثمرة.

بناءً على ما شاركتموه، أنصح بـ Company Diagnosis Sprint.
سأرسل الـ proposal خلال 24 ساعة.

إذا عندكم سؤال، أنا متواجد."

## After Proposal Sent

"Proposal جاهز. هل قرأتموه؟

هل تريدون نراجعه معاً في مكالمة 15 دقيقة هذا الأسبوع؟"

## After Meeting

"شكراً للوقت. الملخص:

[الألم]
[الحل المقترح]
[الخطوة التالية]

سأرسل [ماذا] قبل [متى]."

## After Acceptance

"مرحباً بكم في Dealix!

Kickoff meeting: [DATE]
Intake form: مرفق

نبدأ رحلتكم نحو نظام تشغيل ذكي."

## After Rejection

"أفهم تماماً. لا مشكلة.

هل تخبرني ما الذي كان مفقوداً؟
أنا هنا إذا احتجتم أي شيء في المستقبل.

بالتوفيق!"

## Follow-up after No Reply

Day 3: "Quick follow-up on my message. Any thoughts?"
Day 7: "Still relevant? Happy to share a sector insight if helpful."
Day 14: "This is my final follow-up. Happy to reconnect when timing is better."
Day 30: [Share relevant content, no ask]

## WhatsApp Template (after opt-in)

"السلام عليكم [Name],

شكراً على الوقت yesterday.

[Next step in Arabic]

هل يوم [day] يناسبكم؟"
