# Deal Acceptance Checklist

## لا تقبل الصفقة إلا إذا:

- [ ] يوجد صاحب قرار
- [ ] يوجد ألم واضح
- [ ] يوجد أول workflow محدد
- [ ] يوجد data source واضح
- [ ] يوجد review owner
- [ ] يوجد success metric
- [ ] يوجد timeline
- [ ] يوجد scope واضح
- [ ] يوجد acceptance criteria
- [ ] لا توجد وعود ROI وهمية
- [ ] لا يوجد طلب إرسال خارجي غير محكوم

## بعد القبول

- [ ] Proposal وقع
- [ ] Kickoff meeting محدد
- [ ] Intake form مرسل
- [ ] Ledger محدث
- [ ] Team notified
- [ ] Project workspace ready

## قبل البدء

- [ ] Access checklist مكتمل
- [ ] Data sources confirmed
- [ ] Stakeholder map ready
- [ ] Communication channel set
- [ ] Expectations aligned

## Gates

لا kickoff إلا إذا checklist كامل.
لا delivery إلا إذا kickoff مكتمل.
لا retainer إلا إذا proof report delivered.
