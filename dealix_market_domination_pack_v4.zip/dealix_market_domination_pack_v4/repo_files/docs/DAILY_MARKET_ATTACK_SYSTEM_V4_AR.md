# Daily Market Attack System V4

## المدخلات

- `os/examples/target_accounts_seed_v4.csv`
- `os/config/market_attack_v4.json`

## المخرجات

- `reports/market-attack-v4/daily_attack.json`
- `reports/market-attack-v4/daily_attack.csv`
- `reports/market-attack-v4/daily_attack.md`

## طريقة العمل

1. ضع 10–20 شركة فقط.
2. قيّم الألم، الوصول للمشتري، الاستعجال، القدرة المالية، fit للإثبات، ومخاطر الحوكمة.
3. السكربت يرتب الأولوية.
4. المؤسس يراجع الرسائل.
5. الإرسال يكون مخصص وليس spam.

## صيغة الرسالة الأفضل

```text
لاحظت ألم محدد في [workflow].
Dealix يقدر يبدأ بنطاق صغير قابل للقياس خلال 30 يوم.
هل يناسب أرسل لك خريطة workflow مختصرة؟
```

## ممنوع

- وعود ROI مضمونة.
- رسائل جماعية بلا مراجعة.
- demo ببيانات عميل.
- كلام عام مثل: "نحول شركتك بالذكاء الاصطناعي" بدون workflow.
