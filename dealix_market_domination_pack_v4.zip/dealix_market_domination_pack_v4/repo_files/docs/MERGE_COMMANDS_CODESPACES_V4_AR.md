# أوامر دمج Dealix V4 داخل GitHub Codespaces

افتح Codespace على الريبو ثم نفذ:

```bash
git switch -c feat/dealix-command-center-v4

rsync -av /workspaces/dealix_market_domination_pack_v4/repo_files/ ./

python scripts/dealix_v4_integrity.py --strict
python scripts/dealix_command_center_export.py --write-ts
python scripts/dealix_market_attack_daily_v4.py --seed os/examples/target_accounts_seed_v4.csv
pytest tests/os/test_dealix_v4_command_center.py -q

npm ci
npm run check
npm run build

git status
git add .
git commit -m "feat: add Dealix founder command center v4"
git push -u origin feat/dealix-command-center-v4
```

## بعد الدمج على main

ادخل:

```text
/app/founder/command-room
```

وتأكد من ظهور:

- Revenue War Board
- Priority Accounts
- System Controls
- Delivery Proof Board
- Founder Cadence

## إذا فشل TypeScript

غالباً السبب أن الريبو تغير بعد بناء الحزمة. راجع هذه الملفات فقط:

- `src/App.tsx`
- `src/components/Sidebar.tsx`
- `src/pages/founder/CommandRoomPage.tsx`
- `src/data/dealixCommandCenter.ts`
- `src/data/generated/commandCenterSnapshot.ts`
