# Dealix V4 — Founder Command Center

هذه النسخة تحول Dealix من موقع وخطة دخول سوق إلى **غرفة قيادة تشغيلية** داخل التطبيق:

- `/app/founder/command-room`
- Daily targeting engine
- Revenue war board
- Delivery proof board
- Governance controls
- Scripts تولد snapshot يومي وتحدث بيانات الواجهة

## الهدف

أن تكون Dealix شركة بناء أنظمة تشغيل للشركات، وليست مزود شات بوت أو صفحات Dashboard فقط.

القاعدة:

> كل يوم لازم ينتج واحد على الأقل: target جيد، رسالة مخصصة، discovery call، audit proposal، proof asset، أو قرار إزالة مخاطرة.

## مكونات الغرفة

### 1. Growth Attack

يجيب لك:

- من نستهدف اليوم؟
- ما الألم؟
- ما العرض المناسب؟
- ما الرسالة الأولى؟
- هل يحتاج review قبل الإرسال؟

### 2. Sales Pipeline

يربط الاستهداف بالفلوس:

- Targeted
- Conversation
- Audit Proposed
- Pilot Negotiation
- Won / Retainer

### 3. Delivery Proof

كل مشروع لازم يطلع بإثبات:

- baseline
- target metric
- before/after
- acceptance criteria
- risk notes

### 4. Governance

يحمي الشركة من أكبر أخطاء شركات AI:

- وعود ROI غير مثبتة
- إرسال مزعج
- استخدام بيانات حساسة
- أتمتة قرار حساس بدون موافقة بشرية

## أوامر التشغيل اليومية

```bash
python scripts/dealix_command_center_export.py --write-ts
python scripts/dealix_market_attack_daily_v4.py --seed os/examples/target_accounts_seed_v4.csv
python scripts/dealix_v4_integrity.py --strict
pytest tests/os/test_dealix_v4_command_center.py -q
npm run check
npm run build
```

## معيار النجاح

Dealix جاهزة لدخول السوق عندما تستطيع تنفيذ هذا 5 أيام متتالية:

- 15–20 target يومياً
- 5–7 priority accounts يومياً
- 3 discovery conversations أسبوعياً على الأقل
- 2 paid audits أسبوعياً
- proof asset واحد كل يومين
- ولا رسالة أو claim بدون review
