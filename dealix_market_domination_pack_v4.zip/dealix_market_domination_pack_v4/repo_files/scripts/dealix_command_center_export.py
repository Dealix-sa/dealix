#!/usr/bin/env python3
"""Generate Dealix V4 command center snapshot, markdown brief, and optional TS seed."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

RIYADH = timezone(timedelta(hours=3))


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def build_snapshot(config_path: Path, revenue_path: Path) -> dict:
    config = load_json(config_path)
    revenue = load_json(revenue_path)
    now = datetime.now(RIYADH)
    daily = config["default_daily_numbers"]
    offer_values = revenue["offer_values"]
    expected_pipeline = (
        daily["audits_proposed"] * offer_values["audit_high"]
        + daily["calls_to_book"] * offer_values["pilot_low"]
    )
    return {
        "generatedAt": now.isoformat(timespec="seconds"),
        "commandDate": now.date().isoformat(),
        "founderMode": "Market Attack + Proof Delivery",
        "revenueTargetSar": revenue["monthly_targets"]["breakout_case"],
        "cashTargetSar": revenue["monthly_targets"]["base_case"],
        "weeklyFocus": [
            "Close paid AI Workflow Audits before building large custom systems.",
            "Convert the strongest audit into a 30-Day Pilot with acceptance criteria.",
            "Create proof assets daily: demo, before/after report, or safe case study.",
            "Use human approval gates for every outbound claim and sensitive workflow.",
        ],
        "todayNumbers": daily,
        "conversionModel": {
            "dailyMessages": daily["messages_ready"],
            "positiveReplyRatePct": 11,
            "callBookingRatePct": 45,
            "auditCloseRatePct": 35,
            "pilotUpgradeRatePct": 40,
            "expectedDailyPipelineSar": expected_pipeline,
        },
        "commandAlerts": [
            {
                "id": "alert-human-review",
                "severity": "high",
                "title": "Human review required before outbound",
                "action": "Review every target, claim, and message before sending.",
            },
            {
                "id": "alert-proof-before-scale",
                "severity": "medium",
                "title": "No scale without proof",
                "action": "Every pilot must have baseline, target metric, owner, and proof report.",
            },
        ],
    }


def write_markdown(snapshot: dict, path: Path) -> None:
    numbers = snapshot["todayNumbers"]
    lines = [
        "# Dealix Command Center Brief V4",
        "",
        f"- Generated: {snapshot['generatedAt']}",
        f"- Founder mode: {snapshot['founderMode']}",
        f"- Revenue target: {snapshot['revenueTargetSar']:,} SAR",
        f"- Cash target: {snapshot['cashTargetSar']:,} SAR",
        "",
        "## Today's Numbers",
    ]
    for key, value in numbers.items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Weekly Focus"])
    for item in snapshot["weeklyFocus"]:
        lines.append(f"- {item}")
    lines.extend(["", "## Alerts"])
    for alert in snapshot["commandAlerts"]:
        lines.append(f"- [{alert['severity']}] {alert['title']}: {alert['action']}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_ts(snapshot: dict, path: Path) -> None:
    payload = json.dumps(snapshot, ensure_ascii=False, indent=2)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"export const generatedCommandCenterSnapshot = {payload} as const;\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="os/config/command_center_v4.json")
    parser.add_argument("--revenue", default="os/config/revenue_board_v4.json")
    parser.add_argument("--out-dir", default="reports/command-center")
    parser.add_argument("--write-ts", action="store_true")
    parser.add_argument("--ts-out", default="src/data/generated/commandCenterSnapshot.ts")
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    snapshot = build_snapshot(Path(args.config), Path(args.revenue))
    json_path = out_dir / "dealix-command-center-snapshot.json"
    md_path = out_dir / "dealix-command-center-brief.md"
    json_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_markdown(snapshot, md_path)
    if args.write_ts:
        write_ts(snapshot, Path(args.ts_out))
    print(json.dumps({"snapshot": str(json_path), "brief": str(md_path), "ts_updated": args.write_ts}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
