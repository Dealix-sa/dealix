#!/usr/bin/env python3
"""Build a daily market attack board for Dealix V4."""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

RIYADH = timezone(timedelta(hours=3))


def int_field(row: dict[str, str], key: str) -> int:
    try:
        return int(row.get(key, "0") or 0)
    except ValueError:
        return 0


def score(row: dict[str, str]) -> int:
    subtotal = (
        int_field(row, "pain_strength")
        + int_field(row, "buyer_access")
        + int_field(row, "urgency_signal")
        + int_field(row, "ability_to_pay")
        + int_field(row, "proof_fit")
        - int_field(row, "governance_risk")
    )
    return max(0, min(100, subtotal))


def message_for(row: dict[str, str]) -> str:
    name = row["name"]
    pain = row["main_pain"]
    offer = row["offer"]
    return (
        f"لاحظت أن {name} قد يواجه ألم تشغيلي واضح: {pain}. "
        f"Dealix يقدر يبدأ بـ {offer} كنطاق صغير قابل للقياس خلال 30 يوم. "
        "هل يناسب أرسل لك خريطة workflow مختصرة قبل أي اجتماع؟"
    )


def read_targets(seed: Path, limit: int, priority_limit: int, min_score: int) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    with seed.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            item_score = score(row)
            rows.append({
                "name": row["name"],
                "sector": row["sector"],
                "score": item_score,
                "priority": item_score >= min_score,
                "pain": row["main_pain"],
                "offer": row["offer"],
                "channel": row["channel"],
                "manual_review_required": True,
                "first_message": message_for(row),
                "next_action": "Review claim, personalize opening, then send one low-risk discovery ask.",
            })
    rows.sort(key=lambda item: int(item["score"]), reverse=True)
    selected = rows[:limit]
    priority_seen = 0
    for item in selected:
        if item["priority"] and priority_seen < priority_limit:
            priority_seen += 1
        else:
            item["priority"] = False
    return selected


def write_csv(rows: list[dict[str, object]], path: Path) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_md(rows: list[dict[str, object]], path: Path) -> None:
    lines = ["# Dealix Daily Market Attack V4", "", f"Generated: {datetime.now(RIYADH).isoformat(timespec='seconds')}", ""]
    for idx, row in enumerate(rows, 1):
        marker = "🔥" if row["priority"] else "•"
        lines.extend([
            f"## {idx}. {marker} {row['name']} — Score {row['score']}",
            f"- Sector: {row['sector']}",
            f"- Pain: {row['pain']}",
            f"- Offer: {row['offer']}",
            f"- Channel: {row['channel']}",
            f"- First message: {row['first_message']}",
            f"- Next action: {row['next_action']}",
            "",
        ])
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", default="os/examples/target_accounts_seed_v4.csv")
    parser.add_argument("--config", default="os/config/market_attack_v4.json")
    parser.add_argument("--out-dir", default="reports/market-attack-v4")
    args = parser.parse_args()

    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    rows = read_targets(Path(args.seed), config["daily_limit"], config["priority_limit"], config["minimum_score_for_priority"])
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "generatedAt": datetime.now(RIYADH).isoformat(timespec="seconds"),
        "dailyLimit": config["daily_limit"],
        "priorityLimit": config["priority_limit"],
        "targets": rows,
    }
    json_path = out_dir / "daily_attack.json"
    csv_path = out_dir / "daily_attack.csv"
    md_path = out_dir / "daily_attack.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_csv(rows, csv_path)
    write_md(rows, md_path)
    print(json.dumps({"json": str(json_path), "csv": str(csv_path), "markdown": str(md_path), "targets": len(rows), "priority": sum(1 for row in rows if row["priority"])}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
