#!/usr/bin/env python3
"""Integrity gate for Dealix Market Domination Pack V4."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

REQUIRED = [
    "src/pages/founder/CommandRoomPage.tsx",
    "src/data/dealixCommandCenter.ts",
    "src/data/generated/commandCenterSnapshot.ts",
    "src/App.tsx",
    "src/components/Sidebar.tsx",
    "os/config/command_center_v4.json",
    "os/config/market_attack_v4.json",
    "os/config/ai_system_factory_v4.json",
    "os/config/revenue_board_v4.json",
    "os/config/founder_daily_cadence_v4.yml",
    "os/examples/target_accounts_seed_v4.csv",
    "os/schemas/command-center-snapshot.schema.json",
    "scripts/dealix_command_center_export.py",
    "scripts/dealix_market_attack_daily_v4.py",
    "tests/os/test_dealix_v4_command_center.py",
    "docs/DEALIX_V4_COMMAND_CENTER_AR.md",
    "docs/MERGE_COMMANDS_CODESPACES_V4_AR.md",
]

MUST_CONTAIN = {
    "src/App.tsx": ["CommandRoomPage", "/app/founder/command-room"],
    "src/components/Sidebar.tsx": ["Command Room", "v4.0 Command OS"],
    "src/pages/founder/CommandRoomPage.tsx": ["Revenue War Board", "Priority Accounts", "System Controls"],
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()

    missing = [path for path in REQUIRED if not Path(path).exists()]
    content_failures: list[str] = []
    for file_name, needles in MUST_CONTAIN.items():
        path = Path(file_name)
        if not path.exists():
            continue
        content = path.read_text(encoding="utf-8")
        for needle in needles:
            if needle not in content:
                content_failures.append(f"{file_name} missing {needle}")
    total_checks = len(REQUIRED) + sum(len(v) for v in MUST_CONTAIN.values())
    failures = len(missing) + len(content_failures)
    score = int((total_checks - failures) / total_checks * 100)
    payload = {
        "pack": "dealix_market_domination_pack_v4",
        "score": score,
        "missing": missing,
        "content_failures": content_failures,
        "recommendation": "merge_ready" if failures == 0 else "fix_missing_or_patch_files",
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if args.strict and failures:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
