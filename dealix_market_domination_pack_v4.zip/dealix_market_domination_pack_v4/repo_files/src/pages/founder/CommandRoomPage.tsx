import { useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Bot,
  ClipboardCheck,
  Copy,
  DollarSign,
  FileCheck2,
  Gauge,
  Radar,
  ShieldCheck,
  Sparkles,
  Target,
  Workflow,
} from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  commandCenterSnapshot,
  commandMetrics,
  dailyMissions,
  deliveryProofBoard,
  offerMotions,
  operatingCadence,
  pipelineStages,
  priorityAccounts,
  systemWidgets,
} from "@/data/dealixCommandCenter";
import { cn } from "@/lib/utils";

type BoardKey = "growth" | "sales" | "delivery" | "governance";

const boardLabels: Record<BoardKey, string> = {
  growth: "Growth Attack",
  sales: "Sales Pipeline",
  delivery: "Delivery Proof",
  governance: "Governance",
};

const boardDescriptions: Record<BoardKey, string> = {
  growth: "من نستهدف اليوم؟ ما الألم؟ وما الرسالة الأولى؟",
  sales: "كيف يتحول الاهتمام إلى audit ثم pilot ثم retainer؟",
  delivery: "ما الإثبات الذي يجعل Dealix تبدو حقيقية لا نظرية؟",
  governance: "ما الذي لا يجب إرساله أو وعد العميل به قبل موافقة بشرية؟",
};

function sar(value: number) {
  return `${Math.round(value / 1000)}K SAR`;
}

function statusClass(status: string) {
  if (status === "green" || status === "done") return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (status === "amber" || status === "doing") return "bg-amber-50 text-amber-700 border-amber-200";
  if (status === "blocked" || status === "red") return "bg-red-50 text-red-700 border-red-200";
  return "bg-slate-50 text-slate-700 border-slate-200";
}

export function CommandRoomPage() {
  const [activeBoard, setActiveBoard] = useState<BoardKey>("growth");
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);
  const totalPipeline = useMemo(
    () => pipelineStages.reduce((sum, item) => sum + item.valueSar, 0),
    []
  );
  const chartData = useMemo(
    () => pipelineStages.map((item) => ({ stage: item.stage, value: Math.round(item.valueSar / 1000), count: item.count })),
    []
  );

  const copyCommand = (id: string, command: string) => {
    void navigator.clipboard?.writeText(command).catch(() => undefined);
    setCopiedCommand(id);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-white">
      <div className="border-b border-white/10 bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.22),transparent_35%),linear-gradient(135deg,#020617,#0f172a_55%,#111827)]">
        <div className="px-6 py-6 lg:px-8">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-200">
                <Radar className="h-3.5 w-3.5" /> Dealix Founder Command Room V4
              </div>
              <h1 className="text-3xl font-black tracking-tight lg:text-5xl">غرفة قيادة حقيقية لكل شيء يخص Dealix</h1>
              <p className="mt-3 max-w-3xl text-sm leading-7 text-slate-300 lg:text-base">
                مركز واحد يربط الاستهداف اليومي، المبيعات، العروض، التسليم، إثبات القيمة، المخاطر، والقرارات التنفيذية.
                الهدف: لا يوم يمر بدون target، رسالة، proof، وnext action قابل للقياس.
              </p>
            </div>
            <Card className="border-white/10 bg-white/10 text-white shadow-2xl backdrop-blur lg:w-[360px]">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Gauge className="h-4 w-4 text-emerald-300" /> Snapshot اليوم
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-slate-200">
                <div className="flex items-center justify-between">
                  <span>وضع المؤسس</span>
                  <span className="font-bold text-emerald-200">{commandCenterSnapshot.founderMode}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>هدف Revenue</span>
                  <span className="font-bold">{sar(commandCenterSnapshot.revenueTargetSar)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>هدف Cash</span>
                  <span className="font-bold">{sar(commandCenterSnapshot.cashTargetSar)}</span>
                </div>
                <div className="rounded-xl border border-white/10 bg-black/20 p-3 text-xs leading-6 text-slate-300">
                  آخر تحديث: {commandCenterSnapshot.generatedAt}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <main className="space-y-6 px-6 py-6 lg:px-8">
        <section className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {commandMetrics.map((metric) => (
            <Card key={metric.label} className="border-white/10 bg-white text-slate-950 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-slate-500">{metric.label}</p>
                    <p className="mt-2 text-3xl font-black">{metric.value}</p>
                  </div>
                  <div className="rounded-2xl bg-emerald-50 p-3 text-emerald-700">
                    <Activity className="h-5 w-5" />
                  </div>
                </div>
                <p className="mt-2 text-xs font-bold text-emerald-700">{metric.delta}</p>
                <p className="mt-3 text-xs leading-6 text-slate-500">{metric.meaning}</p>
              </CardContent>
            </Card>
          ))}
        </section>

        <section className="grid grid-cols-1 gap-6 xl:grid-cols-[1.35fr_0.65fr]">
          <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
            <CardHeader className="flex flex-col gap-4 border-b border-slate-100 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <DollarSign className="h-5 w-5 text-emerald-600" /> Revenue War Board
                </CardTitle>
                <p className="mt-1 text-sm text-slate-500">Pipeline إجمالي: {sar(totalPipeline)} عبر مراحل واضحة.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {(Object.keys(boardLabels) as BoardKey[]).map((key) => (
                  <button
                    key={key}
                    onClick={() => setActiveBoard(key)}
                    className={cn(
                      "rounded-full border px-3 py-1.5 text-xs font-bold transition",
                      activeBoard === key
                        ? "border-emerald-600 bg-emerald-600 text-white"
                        : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300"
                    )}
                  >
                    {boardLabels[key]}
                  </button>
                ))}
              </div>
            </CardHeader>
            <CardContent className="grid gap-6 p-5 lg:grid-cols-[0.9fr_1.1fr]">
              <div className="h-[280px] rounded-2xl border border-slate-100 bg-slate-50 p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} layout="vertical" margin={{ left: 20, right: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" unit="K" />
                    <YAxis dataKey="stage" type="category" width={110} />
                    <Tooltip formatter={(value) => [`${value}K SAR`, "Pipeline"]} />
                    <Bar dataKey="value" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-3">
                <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4">
                  <p className="text-xs font-bold text-emerald-700">{boardLabels[activeBoard]}</p>
                  <p className="mt-2 text-sm leading-7 text-slate-700">{boardDescriptions[activeBoard]}</p>
                </div>
                {pipelineStages.map((stage) => (
                  <div key={stage.stage} className="rounded-2xl border border-slate-100 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-bold text-slate-900">{stage.stage}</p>
                        <p className="text-xs text-slate-500">Owner: {stage.owner} · {stage.count} فرصة</p>
                      </div>
                      <span className="rounded-full bg-slate-900 px-3 py-1 text-xs font-bold text-white">{sar(stage.valueSar)}</span>
                    </div>
                    <p className="mt-3 text-sm leading-6 text-slate-600">{stage.nextAction}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Target className="h-5 w-5 text-emerald-600" /> مهام اليوم
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 p-5">
              {dailyMissions.map((mission) => (
                <div key={mission.id} className="rounded-2xl border border-slate-100 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <p className="font-bold leading-6 text-slate-900">{mission.title}</p>
                    <span className={cn("rounded-full border px-2.5 py-1 text-[11px] font-bold", statusClass(mission.status))}>
                      {mission.status}
                    </span>
                  </div>
                  <p className="mt-2 text-xs text-slate-500">{mission.owner} · {mission.due}</p>
                  <p className="mt-2 text-sm leading-6 text-slate-600">{mission.impact}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </section>

        <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Sparkles className="h-5 w-5 text-emerald-600" /> Priority Accounts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 p-5">
              {priorityAccounts.map((account) => (
                <div key={account.id} className="rounded-2xl border border-slate-100 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-black text-slate-900">{account.name}</p>
                      <p className="mt-1 text-xs font-bold text-emerald-700">{account.sector} · Score {account.score}</p>
                    </div>
                    <ArrowUpRight className="h-5 w-5 text-slate-400" />
                  </div>
                  <p className="mt-3 text-sm leading-6 text-slate-600">{account.pain}</p>
                  <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm leading-7 text-slate-700">{account.firstMessage}</div>
                  <div className="mt-3 grid gap-2 text-xs text-slate-500 sm:grid-cols-2">
                    <span>العرض: <b>{account.offer}</b></span>
                    <span>القناة: <b>{account.channel}</b></span>
                    <span className="sm:col-span-2">التالي: <b>{account.nextAction}</b></span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Workflow className="h-5 w-5 text-emerald-600" /> Offer Motions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 p-5">
                {offerMotions.map((offer) => (
                  <div key={offer.name} className="rounded-2xl border border-slate-100 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <p className="font-black text-slate-900">{offer.name}</p>
                      <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">{offer.entryPrice}</span>
                    </div>
                    <p className="mt-2 text-sm leading-6 text-slate-600">Upgrade: {offer.upgradePath}</p>
                    <p className="mt-2 text-xs leading-6 text-slate-500">Proof: {offer.proofMetric}</p>
                    <p className="mt-2 text-xs leading-6 text-slate-500">Buyer: {offer.bestBuyer}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <ShieldCheck className="h-5 w-5 text-emerald-600" /> System Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 p-5">
                {systemWidgets.map((widget) => (
                  <div key={widget.name} className="rounded-2xl border border-slate-100 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-bold text-slate-900">{widget.name}</p>
                        <p className="mt-1 text-xs leading-5 text-slate-500">{widget.description}</p>
                      </div>
                      <span className={cn("rounded-full border px-2.5 py-1 text-[11px] font-bold", statusClass(widget.status))}>
                        {widget.status}
                      </span>
                    </div>
                    <button
                      onClick={() => copyCommand(widget.name, widget.command)}
                      className="mt-3 flex w-full items-center justify-between rounded-xl bg-slate-950 px-3 py-2 text-left text-xs font-mono text-slate-100 transition hover:bg-slate-800"
                    >
                      <span dir="ltr" className="truncate">{widget.command}</span>
                      <Copy className="h-3.5 w-3.5 shrink-0" />
                    </button>
                    {copiedCommand === widget.name && <p className="mt-2 text-xs font-bold text-emerald-700">تم نسخ الأمر.</p>}
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="flex items-center gap-2 text-lg">
                <FileCheck2 className="h-5 w-5 text-emerald-600" /> Delivery Proof Board
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 p-5">
              {deliveryProofBoard.map((proof) => (
                <div key={`${proof.client}-${proof.workflow}`} className="rounded-2xl border border-slate-100 p-4">
                  <p className="font-black text-slate-900">{proof.client}</p>
                  <p className="mt-1 text-sm font-bold text-emerald-700">{proof.workflow}</p>
                  <div className="mt-3 grid gap-3 text-sm leading-6 text-slate-600 sm:grid-cols-2">
                    <p><b>Baseline:</b> {proof.baseline}</p>
                    <p><b>Target:</b> {proof.target}</p>
                    <p><b>Evidence:</b> {proof.evidence}</p>
                    <p><b>Risk:</b> {proof.risk}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-white/10 bg-white text-slate-950 shadow-sm">
            <CardHeader className="border-b border-slate-100">
              <CardTitle className="flex items-center gap-2 text-lg">
                <ClipboardCheck className="h-5 w-5 text-emerald-600" /> Founder Cadence
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 p-5">
              {operatingCadence.map((item) => (
                <div key={item} className="rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3 text-sm font-semibold leading-6 text-slate-700">
                  {item}
                </div>
              ))}
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-7 text-amber-800">
                <div className="mb-1 flex items-center gap-2 font-black">
                  <AlertTriangle className="h-4 w-4" /> قاعدة تنفيذ لا تنكسر
                </div>
                لا يوجد إطلاق حملة، وعد ROI، أو استخدام بيانات عميل إلا بعد review واضح وملف proof أو scope مكتوب.
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
