import { Routes, Route, Navigate } from "react-router";
import { TRPCProvider } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Sidebar } from "@/components/Sidebar";
import DealixPublicSite from "@/pages/public/DealixPublicSite";
import ServicesPage from "@/pages/public/ServicesPage";
import SectorsPage from "@/pages/public/SectorsPage";
import MethodPage from "@/pages/public/MethodPage";
import PricingPage from "@/pages/public/PricingPage";
import ResourcesPage from "@/pages/public/ResourcesPage";
import ContactPage from "@/pages/public/ContactPage";
import AuditPage from "@/pages/public/AuditPage";
import CommandCenterPage from "@/pages/public/CommandCenterPage";
import CaseStudiesPage from "@/pages/public/CaseStudiesPage";
import MarketPage from "@/pages/public/MarketPage";
import { Dashboard } from "@/pages/Dashboard";
import { CompaniesPage } from "@/pages/CompaniesPage";
import { OpportunitiesPage } from "@/pages/OpportunitiesPage";
import { ProjectsPage } from "@/pages/ProjectsPage";
import { DossiersPage } from "@/pages/DossiersPage";
import { ApprovalsPage } from "@/pages/ApprovalsPage";
import { GrowthPage } from "@/pages/founder/GrowthPage";
import { SalesPage } from "@/pages/founder/SalesPage";
import { DeliveryPage } from "@/pages/founder/DeliveryPage";
import { FinancePage } from "@/pages/founder/FinancePage";
import { CommandRoomPage } from "@/pages/founder/CommandRoomPage";
import { SettingsPage } from "@/pages/SettingsPage";
import Login from "@/pages/Login";
import NotFound from "@/pages/NotFound";

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950">
      <Sidebar />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-emerald-600" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <AppLayout>{children}</AppLayout>;
}

function App() {
  return (
    <TRPCProvider>
      <Routes>
        <Route path="/" element={<DealixPublicSite />} />
        <Route path="/ar" element={<DealixPublicSite />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/sectors" element={<SectorsPage />} />
        <Route path="/method" element={<MethodPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route path="/resources" element={<ResourcesPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/audit" element={<AuditPage />} />
        <Route path="/command-center" element={<CommandCenterPage />} />
        <Route path="/case-studies" element={<CaseStudiesPage />} />
        <Route path="/market" element={<MarketPage />} />
        <Route path="/login" element={<Login />} />

        <Route path="/app" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/app/companies" element={<ProtectedRoute><CompaniesPage /></ProtectedRoute>} />
        <Route path="/app/opportunities" element={<ProtectedRoute><OpportunitiesPage /></ProtectedRoute>} />
        <Route path="/app/projects" element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
        <Route path="/app/dossiers" element={<ProtectedRoute><DossiersPage /></ProtectedRoute>} />
        <Route path="/app/approvals" element={<ProtectedRoute><ApprovalsPage /></ProtectedRoute>} />
        <Route path="/app/founder/command-room" element={<ProtectedRoute><CommandRoomPage /></ProtectedRoute>} />
        <Route path="/app/founder/growth" element={<ProtectedRoute><GrowthPage /></ProtectedRoute>} />
        <Route path="/app/founder/sales" element={<ProtectedRoute><SalesPage /></ProtectedRoute>} />
        <Route path="/app/founder/delivery" element={<ProtectedRoute><DeliveryPage /></ProtectedRoute>} />
        <Route path="/app/founder/finance" element={<ProtectedRoute><FinancePage /></ProtectedRoute>} />
        <Route path="/app/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />

        <Route path="/companies" element={<Navigate to="/app/companies" replace />} />
        <Route path="/opportunities" element={<Navigate to="/app/opportunities" replace />} />
        <Route path="/projects" element={<Navigate to="/app/projects" replace />} />
        <Route path="/dossiers" element={<Navigate to="/app/dossiers" replace />} />
        <Route path="/approvals" element={<Navigate to="/app/approvals" replace />} />
        <Route path="/founder/command-room" element={<Navigate to="/app/founder/command-room" replace />} />
        <Route path="/founder/growth" element={<Navigate to="/app/founder/growth" replace />} />
        <Route path="/founder/sales" element={<Navigate to="/app/founder/sales" replace />} />
        <Route path="/founder/delivery" element={<Navigate to="/app/founder/delivery" replace />} />
        <Route path="/founder/finance" element={<Navigate to="/app/founder/finance" replace />} />
        <Route path="/settings" element={<Navigate to="/app/settings" replace />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </TRPCProvider>
  );
}

export default App;
