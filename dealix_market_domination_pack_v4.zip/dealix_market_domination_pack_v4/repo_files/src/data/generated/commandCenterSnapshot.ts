export const generatedCommandCenterSnapshot = {
  generatedAt: "2026-06-12T09:00:00+03:00",
  commandDate: "2026-06-12",
  founderMode: "Market Attack + Proof Delivery",
  revenueTargetSar: 450000,
  cashTargetSar: 90000,
  weeklyFocus: [
    "إغلاق أول 3 AI Workflow Audits مدفوعة",
    "تحويل أفضل audit إلى 30-Day Pilot",
    "بناء إثبات قيمة قابل للنشر بدون كشف بيانات العميل",
    "تشغيل outbound يومي موجه لآلام واضحة وليس رسائل عامة"
  ],
  todayNumbers: {
    targetAccounts: 18,
    priorityAccounts: 7,
    messagesReady: 18,
    auditsProposed: 4,
    callsToBook: 3,
    proposalsDue: 2,
    deliveryProofDue: 1,
    riskItems: 2
  },
  conversionModel: {
    dailyMessages: 18,
    positiveReplyRatePct: 11,
    callBookingRatePct: 45,
    auditCloseRatePct: 35,
    pilotUpgradeRatePct: 40,
    expectedDailyPipelineSar: 57000
  },
  commandAlerts: [
    {
      id: "alert-whatsapp-governance",
      severity: "high",
      title: "لا ترسل دفعات كبيرة بدون review",
      action: "استخدم approval gate قبل أي campaign فوق 20 رسالة واحفظ سبب الاستهداف."
    },
    {
      id: "alert-proof-gap",
      severity: "medium",
      title: "كل عرض لازم يرتبط بألم قابل للقياس",
      action: "ارفض أي proposal لا يحدد baseline وmetric وowner و30-day proof."
    }
  ]
} as const;
