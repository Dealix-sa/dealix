import { generatedCommandCenterSnapshot } from "@/data/generated/commandCenterSnapshot";

export type CommandSeverity = "low" | "medium" | "high" | "critical";

export type CommandMetric = {
  label: string;
  value: string;
  delta: string;
  meaning: string;
};

export type PipelineStage = {
  stage: string;
  count: number;
  valueSar: number;
  owner: string;
  nextAction: string;
};

export type PriorityAccount = {
  id: string;
  name: string;
  sector: string;
  pain: string;
  score: number;
  offer: string;
  channel: string;
  firstMessage: string;
  nextAction: string;
};

export type CommandMission = {
  id: string;
  title: string;
  owner: string;
  due: string;
  impact: string;
  status: "ready" | "doing" | "blocked" | "done";
};

export type OfferMotion = {
  name: string;
  entryPrice: string;
  upgradePath: string;
  proofMetric: string;
  bestBuyer: string;
};

export type DeliveryProof = {
  client: string;
  workflow: string;
  baseline: string;
  target: string;
  evidence: string;
  risk: string;
};

export type SystemWidget = {
  name: string;
  status: "green" | "amber" | "red";
  description: string;
  command: string;
};

export const commandCenterSnapshot = generatedCommandCenterSnapshot;

export const commandMetrics: CommandMetric[] = [
  {
    label: "Pipeline اليوم",
    value: "450K SAR",
    delta: "+57K متوقع",
    meaning: "القيمة التي يجب تحريكها اليوم عبر رسائل، مكالمات، ومقترحات واضحة.",
  },
  {
    label: "Priority Accounts",
    value: "7",
    delta: "من 18 target",
    meaning: "شركات عندها ألم واضح ومؤشر شراء أقوى من مجرد sector عام.",
  },
  {
    label: "Proof Assets",
    value: "4",
    delta: "+1 مطلوب اليوم",
    meaning: "تقارير أو demo أو before/after تساعد البيع بدون وعود فضفاضة.",
  },
  {
    label: "Execution Risk",
    value: "2",
    delta: "تحتاج قرار",
    meaning: "مخاطر في الحوكمة أو الإثبات أو الرسائل يجب حلها قبل التوسع.",
  },
];

export const pipelineStages: PipelineStage[] = [
  {
    stage: "Targeted",
    count: 18,
    valueSar: 180000,
    owner: "Founder",
    nextAction: "اختيار 7 حسابات فقط للأولوية بدل إرسال عشوائي.",
  },
  {
    stage: "Conversation",
    count: 6,
    valueSar: 120000,
    owner: "Sales OS",
    nextAction: "إرسال سؤال تشخيصي واحد لكل حساب بدل pitch طويل.",
  },
  {
    stage: "Audit Proposed",
    count: 4,
    valueSar: 60000,
    owner: "Founder",
    nextAction: "إغلاق audit مدفوع مع نطاق واضح وموعد تسليم.",
  },
  {
    stage: "Pilot Negotiation",
    count: 2,
    valueSar: 90000,
    owner: "Delivery",
    nextAction: "ربط كل pilot بمؤشر قبل/بعد وapproval gate.",
  },
];

export const priorityAccounts: PriorityAccount[] = [
  {
    id: "acct-agency-01",
    name: "وكالة تسويق متوسطة - الرياض",
    sector: "Marketing Agency",
    pain: "تقارير العملاء والعروض والمتابعة تضيع بين واتساب وجداول يدوية.",
    score: 91,
    offer: "Agency Revenue OS Pilot",
    channel: "LinkedIn + WhatsApp after consent",
    firstMessage:
      "لاحظت أن وكالات كثيرة تخسر وقت كبير في تقارير العملاء والمتابعة. أقدر أعطيك audit مختصر يطلع أول workflow يستحق الأتمتة خلال أسبوع؟",
    nextAction: "جهز demo لتقرير عميل قبل/بعد.",
  },
  {
    id: "acct-training-01",
    name: "مركز تدريب مهني - جدة",
    sector: "Training Center",
    pain: "استفسارات الدورات لا تتحول لمسار متابعة واضح حتى التسجيل والدفع.",
    score: 88,
    offer: "Training Sales OS Pilot",
    channel: "Email + Call",
    firstMessage:
      "واضح أن مراكز التدريب تكسب كثير لما يتحول كل استفسار إلى مسار متابعة مضبوط. ممكن أرسل لك نموذج pipeline لدورة واحدة؟",
    nextAction: "ابن one-page pilot لدورة واحدة عالية الهامش.",
  },
  {
    id: "acct-fm-01",
    name: "شركة صيانة وتشغيل - الشرقية",
    sector: "Facilities Management",
    pain: "بلاغات الصيانة والتصعيدات والتقارير لا تظهر للإدارة في وقتها.",
    score: 86,
    offer: "Maintenance Command Center",
    channel: "Referral + Executive Email",
    firstMessage:
      "أغلب شركات التشغيل عندها بلاغات كثيرة لكن visibility ضعيفة للإدارة. Dealix يقدر يبدأ بلوحة بلاغات وتصعيد 30 يوم بدون تغيير نظامكم الحالي.",
    nextAction: "اعمل blueprint لبلاغ واحد من intake إلى closure.",
  },
  {
    id: "acct-clinic-01",
    name: "عيادة متعددة التخصصات - الرياض",
    sector: "Healthcare Ops",
    pain: "المواعيد، no-shows، والمتابعة بعد الزيارة تحتاج تنظيم وحوكمة بيانات.",
    score: 82,
    offer: "Patient Follow-up OS Audit",
    channel: "Warm intro only",
    firstMessage:
      "أقدر أساعدكم في audit تشغيلي لمسار المواعيد والمتابعة مع مراعاة الخصوصية، ونطلع workflow واحد قابل للقياس خلال 30 يوم.",
    nextAction: "راجع data handling policy قبل التواصل.",
  },
];

export const dailyMissions: CommandMission[] = [
  {
    id: "mission-01",
    title: "إرسال 7 رسائل مخصصة لحسابات الأولوية",
    owner: "Founder",
    due: "قبل 11:30 صباحاً",
    impact: "يفتح pipeline يومي بدون انتظار محتوى أو إعلانات.",
    status: "ready",
  },
  {
    id: "mission-02",
    title: "إنتاج proof asset واحد من demo أو workflow",
    owner: "Delivery",
    due: "قبل 3:00 مساءً",
    impact: "يزيد الثقة ويقلل اعتراض: هل هذا حقيقي؟",
    status: "doing",
  },
  {
    id: "mission-03",
    title: "إغلاق scope لأول AI Workflow Audit",
    owner: "Founder",
    due: "نهاية اليوم",
    impact: "يدخل كاش سريع ويصنع مدخل pilot.",
    status: "ready",
  },
  {
    id: "mission-04",
    title: "مراجعة مخاطر الرسائل والخصوصية قبل أي campaign",
    owner: "Governance",
    due: "قبل الإرسال",
    impact: "يحمي الشركة من وعود مبالغ فيها أو تواصل مزعج.",
    status: "ready",
  },
];

export const offerMotions: OfferMotion[] = [
  {
    name: "AI Workflow Audit",
    entryPrice: "5K–15K SAR",
    upgradePath: "30-Day Pilot",
    proofMetric: "وقت مهدور، رسائل ضائعة، تأخير تقارير، أو تسرب leads",
    bestBuyer: "مالك أو مدير عمليات يريد بداية قليلة المخاطرة.",
  },
  {
    name: "30-Day Pilot",
    entryPrice: "25K–60K SAR",
    upgradePath: "Department OS",
    proofMetric: "قبل/بعد في زمن التنفيذ أو جودة المتابعة أو visibility",
    bestBuyer: "قسم لديه ألم واضح ويتحمل تجربة شهر.",
  },
  {
    name: "Command Center OS",
    entryPrice: "200K–500K SAR",
    upgradePath: "AI Ops Retainer",
    proofMetric: "إدارة متعددة القنوات والأقسام مع قرارات أسبوعية قابلة للقياس",
    bestBuyer: "إدارة عليا تحتاج مركز قيادة وليس dashboard فقط.",
  },
];

export const deliveryProofBoard: DeliveryProof[] = [
  {
    client: "Pilot داخلي Dealix",
    workflow: "Target account → custom message → audit proposal",
    baseline: "رسائل عامة بلا scoring موحد",
    target: "18 target يومياً مع 7 priority وmanual review",
    evidence: "reports/command-center + campaign drafts + KPI ledger",
    risk: "يجب منع الإرسال الآلي بدون موافقة بشرية.",
  },
  {
    client: "Demo وكالة تسويق",
    workflow: "Client report generation",
    baseline: "تقرير يدوي يستغرق ساعات ويتأخر",
    target: "تقرير أولي خلال دقائق مع review بشري",
    evidence: "case-study-safe-template + dashboard proof metric",
    risk: "لا تستخدم بيانات عميل حقيقية في demo عام.",
  },
];

export const systemWidgets: SystemWidget[] = [
  {
    name: "Daily Targeting Engine",
    status: "green",
    description: "يولد قائمة accounts ورسائل أولى مبنية على pain واضح.",
    command: "python scripts/dealix_market_attack_daily_v4.py --seed os/examples/target_accounts_seed_v4.csv",
  },
  {
    name: "Command Center Snapshot",
    status: "green",
    description: "يحدث بيانات غرفة القيادة داخل src/data/generated ويصدر brief يومي.",
    command: "python scripts/dealix_command_center_export.py --write-ts",
  },
  {
    name: "Merge Integrity Gate",
    status: "green",
    description: "يتأكد أن ملفات V4 موجودة ومناسبة للدمج قبل push.",
    command: "python scripts/dealix_v4_integrity.py --strict",
  },
  {
    name: "Human Approval Gate",
    status: "amber",
    description: "أي outbound أو claim أو data-heavy workflow يحتاج مراجعة بشرية.",
    command: "python scripts/validate_os_configs.py",
  },
];

export const operatingCadence = [
  "08:30 — Founder brief: ماذا نبيع اليوم؟ لمن؟ ولماذا الآن؟",
  "09:00 — Generate targets: لا أكثر من 20 شركة، الأولوية للجودة.",
  "10:00 — Manual review: احذف أي رسالة عامة أو مبالغ فيها.",
  "11:00 — Outreach: سؤال تشخيصي قصير، لا pitch طويل.",
  "14:00 — Proof build: demo، report، أو before/after asset.",
  "16:00 — Follow-up + proposals: كل فرصة لها next action واضح.",
  "18:00 — KPI ledger: رقم اليوم، العائق، وقرار بكرة.",
];
