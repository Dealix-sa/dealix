import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Building2,
  Target,
  FolderKanban,
  FileText,
  ShieldCheck,
  TrendingUp,
  DollarSign,
  Truck,
  Settings,
  LogOut,
  ChevronRight,
  Bot,
  BarChart3,
  Globe2,
  Radar,
} from "lucide-react";
import { useState } from "react";

const navItems = [
  { path: "/app", label: "Dashboard", icon: LayoutDashboard },
  { path: "/app/companies", label: "Companies", icon: Building2 },
  { path: "/app/opportunities", label: "Opportunities", icon: Target },
  { path: "/app/projects", label: "Projects", icon: FolderKanban },
  { path: "/app/dossiers", label: "Dossiers", icon: FileText },
  { path: "/app/approvals", label: "Approvals", icon: ShieldCheck },
];

const founderItems = [
  { path: "/app/founder/command-room", label: "Command Room", icon: Radar },
  { path: "/app/founder/growth", label: "Growth", icon: TrendingUp },
  { path: "/app/founder/sales", label: "Sales", icon: DollarSign },
  { path: "/app/founder/delivery", label: "Delivery", icon: Truck },
  { path: "/app/founder/finance", label: "Finance", icon: BarChart3 },
];

export function Sidebar() {
  const location = useLocation();
  const { logout } = useAuth();
  const [expanded, setExpanded] = useState(true);

  return (
    <aside
      className={cn(
        "flex flex-col bg-slate-900 text-white transition-all duration-300 border-r border-slate-800",
        expanded ? "w-64" : "w-16"
      )}
    >
      <div className="flex h-16 items-center gap-3 border-b border-slate-800 px-4">
        <Bot className="h-6 w-6 shrink-0 text-emerald-400" />
        {expanded && (
          <div className="flex flex-col">
            <span className="text-sm font-bold tracking-tight">Dealix OS</span>
            <span className="text-[10px] text-slate-400">v4.0 Command OS</span>
          </div>
        )}
        <button onClick={() => setExpanded(!expanded)} className="ml-auto text-slate-400 hover:text-white">
          <ChevronRight className={cn("h-4 w-4 transition-transform", expanded && "rotate-180")} />
        </button>
      </div>

      <nav className="flex-1 space-y-1 px-2 py-4">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                isActive ? "bg-emerald-600 text-white" : "text-slate-300 hover:bg-slate-800 hover:text-white"
              )}
              title={!expanded ? item.label : undefined}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {expanded && <span>{item.label}</span>}
            </Link>
          );
        })}

        {expanded && (
          <div className="pb-2 pt-4">
            <p className="px-3 text-[10px] font-semibold uppercase tracking-wider text-slate-500">Founder</p>
          </div>
        )}
        {!expanded && <div className="h-4" />}

        {founderItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                isActive ? "bg-emerald-600 text-white" : "text-slate-300 hover:bg-slate-800 hover:text-white"
              )}
              title={!expanded ? item.label : undefined}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {expanded && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="space-y-1 border-t border-slate-800 px-2 py-4">
        <Link
          to="/"
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-300 transition-colors hover:bg-slate-800 hover:text-white"
          title={!expanded ? "Public Site" : undefined}
        >
          <Globe2 className="h-4 w-4 shrink-0" />
          {expanded && <span>Public Site</span>}
        </Link>
        <Link
          to="/app/settings"
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
            location.pathname === "/app/settings" ? "bg-emerald-600 text-white" : "text-slate-300 hover:bg-slate-800 hover:text-white"
          )}
          title={!expanded ? "Settings" : undefined}
        >
          <Settings className="h-4 w-4 shrink-0" />
          {expanded && <span>Settings</span>}
        </Link>
        <button
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-white"
          title={!expanded ? "Logout" : undefined}
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {expanded && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}
