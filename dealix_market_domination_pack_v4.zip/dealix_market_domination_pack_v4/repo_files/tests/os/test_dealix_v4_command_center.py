import json
import subprocess
import sys
from pathlib import Path


def test_v4_integrity_gate_passes():
    result = subprocess.run(
        [sys.executable, "scripts/dealix_v4_integrity.py", "--strict"],
        text=True,
        capture_output=True,
        check=True,
    )
    payload = json.loads(result.stdout)
    assert payload["score"] == 100
    assert payload["recommendation"] == "merge_ready"


def test_command_center_export_outputs_snapshot_and_ts(tmp_path: Path):
    out_dir = tmp_path / "command-center"
    ts_out = tmp_path / "commandCenterSnapshot.ts"
    result = subprocess.run(
        [
            sys.executable,
            "scripts/dealix_command_center_export.py",
            "--out-dir",
            str(out_dir),
            "--write-ts",
            "--ts-out",
            str(ts_out),
        ],
        text=True,
        capture_output=True,
        check=True,
    )
    payload = json.loads(result.stdout)
    assert Path(payload["snapshot"]).exists()
    assert Path(payload["brief"]).exists()
    assert ts_out.exists()
    snapshot = json.loads(Path(payload["snapshot"]).read_text(encoding="utf-8"))
    assert snapshot["todayNumbers"]["targetAccounts"] if "targetAccounts" in snapshot["todayNumbers"] else snapshot["todayNumbers"]["target_accounts"] >= 0
    assert snapshot["conversionModel"]["expectedDailyPipelineSar"] > 0


def test_market_attack_v4_generates_priority_targets(tmp_path: Path):
    out_dir = tmp_path / "market-attack"
    result = subprocess.run(
        [
            sys.executable,
            "scripts/dealix_market_attack_daily_v4.py",
            "--seed",
            "os/examples/target_accounts_seed_v4.csv",
            "--out-dir",
            str(out_dir),
        ],
        text=True,
        capture_output=True,
        check=True,
    )
    payload = json.loads(result.stdout)
    assert payload["targets"] >= 5
    assert payload["priority"] >= 3
    data = json.loads(Path(payload["json"]).read_text(encoding="utf-8"))
    assert all(target["manual_review_required"] is True for target in data["targets"])
    assert all("Dealix" in target["first_message"] for target in data["targets"])
