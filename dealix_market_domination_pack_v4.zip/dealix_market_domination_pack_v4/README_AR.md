# Dealix Market Domination Pack V4 — Founder Command Center

هذه حزمة دمج جاهزة فوق V3 تضيف غرفة قيادة داخلية حقيقية:

- `/app/founder/command-room`
- بيانات تشغيل في `src/data/dealixCommandCenter.ts`
- snapshot قابل للتحديث في `src/data/generated/commandCenterSnapshot.ts`
- scripts يومية للـ Command Center والـ Market Attack
- configs للـ Revenue Board وAI System Factory والحوكمة
- اختبارات وGitHub Action للدمج الآمن

## أوامر الدمج

```bash
git switch -c feat/dealix-command-center-v4
rsync -av /workspaces/dealix_market_domination_pack_v4/repo_files/ ./
python scripts/dealix_v4_integrity.py --strict
python scripts/dealix_command_center_export.py --write-ts
python scripts/dealix_market_attack_daily_v4.py --seed os/examples/target_accounts_seed_v4.csv
pytest tests/os/test_dealix_v4_command_center.py -q
npm ci
npm run check
npm run build
git add .
git commit -m "feat: add Dealix founder command center v4"
git push -u origin feat/dealix-command-center-v4
```

## عدد الملفات داخل الحزمة

24 ملف.
