# Dealix Kimi Clean Merge Payload

هذه نسخة منظّفة من تسليم Kimi تحتوي فقط على طبقة الدمج المطلوبة، بدون `__pycache__` وبدون أرشيفات داخلية ضخمة.

## الاستخدام داخل الريبو

```bash
unzip -q dealix_kimi_clean_merge_pack.zip -d /tmp/kimi_merge
cd /workspaces/dealix
bash /tmp/kimi_merge/dealix_kimi_clean_merge_payload/merge_kimi_delivery.sh /tmp/kimi_merge/dealix_kimi_clean_merge_payload
```

بعدها راجع:

```bash
git diff --stat
git diff -- .env.example Makefile
```

ثم commit وPR.
