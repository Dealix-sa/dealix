# Outbound Go-Live Runbook

## Pre-Flight Checklist

- [ ] OUTBOUND_MODE=controlled_live
- [ ] EXTERNAL_SEND_ENABLED=true
- [ ] EMAIL_SEND_ENABLED=true (if using email)
- [ ] EMAIL_PROVIDER configured (smtp/sendgrid/postmark)
- [ ] SMTP credentials set (via env, NOT in repo)
- [ ] WHATSAPP_SEND_ENABLED=true (if using WhatsApp)
- [ ] WHATSAPP_ALLOW_LIVE_SEND=true
- [ ] WHATSAPP_PROVIDER configured (meta_cloud)
- [ ] Templates approved by Meta
- [ ] Opt-in lists verified
- [ ] SMS_SEND_ENABLED=true (if using SMS)
- [ ] SMS opt-in lists verified
- [ ] Suppression list loaded
- [ ] Rate limits configured
- [ ] Approval workflow tested
- [ ] Founder trained on approval process

## Go-Live Steps

1. Run `make production-check`
2. Run `make outbound-env`
3. Run `make outbound-queue`
4. Review approval queue
5. Approve first small batch (5-10)
6. Run `make outbound-dry`
7. Monitor for 24 hours
8. Gradually increase volume

## Emergency Stop

To immediately halt all outbound:

```bash
export EXTERNAL_SEND_ENABLED=false
export OUTBOUND_MODE=disabled
```

Or run: `make production-check` to verify stopped state.

## Escalation

If spam complaints received:
1. Stop all sends immediately
2. Review suppression list
3. Audit recent messages
4. Fix issue before resuming
