# Required Environment Variables

## Critical (Production)

| Variable | Required In | Description |
|----------|-------------|-------------|
| APP_ENV | production | Set to `production` |
| DATABASE_URL | production | PostgreSQL connection string |
| APP_SECRET_KEY | production | Application secret |
| JWT_SECRET_KEY | production | JWT signing secret |

## Outbound

| Variable | Default | Description |
|----------|---------|-------------|
| EXTERNAL_SEND_ENABLED | false | Master send switch |
| OUTBOUND_MODE | draft_only | disabled/draft_only/approval_queue/controlled_live |
| OUTBOUND_REQUIRE_APPROVAL | true | Require human approval |
| OUTBOUND_REQUIRE_VERIFIED_TARGET | true | Require verified targets |
| OUTBOUND_REQUIRE_SOURCE_URL | true | Require source URL |

## Email

| Variable | Default | Description |
|----------|---------|-------------|
| EMAIL_SEND_ENABLED | false | Enable email sends |
| EMAIL_PROVIDER | smtp | smtp/sendgrid/postmark |
| EMAIL_DAILY_LIMIT | 25 | Max sends per day |
| EMAIL_BATCH_LIMIT | 10 | Max per batch |
| EMAIL_REQUIRE_UNSUBSCRIBE | true | Require unsubscribe link |

## WhatsApp

| Variable | Default | Description |
|----------|---------|-------------|
| WHATSAPP_SEND_ENABLED | false | Enable WhatsApp |
| WHATSAPP_ALLOW_LIVE_SEND | false | Allow live WhatsApp sends |
| WHATSAPP_PROVIDER | meta_cloud | Provider |
| WHATSAPP_REQUIRE_OPT_IN | true | Require opt-in |
| WHATSAPP_REQUIRE_APPROVED_TEMPLATE | true | Require approved template |

## Payment

| Variable | Default | Description |
|----------|---------|-------------|
| MOYASAR_ENABLED | false | Enable Moyasar payments |
| MOYASAR_SECRET_KEY | | Secret key (NEVER in repo) |
| PAYMENT_SUCCESS_URL | | Redirect URL |
| PAYMENT_CANCEL_URL | | Cancel URL |

## ⚠️ NEVER add secrets to this file or the repository
