"""Test that invoice stub has no real secrets."""

from __future__ import annotations

import os

from app.commercial.invoice_stub import InvoiceEngine


def test_invoice_stub_no_secret_in_output(monkeypatch):
    monkeypatch.setenv("MOYASAR_ENABLED", "false")
    engine = InvoiceEngine()
    invoice = engine.create("test_client", amount_sar=5000)
    text = invoice.render_markdown()
    assert "MOYASAR_SECRET_KEY" not in text
    assert "sk_" not in text  # No secret key patterns
    assert "false" in text.lower() or "disabled" in text.lower()


def test_moyasar_not_enabled_by_default():
    assert os.getenv("MOYASAR_ENABLED", "false").lower() == "false"
