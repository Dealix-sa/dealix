"""Test outbound queue schema validation."""

from __future__ import annotations

from app.outbound.schemas import OutboundMessage, OutboundChannel, OutboundStatus


def test_message_defaults_safe():
    msg = OutboundMessage(contact_id="test@example.com", channel=OutboundChannel.EMAIL)
    assert msg.status == OutboundStatus.DRAFT
    assert msg.approval_status == "pending"
    assert msg.opt_in_required is True
    assert msg.suppression_checked is False


def test_blocked_phrases_in_body_raise():
    import pytest
    from pydantic import ValidationError
    with pytest.raises(ValidationError) as exc_info:
        OutboundMessage(
            contact_id="test@example.com",
            channel=OutboundChannel.EMAIL,
            body="We guarantee guaranteed results for you",
        )
    assert "Blocked phrase" in str(exc_info.value)

def test_schema_allows_safe_body():
    msg = OutboundMessage(
        contact_id="test@example.com",
        channel=OutboundChannel.EMAIL,
        body="Hello, we offer AI Operating Systems for companies. Let us know if you'd like to learn more.",
    )
    assert "offer" in msg.body


def test_csv_roundtrip():
    msg = OutboundMessage(
        contact_id="test@example.com",
        channel=OutboundChannel.EMAIL,
        subject="Test",
        body="Hello",
    )
    row = msg.to_csv_row()
    restored = OutboundMessage.from_csv_row(row)
    assert restored.contact_id == msg.contact_id
    assert restored.channel == msg.channel
