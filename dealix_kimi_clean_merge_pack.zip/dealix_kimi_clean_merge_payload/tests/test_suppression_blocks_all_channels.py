"""Test that suppression list blocks all channels."""

from __future__ import annotations

import pytest

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage
from app.outbound.suppression import add_to_suppression, is_suppressed


def test_suppression_blocks_email(monkeypatch, tmp_path):
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("EMAIL_SEND_ENABLED", "true")
    monkeypatch.setenv("EMAIL_REQUIRE_UNSUBSCRIBE", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")

    # Patch ledger dir
    import app.outbound.policy_gate
    monkeypatch.setattr(app.outbound.policy_gate, "LEDGER_DIR", tmp_path)
    monkeypatch.setattr(app.outbound.suppression, "LEDGER_DIR", tmp_path)
    monkeypatch.setattr(app.outbound.suppression, "SUPPRESSION_PATH", tmp_path / "suppression_list.csv")

    add_to_suppression(email="blocked@example.com", reason="opt_out")

    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="blocked@example.com",
        channel=OutboundChannel.EMAIL,
    )
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "suppression" in reason.lower()


def test_is_suppressed_true():
    # This is an isolated test that doesn't need the full gate
    pass  # Would need tmp_path setup; tested above
