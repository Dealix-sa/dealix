"""Test AI safety filter."""

from __future__ import annotations

from app.ai.safety_filter import SafetyFilter


def test_blocks_unsafe_content():
    # This should be safe text
    assert SafetyFilter.is_safe("This is a normal business email draft")


def test_allows_safe_content():
    result = SafetyFilter.filter_output("Hello, this is a professional outreach message")
    assert "[Content filtered]" not in result
