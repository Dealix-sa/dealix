"""Test that WhatsApp requires opt-in."""

from __future__ import annotations

import pytest

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage


def test_whatsapp_without_opt_in_blocked(monkeypatch):
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("WHATSAPP_SEND_ENABLED", "true")
    monkeypatch.setenv("WHATSAPP_ALLOW_LIVE_SEND", "true")
    monkeypatch.setenv("WHATSAPP_REQUIRE_OPT_IN", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="+966500000000",
        channel=OutboundChannel.WHATSAPP,
        template_name="test_template",
        opt_in_status="unknown",
    )
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "opt-in" in reason.lower()


def test_whatsapp_with_opt_in_passes_opt_in_check(monkeypatch):
    monkeypatch.setenv("WHATSAPP_REQUIRE_OPT_IN", "true")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="+966500000000",
        channel=OutboundChannel.WHATSAPP,
        opt_in_status="opted_in",
    )
    # The opt-in check should pass
    allowed, reason = gate._check_whatsapp(msg)
    assert "opt-in" not in reason.lower()
