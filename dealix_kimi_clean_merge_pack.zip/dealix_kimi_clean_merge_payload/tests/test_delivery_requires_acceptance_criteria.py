"""Test delivery requires acceptance criteria."""

from __future__ import annotations

from app.delivery.schemas import ClientDeliveryLog, DeliveryPhase, DeliveryStatus


def test_delivery_log_has_acceptance_criteria():
    log = ClientDeliveryLog(
        client_id="test",
        project_id="test_001",
        phase=DeliveryPhase.UAT,
        acceptance_criteria="Client signs off on all test cases",
    )
    assert log.acceptance_criteria != ""
    assert "sign" in log.acceptance_criteria.lower() or "test" in log.acceptance_criteria.lower()


def test_delivery_requires_proof_by_default():
    log = ClientDeliveryLog(client_id="test", project_id="test_001")
    assert log.proof_required is True
