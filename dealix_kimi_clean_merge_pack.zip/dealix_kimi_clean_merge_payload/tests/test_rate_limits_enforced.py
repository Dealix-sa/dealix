"""Test rate limiting."""

from __future__ import annotations

from app.outbound.rate_limiter import RateLimiter
from app.outbound.schemas import OutboundChannel


def test_rate_limiter_has_defaults():
    limiter = RateLimiter()
    assert limiter.daily_remaining(OutboundChannel.EMAIL) > 0


def test_email_daily_limit_default():
    limiter = RateLimiter()
    assert limiter.daily_remaining(OutboundChannel.EMAIL) == 25


def test_whatsapp_daily_limit_default():
    limiter = RateLimiter()
    assert limiter.daily_remaining(OutboundChannel.WHATSAPP) == 10


def test_batch_limits_exist():
    limiter = RateLimiter()
    assert limiter.batch_limit(OutboundChannel.EMAIL) > 0
