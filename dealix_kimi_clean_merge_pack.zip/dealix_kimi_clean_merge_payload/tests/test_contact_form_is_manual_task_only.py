"""Test that contact forms are manual task only."""

from __future__ import annotations

import pytest

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage


def test_contact_form_auto_send_blocked(monkeypatch):
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("CONTACT_FORM_SEND_ENABLED", "true")
    monkeypatch.setenv("CONTACT_FORM_MODE", "manual_tasks_only")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="form_contact",
        channel=OutboundChannel.CONTACT_FORM,
    )
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "manual_tasks_only" in reason
