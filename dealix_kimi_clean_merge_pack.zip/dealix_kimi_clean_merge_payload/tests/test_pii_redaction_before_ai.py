"""Test PII redaction before AI calls."""

from __future__ import annotations

from app.ai.pii_redactor import PIIRedactor


def test_redacts_email():
    text = "Contact john@example.com for details"
    result = PIIRedactor.redact(text)
    assert "john@example.com" not in result
    assert "[email_REDACTED]" in result


def test_redacts_phone():
    text = "Call +966501234567"
    result = PIIRedactor.redact(text)
    assert "+966501234567" not in result
    assert "[phone_REDACTED]" in result


def test_allows_pii_when_configured():
    text = "Contact john@example.com"
    result = PIIRedactor.redact(text, allow_pii=True)
    assert "john@example.com" in result


def test_detects_pii():
    assert PIIRedactor.has_pii("Email: test@example.com")
    assert not PIIRedactor.has_pii("Just regular text")
