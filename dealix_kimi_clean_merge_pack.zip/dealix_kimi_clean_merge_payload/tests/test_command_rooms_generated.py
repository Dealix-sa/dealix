"""Test that command rooms are generated."""

from __future__ import annotations

from pathlib import Path

REPORTS_DIR = Path(__file__).resolve().parent.parent / "reports"


def test_outbound_reports_dir_exists():
    (REPORTS_DIR / "outbound").mkdir(parents=True, exist_ok=True)
    assert (REPORTS_DIR / "outbound").exists()


def test_delivery_reports_dir_exists():
    (REPORTS_DIR / "delivery").mkdir(parents=True, exist_ok=True)
    assert (REPORTS_DIR / "delivery").exists()
