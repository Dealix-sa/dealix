"""Test that outbound defaults to safe mode."""

from __future__ import annotations

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage, OutboundMode


def test_default_mode_is_draft_only():
    # No env vars set — should default to draft_only
    gate = OutboundPolicyGate()
    assert gate.mode == OutboundMode.DRAFT_ONLY

def test_default_external_send_is_false():
    gate = OutboundPolicyGate()
    assert not gate.external_send

def test_default_blocks_live_send():
    gate = OutboundPolicyGate()
    msg = OutboundMessage(contact_id="test@example.com", channel=OutboundChannel.EMAIL)
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "draft_only" in reason

def test_whatsapp_defaults_to_false():
    import os
    assert os.getenv("WHATSAPP_SEND_ENABLED", "false").lower() == "false"

def test_sms_defaults_to_false():
    import os
    assert os.getenv("SMS_SEND_ENABLED", "false").lower() == "false"
