"""Test proof pack generation."""

from __future__ import annotations

from pathlib import Path

REPORTS_DIR = Path(__file__).resolve().parent.parent / "reports" / "delivery"


def test_proof_pack_script_exists():
    script = Path(__file__).resolve().parent.parent / "scripts" / "delivery" / "generate_proof_pack.py"
    assert script.exists()


def test_proof_report_dir_exists():
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    assert REPORTS_DIR.exists()
