"""Test that call tasks are human-only, no robocalls."""

from __future__ import annotations

from app.outbound.call_tasks import create_task, list_tasks


def test_call_task_creates_human_task():
    task = create_task(contact_id="test_caller", phone="+966500000001")
    assert task["status"] == "pending"
    assert task["contact_id"] == "test_caller"
    # No automated dialer — just a task for a human
    assert "duration_seconds" in task


def test_call_task_requires_human_completion():
    # Call tasks should never auto-complete
    tasks = list_tasks()
    # All tasks should be pending unless explicitly completed
    for t in tasks:
        if t["contact_id"] == "test_caller":
            assert t["status"] in ("pending", "completed")
