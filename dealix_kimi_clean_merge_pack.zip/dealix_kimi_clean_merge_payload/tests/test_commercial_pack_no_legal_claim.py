"""Test that commercial pack has no unauthorized legal claims."""

from __future__ import annotations

from app.commercial.commercial_policy import CommercialPolicy
from app.commercial.proposal_to_contract import ProposalEngine


def test_proposal_has_disclaimer():
    engine = ProposalEngine()
    pack = engine.generate("test_client")
    text = pack.render_markdown()
    assert CommercialPolicy.validate_has_disclaimer(text)


def test_proposal_no_blocked_phrases():
    engine = ProposalEngine()
    pack = engine.generate("test_client")
    text = pack.render_markdown()
    ok, reason = CommercialPolicy.validate_proposal(text)
    assert ok, f"Blocked phrase found: {reason}"


def test_proposal_has_no_guaranteed_roi():
    engine = ProposalEngine()
    pack = engine.generate("test_client")
    text = pack.render_markdown()
    assert "guaranteed roi" not in text.lower()
    assert "guaranteed results" not in text.lower()
