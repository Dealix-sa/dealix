"""Tests for outbound policy gate."""

from __future__ import annotations

import os

import pytest

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage


class TestOutboundPolicyGate:
    def test_disabled_mode_blocks_all(self, monkeypatch):
        monkeypatch.setenv("OUTBOUND_MODE", "disabled")
        gate = OutboundPolicyGate()
        msg = OutboundMessage(contact_id="test@example.com", channel=OutboundChannel.EMAIL)
        allowed, reason = gate.can_send(msg)
        assert not allowed
        assert "disabled" in reason.lower()

    def test_draft_only_blocks_live(self, monkeypatch):
        monkeypatch.setenv("OUTBOUND_MODE", "draft_only")
        monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
        gate = OutboundPolicyGate()
        msg = OutboundMessage(contact_id="test@example.com", channel=OutboundChannel.EMAIL)
        allowed, reason = gate.can_send(msg)
        assert not allowed
        assert "draft_only" in reason

    def test_external_send_false_blocks(self, monkeypatch):
        monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
        monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "false")
        gate = OutboundPolicyGate()
        msg = OutboundMessage(contact_id="test@example.com", channel=OutboundChannel.EMAIL)
        allowed, reason = gate.can_send(msg)
        assert not allowed
        assert "EXTERNAL_SEND_ENABLED" in reason

    def test_unapproved_message_blocked(self, monkeypatch):
        monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
        monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
        monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "true")
        monkeypatch.setenv("EMAIL_SEND_ENABLED", "true")
        monkeypatch.setenv("EMAIL_REQUIRE_UNSUBSCRIBE", "false")
        monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
        monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
        gate = OutboundPolicyGate()
        msg = OutboundMessage(
            contact_id="test@example.com",
            channel=OutboundChannel.EMAIL,
            approval_status="pending",
        )
        allowed, reason = gate.can_send(msg)
        assert not allowed
        assert "not approved" in reason

    def test_blocked_phrases_detected(self, monkeypatch):
        monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
        monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
        monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
        monkeypatch.setenv("EMAIL_SEND_ENABLED", "true")
        monkeypatch.setenv("EMAIL_REQUIRE_UNSUBSCRIBE", "false")
        monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
        monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
        monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "true")
        gate = OutboundPolicyGate()
        # Use a phrase that passes Pydantic validation but hits the policy gate
        msg = OutboundMessage(
            contact_id="test@example.com",
            channel=OutboundChannel.EMAIL,
            body="Risk free investment with no risk at all",
        )
        allowed, reason = gate.can_send(msg)
        assert not allowed
        assert "blocked phrase" in reason.lower()

    def test_draft_allowed_in_draft_only(self, monkeypatch):
        monkeypatch.setenv("OUTBOUND_MODE", "draft_only")
        gate = OutboundPolicyGate()
        msg = OutboundMessage(contact_id="test@example.com", channel=OutboundChannel.EMAIL)
        allowed, reason = gate.can_draft(msg)
        assert allowed
        assert "draft" in reason

    def test_detect_opt_out(self):
        gate = OutboundPolicyGate()
        assert gate.detect_opt_out("Please stop sending me messages")
        assert gate.detect_opt_out("\u0625\u064a\u0642\u0627\u0641")  # إيقاف
        assert not gate.detect_opt_out("I am interested")
