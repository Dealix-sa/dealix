"""Test production environment check script."""

from __future__ import annotations

import sys
from pathlib import Path

# Run the check script in isolation
def test_check_script_exists():
    script = Path(__file__).resolve().parent.parent / "scripts" / "ops" / "check_required_env.py"
    assert script.exists()


def test_outbound_safety_script_exists():
    script = Path(__file__).resolve().parent.parent / "scripts" / "ops" / "check_outbound_safety.py"
    assert script.exists()
