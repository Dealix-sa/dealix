"""Test that SMS requires opt-in."""

from __future__ import annotations

import pytest

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage


def test_sms_without_opt_in_blocked(monkeypatch):
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("SMS_SEND_ENABLED", "true")
    monkeypatch.setenv("SMS_REQUIRE_OPT_IN", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="+966500000000",
        channel=OutboundChannel.SMS,
        opt_in_status="unknown",
    )
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "opt-in" in reason.lower()


def test_sms_disabled_by_default(monkeypatch):
    monkeypatch.setenv("SMS_SEND_ENABLED", "false")
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="+966500000000",
        channel=OutboundChannel.SMS,
    )
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "SMS" in reason
