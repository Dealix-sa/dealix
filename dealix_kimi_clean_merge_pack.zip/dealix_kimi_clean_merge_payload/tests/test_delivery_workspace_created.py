"""Test that delivery workspace is created correctly."""

from __future__ import annotations

from pathlib import Path

from app.delivery.project_workspace import ProjectWorkspace


def test_workspace_creates_files(tmp_path, monkeypatch):
    monkeypatch.setattr("app.delivery.project_workspace.WORKSPACE_ROOT", tmp_path)
    ws = ProjectWorkspace("test_client")
    created = ws.create()
    assert len(created) > 0
    assert ws.exists()
    assert (ws.root / "00_contract" / "scope_summary.md").exists()
    assert (ws.root / "01_onboarding" / "welcome.md").exists()


def test_workspace_has_all_phases(tmp_path, monkeypatch):
    monkeypatch.setattr("app.delivery.project_workspace.WORKSPACE_ROOT", tmp_path)
    ws = ProjectWorkspace("test_client")
    ws.create()
    phases = ["00_contract", "01_onboarding", "02_diagnosis", "03_blueprint",
              "04_build", "05_uat", "06_training", "07_proof", "08_retainer"]
    for phase in phases:
        assert (ws.root / phase).exists(), f"Phase {phase} missing"


def test_scope_summary_has_disclaimer(tmp_path, monkeypatch):
    monkeypatch.setattr("app.delivery.project_workspace.WORKSPACE_ROOT", tmp_path)
    ws = ProjectWorkspace("test_client")
    ws.create()
    content = (ws.root / "00_contract" / "scope_summary.md").read_text()
    assert "not legal advice" in content.lower()
