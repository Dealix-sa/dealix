"""Test that email requires unsubscribe link."""

from __future__ import annotations

import pytest

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import OutboundChannel, OutboundMessage


def test_email_without_unsubscribe_blocked(monkeypatch):
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("EMAIL_SEND_ENABLED", "true")
    monkeypatch.setenv("EMAIL_REQUIRE_UNSUBSCRIBE", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="test@example.com",
        channel=OutboundChannel.EMAIL,
        unsubscribe_link=None,
        unsubscribe_required=False,
    )
    allowed, reason = gate.can_send(msg)
    assert not allowed
    assert "unsubscribe" in reason.lower()


def test_email_with_unsubscribe_allowed(monkeypatch):
    monkeypatch.setenv("OUTBOUND_MODE", "controlled_live")
    monkeypatch.setenv("EXTERNAL_SEND_ENABLED", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_APPROVAL", "false")
    monkeypatch.setenv("EMAIL_SEND_ENABLED", "true")
    monkeypatch.setenv("EMAIL_REQUIRE_UNSUBSCRIBE", "true")
    monkeypatch.setenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "false")
    monkeypatch.setenv("OUTBOUND_REQUIRE_SOURCE_URL", "false")
    monkeypatch.setenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "false")
    gate = OutboundPolicyGate()
    msg = OutboundMessage(
        contact_id="test@example.com",
        channel=OutboundChannel.EMAIL,
        unsubscribe_link="https://dealix.me/unsubscribe",
        unsubscribe_required=True,
    )
    allowed, reason = gate.can_send(msg)
    # Should pass unsubscribe check (may fail on other checks)
    assert "unsubscribe" not in reason.lower()
