"""Test that AI router falls back without API keys."""

from __future__ import annotations

from app.ai.provider_router import AIProviderRouter


def test_fallback_when_no_keys():
    router = AIProviderRouter()
    response = router.complete("Draft an email for outbound")
    assert response.fallback
    assert response.provider == "fallback"
    assert "deterministic" in response.model


def test_fallback_no_pii_sent():
    router = AIProviderRouter()
    response = router.complete("Email for user@example.com")
    assert response.fallback
    # Should not crash even with PII in prompt


def test_is_configured_false_without_keys(monkeypatch):
    # Ensure no provider keys are set
    for provider in AIProviderRouter.PROVIDER_ORDER:
        monkeypatch.delenv(f"{provider.upper()}_API_KEY", raising=False)
    router = AIProviderRouter()
    assert not router.is_configured()
