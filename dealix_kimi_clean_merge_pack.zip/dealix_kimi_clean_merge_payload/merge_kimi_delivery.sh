#!/usr/bin/env bash
set -Eeuo pipefail

SRC="${1:-dealix_kimi_clean_merge_payload}"
if [ ! -d "$SRC" ]; then
  echo "ERROR: payload directory not found: $SRC" >&2
  echo "Usage: bash merge_kimi_delivery.sh /path/to/dealix_kimi_clean_merge_payload" >&2
  exit 2
fi

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "ERROR: run this from the Dealix git repo root" >&2
  exit 2
fi

if [ -n "$(git status --porcelain)" ] && [ "${ALLOW_DIRTY:-false}" != "true" ]; then
  echo "ERROR: working tree is not clean. Commit/stash first, or run with ALLOW_DIRTY=true." >&2
  git status --short
  exit 2
fi

BRANCH="${MERGE_BRANCH:-feat/merge-kimi-full-delivery-outbound}"
CURRENT_BRANCH="$(git branch --show-current || true)"
if [ "$CURRENT_BRANCH" != "$BRANCH" ]; then
  git switch -c "$BRANCH" 2>/dev/null || git switch "$BRANCH"
fi

STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR=".merge_backups/kimi_delivery_$STAMP"
mkdir -p "$BACKUP_DIR"
[ -f Makefile ] && cp Makefile "$BACKUP_DIR/Makefile.before"
[ -f .env.example ] && cp .env.example "$BACKUP_DIR/.env.example.before"

copy_dir() {
  local d="$1"
  if [ -d "$SRC/$d" ]; then
    mkdir -p "$d"
    rsync -a --exclude='__pycache__/' --exclude='*.pyc' "$SRC/$d/" "$d/"
  fi
}

copy_file() {
  local f="$1"
  if [ -f "$SRC/$f" ]; then
    mkdir -p "$(dirname "$f")"
    cp "$SRC/$f" "$f"
  fi
}

# Core systems
copy_file app/__init__.py
copy_dir app/outbound
copy_dir app/channels
copy_dir app/delivery
copy_dir app/commercial
copy_dir app/ai

# Scripts
copy_dir scripts/outbound
copy_dir scripts/channels
copy_dir scripts/delivery
copy_dir scripts/commercial
copy_file scripts/ops/check_required_env.py
copy_file scripts/ops/check_outbound_safety.py

# Docs / ops / reports
copy_dir docs/outbound
copy_dir docs/delivery_full
copy_dir ops/production
copy_dir reports/continuation
copy_dir reports/outbound
copy_dir reports/delivery
copy_dir reports/commercial
copy_dir reports/ops
copy_file PR_DESCRIPTION_FULL_DELIVERY_OUTBOUND.md

# Tests
while IFS= read -r testfile; do
  [ -z "$testfile" ] && continue
  copy_file "$testfile"
done <<'TESTS'
tests/test_outbound_policy_gate.py
tests/test_outbound_queue_schema.py
tests/test_outbound_default_safe.py
tests/test_email_requires_unsubscribe.py
tests/test_whatsapp_requires_opt_in.py
tests/test_suppression_blocks_all_channels.py
tests/test_rate_limits_enforced.py
tests/test_linkedin_is_manual_task_only.py
tests/test_contact_form_is_manual_task_only.py
tests/test_call_tasks_no_robocall.py
tests/test_sms_requires_opt_in.py
tests/test_delivery_workspace_created.py
tests/test_delivery_requires_acceptance_criteria.py
tests/test_proof_pack_generated.py
tests/test_commercial_pack_no_legal_claim.py
tests/test_invoice_stub_no_real_secret.py
tests/test_ai_router_fallback_without_keys.py
tests/test_pii_redaction_before_ai.py
tests/test_prompt_injection_guard_exists.py
tests/test_production_env_check.py
tests/test_command_rooms_generated.py
tests/test_safety_filter.py
TESTS

# Makefile and env example: copy comprehensive version, but backups exist.
copy_file Makefile
copy_file .env.example

# Cleanup accidental Python caches
find app scripts tests -type d -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null || true
find app scripts tests -type f -name '*.pyc' -delete 2>/dev/null || true

# First validation
git diff --check
python -m compileall -q app scripts

TEST_SET=(
  tests/test_outbound_policy_gate.py
  tests/test_outbound_queue_schema.py
  tests/test_outbound_default_safe.py
  tests/test_email_requires_unsubscribe.py
  tests/test_whatsapp_requires_opt_in.py
  tests/test_suppression_blocks_all_channels.py
  tests/test_rate_limits_enforced.py
  tests/test_linkedin_is_manual_task_only.py
  tests/test_contact_form_is_manual_task_only.py
  tests/test_call_tasks_no_robocall.py
  tests/test_sms_requires_opt_in.py
  tests/test_delivery_workspace_created.py
  tests/test_delivery_requires_acceptance_criteria.py
  tests/test_proof_pack_generated.py
  tests/test_commercial_pack_no_legal_claim.py
  tests/test_invoice_stub_no_real_secret.py
  tests/test_ai_router_fallback_without_keys.py
  tests/test_pii_redaction_before_ai.py
  tests/test_prompt_injection_guard_exists.py
  tests/test_production_env_check.py
  tests/test_command_rooms_generated.py
  tests/test_safety_filter.py
)
python -m pytest -q "${TEST_SET[@]}"

make outbound-env
make outbound-queue
make outbound-dry
make channel-day
make production-check
make delivery-onboard CLIENT=sample_client
make delivery-day CLIENT=sample_client
make delivery-report CLIENT=sample_client
make delivery-proof CLIENT=sample_client
make commercial-pack CLIENT=sample_client
make full-revenue-day
make full-client-delivery CLIENT=sample_client

echo ""
echo "MERGE_PAYLOAD_IMPORTED_OK"
echo "Branch: $(git branch --show-current)"
echo "Backup dir: $BACKUP_DIR"
git status --short
git diff --stat
