"""
Dealix Multi-channel Outreach Engine

Generates safe multi-channel sequences:
- Day 0: Email draft + LinkedIn view task + Call task
- Day 3: Email follow-up + LinkedIn follow-up task
- Day 7: Value email / one-pager
- Day 14: Polite close email
- WhatsApp: only if opt-in/existing relationship + approved template
- Contact form: manual task with prepared message
"""

from app.channels.channel_router import ChannelRouter
from app.channels.channel_policy import ChannelPolicy

__all__ = ["ChannelRouter", "ChannelPolicy"]
