"""Channel policy — validates that each channel complies with safety rules."""

from __future__ import annotations

import os

from app.outbound.schemas import OutboundChannel


class ChannelPolicy:
    """Policy enforcement per channel — used by the channel router."""

    @classmethod
    def is_channel_enabled(cls, channel: OutboundChannel) -> bool:
        env_map = {
            OutboundChannel.EMAIL: "EMAIL_SEND_ENABLED",
            OutboundChannel.WHATSAPP: "WHATSAPP_SEND_ENABLED",
            OutboundChannel.LINKEDIN: "LINKEDIN_SEND_ENABLED",
            OutboundChannel.CONTACT_FORM: "CONTACT_FORM_SEND_ENABLED",
            OutboundChannel.CALL: "CALL_TASKS_ENABLED",
            OutboundChannel.SMS: "SMS_SEND_ENABLED",
        }
        env_var = env_map.get(channel, "")
        if not env_var:
            return False
        return os.getenv(env_var, "false").lower() == "true"

    @classmethod
    def channel_mode(cls, channel: OutboundChannel) -> str:
        mode_map = {
            OutboundChannel.LINKEDIN: os.getenv("LINKEDIN_MODE", "manual_tasks_only"),
            OutboundChannel.CONTACT_FORM: os.getenv("CONTACT_FORM_MODE", "manual_tasks_only"),
        }
        return mode_map.get(channel, "automated")

    @classmethod
    def requires_opt_in(cls, channel: OutboundChannel) -> bool:
        return channel in (OutboundChannel.WHATSAPP, OutboundChannel.SMS)

    @classmethod
    def requires_approval(cls, channel: OutboundChannel) -> bool:
        return os.getenv("OUTBOUND_REQUIRE_APPROVAL", "true").lower() == "true"

    @classmethod
    def max_daily(cls, channel: OutboundChannel) -> int:
        limits = {
            OutboundChannel.EMAIL: int(os.getenv("EMAIL_DAILY_LIMIT", "25")),
            OutboundChannel.WHATSAPP: int(os.getenv("WHATSAPP_DAILY_LIMIT", "10")),
            OutboundChannel.SMS: int(os.getenv("SMS_DAILY_LIMIT", "5")),
            OutboundChannel.LINKEDIN: int(os.getenv("LINKEDIN_DAILY_LIMIT", "20")),
            OutboundChannel.CONTACT_FORM: int(os.getenv("CONTACT_FORM_DAILY_LIMIT", "15")),
            OutboundChannel.CALL: int(os.getenv("CALL_DAILY_LIMIT", "30")),
        }
        return limits.get(channel, 10)

    @classmethod
    def can_auto_send(cls, channel: OutboundChannel) -> bool:
        """Returns True if the channel supports automated sending (not manual-only)."""
        if not cls.is_channel_enabled(channel):
            return False
        if cls.channel_mode(channel) == "manual_tasks_only":
            return False
        return True
