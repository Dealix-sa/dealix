"""Channel router — generates multi-channel sequences and dispatches."""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from app.channels.channel_policy import ChannelPolicy
from app.outbound.call_tasks import create_task as create_call_task
from app.outbound.contact_form_tasks import create_task as create_form_task
from app.outbound.linkedin_tasks import create_task as create_linkedin_task
from app.outbound.provider_router import ProviderRouter
from app.outbound.schemas import (
    QUEUE_HEADER,
    OutboundChannel,
    OutboundMessage,
    OutboundMode,
    OutboundStatus,
    append_to_ledger,
    ensure_ledger,
)

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"


class ChannelRouter:
    """Generates multi-day, multi-channel outreach sequences."""

    SEQUENCE_DAYS = [0, 3, 7, 14]

    def __init__(self) -> None:
        self.policy = ChannelPolicy()
        self.provider = ProviderRouter()
        self.mode = OutboundMode(os.getenv("OUTBOUND_MODE", "draft_only"))

    def generate_sequence(
        self,
        contact_id: str,
        company_name: str = "",
        source_url: str = "",
        has_opt_in: bool = False,
        has_phone: bool = False,
    ) -> list[OutboundMessage]:
        """Generate a 14-day multi-channel sequence for a prospect."""
        messages: list[OutboundMessage] = []
        base_date = datetime.now(timezone.utc)

        # Day 0: Email + LinkedIn + Call
        messages.extend(self._day_0(contact_id, company_name, source_url, has_phone, base_date))

        # Day 3: Follow-up email + LinkedIn
        messages.extend(self._day_3(contact_id, company_name, source_url, base_date))

        # Day 7: Value email
        messages.extend(self._day_7(contact_id, company_name, source_url, base_date))

        # Day 14: Polite close
        messages.extend(self._day_14(contact_id, company_name, source_url, base_date))

        # WhatsApp: only if opt-in
        if has_opt_in:
            messages.extend(self._whatsapp_touch(contact_id, company_name, base_date))

        return messages

    def _day_0(
        self,
        contact_id: str,
        company_name: str,
        source_url: str,
        has_phone: bool,
        base_date: datetime,
    ) -> list[OutboundMessage]:
        msgs: list[OutboundMessage] = []
        # Email
        msgs.append(OutboundMessage(
            contact_id=contact_id,
            channel=OutboundChannel.EMAIL,
            subject=f"Introduction — AI Operating Systems for {company_name or 'your company'}",
            body=self._render_email_body("intro", company_name),
            source_url=source_url,
            verification_status="verified" if source_url else "unverified",
            unsubscribe_required=True,
            scheduled_at=base_date,
        ))
        # LinkedIn task
        if self.policy.is_channel_enabled(OutboundChannel.LINKEDIN):
            create_linkedin_task(
                contact_id=contact_id,
                action_type="view_profile",
                message_draft=f"View {company_name} contact profile",
            )
        # Call task
        if has_phone and self.policy.is_channel_enabled(OutboundChannel.CALL):
            create_call_task(
                contact_id=contact_id,
                call_script_path="scripts/call_scripts/intro_discovery.md",
            )
        return msgs

    def _day_3(self, contact_id: str, company_name: str, source_url: str, base_date: datetime) -> list[OutboundMessage]:
        msgs: list[OutboundMessage] = []
        msgs.append(OutboundMessage(
            contact_id=contact_id,
            channel=OutboundChannel.EMAIL,
            subject="Follow-up — AI Operating Systems",
            body=self._render_email_body("follow_up", company_name),
            source_url=source_url,
            unsubscribe_required=True,
            scheduled_at=base_date + timedelta(days=3),
        ))
        if self.policy.is_channel_enabled(OutboundChannel.LINKEDIN):
            create_linkedin_task(
                contact_id=contact_id,
                action_type="follow_up",
                message_draft=f"Follow-up message for {company_name}",
            )
        return msgs

    def _day_7(self, contact_id: str, company_name: str, source_url: str, base_date: datetime) -> list[OutboundMessage]:
        msgs: list[OutboundMessage] = []
        msgs.append(OutboundMessage(
            contact_id=contact_id,
            channel=OutboundChannel.EMAIL,
            subject="Value: How companies reduce operational costs with AI OS",
            body=self._render_email_body("value", company_name),
            source_url=source_url,
            unsubscribe_required=True,
            scheduled_at=base_date + timedelta(days=7),
        ))
        return msgs

    def _day_14(self, contact_id: str, company_name: str, source_url: str, base_date: datetime) -> list[OutboundMessage]:
        msgs: list[OutboundMessage] = []
        msgs.append(OutboundMessage(
            contact_id=contact_id,
            channel=OutboundChannel.EMAIL,
            subject="Polite close — let me know if timing changes",
            body=self._render_email_body("polite_close", company_name),
            source_url=source_url,
            unsubscribe_required=True,
            scheduled_at=base_date + timedelta(days=14),
        ))
        return msgs

    def _whatsapp_touch(self, contact_id: str, company_name: str, base_date: datetime) -> list[OutboundMessage]:
        msgs: list[OutboundMessage] = []
        if not self.policy.is_channel_enabled(OutboundChannel.WHATSAPP):
            return msgs
        msgs.append(OutboundMessage(
            contact_id=contact_id,
            channel=OutboundChannel.WHATSAPP,
            template_name="follow_up_template_v1",
            body=f"Hi, following up on our AI Operating Systems for {company_name}. Let me know if you'd like to explore.",
            opt_in_status="opted_in",
            scheduled_at=base_date + timedelta(days=1),
        ))
        return msgs

    def _render_email_body(self, template_name: str, company_name: str) -> str:
        templates = {
            "intro": f"""Hi there,

I came across {company_name or 'your company'} and wanted to reach out.

We build AI Operating Systems for companies — custom AI infrastructure that automates workflows, reduces operational overhead, and helps teams scale without proportional hiring.

Would you be open to a brief conversation to explore if this fits your current roadmap?

Best regards,
Dealix Team

Unsubscribe: [UNSUBSCRIBE_LINK]
""",
            "follow_up": f"""Hi,

Following up on my previous email about AI Operating Systems for {company_name or 'your company'}.

We recently helped a similar company automate 40% of their operational workflows within 60 days. I'd love to share how if there's interest.

No pressure — just let me know if you'd like to explore.

Best,
Dealix Team

Unsubscribe: [UNSUBSCRIBE_LINK]
""",
            "value": f"""Hi,

I wanted to share a quick case study that might resonate with {company_name or 'your team'}.

A mid-sized Saudi company in the operations sector implemented our AI OS and:
- Reduced manual reporting time by 60%
- Automated customer follow-ups
- Improved team capacity without new hires

Results vary by company size and maturity, but the framework is proven.

Worth a 15-minute conversation?

Best,
Dealix Team

Unsubscribe: [UNSUBSCRIBE_LINK]
""",
            "polite_close": f"""Hi,

I don't want to clutter your inbox. This will be my last email unless you tell me otherwise.

If AI Operating Systems become relevant for {company_name or 'your company'} in the future, feel free to reach out.

Wishing you continued success.

Best,
Dealix Team

Unsubscribe: [UNSUBSCRIBE_LINK]
""",
        }
        return templates.get(template_name, "")

    def submit_for_approval(self, messages: list[OutboundMessage]) -> list[str]:
        """Queue messages for approval. Returns list of message_ids."""
        ids: list[str] = []
        ensure_ledger(QUEUE_PATH, QUEUE_HEADER)
        for msg in messages:
            msg.status = OutboundStatus.PENDING_APPROVAL
            msg.approval_status = "pending"
            append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
            ids.append(msg.message_id)
        return ids

    def run_dry(self, messages: list[OutboundMessage]) -> list[dict]:
        """Run a dry-run of the sequence — no actual sends."""
        results = []
        for msg in messages:
            result = self.provider.draft(msg)
            results.append(result)
        return results
