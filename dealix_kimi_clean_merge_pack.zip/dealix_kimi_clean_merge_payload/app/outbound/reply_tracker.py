"""Reply tracker — classifies incoming replies and triggers next actions."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from app.outbound.schemas import REPLY_HEADER, OutboundChannel, ReplyLog, append_to_ledger, ensure_ledger
from app.outbound.suppression import process_opt_out

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
REPLY_PATH = LEDGER_DIR / "reply_log.csv"


class ReplyTracker:
    """Tracks and classifies replies from contacts across all channels."""

    CLASSIFICATION_KEYWORDS = {
        "interested": ["interested", "tell me more", "pricing", "details", "\u0645\u0647\u062a\u0645"],
        "not_interested": ["not interested", "no thanks", "unsubscribe", "remove", "\u0644\u0627 \u0634\u0643\u0631"],
        "meeting_request": ["meeting", "call", "schedule", "book", "demo", "\u0627\u062c\u062a\u0645\u0627\u0639"],
        "objection": ["too expensive", "not now", "later", "budget", "\u063a\u0627\u0644\u064a"],
        "opt_out": ["stop", "unsubscribe", "cancel", "\u0625\u064a\u0642\u0627\u0641", "\u0627\u0644\u063a\u0627\u0621", "\u0625\u0644\u063a\u0627\u0621"],
    }

    def track_reply(
        self,
        message_id: str,
        company_id: str,
        contact_id: str,
        channel: OutboundChannel,
        reply_text: str,
    ) -> ReplyLog:
        classification = self._classify(reply_text)
        meeting_intent = classification == "meeting_request" or "meeting" in reply_text.lower()
        opt_out_detected = classification == "opt_out" or self._detect_opt_out(reply_text)

        reply = ReplyLog(
            message_id=message_id,
            company_id=company_id,
            contact_id=contact_id,
            channel=channel,
            reply_text=reply_text,
            classification=classification,
            meeting_intent=meeting_intent,
            opt_out_detected=opt_out_detected,
            next_action=self._suggest_next_action(classification),
        )

        ensure_ledger(REPLY_PATH, REPLY_HEADER)
        append_to_ledger(REPLY_PATH, REPLY_HEADER, reply.to_csv_row())

        # Auto-process opt-outs
        if opt_out_detected:
            process_opt_out(reply_text, contact_id, channel.value)

        return reply

    def _classify(self, text: str) -> str:
        lower = text.lower()
        for category, keywords in self.CLASSIFICATION_KEYWORDS.items():
            for kw in keywords:
                if kw.lower() in lower:
                    return category
        return "unclassified"

    def _detect_opt_out(self, text: str) -> bool:
        return process_opt_out(text, "", "")

    def _suggest_next_action(self, classification: str) -> str:
        actions = {
            "interested": "send_proposal_or_book_meeting",
            "not_interested": "polite_close_add_to_nurture",
            "meeting_request": "send_calendly_or_propose_slots",
            "objection": "send_objection_handler",
            "opt_out": "suppress_and_stop",
            "unclassified": "manual_review",
        }
        return actions.get(classification, "manual_review")


def get_replies(contact_id: str = "") -> list[ReplyLog]:
    ensure_ledger(REPLY_PATH, REPLY_HEADER)
    rows = []
    import csv
    with open(REPLY_PATH, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if not contact_id or row.get("contact_id") == contact_id:
                rows.append(ReplyLog(**{k: (v if v != "" else None) for k, v in row.items()}))
    return rows
