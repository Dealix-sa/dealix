"""Suppression list management — opt-out and blocklist."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from app.outbound.schemas import (
    SUPPRESSION_HEADER,
    SuppressionEntry,
    append_to_ledger,
    ensure_ledger,
    read_ledger,
)

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
SUPPRESSION_PATH = LEDGER_DIR / "suppression_list.csv"


def add_to_suppression(
    email: str = "",
    phone: str = "",
    whatsapp_number: str = "",
    reason: str = "opt_out",
    source: str = "manual",
) -> None:
    """Add a contact to the suppression list."""
    entry = SuppressionEntry(
        email=email or None,
        phone=phone or None,
        whatsapp_number=whatsapp_number or None,
        reason=reason,
        source=source,
    )
    append_to_ledger(SUPPRESSION_PATH, SUPPRESSION_HEADER, entry.to_csv_row())


def is_suppressed(contact_id: str) -> bool:
    """Check if a contact identifier (email/phone/whatsapp) is suppressed."""
    if not SUPPRESSION_PATH.exists():
        return False
    for row in read_ledger(SUPPRESSION_PATH):
        if row.get("email") == contact_id or row.get("phone") == contact_id or row.get("whatsapp_number") == contact_id:
            return True
    return False


def list_suppressed() -> list[dict[str, str]]:
    ensure_ledger(SUPPRESSION_PATH, SUPPRESSION_HEADER)
    return read_ledger(SUPPRESSION_PATH)


def process_opt_out(text: str, contact_id: str, channel: str) -> bool:
    """Process an opt-out request. Returns True if opt-out was detected and processed."""
    stop_keywords = [
        "stop", "unsubscribe", "cancel",
        "\u0625\u064a\u0642\u0627\u0641",  # إيقاف
        "\u0627\u0644\u063a\u0627\u0621",  # الغاء
        "\u0625\u0644\u063a\u0627\u0621",  # إلغاء
    ]
    lower = text.lower()
    for kw in stop_keywords:
        if kw.lower() in lower:
            if "@" in contact_id:
                add_to_suppression(email=contact_id, reason="opt_out", source=f"{channel}_reply")
            else:
                add_to_suppression(phone=contact_id, reason="opt_out", source=f"{channel}_reply")
            return True
    return False
