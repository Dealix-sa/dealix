"""Audit logging for outbound activity — writes to CSV ledger."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from app.outbound.schemas import (
    EVENTS_HEADER,
    OutboundChannel,
    OutboundEvent,
    append_to_ledger,
    ensure_ledger,
)

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
EVENTS_PATH = LEDGER_DIR / "outbound_events.csv"


def log_event(
    message_id: str,
    company_id: str,
    contact_id: str,
    channel: OutboundChannel,
    event_type: str,
    event_payload: str = "",
) -> OutboundEvent:
    """Log an outbound event."""
    event = OutboundEvent(
        message_id=message_id,
        company_id=company_id,
        contact_id=contact_id,
        channel=channel,
        event_type=event_type,
        event_payload=event_payload,
    )
    append_to_ledger(EVENTS_PATH, EVENTS_HEADER, event.to_csv_row())
    return event


def log_send_attempt(
    message_id: str,
    company_id: str,
    contact_id: str,
    channel: OutboundChannel,
    success: bool,
    detail: str = "",
) -> OutboundEvent:
    event_type = "sent" if success else "send_failed"
    return log_event(message_id, company_id, contact_id, channel, event_type, detail)
