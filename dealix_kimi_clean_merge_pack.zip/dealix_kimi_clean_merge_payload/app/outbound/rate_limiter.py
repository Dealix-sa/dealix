"""Rate limiter for outbound channels — per-channel daily/batch limits."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

from app.outbound.schemas import OutboundChannel, read_ledger

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"


class RateLimiter:
    """Enforce daily and batch rate limits per channel."""

    DEFAULT_LIMITS: dict[OutboundChannel, int] = {
        OutboundChannel.EMAIL: 25,
        OutboundChannel.WHATSAPP: 10,
        OutboundChannel.SMS: 5,
        OutboundChannel.LINKEDIN: 20,
        OutboundChannel.CONTACT_FORM: 15,
        OutboundChannel.CALL: 30,
    }

    DEFAULT_BATCH_LIMITS: dict[OutboundChannel, int] = {
        OutboundChannel.EMAIL: 10,
        OutboundChannel.WHATSAPP: 5,
        OutboundChannel.SMS: 3,
        OutboundChannel.LINKEDIN: 10,
        OutboundChannel.CONTACT_FORM: 5,
        OutboundChannel.CALL: 15,
    }

    DEFAULT_MIN_SECONDS: dict[OutboundChannel, int] = {
        OutboundChannel.EMAIL: 90,
        OutboundChannel.WHATSAPP: 120,
        OutboundChannel.SMS: 120,
        OutboundChannel.LINKEDIN: 60,
        OutboundChannel.CONTACT_FORM: 60,
        OutboundChannel.CALL: 30,
    }

    def __init__(self) -> None:
        self._load_env_limits()

    def _load_env_limits(self) -> None:
        """Override defaults with env vars."""
        for ch in OutboundChannel:
            env_key = f"{ch.value.upper()}_DAILY_LIMIT"
            val = os.getenv(env_key)
            if val:
                self.DEFAULT_LIMITS[ch] = int(val)
            batch_key = f"{ch.value.upper()}_BATCH_LIMIT"
            batch_val = os.getenv(batch_key)
            if batch_val:
                self.DEFAULT_BATCH_LIMITS[ch] = int(batch_val)
            sec_key = f"{ch.value.upper()}_MIN_SECONDS_BETWEEN_SENDS"
            sec_val = os.getenv(sec_key)
            if sec_val:
                self.DEFAULT_MIN_SECONDS[ch] = int(sec_val)

    def daily_remaining(self, channel: OutboundChannel) -> int:
        """How many sends remain today for this channel."""
        limit = self.DEFAULT_LIMITS.get(channel, 25)
        sent = self._count_today(channel)
        return max(0, limit - sent)

    def is_allowed(self, channel: OutboundChannel) -> bool:
        return self.daily_remaining(channel) > 0

    def batch_limit(self, channel: OutboundChannel) -> int:
        return self.DEFAULT_BATCH_LIMITS.get(channel, 10)

    def min_seconds_between(self, channel: OutboundChannel) -> int:
        return self.DEFAULT_MIN_SECONDS.get(channel, 90)

    def _count_today(self, channel: OutboundChannel) -> int:
        queue_path = LEDGER_DIR / "outbound_queue.csv"
        if not queue_path.exists():
            return 0
        count = 0
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        for row in read_ledger(queue_path):
            if row.get("channel") == channel.value and row.get("status") in ("sent", "delivered"):
                sent_at = row.get("sent_at", "")
                if sent_at.startswith(today):
                    count += 1
        return count
