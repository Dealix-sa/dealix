"""Webhook handlers for inbound events (email opens, WhatsApp replies, etc.)."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from app.outbound.audit import log_event
from app.outbound.reply_tracker import ReplyTracker
from app.outbound.schemas import OutboundChannel


def handle_email_webhook(payload: dict) -> dict:
    """Handle email provider webhooks (delivered, opened, bounced, replied)."""
    event_type = payload.get("event", "unknown")
    message_id = payload.get("message_id", "unknown")
    contact_id = payload.get("email", "")
    log_event(message_id, "dealix", contact_id, OutboundChannel.EMAIL, event_type, json.dumps(payload))
    return {"status": "logged", "event": event_type}


def handle_whatsapp_webhook(payload: dict) -> dict:
    """Handle WhatsApp webhook (message status, incoming message)."""
    event_type = payload.get("status", "unknown")  # sent | delivered | read | failed
    message_id = payload.get("message_id", "unknown")
    contact_id = payload.get("from", "")

    log_event(message_id, "dealix", contact_id, OutboundChannel.WHATSAPP, event_type, json.dumps(payload))

    # Handle incoming message
    if payload.get("type") == "incoming_message":
        text = payload.get("text", "")
        tracker = ReplyTracker()
        tracker.track_reply(message_id, "dealix", contact_id, OutboundChannel.WHATSAPP, text)

    return {"status": "logged", "event": event_type}


def handle_sms_webhook(payload: dict) -> dict:
    """Handle SMS webhook (delivery status, incoming reply)."""
    event_type = payload.get("status", "unknown")
    message_id = payload.get("message_id", "unknown")
    contact_id = payload.get("from", "")
    log_event(message_id, "dealix", contact_id, OutboundChannel.SMS, event_type, json.dumps(payload))
    return {"status": "logged", "event": event_type}
