"""Provider router — dispatches to the correct channel sender."""

from __future__ import annotations

import os
from pathlib import Path

from app.outbound.schemas import OutboundChannel, OutboundMessage, OutboundStatus
from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.audit import log_send_attempt
from app.outbound.schemas import append_to_ledger

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"
QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]


class ProviderRouter:
    """Routes outbound messages to the correct channel. All sends go through policy gate first."""

    def __init__(self) -> None:
        self.gate = OutboundPolicyGate()

    def send(self, msg: OutboundMessage) -> dict:
        """Attempt to send a message. Returns result dict."""
        allowed, reason = self.gate.can_send(msg)
        if not allowed:
            return {"success": False, "error": reason, "message_id": msg.message_id}

        # Log attempt
        result = self._dispatch(msg)
        log_send_attempt(
            msg.message_id, msg.company_id, msg.contact_id, msg.channel,
            result["success"], result.get("detail", "")
        )
        return result

    def draft(self, msg: OutboundMessage) -> dict:
        """Queue a message as draft (no send)."""
        allowed, reason = self.gate.can_draft(msg)
        if not allowed:
            return {"success": False, "error": reason, "message_id": msg.message_id}
        msg.status = OutboundStatus.DRAFT
        append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
        return {"success": True, "status": "draft", "message_id": msg.message_id}

    def _dispatch(self, msg: OutboundMessage) -> dict:
        """Dispatch to channel-specific sender."""
        dispatchers = {
            OutboundChannel.EMAIL: self._send_email,
            OutboundChannel.WHATSAPP: self._send_whatsapp,
            OutboundChannel.SMS: self._send_sms,
            OutboundChannel.LINKEDIN: self._send_linkedin,
            OutboundChannel.CONTACT_FORM: self._send_contact_form,
            OutboundChannel.CALL: self._send_call,
        }
        handler = dispatchers.get(msg.channel)
        if not handler:
            return {"success": False, "error": f"no handler for {msg.channel.value}", "message_id": msg.message_id}
        return handler(msg)

    def _send_email(self, msg: OutboundMessage) -> dict:
        provider = os.getenv("EMAIL_PROVIDER", "smtp")
        return {
            "success": True,
            "status": "dry_run",
            "detail": f"Email via {provider} — EXTERNAL_SEND_ENABLED=false prevents real send",
            "message_id": msg.message_id,
        }

    def _send_whatsapp(self, msg: OutboundMessage) -> dict:
        provider = os.getenv("WHATSAPP_PROVIDER", "meta_cloud")
        return {
            "success": True,
            "status": "dry_run",
            "detail": f"WhatsApp via {provider} — WHATSAPP_ALLOW_LIVE_SEND=false prevents real send",
            "message_id": msg.message_id,
        }

    def _send_sms(self, msg: OutboundMessage) -> dict:
        return {
            "success": True,
            "status": "dry_run",
            "detail": "SMS — SMS_SEND_ENABLED=false prevents real send",
            "message_id": msg.message_id,
        }

    def _send_linkedin(self, msg: OutboundMessage) -> dict:
        return {
            "success": False,
            "error": "LinkedIn is manual_tasks_only — automated send not allowed",
            "message_id": msg.message_id,
        }

    def _send_contact_form(self, msg: OutboundMessage) -> dict:
        return {
            "success": False,
            "error": "Contact forms are manual_tasks_only — automated send not allowed",
            "message_id": msg.message_id,
        }

    def _send_call(self, msg: OutboundMessage) -> dict:
        return {
            "success": True,
            "status": "task_created",
            "detail": "Call task created — human execution required",
            "message_id": msg.message_id,
        }
