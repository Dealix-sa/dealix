"""Approval workflow for outbound batches."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from app.outbound.schemas import (
    QUEUE_HEADER,
    OutboundMessage,
    OutboundStatus,
    append_to_ledger,
    ensure_ledger,
    read_ledger,
)

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"


def queue_for_approval(msg: OutboundMessage) -> OutboundMessage:
    """Queue a message for approval. Does NOT send."""
    msg.status = OutboundStatus.PENDING_APPROVAL
    msg.approval_status = "pending"
    msg.updated_at = datetime.now(timezone.utc)
    append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
    return msg


def approve_message(message_id: str, approved_by: str) -> Optional[OutboundMessage]:
    """Approve a pending message."""
    ensure_ledger(QUEUE_PATH, QUEUE_HEADER)
    rows = read_ledger(QUEUE_PATH)
    updated = False
    for row in rows:
        if row["message_id"] == message_id:
            row["approval_status"] = "approved"
            row["approved_by"] = approved_by
            row["status"] = OutboundStatus.APPROVED.value
            row["updated_at"] = datetime.now(timezone.utc).isoformat()
            updated = True
            break
    if updated:
        _rewrite_queue(rows)
        return OutboundMessage.from_csv_row(next(r for r in rows if r["message_id"] == message_id))
    return None


def reject_message(message_id: str, reason: str) -> Optional[OutboundMessage]:
    """Reject a pending message."""
    ensure_ledger(QUEUE_PATH, QUEUE_HEADER)
    rows = read_ledger(QUEUE_PATH)
    updated = False
    for row in rows:
        if row["message_id"] == message_id:
            row["approval_status"] = "rejected"
            row["status"] = OutboundStatus.REJECTED.value
            row["error_message"] = reason
            row["updated_at"] = datetime.now(timezone.utc).isoformat()
            updated = True
            break
    if updated:
        _rewrite_queue(rows)
    return None


def get_pending_approval() -> list[OutboundMessage]:
    """Get all messages pending approval."""
    if not QUEUE_PATH.exists():
        return []
    rows = read_ledger(QUEUE_PATH)
    return [OutboundMessage.from_csv_row(r) for r in rows if r.get("approval_status") == "pending"]


def _rewrite_queue(rows: list[dict[str, str]]) -> None:
    with open(QUEUE_PATH, "w", newline="", encoding="utf-8") as f:
        import csv
        writer = csv.DictWriter(f, fieldnames=QUEUE_HEADER)
        writer.writeheader()
        writer.writerows(rows)
