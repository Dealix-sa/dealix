"""
Outbound Policy Gate — the central safety mechanism for ALL outbound activity.

Enforces:
- No send without approval in controlled_live mode
- No email without unsubscribe
- No WhatsApp without opt-in + approved template
- No SMS without opt-in
- No sending to suppressed contacts
- No fake ROI, testimonials, or guaranteed claims
- Source URL required for verification
- Rate limits enforced
- Mode checks (disabled/draft_only block live sends)
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from app.outbound.schemas import (
    OutboundChannel,
    OutboundMessage,
    OutboundMode,
    OutboundStatus,
    read_ledger,
)

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"


class OutboundPolicyGate:
    """Central policy enforcement for outbound messaging."""

    BLOCKED_PHRASES = [
        r"guaranteed\s+roi",
        r"guaranteed\s+return",
        r"100%\s+success",
        r"fake\s+testimonial",
        r"guaranteed\s+results",
        r"\$\d+k?\s+guaranteed",
        r"risk.free",
        r"no\s+risk",
    ]

    WHATSAPP_STOP_KEYWORDS = [
        "stop", "unsubscribe", "cancel",
        "\u0625\u064a\u0642\u0627\u0641",  # إيقاف
        "\u0627\u0644\u063a\u0627\u0621",  # الغاء
        "\u0625\u0644\u063a\u0627\u0621",  # إلغاء
    ]

    def __init__(self) -> None:
        self.mode = OutboundMode(os.getenv("OUTBOUND_MODE", "draft_only"))
        self.external_send = os.getenv("EXTERNAL_SEND_ENABLED", "false").lower() == "true"
        self.require_approval = os.getenv("OUTBOUND_REQUIRE_APPROVAL", "true").lower() == "true"
        self.require_verified_target = os.getenv("OUTBOUND_REQUIRE_VERIFIED_TARGET", "true").lower() == "true"
        self.require_source_url = os.getenv("OUTBOUND_REQUIRE_SOURCE_URL", "true").lower() == "true"
        self.block_fake_claims = os.getenv("OUTBOUND_BLOCK_FAKE_CLAIMS", "true").lower() == "true"
        self.block_guaranteed_roi = os.getenv("OUTBOUND_BLOCK_GUARANTEED_ROI", "true").lower() == "true"
        self.block_fake_testimonials = os.getenv("OUTBOUND_BLOCK_FAKE_TESTIMONIALS", "true").lower() == "true"

    # ── Main gate ──────────────────────────────────────────────────────────

    def can_send(self, msg: OutboundMessage) -> tuple[bool, str]:
        """Return (allowed, reason). Every send MUST call this first."""
        checks = [
            self._check_mode,
            self._check_external_send_enabled,
            self._check_approval,
            self._check_verified_target,
            self._check_source_url,
            self._check_suppression,
            self._check_blocked_phrases,
            self._check_channel_specific,
            self._check_rate_limit,
        ]
        for check in checks:
            allowed, reason = check(msg)
            if not allowed:
                return False, reason
        return True, "passed"

    def can_draft(self, msg: OutboundMessage) -> tuple[bool, str]:
        """Drafting is allowed in draft_only, approval_queue, and controlled_live."""
        if self.mode == OutboundMode.DISABLED:
            return False, "outbound mode is disabled"
        return True, "draft_allowed"

    # ── Individual checks ──────────────────────────────────────────────────

    def _check_mode(self, msg: OutboundMessage) -> tuple[bool, str]:
        if self.mode == OutboundMode.DISABLED:
            return False, "outbound mode is disabled"
        if self.mode in (OutboundMode.DRAFT_ONLY, OutboundMode.APPROVAL_QUEUE):
            return False, f"mode is {self.mode.value}; live send blocked"
        return True, "ok"

    def _check_external_send_enabled(self, msg: OutboundMessage) -> tuple[bool, str]:
        if not self.external_send:
            return False, "EXTERNAL_SEND_ENABLED is false"
        return True, "ok"

    def _check_approval(self, msg: OutboundMessage) -> tuple[bool, str]:
        if self.require_approval and msg.approval_status != "approved":
            return False, "message not approved"
        return True, "ok"

    def _check_verified_target(self, msg: OutboundMessage) -> tuple[bool, str]:
        if self.require_verified_target and msg.verification_status != "verified":
            return False, "target not verified"
        return True, "ok"

    def _check_source_url(self, msg: OutboundMessage) -> tuple[bool, str]:
        if self.require_source_url and not msg.source_url:
            return False, "source_url required"
        return True, "ok"

    def _check_suppression(self, msg: OutboundMessage) -> tuple[bool, str]:
        suppression_path = LEDGER_DIR / "suppression_list.csv"
        if not suppression_path.exists():
            return True, "ok"
        entries = read_ledger(suppression_path)
        for entry in entries:
            if entry.get("email") == msg.contact_id or entry.get("phone") == msg.contact_id:
                return False, "contact in suppression_list"
        return True, "ok"

    def _check_blocked_phrases(self, msg: OutboundMessage) -> tuple[bool, str]:
        if not self.block_fake_claims:
            return True, "ok"
        text = f"{msg.subject or ''} {msg.body}".lower()
        for pattern in self.BLOCKED_PHRASES:
            if re.search(pattern, text):
                return False, f"blocked phrase matched: {pattern!r}"
        return True, "ok"

    def _check_channel_specific(self, msg: OutboundMessage) -> tuple[bool, str]:
        if msg.channel == OutboundChannel.EMAIL:
            return self._check_email(msg)
        if msg.channel == OutboundChannel.WHATSAPP:
            return self._check_whatsapp(msg)
        if msg.channel == OutboundChannel.SMS:
            return self._check_sms(msg)
        if msg.channel == OutboundChannel.LINKEDIN:
            return self._check_linkedin(msg)
        if msg.channel == OutboundChannel.CONTACT_FORM:
            return self._check_contact_form(msg)
        if msg.channel == OutboundChannel.CALL:
            return self._check_call(msg)
        return True, "ok"

    def _check_email(self, msg: OutboundMessage) -> tuple[bool, str]:
        email_enabled = os.getenv("EMAIL_SEND_ENABLED", "false").lower() == "true"
        if not email_enabled:
            return False, "EMAIL_SEND_ENABLED is false"
        require_unsub = os.getenv("EMAIL_REQUIRE_UNSUBSCRIBE", "true").lower() == "true"
        if require_unsub and not msg.unsubscribe_link and not msg.unsubscribe_required:
            return False, "email requires unsubscribe"
        return True, "ok"

    def _check_whatsapp(self, msg: OutboundMessage) -> tuple[bool, str]:
        wa_enabled = os.getenv("WHATSAPP_SEND_ENABLED", "false").lower() == "true"
        if not wa_enabled:
            return False, "WHATSAPP_SEND_ENABLED is false"
        wa_live = os.getenv("WHATSAPP_ALLOW_LIVE_SEND", "false").lower() == "true"
        if not wa_live:
            return False, "WHATSAPP_ALLOW_LIVE_SEND is false"
        require_opt_in = os.getenv("WHATSAPP_REQUIRE_OPT_IN", "true").lower() == "true"
        if require_opt_in and msg.opt_in_status != "opted_in":
            return False, "whatsapp requires opt-in"
        require_template = os.getenv("WHATSAPP_REQUIRE_APPROVED_TEMPLATE", "true").lower() == "true"
        if require_template and not msg.template_name:
            return False, "whatsapp requires approved template"
        # Check for stop keywords in body
        body_lower = msg.body.lower()
        for kw in self.WHATSAPP_STOP_KEYWORDS:
            if kw.lower() in body_lower:
                return False, f"message contains stop keyword: {kw!r}"
        return True, "ok"

    def _check_sms(self, msg: OutboundMessage) -> tuple[bool, str]:
        sms_enabled = os.getenv("SMS_SEND_ENABLED", "false").lower() == "true"
        if not sms_enabled:
            return False, "SMS_SEND_ENABLED is false"
        require_opt_in = os.getenv("SMS_REQUIRE_OPT_IN", "true").lower() == "true"
        if require_opt_in and msg.opt_in_status != "opted_in":
            return False, "sms requires opt-in"
        return True, "ok"

    def _check_linkedin(self, msg: OutboundMessage) -> tuple[bool, str]:
        li_enabled = os.getenv("LINKEDIN_SEND_ENABLED", "false").lower() == "true"
        if not li_enabled:
            return False, "LINKEDIN_SEND_ENABLED is false"
        li_mode = os.getenv("LINKEDIN_MODE", "manual_tasks_only")
        if li_mode == "manual_tasks_only":
            return False, "LinkedIn is manual_tasks_only; no automated send"
        return True, "ok"

    def _check_contact_form(self, msg: OutboundMessage) -> tuple[bool, str]:
        cf_enabled = os.getenv("CONTACT_FORM_SEND_ENABLED", "false").lower() == "true"
        if not cf_enabled:
            return False, "CONTACT_FORM_SEND_ENABLED is false"
        cf_mode = os.getenv("CONTACT_FORM_MODE", "manual_tasks_only")
        if cf_mode == "manual_tasks_only":
            return False, "contact_form is manual_tasks_only; no automated send"
        return True, "ok"

    def _check_call(self, msg: OutboundMessage) -> tuple[bool, str]:
        call_enabled = os.getenv("CALL_TASKS_ENABLED", "true").lower() == "true"
        if not call_enabled:
            return False, "CALL_TASKS_ENABLED is false"
        return True, "ok"

    def _check_rate_limit(self, msg: OutboundMessage) -> tuple[bool, str]:
        # Per-channel daily limits from env
        limits = {
            OutboundChannel.EMAIL: int(os.getenv("EMAIL_DAILY_LIMIT", "25")),
            OutboundChannel.WHATSAPP: int(os.getenv("WHATSAPP_DAILY_LIMIT", "10")),
            OutboundChannel.SMS: int(os.getenv("SMS_DAILY_LIMIT", "5")),
        }
        if msg.channel not in limits:
            return True, "ok"
        # Count today's sends from ledger
        queue_path = LEDGER_DIR / "outbound_queue.csv"
        if not queue_path.exists():
            return True, "ok"
        sent_today = 0
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        for row in read_ledger(queue_path):
            if row.get("channel") == msg.channel.value and row.get("status") == "sent":
                sent_at = row.get("sent_at", "")
                if sent_at.startswith(today):
                    sent_today += 1
        if sent_today >= limits[msg.channel]:
            return False, f"daily limit reached for {msg.channel.value}: {limits[msg.channel]}"
        return True, "ok"

    # ── Opt-out detection ──────────────────────────────────────────────────

    def detect_opt_out(self, text: str) -> bool:
        """Check if incoming text contains opt-out keywords."""
        lower = text.lower()
        for kw in self.WHATSAPP_STOP_KEYWORDS:
            if kw.lower() in lower:
                return True
        return False
