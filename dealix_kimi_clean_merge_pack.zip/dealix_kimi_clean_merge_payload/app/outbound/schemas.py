"""
Outbound schemas — all outbound activity is tracked via CSV ledgers.
No database required; optional SQLModel classes provided for Postgres environments.
"""

from __future__ import annotations

import csv
import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


class OutboundChannel(str, Enum):
    EMAIL = "email"
    WHATSAPP = "whatsapp"
    LINKEDIN = "linkedin"
    CONTACT_FORM = "contact_form"
    CALL = "call"
    SMS = "sms"


class OutboundStatus(str, Enum):
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    SCHEDULED = "scheduled"
    SENDING = "sending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    BOUNCED = "bounced"
    REPLIED = "replied"
    OPTED_OUT = "opted_out"


class OutboundMode(str, Enum):
    DISABLED = "disabled"
    DRAFT_ONLY = "draft_only"
    APPROVAL_QUEUE = "approval_queue"
    CONTROLLED_LIVE = "controlled_live"


class OutboundMessage(BaseModel):
    """A single outbound message request."""

    message_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    company_id: str = "dealix"
    contact_id: str
    channel: OutboundChannel
    status: OutboundStatus = OutboundStatus.DRAFT
    subject: Optional[str] = None
    body: str = ""
    body_path: Optional[str] = None  # path to markdown file
    template_name: Optional[str] = None
    source_url: Optional[str] = None
    verification_status: str = "unverified"  # unverified | verified | failed
    approval_status: str = "pending"  # pending | approved | rejected
    approved_by: Optional[str] = None
    opt_in_required: bool = True
    opt_in_status: str = "unknown"  # unknown | opted_in | opted_out
    unsubscribe_required: bool = False
    unsubscribe_link: Optional[str] = None
    suppression_checked: bool = False
    suppression_match: bool = False
    scheduled_at: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    provider_message_id: Optional[str] = None
    error_message: Optional[str] = None
    next_action: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_validator("body")
    @classmethod
    def block_fake_claims(cls, v: str) -> str:
        blocked_phrases = [
            "guaranteed roi",
            "guaranteed return",
            "100% success",
            "fake testimonial",
            "guaranteed results",
        ]
        lower = v.lower()
        for phrase in blocked_phrases:
            if phrase in lower:
                raise ValueError(f"Blocked phrase detected: {phrase!r}")
        return v

    def to_csv_row(self) -> dict[str, Any]:
        return {
            "message_id": self.message_id,
            "company_id": self.company_id,
            "contact_id": self.contact_id,
            "channel": self.channel.value,
            "status": self.status.value,
            "subject": self.subject or "",
            "body_path": self.body_path or "",
            "template_name": self.template_name or "",
            "source_url": self.source_url or "",
            "verification_status": self.verification_status,
            "approval_status": self.approval_status,
            "approved_by": self.approved_by or "",
            "opt_in_required": str(self.opt_in_required).lower(),
            "opt_in_status": self.opt_in_status,
            "unsubscribe_required": str(self.unsubscribe_required).lower(),
            "suppression_checked": str(self.suppression_checked).lower(),
            "scheduled_at": self.scheduled_at.isoformat() if self.scheduled_at else "",
            "sent_at": self.sent_at.isoformat() if self.sent_at else "",
            "provider_message_id": self.provider_message_id or "",
            "error_message": self.error_message or "",
            "next_action": self.next_action or "",
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_csv_row(cls, row: dict[str, str]) -> OutboundMessage:
        def _dt(key: str) -> Optional[datetime]:
            return datetime.fromisoformat(row[key]) if row.get(key) else None

        return cls(
            message_id=row["message_id"],
            company_id=row["company_id"],
            contact_id=row["contact_id"],
            channel=OutboundChannel(row["channel"]),
            status=OutboundStatus(row["status"]),
            subject=row.get("subject") or None,
            body_path=row.get("body_path") or None,
            template_name=row.get("template_name") or None,
            source_url=row.get("source_url") or None,
            verification_status=row.get("verification_status", "unverified"),
            approval_status=row.get("approval_status", "pending"),
            approved_by=row.get("approved_by") or None,
            opt_in_required=row.get("opt_in_required", "true").lower() == "true",
            opt_in_status=row.get("opt_in_status", "unknown"),
            unsubscribe_required=row.get("unsubscribe_required", "false").lower() == "true",
            suppression_checked=row.get("suppression_checked", "false").lower() == "true",
            suppression_match=row.get("suppression_match", "false").lower() == "true",
            scheduled_at=_dt("scheduled_at"),
            sent_at=_dt("sent_at"),
            provider_message_id=row.get("provider_message_id") or None,
            error_message=row.get("error_message") or None,
            next_action=row.get("next_action") or None,
            created_at=_dt("created_at") or datetime.now(timezone.utc),
            updated_at=_dt("updated_at") or datetime.now(timezone.utc),
        )


class OutboundEvent(BaseModel):
    """An event in the outbound lifecycle (open, click, bounce, reply, etc.)."""

    event_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    message_id: str
    company_id: str = "dealix"
    contact_id: str
    channel: OutboundChannel
    event_type: str  # sent | delivered | opened | clicked | bounced | replied | opted_out
    event_payload: str = ""  # JSON string
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_csv_row(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id,
            "message_id": self.message_id,
            "company_id": self.company_id,
            "contact_id": self.contact_id,
            "channel": self.channel.value,
            "event_type": self.event_type,
            "event_payload": self.event_payload,
            "created_at": self.created_at.isoformat(),
        }


class ReplyLog(BaseModel):
    """A reply received from a contact."""

    reply_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    message_id: str
    company_id: str = "dealix"
    contact_id: str
    channel: OutboundChannel
    reply_text: str = ""
    classification: str = "unclassified"  # interested | not_interested | meeting_request | objection | opt_out | spam
    next_action: Optional[str] = None
    meeting_intent: bool = False
    opt_out_detected: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_csv_row(self) -> dict[str, Any]:
        return {
            "reply_id": self.reply_id,
            "message_id": self.message_id,
            "company_id": self.company_id,
            "contact_id": self.contact_id,
            "channel": self.channel.value,
            "reply_text": self.reply_text,
            "classification": self.classification,
            "next_action": self.next_action or "",
            "meeting_intent": str(self.meeting_intent).lower(),
            "opt_out_detected": str(self.opt_out_detected).lower(),
            "created_at": self.created_at.isoformat(),
        }


class SuppressionEntry(BaseModel):
    """An entry in the suppression list."""

    email: Optional[str] = None
    phone: Optional[str] = None
    whatsapp_number: Optional[str] = None
    reason: str = "opt_out"
    source: str = "manual"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_csv_row(self) -> dict[str, Any]:
        return {
            "email": self.email or "",
            "phone": self.phone or "",
            "whatsapp_number": self.whatsapp_number or "",
            "reason": self.reason,
            "source": self.source,
            "created_at": self.created_at.isoformat(),
        }


# ── CSV helpers ──────────────────────────────────────────────────────────────

QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]

EVENTS_HEADER = [
    "event_id", "message_id", "company_id", "contact_id", "channel",
    "event_type", "event_payload", "created_at",
]

REPLY_HEADER = [
    "reply_id", "message_id", "company_id", "contact_id", "channel",
    "reply_text", "classification", "next_action", "meeting_intent",
    "opt_out_detected", "created_at",
]

SUPPRESSION_HEADER = ["email", "phone", "whatsapp_number", "reason", "source", "created_at"]


def ensure_ledger(path: Path, header: list[str]) -> None:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()


def append_to_ledger(path: Path, header: list[str], row: dict[str, Any]) -> None:
    ensure_ledger(path, header)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writerow(row)


def read_ledger(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        return list(csv.DictReader(f))
