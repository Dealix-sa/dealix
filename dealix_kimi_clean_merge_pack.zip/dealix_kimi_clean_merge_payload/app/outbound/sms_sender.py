"""SMS sender — opt-in only, disabled by default."""

from __future__ import annotations

import os
from datetime import datetime, timezone

from app.outbound.schemas import OutboundMessage, OutboundStatus, append_to_ledger

LEDGER_DIR = __import__("pathlib").Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"
QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]


def send_sms(msg: OutboundMessage, dry_run: bool = True) -> dict:
    """Send or simulate sending an SMS."""
    if os.getenv("SMS_SEND_ENABLED", "false").lower() != "true":
        return {"success": False, "error": "SMS_SEND_ENABLED is false", "message_id": msg.message_id}

    require_opt_in = os.getenv("SMS_REQUIRE_OPT_IN", "true").lower() == "true"
    if require_opt_in and msg.opt_in_status != "opted_in":
        return {"success": False, "error": "SMS opt-in required", "message_id": msg.message_id}

    if dry_run:
        msg.status = OutboundStatus.SCHEDULED
        msg.next_action = "awaiting_live_enable"
        append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
        return {
            "success": True,
            "status": "dry_run",
            "message_id": msg.message_id,
            "detail": "SMS logged as SCHEDULED",
        }

    msg.status = OutboundStatus.SENT
    msg.sent_at = datetime.now(timezone.utc)
    append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
    return {"success": True, "status": "sent", "message_id": msg.message_id, "detail": "SMS sent (live)"}
