"""LinkedIn task queue — manual tasks only, no browser automation."""

from __future__ import annotations

import csv
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
TASKS_PATH = LEDGER_DIR / "linkedin_tasks.csv"
TASKS_HEADER = [
    "task_id", "company_id", "contact_id", "contact_url", "action_type",
    "message_draft", "status", "outcome", "owner", "due_at", "completed_at",
    "notes", "created_at", "updated_at",
]


class LinkedInTask(BaseModel := __import__("pydantic").BaseModel):
    task_id: str = ""
    company_id: str = "dealix"
    contact_id: str = ""
    contact_url: str = ""
    action_type: str = ""  # view_profile | connect | message | follow_up
    message_draft: str = ""
    status: str = "pending"  # pending | in_progress | completed | cancelled
    outcome: str = ""
    owner: str = "founder"
    due_at: Optional[str] = None
    completed_at: Optional[str] = None
    notes: str = ""
    created_at: str = ""
    updated_at: str = ""

    def model_post_init(self, __context):
        if not self.task_id:
            self.task_id = str(uuid.uuid4())[:8]
        now = datetime.now(timezone.utc).isoformat()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now

    def to_row(self) -> dict:
        return {
            "task_id": self.task_id, "company_id": self.company_id,
            "contact_id": self.contact_id, "contact_url": self.contact_url,
            "action_type": self.action_type, "message_draft": self.message_draft,
            "status": self.status, "outcome": self.outcome, "owner": self.owner,
            "due_at": self.due_at or "", "completed_at": self.completed_at or "",
            "notes": self.notes, "created_at": self.created_at, "updated_at": self.updated_at,
        }


def create_task(
    contact_id: str,
    contact_url: str = "",
    action_type: str = "view_profile",
    message_draft: str = "",
    owner: str = "founder",
    due_at: Optional[str] = None,
) -> LinkedInTask:
    task = LinkedInTask(
        contact_id=contact_id, contact_url=contact_url,
        action_type=action_type, message_draft=message_draft,
        owner=owner, due_at=due_at,
    )
    _ensure_tasks()
    with open(TASKS_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writerow(task.to_row())
    return task


def list_tasks(status_filter: Optional[str] = None) -> list[LinkedInTask]:
    _ensure_tasks()
    tasks = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if status_filter and row.get("status") != status_filter:
                continue
            tasks.append(LinkedInTask(**row))
    return tasks


def complete_task(task_id: str, outcome: str, notes: str = "") -> None:
    _ensure_tasks()
    rows = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        if row["task_id"] == task_id:
            row["status"] = "completed"
            row["outcome"] = outcome
            row["notes"] = notes
            row["completed_at"] = datetime.now(timezone.utc).isoformat()
            row["updated_at"] = datetime.now(timezone.utc).isoformat()
    with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writeheader()
        writer.writerows(rows)


def _ensure_tasks() -> None:
    if not TASKS_PATH.exists():
        TASKS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
            writer.writeheader()
