"""
Dealix Controlled Live Outbound System

Multi-channel outreach engine with safety gates:
- Email: controlled live with approval, unsubscribe, rate limits
- WhatsApp: opt-in/template only
- LinkedIn: manual task queue only
- Contact forms: manual task queue only
- Calls: task queue and scripts only
- SMS: opt-in only, disabled by default

Modes: disabled | draft_only | approval_queue | controlled_live
Default: draft_only
"""

from app.outbound.policy_gate import OutboundPolicyGate
from app.outbound.schemas import (
    OutboundMessage,
    OutboundStatus,
    OutboundChannel,
    OutboundMode,
    OutboundEvent,
    ReplyLog,
)

__all__ = [
    "OutboundPolicyGate",
    "OutboundMessage",
    "OutboundStatus",
    "OutboundChannel",
    "OutboundMode",
    "OutboundEvent",
    "ReplyLog",
]
