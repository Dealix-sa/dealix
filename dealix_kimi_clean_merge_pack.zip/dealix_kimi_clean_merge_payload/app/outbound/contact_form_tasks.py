"""Contact form task queue — manual tasks only, no automated spam."""

from __future__ import annotations

import csv
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
TASKS_PATH = LEDGER_DIR / "contact_form_tasks.csv"
TASKS_HEADER = [
    "task_id", "company_id", "contact_id", "form_url", "action_type",
    "message_draft", "status", "outcome", "owner", "due_at", "completed_at",
    "human_reviewed", "notes", "created_at", "updated_at",
]


def create_task(
    contact_id: str,
    form_url: str = "",
    action_type: str = "submit_inquiry",
    message_draft: str = "",
    owner: str = "founder",
    due_at: Optional[str] = None,
) -> dict:
    task = {
        "task_id": str(uuid.uuid4())[:8],
        "company_id": "dealix",
        "contact_id": contact_id,
        "form_url": form_url,
        "action_type": action_type,
        "message_draft": message_draft,
        "status": "pending",
        "outcome": "",
        "owner": owner,
        "due_at": due_at or "",
        "completed_at": "",
        "human_reviewed": "false",
        "notes": "",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    _ensure_tasks()
    with open(TASKS_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writerow(task)
    return task


def list_tasks(status_filter: Optional[str] = None) -> list[dict]:
    _ensure_tasks()
    tasks = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if status_filter and row.get("status") != status_filter:
                continue
            tasks.append(row)
    return tasks


def complete_task(task_id: str, outcome: str, notes: str = "") -> None:
    _ensure_tasks()
    rows = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        if row["task_id"] == task_id:
            row["status"] = "completed"
            row["outcome"] = outcome
            row["notes"] = notes
            row["completed_at"] = datetime.now(timezone.utc).isoformat()
            row["updated_at"] = datetime.now(timezone.utc).isoformat()
    with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writeheader()
        writer.writerows(rows)


def mark_human_reviewed(task_id: str, approved: bool) -> None:
    _ensure_tasks()
    rows = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        if row["task_id"] == task_id:
            row["human_reviewed"] = "true" if approved else "false"
            if not approved:
                row["status"] = "rejected"
            row["updated_at"] = datetime.now(timezone.utc).isoformat()
    with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writeheader()
        writer.writerows(rows)


def _ensure_tasks() -> None:
    if not TASKS_PATH.exists():
        TASKS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
            writer.writeheader()
