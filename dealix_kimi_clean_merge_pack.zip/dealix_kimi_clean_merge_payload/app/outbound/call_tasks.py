"""Call task queue — task + script + outcome logging. No robocalls."""

from __future__ import annotations

import csv
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
TASKS_PATH = LEDGER_DIR / "call_tasks.csv"
TASKS_HEADER = [
    "task_id", "company_id", "contact_id", "phone", "call_script_path",
    "status", "outcome", "next_action", "owner", "due_at", "completed_at",
    "duration_seconds", "notes", "created_at", "updated_at",
]


def create_task(
    contact_id: str,
    phone: str = "",
    call_script_path: str = "",
    owner: str = "founder",
    due_at: Optional[str] = None,
) -> dict:
    task = {
        "task_id": str(uuid.uuid4())[:8],
        "company_id": "dealix",
        "contact_id": contact_id,
        "phone": phone,
        "call_script_path": call_script_path,
        "status": "pending",
        "outcome": "",
        "next_action": "",
        "owner": owner,
        "due_at": due_at or "",
        "completed_at": "",
        "duration_seconds": "0",
        "notes": "",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    _ensure_tasks()
    with open(TASKS_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writerow(task)
    return task


def list_tasks(status_filter: Optional[str] = None) -> list[dict]:
    _ensure_tasks()
    tasks = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if status_filter and row.get("status") != status_filter:
                continue
            tasks.append(row)
    return tasks


def complete_task(
    task_id: str,
    outcome: str,
    next_action: str = "",
    duration_seconds: int = 0,
    notes: str = "",
) -> None:
    """Log call outcome. Outcome should be one of: no_answer | voicemail | connected | meeting_booked | not_interested | callback_requested"""
    _ensure_tasks()
    rows = []
    with open(TASKS_PATH, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        if row["task_id"] == task_id:
            row["status"] = "completed"
            row["outcome"] = outcome
            row["next_action"] = next_action
            row["duration_seconds"] = str(duration_seconds)
            row["notes"] = notes
            row["completed_at"] = datetime.now(timezone.utc).isoformat()
            row["updated_at"] = datetime.now(timezone.utc).isoformat()
    with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
        writer.writeheader()
        writer.writerows(rows)


def _ensure_tasks() -> None:
    if not TASKS_PATH.exists():
        TASKS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(TASKS_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=TASKS_HEADER)
            writer.writeheader()
