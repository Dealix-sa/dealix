"""WhatsApp sender — opt-in/template only, dry-run by default."""

from __future__ import annotations

import os
from datetime import datetime, timezone

from app.outbound.schemas import OutboundMessage, OutboundStatus, append_to_ledger
from app.outbound.suppression import process_opt_out

LEDGER_DIR = __import__("pathlib").Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"
QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]


def send_whatsapp(msg: OutboundMessage, dry_run: bool = True) -> dict:
    """Send or simulate sending a WhatsApp message."""
    # Check opt-in
    require_opt_in = os.getenv("WHATSAPP_REQUIRE_OPT_IN", "true").lower() == "true"
    if require_opt_in and msg.opt_in_status != "opted_in":
        return {"success": False, "error": "opt-in required", "message_id": msg.message_id}

    # Check template
    require_template = os.getenv("WHATSAPP_REQUIRE_APPROVED_TEMPLATE", "true").lower() == "true"
    if require_template and not msg.template_name:
        return {"success": False, "error": "approved template required", "message_id": msg.message_id}

    if dry_run or os.getenv("WHATSAPP_ALLOW_LIVE_SEND", "false").lower() != "true":
        msg.status = OutboundStatus.SCHEDULED
        msg.next_action = "awaiting_live_enable"
        append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
        return {
            "success": True,
            "status": "dry_run",
            "message_id": msg.message_id,
            "detail": "WhatsApp logged as SCHEDULED — enable WHATSAPP_ALLOW_LIVE_SEND for live",
        }

    msg.status = OutboundStatus.SENT
    msg.sent_at = datetime.now(timezone.utc)
    append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
    return {
        "success": True,
        "status": "sent",
        "message_id": msg.message_id,
        "detail": "WhatsApp sent (live)",
    }
