"""Email sender — dry-run by default, logs to ledger."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

from app.outbound.schemas import OutboundMessage, OutboundStatus, append_to_ledger

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"
QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]


def send_email(msg: OutboundMessage, dry_run: bool = True) -> dict:
    """Send or simulate sending an email."""
    if dry_run or os.getenv("EMAIL_SEND_ENABLED", "false").lower() != "true":
        msg.status = OutboundStatus.SCHEDULED
        msg.next_action = "awaiting_live_enable"
        append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
        return {
            "success": True,
            "status": "dry_run",
            "message_id": msg.message_id,
            "detail": "Email logged as SCHEDULED — enable EMAIL_SEND_ENABLED for live",
        }

    # Live path (only reached if EMAIL_SEND_ENABLED=true)
    msg.status = OutboundStatus.SENDING
    # TODO: integrate SMTP/SendGrid/Postmark here
    msg.status = OutboundStatus.SENT
    msg.sent_at = datetime.now(timezone.utc)
    append_to_ledger(QUEUE_PATH, QUEUE_HEADER, msg.to_csv_row())
    return {
        "success": True,
        "status": "sent",
        "message_id": msg.message_id,
        "detail": "Email sent (live)",
    }
