"""Delivery schemas — tracked via CSV ledger."""

from __future__ import annotations

import csv
import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field


class DeliveryPhase(str, Enum):
    WON = "won"
    CONTRACT_PENDING = "contract_pending"
    INVOICE_PENDING = "invoice_pending"
    PAYMENT_PENDING = "payment_pending"
    ONBOARDING = "onboarding"
    INTAKE = "intake"
    DIAGNOSIS = "diagnosis"
    BLUEPRINT = "blueprint"
    BUILD = "build"
    INTERNAL_QA = "internal_qa"
    UAT = "uat"
    LAUNCH = "launch"
    TRAINING = "training"
    PROOF_REPORT = "proof_report"
    MANAGED_OS = "managed_os"
    RENEWAL_DUE = "renewal_due"
    EXPANDED = "expanded"
    CLOSED = "closed"


class DeliveryStatus(str, Enum):
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    SKIPPED = "skipped"


class ClientDeliveryLog(BaseModel):
    """A single delivery log entry per client/project/phase."""

    delivery_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    client_id: str = ""
    project_id: str = ""
    phase: DeliveryPhase = DeliveryPhase.ONBOARDING
    status: DeliveryStatus = DeliveryStatus.NOT_STARTED
    owner: str = "founder"
    deliverable: str = ""
    acceptance_criteria: str = ""
    proof_required: bool = True
    proof_status: str = "pending"
    blocker: str = ""
    next_action: str = ""
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def to_csv_row(self) -> dict[str, Any]:
        return {
            "delivery_id": self.delivery_id,
            "client_id": self.client_id,
            "project_id": self.project_id,
            "phase": self.phase.value,
            "status": self.status.value,
            "owner": self.owner,
            "deliverable": self.deliverable,
            "acceptance_criteria": self.acceptance_criteria,
            "proof_required": str(self.proof_required).lower(),
            "proof_status": self.proof_status,
            "blocker": self.blocker,
            "next_action": self.next_action,
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_csv_row(cls, row: dict[str, str]) -> ClientDeliveryLog:
        def _dt(key: str) -> datetime:
            return datetime.fromisoformat(row[key]) if row.get(key) else datetime.now(timezone.utc)
        return cls(
            delivery_id=row["delivery_id"],
            client_id=row["client_id"],
            project_id=row["project_id"],
            phase=DeliveryPhase(row["phase"]),
            status=DeliveryStatus(row["status"]),
            owner=row.get("owner", "founder"),
            deliverable=row.get("deliverable", ""),
            acceptance_criteria=row.get("acceptance_criteria", ""),
            proof_required=row.get("proof_required", "true").lower() == "true",
            proof_status=row.get("proof_status", "pending"),
            blocker=row.get("blocker", ""),
            next_action=row.get("next_action", ""),
            updated_at=_dt("updated_at"),
        )


DELIVERY_HEADER = [
    "delivery_id", "client_id", "project_id", "phase", "status", "owner",
    "deliverable", "acceptance_criteria", "proof_required", "proof_status",
    "blocker", "next_action", "updated_at",
]

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
DELIVERY_PATH = LEDGER_DIR / "client_delivery_log.csv"


def ensure_delivery_ledger() -> None:
    if not DELIVERY_PATH.exists():
        DELIVERY_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(DELIVERY_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=DELIVERY_HEADER)
            writer.writeheader()


def log_delivery(entry: ClientDeliveryLog) -> None:
    ensure_delivery_ledger()
    with open(DELIVERY_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=DELIVERY_HEADER)
        writer.writerow(entry.to_csv_row())


def read_delivery_log(client_id: str = "") -> list[ClientDeliveryLog]:
    ensure_delivery_ledger()
    entries = []
    with open(DELIVERY_PATH, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if not client_id or row.get("client_id") == client_id:
                entries.append(ClientDeliveryLog.from_csv_row(row))
    return entries
