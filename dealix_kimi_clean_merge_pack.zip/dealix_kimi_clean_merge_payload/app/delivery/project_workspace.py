"""Client workspace generator — creates the full client directory structure."""

from __future__ import annotations

from pathlib import Path
from typing import Optional


WORKSPACE_ROOT = Path(__file__).resolve().parents[2] / "clients"


class ProjectWorkspace:
    """Generates and manages client workspaces."""

    PHASES: list[dict[str, str]] = [
        {"dir": "00_contract", "name": "Contract & Scope"},
        {"dir": "01_onboarding", "name": "Onboarding"},
        {"dir": "02_diagnosis", "name": "Diagnosis"},
        {"dir": "03_blueprint", "name": "Blueprint"},
        {"dir": "04_build", "name": "Build"},
        {"dir": "05_uat", "name": "UAT"},
        {"dir": "06_training", "name": "Training"},
        {"dir": "07_proof", "name": "Proof"},
        {"dir": "08_retainer", "name": "Retainer & Expansion"},
    ]

    FILES: dict[str, list[str]] = {
        "00_contract": ["scope_summary.md", "acceptance_terms.md", "invoice_stub.md"],
        "01_onboarding": ["welcome.md", "access_checklist.md", "data_request.md", "stakeholder_map.md"],
        "02_diagnosis": ["current_state.md", "pain_map.md", "risk_register.md"],
        "03_blueprint": ["system_blueprint.md", "workflow_map.md", "data_model.md", "acceptance_criteria.md"],
        "04_build": ["sprint_plan.md", "implementation_log.md", "internal_qa.md"],
        "05_uat": ["uat_plan.md", "uat_notes.md", "signoff.md"],
        "06_training": ["user_guide.md", "admin_guide.md", "operating_sop.md"],
        "07_proof": ["weekly_proof_report.md", "before_after.md", "executive_summary.md"],
        "08_retainer": ["managed_os_offer.md", "expansion_map.md", "renewal_plan.md"],
    }

    def __init__(self, client_id: str) -> None:
        self.client_id = client_id
        self.root = WORKSPACE_ROOT / client_id

    def create(self) -> list[Path]:
        """Create the full workspace. Returns list of created files."""
        created: list[Path] = []
        for phase in self.PHASES:
            phase_dir = self.root / phase["dir"]
            phase_dir.mkdir(parents=True, exist_ok=True)
            for filename in self.FILES.get(phase["dir"], []):
                filepath = phase_dir / filename
                if not filepath.exists():
                    content = self._render_template(phase["dir"], filename)
                    filepath.write_text(content, encoding="utf-8")
                    created.append(filepath)
        # Create client metadata
        meta_file = self.root / "client_meta.md"
        if not meta_file.exists():
            meta_file.write_text(self._render_meta(), encoding="utf-8")
            created.append(meta_file)
        return created

    def get_phase_path(self, phase_dir: str) -> Path:
        return self.root / phase_dir

    def exists(self) -> bool:
        return self.root.exists()

    def _render_template(self, phase_dir: str, filename: str) -> str:
        client = self.client_id
        templates = {
            "00_contract/scope_summary.md": f"""# Scope Summary — {client}

> This is a commercial scope/acceptance draft, not legal advice.

## Project Overview
- Client: {client}
- Service: AI Operating System Implementation
- Start Date: TBD
- Target Go-Live: TBD

## Deliverables
1. AI Operating System core infrastructure
2. Workflow automation (up to 5 workflows)
3. Integration with existing tools
4. Training and documentation

## Acceptance Criteria
- [ ] System deployed and accessible
- [ ] Core workflows automated
- [ ] UAT passed by client
- [ ] Training completed
- [ ] Proof report approved

## Limitations
- Does not include guaranteed ROI
- Results depend on client data quality and participation
- Change requests require separate approval
""",
            "00_contract/acceptance_terms.md": f"""# Acceptance Terms — {client}

## Sign-off Criteria
1. All deliverables completed per scope
2. UAT sign-off from client stakeholder
3. Training attendance documented
4. No critical bugs open

## This is NOT legal advice
This document is a commercial scope/acceptance draft only.
Consult legal counsel for binding contractual documents.
""",
            "00_contract/invoice_stub.md": f"""# Invoice Stub — {client}

| Item | Amount (SAR) |
|------|-------------|
| AI OS Implementation | TBD |
| Training & Onboarding | TBD |
| Total | TBD |

## Payment
- Provider: Moyasar (when enabled)
- Status: Pending scope finalization

Note: MOYASAR_ENABLED=false — payment processing not active
""",
            "01_onboarding/welcome.md": f"""# Welcome — {client}

Welcome to your AI Operating System journey.

## Next Steps
1. Complete access checklist
2. Fill data request
3. Confirm stakeholder map
4. Schedule kickoff call

## Your Dealix Team
- Primary: Founder
- Support: ops@dealix.me
""",
            "01_onboarding/access_checklist.md": f"""# Access Checklist — {client}

- [ ] CRM access granted
- [ ] API keys shared (read-only)
- [ ] Database credentials (if applicable)
- [ ] Stakeholder calendar access
- [ ] Communication channel established
""",
            "01_onboarding/data_request.md": f"""# Data Request — {client}

Please provide:
1. Sample customer data (anonymized)
2. Current workflow documentation
3. Tool inventory (CRM, ERP, etc.)
4. Team structure and roles
5. KPI definitions
""",
            "01_onboarding/stakeholder_map.md": f"""# Stakeholder Map — {client}

| Role | Name | Contact | Decision Maker |
|------|------|---------|----------------|
| Sponsor | | | Yes |
| Day-to-day | | | No |
| IT/Technical | | | No |
| End User | | | No |
""",
            "02_diagnosis/current_state.md": f"""# Current State — {client}

## Business Context
- Industry:
- Size:
- Current tools:
- Key pain points:

## Operational Maturity
- [ ] Manual processes dominant
- [ ] Some automation exists
- [ ] Data-driven decisions
- [ ] AI experimentation
""",
            "02_diagnosis/pain_map.md": f"""# Pain Map — {client}

| Pain Area | Severity (1-5) | Impact | Frequency |
|-----------|---------------|--------|-----------|
| | | | |
| | | | |
| | | | |
""",
            "02_diagnosis/risk_register.md": f"""# Risk Register — {client}

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Data quality issues | Medium | High | Data audit phase |
| Low adoption | Medium | High | Training + change management |
| Integration complexity | Low | High | Scoping + fallback plans |
| Scope creep | High | Medium | Change request process |
""",
            "03_blueprint/system_blueprint.md": f"""# System Blueprint — {client}

## Architecture
- Core platform: Dealix AI OS
- Integration layer: API + webhooks
- Data layer: Client database + vector store
- Frontend: Custom dashboards

## Components
1. Workflow engine
2. AI agent orchestrator
3. Knowledge base
4. Analytics module
""",
            "03_blueprint/acceptance_criteria.md": f"""# Acceptance Criteria — {client}

## Must Have
- [ ] All workflows functional
- [ ] Data flowing correctly
- [ ] User authentication working
- [ ] Basic reporting available

## Nice to Have
- [ ] Advanced analytics
- [ ] Custom dashboards
- [ ] Mobile optimization
""",
            "04_build/sprint_plan.md": f"""# Sprint Plan — {client}

## Sprint 1: Foundation (Week 1-2)
- [ ] Environment setup
- [ ] Data connection
- [ ] Core workflow 1

## Sprint 2: Core Features (Week 3-4)
- [ ] Workflow 2-3
- [ ] Integration testing

## Sprint 3: Polish (Week 5-6)
- [ ] UAT preparation
- [ ] Documentation
- [ ] Training materials
""",
            "05_uat/uat_plan.md": f"""# UAT Plan — {client}

## Test Scenarios
1. Workflow execution end-to-end
2. Data accuracy checks
3. User permission verification
4. Error handling validation

## Sign-off
- Client tester:
- Date:
- Result: Pass / Fail / Conditional
""",
            "07_proof/weekly_proof_report.md": f"""# Weekly Proof Report — {client}

## Week of:

### Deliverables Completed
- 

### Metrics
- Workflows automated:
- Time saved (est.):
- User adoption rate:

### Client Feedback
- 

### Risks
- 

### Next Week
- 
""",
        }
        key = f"{phase_dir}/{filename}"
        return templates.get(key, f"# {filename.replace('.md', '').title()} — {client}\n\n(Template)\n")

    def _render_meta(self) -> str:
        return f"""# Client Metadata — {self.client_id}

- Created: auto-generated
- Status: onboarding
- Dealix ID: {self.client_id}
- Workspace: {self.root}
"""
