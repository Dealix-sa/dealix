"""Safety filter — blocks harmful or non-compliant content."""

from __future__ import annotations

import re


class SafetyFilter:
    """Filters AI inputs and outputs for safety."""

    BLOCKED_PATTERNS = [
        r"\b(hate\s+speech|racist|sexist|discriminatory)\b",
        r"\b(terrorist|bomb\s+making|weapon)\b",
        r"\b(scam|fraudulent|deceptive\s+practice)\b",
    ]

    @classmethod
    def is_safe(cls, text: str) -> bool:
        lower = text.lower()
        for pattern in cls.BLOCKED_PATTERNS:
            if re.search(pattern, lower):
                return False
        return True

    @classmethod
    def filter_output(cls, text: str) -> str:
        """Remove any blocked content from output."""
        if cls.is_safe(text):
            return text
        return "[Content filtered for safety. Please revise your request.]"
