"""
Dealix AI Provider Router with Safety Layer

Order: local/deterministic fallback → OpenAI → OpenRouter → DeepSeek → Groq → MiniMax → Kimi

Rules:
- No API dependency in tests
- All providers optional via env
- PII redaction before sending
- Prompt injection guard
- Token/cost guard
- No secrets in logs
"""

from app.ai.provider_router import AIProviderRouter
from app.ai.safety_filter import SafetyFilter
from app.ai.pii_redactor import PIIRedactor
from app.ai.prompt_injection_guard import PromptInjectionGuard

__all__ = ["AIProviderRouter", "SafetyFilter", "PIIRedactor", "PromptInjectionGuard"]
