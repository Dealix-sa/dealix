"""PII Redactor — removes personally identifiable information before AI calls."""

from __future__ import annotations

import os
import re


class PIIRedactor:
    """Redacts PII from text before sending to AI providers."""

    PATTERNS = {
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone": r"\b(?:\+?966|0)?5\d{8}\b|\b\+?1?\d{9,15}\b",
        "saudi_id": r"\b1\d{9}\b",
        "credit_card": r"\b(?:\d{4}[-\s]?){3}\d{4}\b",
        "iban": r"\bSA\d{22}\b",
    }

    @classmethod
    def redact(cls, text: str, allow_pii: bool = False) -> str:
        """Redact PII from text. If allow_pii is True, skip redaction."""
        if allow_pii:
            return text
        result = text
        for pii_type, pattern in cls.PATTERNS.items():
            result = re.sub(pattern, f"[{pii_type}_REDACTED]", result)
        return result

    @classmethod
    def has_pii(cls, text: str) -> bool:
        for pattern in cls.PATTERNS.values():
            if re.search(pattern, text):
                return True
        return False
