"""AI Provider Router — falls back gracefully when no API keys are present."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class AIResponse:
    provider: str
    content: str
    model: str = ""
    tokens_used: int = 0
    cost_usd: float = 0.0
    fallback: bool = False


class AIProviderRouter:
    """Routes AI requests through available providers with deterministic fallback."""

    PROVIDER_ORDER = ["openai", "openrouter", "deepseek", "groq", "minimax", "kimi"]

    def __init__(self) -> None:
        self.allow_pii = os.getenv("AI_ALLOW_PII", "false").lower() == "true"
        self.max_tokens = int(os.getenv("AI_MAX_TOKENS", "4000"))
        self.max_cost_usd = float(os.getenv("AI_MAX_COST_USD", "1.0"))
        self._providers_checked = False
        self._configured = None

    def _check_configuration(self) -> bool:
        if not self._providers_checked:
            self._configured = any(os.getenv(f"{p.upper()}_API_KEY") for p in self.PROVIDER_ORDER)
            self._providers_checked = True
        return bool(self._configured)

    def complete(self, prompt: str, system: str = "") -> AIResponse:
        """Get completion from first available provider, or deterministic fallback."""
        # Try each provider in order
        for provider in self.PROVIDER_ORDER:
            response = self._try_provider(provider, prompt, system)
            if response:
                return response

        # Deterministic fallback — no API call
        return self._fallback_response(prompt)

    def _try_provider(self, provider: str, prompt: str, system: str) -> Optional[AIResponse]:
        env_key = f"{provider.upper()}_API_KEY"
        if not os.getenv(env_key):
            return None
        # Provider integration placeholder — real implementation would call the API
        return None

    def _fallback_response(self, prompt: str) -> AIResponse:
        """Deterministic fallback when no providers are available."""
        # Simple rule-based response for common patterns
        lower = prompt.lower()
        if "email" in lower and "draft" in lower:
            return AIResponse(
                provider="fallback",
                content="I can draft emails when an AI provider is configured. For now, use the templates in app/channels/channel_router.py.",
                model="deterministic_fallback",
                fallback=True,
            )
        if "outbound" in lower or "sequence" in lower:
            return AIResponse(
                provider="fallback",
                content="Use ChannelRouter.generate_sequence() to create multi-channel sequences. Enable an AI provider for personalized drafts.",
                model="deterministic_fallback",
                fallback=True,
            )
        return AIResponse(
            provider="fallback",
            content="No AI provider configured. Set OPENAI_API_KEY or another provider key in your environment. Set AI_ALLOW_PII=true only if client approval exists.",
            model="deterministic_fallback",
            fallback=True,
        )

    def is_configured(self) -> bool:
        """Check if any AI provider is configured."""
        return self._check_configuration()
