"""Prompt injection guard — detects and blocks prompt injection attempts."""

from __future__ import annotations

import re


class PromptInjectionGuard:
    """Guards against prompt injection attacks."""

    INJECTION_PATTERNS = [
        r"ignore\s+(previous|above|earlier)\s+instructions",
        r"forget\s+(your|the)\s+(instructions|rules|prompt)",
        r"you\s+are\s+now\s+",
        r"system\s+prompt",
        r"\{\{\s*\}\}",  # Template injection
        r"<\s*script\s*>",
        r"\bDAN\b",  # Do Anything Now
        r"jailbreak",
        r"\badmin\b.*\bmode\b",
    ]

    @classmethod
    def is_injection_attempt(cls, text: str) -> bool:
        lower = text.lower()
        for pattern in cls.INJECTION_PATTERNS:
            if re.search(pattern, lower):
                return True
        return False

    @classmethod
    def sanitize(cls, text: str) -> str:
        if cls.is_injection_attempt(text):
            # Replace injection patterns with safe placeholder
            result = text
            for pattern in cls.INJECTION_PATTERNS:
                result = re.sub(pattern, "[FILTERED]", result, flags=re.IGNORECASE)
            return result
        return text
