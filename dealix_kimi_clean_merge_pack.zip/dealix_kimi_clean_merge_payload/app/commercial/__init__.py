"""
Dealix Commercial System

Proposal → Contract → Invoice/Payment → Onboarding

Note: This is a commercial scope/acceptance draft system, not legal advice.
"""

from app.commercial.proposal_to_contract import ProposalEngine
from app.commercial.invoice_stub import InvoiceStub

__all__ = ["ProposalEngine", "InvoiceStub"]
