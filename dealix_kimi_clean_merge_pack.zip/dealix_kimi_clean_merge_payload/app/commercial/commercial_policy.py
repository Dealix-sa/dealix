"""Commercial policy — ensures no fake claims or legal overreach."""

from __future__ import annotations

import re


class CommercialPolicy:
    """Validates commercial documents for compliance."""

    BLOCKED_PHRASES = [
        r"guaranteed\s+roi",
        r"guaranteed\s+return",
        r"guaranteed\s+results",
        r"100%\s+success",
        r"risk.free",
        r"no\s+risk",
        r"fake\s+testimonial",
    ]

    REQUIRED_DISCLAIMERS = [
        "not legal advice",
        "legal counsel",
    ]

    @classmethod
    def validate_proposal(cls, text: str) -> tuple[bool, str]:
        lower = text.lower()
        for pattern in cls.BLOCKED_PHRASES:
            if re.search(pattern, lower):
                return False, f"Blocked phrase: {pattern!r}"
        return True, "ok"

    @classmethod
    def validate_has_disclaimer(cls, text: str) -> bool:
        lower = text.lower()
        return any(d in lower for d in cls.REQUIRED_DISCLAIMERS)
