#!/usr/bin/env python3
"""Prepare the outbound queue from prospect list."""

from __future__ import annotations

import csv
import sys
from pathlib import Path

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
PROSPECTS_PATH = LEDGER_DIR / "prospects.csv"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"

QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]

def main() -> int:
    print("=== Prepare Outbound Queue ===\n")
    if not PROSPECTS_PATH.exists():
        print(f"  No prospects file at {PROSPECTS_PATH}")
        return 0

    # Ensure queue exists
    if not QUEUE_PATH.exists():
        QUEUE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(QUEUE_PATH, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=QUEUE_HEADER)
            writer.writeheader()
        print(f"  Created empty queue at {QUEUE_PATH}")

    # Count prospects and queue entries
    prospects = list(csv.DictReader(open(PROSPECTS_PATH, encoding="utf-8")))
    queue = list(csv.DictReader(open(QUEUE_PATH, encoding="utf-8")))

    print(f"  Prospects: {len(prospects)}")
    print(f"  Queue entries: {len(queue)}")
    print(f"  Mode: draft_only (default)")
    print("\n  Use `make outbound-dry` to preview or `make outbound-approve` to approve.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
