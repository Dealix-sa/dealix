#!/usr/bin/env python3
"""Run outbound in live mode — ONLY when controlled_live + EXTERNAL_SEND_ENABLED + approval."""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.outbound.policy_gate import OutboundPolicyGate


def main() -> int:
    print("=== Outbound LIVE Run ===\n")

    gate = OutboundPolicyGate()

    # Critical safety checks
    if gate.mode.value != "controlled_live":
        print(f"  BLOCKED: mode is {gate.mode.value}, not controlled_live")
        return 1

    if not gate.external_send:
        print("  BLOCKED: EXTERNAL_SEND_ENABLED is false")
        return 1

    if gate.require_approval:
        print("  Approval required: checking for approved messages...")

    print("\n  All safety checks passed.")
    print("  NOTE: This script does not auto-send.")
    print("  Use the API or manual trigger for actual sends.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
