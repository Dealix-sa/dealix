#!/usr/bin/env python3
"""Approve a batch of outbound messages for sending."""

from __future__ import annotations

import csv
import sys
from datetime import datetime, timezone
from pathlib import Path

LEDGER_DIR = Path(__file__).resolve().parents[2] / "ledgers"
QUEUE_PATH = LEDGER_DIR / "outbound_queue.csv"

QUEUE_HEADER = [
    "message_id", "company_id", "contact_id", "channel", "status", "subject",
    "body_path", "template_name", "source_url", "verification_status",
    "approval_status", "approved_by", "opt_in_required", "opt_in_status",
    "unsubscribe_required", "suppression_checked", "scheduled_at", "sent_at",
    "provider_message_id", "error_message", "next_action", "created_at", "updated_at",
]

def main() -> int:
    print("=== Approve Outbound Batch ===\n")
    if not QUEUE_PATH.exists():
        print("  No queue found. Run `make outbound-queue` first.")
        return 1

    rows = list(csv.DictReader(open(QUEUE_PATH, encoding="utf-8")))
    pending = [r for r in rows if r.get("approval_status") == "pending"]

    print(f"  Pending approval: {len(pending)}")

    if not pending:
        print("  Nothing to approve.")
        return 0

    # Auto-approve first 5 for demo (in production, this requires human review)
    approved_by = "founder_manual"
    approved_count = 0
    for row in pending[:5]:
        row["approval_status"] = "approved"
        row["approved_by"] = approved_by
        row["status"] = "approved"
        row["updated_at"] = datetime.now(timezone.utc).isoformat()
        approved_count += 1

    with open(QUEUE_PATH, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=QUEUE_HEADER)
        writer.writeheader()
        writer.writerows(rows)

    print(f"  Approved {approved_count} messages.")
    print("  Next: run `make outbound-dry` to preview, then `make outbound-live` (only if controlled_live).")
    return 0

if __name__ == "__main__":
    sys.exit(main())
