#!/usr/bin/env python3
"""Run outbound in dry-run mode — no actual sends."""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Ensure app is importable
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.channels.channel_router import ChannelRouter


def main() -> int:
    print("=== Outbound Dry Run ===\n")
    print(f"  OUTBOUND_MODE: {os.getenv('OUTBOUND_MODE', 'draft_only')}")
    print(f"  EXTERNAL_SEND_ENABLED: {os.getenv('EXTERNAL_SEND_ENABLED', 'false')}")
    print("\n  Dry run: generating drafts only, no sends.\n")

    router = ChannelRouter()

    # Demo sequence
    msgs = router.generate_sequence(
        contact_id="demo@example.com",
        company_name="Demo Corp",
        source_url="https://example.com",
        has_opt_in=False,
        has_phone=True,
    )

    print(f"  Generated {len(msgs)} message(s):\n")
    for i, msg in enumerate(msgs, 1):
        print(f"    {i}. [{msg.channel.value}] {msg.subject or '(no subject)'}")
        print(f"       Status: {msg.status.value}")
        print(f"       Approval: {msg.approval_status}")
        if msg.scheduled_at:
            print(f"       Scheduled: {msg.scheduled_at.strftime('%Y-%m-%d')}")
        print()

    print("  Dry run complete. No messages sent.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
