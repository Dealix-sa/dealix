#!/usr/bin/env python3
"""Check outbound environment configuration."""

from __future__ import annotations

import os
import sys

REQUIRED = [
    ("OUTBOUND_MODE", "draft_only", "Current outbound mode"),
    ("EXTERNAL_SEND_ENABLED", "false", "Master send switch"),
    ("EMAIL_SEND_ENABLED", "false", "Email channel"),
    ("WHATSAPP_SEND_ENABLED", "false", "WhatsApp channel"),
    ("SMS_SEND_ENABLED", "false", "SMS channel (opt-in only)"),
]

def main() -> int:
    print("=== Dealix Outbound Environment Check ===\n")
    issues = 0
    for var, default, desc in REQUIRED:
        val = os.getenv(var, f"[not set, default={default}]")
        safe = val != "true" if "ENABLED" in var else True
        status = "OK" if safe else "WARNING"
        if not safe:
            issues += 1
        print(f"  {var}: {val} ({desc}) [{status}]")

    mode = os.getenv("OUTBOUND_MODE", "draft_only")
    if mode not in ("disabled", "draft_only", "approval_queue", "controlled_live"):
        print(f"\n  ERROR: Invalid OUTBOUND_MODE: {mode}")
        issues += 1

    if issues == 0:
        print("\n  All safety checks passed. Default safe configuration confirmed.")
    else:
        print(f"\n  {issues} issue(s) found. Review before enabling live send.")
    return 0 if issues == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
