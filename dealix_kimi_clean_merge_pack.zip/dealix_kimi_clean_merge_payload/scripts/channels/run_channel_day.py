#!/usr/bin/env python3
"""Run a channel day — generate and queue multi-channel sequence."""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.channels.channel_router import ChannelRouter


def main() -> int:
    print("=== Channel Day ===\n")
    print(f"  OUTBOUND_MODE: {os.getenv('OUTBOUND_MODE', 'draft_only')}")

    router = ChannelRouter()
    msgs = router.generate_sequence(
        contact_id="sample@dealix.me",
        company_name="Sample Co",
        source_url="https://sample.co",
        has_opt_in=False,
        has_phone=True,
    )

    ids = router.submit_for_approval(msgs)
    print(f"  Queued {len(ids)} message(s) for approval.")
    print(f"  IDs: {', '.join(ids[:5])}{'...' if len(ids) > 5 else ''}")
    print("\n  Next: `make outbound-approve` to approve batch.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
