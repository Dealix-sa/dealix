#!/usr/bin/env python3
"""Run delivery day for a client."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.delivery.schemas import ClientDeliveryLog, DeliveryPhase, DeliveryStatus, log_delivery


def main() -> int:
    parser = argparse.ArgumentParser(description="Run delivery day")
    parser.add_argument("--client", required=True, help="Client ID")
    args = parser.parse_args()

    print(f"=== Delivery Day: {args.client} ===\n")

    # Log current phase as in_progress
    entry = ClientDeliveryLog(
        client_id=args.client,
        project_id=f"{args.client}_001",
        phase=DeliveryPhase.ONBOARDING,
        status=DeliveryStatus.IN_PROGRESS,
        deliverable="Client workspace setup",
        acceptance_criteria="All folders created, stakeholder map filled",
        next_action="Schedule kickoff call",
    )
    log_delivery(entry)
    print(f"  Logged delivery entry: {entry.phase.value} → {entry.status.value}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
