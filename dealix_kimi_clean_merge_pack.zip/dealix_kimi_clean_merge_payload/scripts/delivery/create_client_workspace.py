#!/usr/bin/env python3
"""Create client workspace — run with: make delivery-onboard CLIENT=client_001"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.delivery.project_workspace import ProjectWorkspace


def main() -> int:
    parser = argparse.ArgumentParser(description="Create client workspace")
    parser.add_argument("--client", required=True, help="Client ID")
    args = parser.parse_args()

    print(f"=== Create Client Workspace: {args.client} ===\n")

    workspace = ProjectWorkspace(args.client)
    if workspace.exists():
        print(f"  Workspace already exists at {workspace.root}")
        return 0

    created = workspace.create()
    print(f"  Created {len(created)} files:")
    for f in created[:10]:
        print(f"    - {f.relative_to(workspace.root)}")
    if len(created) > 10:
        print(f"    ... and {len(created) - 10} more")
    print(f"\n  Workspace ready at: {workspace.root}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
