#!/usr/bin/env python3
"""Generate invoice stub for a client."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.commercial.invoice_stub import InvoiceEngine


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate invoice stub")
    parser.add_argument("--client", required=True, help="Client ID")
    parser.add_argument("--amount", type=float, default=0.0, help="Amount in SAR")
    args = parser.parse_args()

    print(f"=== Invoice Stub: {args.client} ===\n")

    engine = InvoiceEngine()
    invoice = engine.create(args.client, amount_sar=args.amount)

    output_dir = Path(__file__).resolve().parents[2] / "clients" / args.client / "00_contract"
    path = engine.render_to_file(invoice, output_dir)

    print(f"  Written to {path}")
    print(f"  Status: {invoice.status}")
    if not invoice.moyasar_enabled:
        print("  NOTE: MOYASAR_ENABLED=false — payment processing not active.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
