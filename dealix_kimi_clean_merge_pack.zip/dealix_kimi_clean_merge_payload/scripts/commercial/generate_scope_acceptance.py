#!/usr/bin/env python3
"""Generate scope acceptance document — not legal advice."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.commercial.proposal_to_contract import ProposalEngine


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate scope acceptance")
    parser.add_argument("--client", required=True, help="Client ID")
    args = parser.parse_args()

    print(f"=== Scope Acceptance: {args.client} ===\n")

    engine = ProposalEngine()
    pack = engine.generate(args.client)
    doc = engine.generate_scope_acceptance(pack)

    output_dir = Path(__file__).resolve().parents[2] / "clients" / args.client / "00_contract"
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "scope_acceptance.md"
    path.write_text(doc, encoding="utf-8")

    print(f"  Written to {path}")
    print("  NOTE: This is a commercial scope/acceptance draft, not legal advice.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
