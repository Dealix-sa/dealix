#!/usr/bin/env python3
"""Check required environment variables for production."""

from __future__ import annotations

import os
import sys

REQUIRED_PROD = [
    "APP_ENV",
    "DATABASE_URL",
    "APP_SECRET_KEY",
    "JWT_SECRET_KEY",
]

REQUIRED_OUTBOUND = [
    "OUTBOUND_MODE",
    "EXTERNAL_SEND_ENABLED",
]

OPTIONAL_BUT_RECOMMENDED = [
    "EMAIL_SEND_ENABLED",
    "WHATSAPP_SEND_ENABLED",
    "MOYASAR_ENABLED",
]

def main() -> int:
    print("=== Required Environment Check ===\n")
    is_prod = os.getenv("APP_ENV") == "production"

    issues = 0
    if is_prod:
        print("  Production mode detected — checking required vars...\n")
        for var in REQUIRED_PROD:
            val = os.getenv(var)
            status = "OK" if val else "MISSING"
            if not val:
                issues += 1
            print(f"    {var}: {'[set]' if val else '[MISSING]'} [{status}]")
    else:
        print(f"  APP_ENV={os.getenv('APP_ENV', 'not set')} (not production)")
        print("  Skipping strict required var checks.\n")

    print("  Outbound vars:")
    for var in REQUIRED_OUTBOUND:
        val = os.getenv(var, "[not set]")
        print(f"    {var}: {val}")

    print("\n  Optional but recommended:")
    for var in OPTIONAL_BUT_RECOMMENDED:
        val = os.getenv(var, "[not set]")
        print(f"    {var}: {val}")

    if issues > 0:
        print(f"\n  {issues} missing required variable(s)")
        return 1
    print("\n  Environment check passed.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
