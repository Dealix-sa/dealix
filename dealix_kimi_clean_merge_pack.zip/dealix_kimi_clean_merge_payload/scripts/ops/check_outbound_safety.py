#!/usr/bin/env python3
"""Check outbound safety configuration."""

from __future__ import annotations

import os
import sys

def main() -> int:
    print("=== Outbound Safety Check ===\n")

    checks = {
        "EXTERNAL_SEND_ENABLED": os.getenv("EXTERNAL_SEND_ENABLED", "false").lower() == "false",
        "OUTBOUND_MODE": os.getenv("OUTBOUND_MODE", "draft_only") in ("disabled", "draft_only"),
        "EMAIL_SEND_ENABLED": os.getenv("EMAIL_SEND_ENABLED", "false").lower() == "false",
        "WHATSAPP_SEND_ENABLED": os.getenv("WHATSAPP_SEND_ENABLED", "false").lower() == "false",
        "WHATSAPP_ALLOW_LIVE_SEND": os.getenv("WHATSAPP_ALLOW_LIVE_SEND", "false").lower() == "false",
        "SMS_SEND_ENABLED": os.getenv("SMS_SEND_ENABLED", "false").lower() == "false",
    }

    all_safe = True
    for check, is_safe in checks.items():
        status = "SAFE" if is_safe else "LIVE"
        if not is_safe:
            all_safe = False
        print(f"  {check}: {status}")

    print()
    if all_safe:
        print("  All channels safe (default/off).")
    else:
        print("  WARNING: Some channels are LIVE. Review before proceeding.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
