# نظام تسليم العملاء الكامل — Dealix

## دورة التسليم

```
won → contract_pending → invoice_pending → payment_pending → onboarding → intake → diagnosis → blueprint → build → internal_qa → uat → launch → training → proof_report → managed_os → renewal_due → expanded → closed
```

## بنية مساحة العميل

```
clients/{client_id}/
  00_contract/       — العقد ونطاق العمل
  01_onboarding/     — التأهيل
  02_diagnosis/      — التشخيص
  03_blueprint/      — المخطط
  04_build/          — البناء
  05_uat/            — اختبار القبول
  06_training/       — التدريب
  07_proof/          — دليل النتائج
  08_retainer/       — العقد الدائم
```

## أوامر Make

```bash
make delivery-onboard CLIENT=client_001
make delivery-day CLIENT=client_001
make delivery-report CLIENT=client_001
make delivery-proof CLIENT=client_001
```

## مبادئ

- كل مرحلة لها معايير قبول
- لا ضمانات وهمية
- لا نتائج مضمونة
- الشفافية مع العميل
