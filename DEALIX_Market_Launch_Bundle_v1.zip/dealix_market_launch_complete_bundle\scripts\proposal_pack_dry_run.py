#!/usr/bin/env python3
"""Proposal pack dry-run.

Renders the example proposal to a Markdown summary.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "proposal_pack.example.json"


def main() -> int:
    print("DEALIX_PROPOSAL_PACK_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_PROPOSAL_PACK_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    print(f"proposal_id: {data.get('proposal_id')}")
    print(f"deal_id:     {data.get('deal_id')}")
    print(f"offer:       {(data.get('proposed_system') or {}).get('offer')}")
    print(f"pricing_status: {data.get('pricing_status')}")
    print("")
    print("Scope:")
    for k, v in (data.get("scope") or {}).items():
        print(f"  {k}: {v}")
    print("")
    print("Out of scope:")
    for line in data.get("out_of_scope") or []:
        print(f"  - {line}")
    print("")
    print("Success metrics:")
    for m in data.get("success_metrics") or []:
        print(f"  - {m}")
    print("")
    print("DEALIX_PROPOSAL_PACK_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
