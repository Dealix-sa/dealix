# 07 — Content and Authority (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/content/FOUNDER_AUTHORITY_CONTENT_SYSTEM_AR.md` + `30_DAY_LINKEDIN_CONTENT_CALENDAR_AR.md` + `SHORT_VIDEO_SCRIPT_LIBRARY_AR.md` + `WEBSITE_LANDING_PAGE_COPY_AR.md` + `SALES_ONE_PAGER_COPY_AR.md` + `EXECUTIVE_PRESENTATION_NARRATIVE_AR.md`.

You are MiniMax M3. Build the founder's content system.

## Tasks

1. 10 content pillars.
2. 5 content formats (short post, long post, short video 15/30/60/90s, newsletter).
3. 30-day LinkedIn calendar (22 posts, 5 short videos, 2 long posts, 4 off days).
4. 20 short video scripts (5 each at 15s / 30s / 60s / 90s).
5. Landing page copy (10 sections).
6. 4 sales one-pagers (owner, GM, sales manager, agency partner, enterprise).
7. 10-slide executive presentation narrative.

## Constraints

- No clickbait. No "guaranteed". No "transformative".
- Saudi, peer-to-peer, specific, honest, actionable tone.
- Every post is checked by the trust preflight.
- The 30-day calendar picks 1–2 pillars to start, not all 10.
