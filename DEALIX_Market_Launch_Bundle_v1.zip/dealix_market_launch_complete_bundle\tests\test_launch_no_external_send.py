"""Tests that no script in the bundle makes a network call or external send.

The dry-run scripts are allowed to read local files. They must not use
requests, smtplib, sendgrid, twilio, urllib, socket, or subprocess to
external hosts.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

FORBIDDEN = [
    r"requests\.(post|put|patch|delete)",
    r"smtplib",
    r"sendgrid",
    r"twilio",
    r"urllib\.request\.urlopen",
    r"socket\.connect",
    r"subprocess\.(run|Popen)\(.*\b(curl|wget|nc|telnet)\b",
]


def test_no_external_send_in_scripts():
    for path in (ROOT / "scripts").rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        for pat in FORBIDDEN:
            assert not re.search(pat, text), f"Network call {pat!r} in {path}"


def test_no_imports_of_sendgrid_or_twilio():
    for path in (ROOT / "scripts").rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        for lib in ["import sendgrid", "from sendgrid", "import twilio", "from twilio"]:
            assert lib not in text, f"Forbidden import {lib!r} in {path}"


def test_scripts_have_argparse_or_no_args():
    for path in (ROOT / "scripts").rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        # Soft check: scripts should at least have a main() and an entry-point.
        assert "def main" in text, f"No main() in {path}"
        assert "__name__" in text, f"No __name__ guard in {path}"
