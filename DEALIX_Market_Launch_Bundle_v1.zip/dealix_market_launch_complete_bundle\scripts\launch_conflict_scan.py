#!/usr/bin/env python3
"""Launch bundle conflict scan.

Reads the bundle and (optionally) the repo root, then reports potential
conflicts: bundle files whose names match files in the repo at a path
outside the bundle's target location. The script does NOT modify anything.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent


def _collect_files(root: Path) -> dict[str, Path]:
    out: dict[str, Path] = {}
    if not root.exists():
        return out
    for p in root.rglob("*"):
        if p.is_file():
            out[str(p.relative_to(root)).replace("\\", "/")] = p
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=None)
    parser.add_argument("--bundle-root", type=Path, default=BUNDLE)
    args = parser.parse_args()

    bundle_files = _collect_files(args.bundle_root)
    print(f"DEALIX_LAUNCH_CONFLICT_SCAN")
    print(f"bundle_root: {args.bundle_root}")
    print(f"bundle_files: {len(bundle_files)}")
    print("")

    if args.repo_root is None:
        print("No --repo-root provided. Listing bundle files only.")
        for name in sorted(bundle_files):
            print(f"  bundle: {name}")
        print("")
        print("DEALIX_LAUNCH_CONFLICT_SCAN=OK (no repo scan)")
        return 0

    repo_files = _collect_files(args.repo_root)
    print(f"repo_root: {args.repo_root}")
    print(f"repo_files: {len(repo_files)}")
    print("")

    # The bundle lives at _incoming/minimax3/.../  which is itself under the
    # repo. We compare the bundle's *internal* file names against the *rest*
    # of the repo. A conflict = same name in the bundle and in the repo at
    # a non-bundle path.
    bundle_name_prefix = "_incoming/minimax3/dealix_market_launch_complete_bundle/"
    bundle_internal: dict[str, Path] = {}
    for name, path in bundle_files.items():
        if name.startswith(bundle_name_prefix):
            internal = name[len(bundle_name_prefix):]
            bundle_internal[internal] = path
        else:
            bundle_internal[name] = path

    repo_excluding_bundle = {
        name: path
        for name, path in repo_files.items()
        if not name.startswith(bundle_name_prefix)
    }

    conflicts = []
    for name in sorted(bundle_internal):
        if name in repo_excluding_bundle:
            conflicts.append(name)

    print(f"Conflicts (bundle file already exists in repo): {len(conflicts)}")
    for name in conflicts[:20]:
        print(f"  CONFLICT  {name}")
    if len(conflicts) > 20:
        print(f"  ... and {len(conflicts) - 20} more")
    print("")
    print("DEALIX_LAUNCH_CONFLICT_SCAN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
