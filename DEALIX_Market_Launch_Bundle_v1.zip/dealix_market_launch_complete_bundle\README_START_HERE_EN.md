# Dealix Market Launch — Start Here (EN)

> **Bundle:** `dealix_market_launch_complete_bundle/`
> **Generated:** 2026-06-12.
> **Audience:** the founder. Only file to read on day 1.
> **Read time:** 5 minutes.

## What this is

A complete bundle (100+ files) covering everything you need to actually start the Saudi market for Dealix in days, not months. Additive — does not modify the repo, does not send messages, does not call APIs, does not create final prices.

## Who you are

The founder. You have the Dealix V6–V10 enterprise-scale repo. You do not need to build. You need to **operate**.

## Read in this order (5 files only)

1. **`02_FIRST_7_DAYS_EXECUTION.md`** — day-by-day, first week.
2. **`docs/strategy/BEST_FIRST_WEDGE_DECISION_AR.md`** (AR; translate mentally) — which vertical, which offer, why.
3. **`04_DAILY_FOUNDER_COMMAND.md`** — the daily routine (15 min).
4. **`docs/offers/REVENUE_LEAK_AUDIT_OFFER_AR.md`** (AR; translate mentally) — the first offer to sell.
5. **`docs/sales/OBJECTION_HANDLING_BIBLE_AR.md`** (AR; translate mentally) — top 25 objections.

## The rest

- `00_REPO_LAUNCH_INVENTORY.md` — repo map (what exists, what we add).
- `01_MERGE_PLAN.md` — how to merge safely.
- `03_30_60_90_DAY_PLAN.md` — 90-day plan.
- `05_LAUNCH_ACCEPTANCE_REPORT.md` — bundle status, what works, what needs founder review.

## 5 commands to try

```bash
# 1. Validate the bundle.
python scripts/launch_bundle_validate.py

# 2. Run conflict scan.
python scripts/launch_conflict_scan.py --repo-root . --bundle-root .

# 3. See the top 3 verticals.
python scripts/vertical_score_dry_run.py

# 4. Try ICP scoring.
python scripts/icp_score_dry_run.py

# 5. Run the tests.
python -m pytest tests/ -q --no-cov
```

## 5 rules that never break

1. **No cold WhatsApp.** Consent only.
2. **No guaranteed ROI.** Proof metric only.
3. **No final price without founder approval.** Every draft has `pricing_status: draft_only`.
4. **No payment link.** The bundle does not generate them.
5. **No trust preflight bypass.** Every draft runs through `scripts/trust_preflight_dry_run.py`.

## If you have 30 minutes

1. Read `02_FIRST_7_DAYS_EXECUTION.md`.
2. Open `templates/launch/target_account.example.json`.
3. Send the first email. No delay.

## If you have 5 days

Day 1: read + decide vertical.
Day 2: research 10 companies.
Day 3: write 10 drafts.
Day 4: run preflight, send.
Day 5: review replies, decide next step.

## If you have 30 days

Open `03_30_60_90_DAY_PLAN.md` and follow it.

## The most important thing

> The bundle does not sell. You sell. The bundle makes you sell fast, accurately, and without disasters.

Start.
