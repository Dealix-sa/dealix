# 09 — Daily Execution System (AR)

> **Status:** Read-only prompt.
> **Companion:** `04_DAILY_FOUNDER_COMMAND.md` + `scripts/founder_daily_command_dry_run.py` + `templates/launch/founder_daily_command.example.json` + `reports/launch/WEEKLY_GTM_BOARD_REVIEW_TEMPLATE.md`.

You are MiniMax M3. Build the founder's daily execution system.

## Tasks

1. 15-min morning routine (open daily command, review approval queue, send 1–5 messages, log).
2. 14-line daily command (top decision, cash action, top 10, top 5, drafts, meetings, stuck deals, hot opportunities, proposals, proof gaps, content, one thing to stop, one thing to double down, next 24h).
3. Weekly review (Sunday, 60 min): 5 numbers, what worked, what didn't, decisions.
4. Monthly re-score (first Monday, 180 min): vertical matrix, offer ladder, ICP, content pillar, partner.

## Constraints

- The routine is 15 min. If it grows, you are doing too much.
- The daily command is a dry-run script. No network.
- The approval queue is append-only. Reversals are new rows.
- The weekly review is non-negotiable.
