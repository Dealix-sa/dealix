#!/usr/bin/env python3
"""Outreach draft factory dry-run.

Picks a sequence (A/B/C/D) based on the persona in the example draft.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "outreach_draft.example.json"

PERSONA_TO_SEQUENCE = {
    "owner_operator": "A",
    "head_of_sales": "B",
    "general_manager": "C",
    "spouse_partner": "A",
    "skeptic": "D",
}


def main() -> int:
    print("DEALIX_OUTREACH_DRAFT_FACTORY_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_OUTREACH_DRAFT_FACTORY_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    persona = data.get("persona", "owner_operator")
    sequence = PERSONA_TO_SEQUENCE.get(persona, "A")
    print(f"persona:   {persona}")
    print(f"sequence:  {sequence}")
    print(f"step:      {data.get('step')}")
    print(f"channel:   {data.get('channel')}")
    print(f"subject:   {data.get('subject')}")
    print(f"evidence:  {data.get('evidence_level')}")
    print(f"risk:      {data.get('risk_level')}")
    print(f"approval:  {data.get('approval_required')}")
    print(f"pricing:   {data.get('pricing_status')}")
    print("")
    print("See docs/sales/EMAIL_SEQUENCE_LIBRARY_AR.md for the full library.")
    print("")
    print("DEALIX_OUTREACH_DRAFT_FACTORY_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
