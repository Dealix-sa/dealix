#!/usr/bin/env python3
"""ICP score dry-run.

Reads the example ICP score and prints the breakdown + action.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "icp_score.example.json"


def main() -> int:
    print("DEALIX_ICP_SCORE_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_ICP_SCORE_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    print(f"account_id: {data.get('account_id')}")
    print(f"total: {data.get('total')}/100")
    print(f"action: {data.get('action')}")
    print("")
    print("Scores breakdown:")
    for k, v in (data.get("scores") or {}).items():
        print(f"  {k:<32} {v}")
    print("")
    print("Thresholds:")
    print("  80+  pursue_today")
    print("  65-79 warm_sequence")
    print("  50-64 nurture")
    print("  <50  ignore")
    print("  any critical compliance risk = manual_review")
    print("")
    print("DEALIX_ICP_SCORE_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
