# 04 — Outreach and Approval (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/sales/EMAIL_SEQUENCE_LIBRARY_AR.md` + `OUTREACH_APPROVAL_PLAYBOOK_AR.md`.

You are MiniMax M3. Build the outreach library (4 channels, 4 sequences) and the approval flow.

## Tasks

1. Email sequences: A (Owner-Operator), B (Head of Sales), C (GM), D (Skeptic). Each has first touch + 2 follow-ups + breakup.
2. LinkedIn manual outreach (no automation, no scraping).
3. Phone call scripts (no robo-dialer).
4. WhatsApp-after-consent library (consent record required).
5. The follow-up system (3 categories, 5 follow-up types, 5 timing rules).
6. The approval flow (drafted → preflight → queue → founder → sent → logged).
7. The trust preflight catches the banned patterns.

## Constraints

- Every external draft has `evidence_level`, `risk_level`, `approval_required=true`, `pricing_status`.
- No scraping. No automation. No auto-DM.
- WhatsApp only after explicit consent (consent_id referenced).
- The preflight is regex + schema + code (N/A for drafts).
