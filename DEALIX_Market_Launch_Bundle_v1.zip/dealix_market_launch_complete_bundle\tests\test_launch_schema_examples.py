"""Tests for the example JSONs against the schemas."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
SCHEMAS = ROOT / "schemas" / "launch"
TEMPLATES = ROOT / "templates" / "launch"


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_vertical_score_example_matches_schema():
    schema = _load(SCHEMAS / "vertical_score.schema.json")
    data = _load(TEMPLATES / "vertical_score.example.json")
    try:
        import jsonschema
    except ImportError:
        pytest.skip("jsonschema not installed")
    jsonschema.validate(instance=data, schema=schema)


def test_icp_score_example_matches_schema():
    schema = _load(SCHEMAS / "icp_score.schema.json")
    data = _load(TEMPLATES / "icp_score.example.json")
    try:
        import jsonschema
    except ImportError:
        pytest.skip("jsonschema not installed")
    jsonschema.validate(instance=data, schema=schema)


def test_target_account_example_matches_schema():
    schema = _load(SCHEMAS / "target_account.schema.json")
    data = _load(TEMPLATES / "target_account.example.json")
    try:
        import jsonschema
    except ImportError:
        pytest.skip("jsonschema not installed")
    jsonschema.validate(instance=data, schema=schema)


def test_outreach_draft_example_matches_schema():
    schema = _load(SCHEMAS / "outreach_draft.schema.json")
    data = _load(TEMPLATES / "outreach_draft.example.json")
    try:
        import jsonschema
    except ImportError:
        pytest.skip("jsonschema not installed")
    jsonschema.validate(instance=data, schema=schema)


def test_proof_pack_example_matches_schema():
    schema = _load(SCHEMAS / "proof_pack.schema.json")
    data = _load(TEMPLATES / "proof_pack.example.json")
    try:
        import jsonschema
    except ImportError:
        pytest.skip("jsonschema not installed")
    jsonschema.validate(instance=data, schema=schema)


def test_founder_daily_command_example_matches_schema():
    schema = _load(SCHEMAS / "founder_daily_command.schema.json")
    data = _load(TEMPLATES / "founder_daily_command.example.json")
    try:
        import jsonschema
    except ImportError:
        pytest.skip("jsonschema not installed")
    jsonschema.validate(instance=data, schema=schema)
