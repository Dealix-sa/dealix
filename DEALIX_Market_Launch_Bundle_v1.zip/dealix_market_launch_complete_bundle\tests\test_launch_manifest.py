"""Tests for the launch bundle manifest."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
MANIFEST = ROOT / "LAUNCH_BUNDLE_MANIFEST.json"


def test_manifest_exists():
    assert MANIFEST.exists(), f"Manifest missing at {MANIFEST}"


def test_manifest_is_valid_json():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert isinstance(data, dict)


def test_manifest_required_fields():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    for k in ["bundle_name", "version", "created_at", "purpose", "files", "integration_steps", "rollback_steps", "known_limitations"]:
        assert k in data, f"Missing {k}"


def test_manifest_policies_are_true():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    assert data.get("non_overwrite_policy") is True
    assert data.get("network_free") is True
    assert data.get("external_send_free") is True


def test_manifest_files_no_duplicates():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    paths = [f.get("path") for f in data.get("files", [])]
    assert len(paths) == len(set(paths)), "Duplicate paths in manifest files."


def test_manifest_files_required_keys():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    for f in data.get("files", []):
        for k in ["path", "type", "purpose", "risk_level", "requires_approval"]:
            assert k in f, f"File {f.get('path')} missing {k}"


def test_every_listed_file_exists():
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    missing = [f["path"] for f in data.get("files", []) if not (ROOT / f["path"]).exists()]
    # Allow some files to be planned but not yet shipped; the test only flags unexpected absences.
    assert not missing, f"Listed but missing: {missing}"
