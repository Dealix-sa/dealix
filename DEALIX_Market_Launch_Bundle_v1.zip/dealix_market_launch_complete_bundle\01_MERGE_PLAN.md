# 01 — Merge Plan

> **Status:** Generated 2026-06-12. Read before applying anything.
> **Audience:** the founder / engineering owner. No merge happens without your eyes on this.
> **Policy:** the bundle is **additive only** until you decide otherwise. The patches are optional.

## 1. Goal

Bring the GTM/Revenue overlay into the repo without breaking what is already there. The repo is at V6–V10 enterprise scale — the bundle's job is to **operate** that scale, not rebuild it.

## 2. Three integration modes

The bundle supports three modes. Pick one. The default is **Mode A**.

### Mode A — Bundle as standalone (recommended for week 1)

Keep the bundle in `_incoming/minimax3/dealix_market_launch_complete_bundle/`. Do not touch the repo. Use the bundle's docs, scripts, and templates from there. Run the `make launch-*` targets via wrapper scripts (or just call `python .../scripts/launch_*.py`).

Pros:
- Zero risk to the running repo.
- The bundle can be replaced or removed without a git history trace.
- Easy to A/B test bundle vs repo content.

Cons:
- Two sources of truth (bundle docs + repo docs). The bundle's `00_REPO_LAUNCH_INVENTORY.md` is the bridge.

### Mode B — Promote select docs into the repo

For docs that the founder will read every day (e.g. `02_FIRST_7_DAYS_EXECUTION.md`, `04_DAILY_FOUNDER_COMMAND.md`), copy them into `docs/strategy/` or `docs/sales/`. The `01_MERGE_PLAN.md` (this file) becomes a one-time migration doc.

Pros:
- One source of truth.
- Found in the same place as everything else.

Cons:
- Risk of accidental overwrites if two people edit the same file.
- Need a follow-up commit to remove the bundle once promoted.

### Mode C — Apply the optional patches

Apply `patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch` to get `make launch-*` targets. Optionally apply the web and API patches to get a launch UI and dry-run endpoints.

Pros:
- Native feel — `make launch-validate` instead of `python _incoming/.../scripts/launch_validate.py`.

Cons:
- The patches touch the Makefile and possibly the Next.js routes / FastAPI routers. Wrong patch application can break CI.
- We do not auto-apply. You apply, you test, you commit.

## 3. Recommended order (Mode A, week 1)

```bash
# 1. Unzip the bundle (this is the only step required for Mode A).
mkdir -p _incoming/minimax3
unzip dealix_market_launch_complete_bundle.zip -d _incoming/minimax3

# 2. Validate it.
python _incoming/minimax3/.../scripts/launch_bundle_validate.py

# 3. Run the conflict scan.
python _incoming/minimax3/.../scripts/launch_conflict_scan.py \
    --repo-root . \
    --bundle-root _incoming/minimax3/dealix_market_launch_complete_bundle

# 4. Run the tests.
python -m pytest _incoming/minimax3/.../tests -q --no-cov

# 5. Read the four orientation files.
cat _incoming/minimax3/.../README_START_HERE_AR.md
cat _incoming/minimax3/.../02_FIRST_7_DAYS_EXECUTION.md
cat _incoming/minimax3/.../docs/strategy/BEST_FIRST_WEDGE_DECISION_AR.md
cat _incoming/minimax3/.../04_DAILY_FOUNDER_COMMAND.md
```

That is enough for the first 7 days. No Makefile changes, no web changes, no API changes.

## 4. Optional: apply the Makefile patch (week 2+)

```bash
# Inspect the patch first.
cat _incoming/minimax3/.../patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch

# If you agree, apply it.
git apply _incoming/minimax3/.../patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch

# Verify.
make help | grep launch-

# Roll back if needed.
git apply -R _incoming/minimax3/.../patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch
```

The patch adds 10 targets (all dry-run, all safe):

- `make launch-validate` — bundle validation
- `make launch-conflict-scan` — repo-vs-bundle conflict scan
- `make launch-vertical-score` — print the 15-sector matrix + top 3
- `make launch-icp-score` — load `templates/launch/icp_score.example.json` and explain the math
- `make launch-founder-command` — print today's founder command from the example
- `make launch-outreach-drafts` — print a sample outreach draft set
- `make launch-trust-preflight` — run the preflight on the example drafts
- `make launch-proposal-dry-run` — render the proposal example
- `make launch-content-dry-run` — render the content calendar example
- `make launch-weekly-review` — render the weekly review example

## 5. Optional: apply the web and API patches (week 3+)

The web patch scaffolds:

- `apps/web/src/app/[locale]/command/launch/page.tsx` (or the equivalent under `frontend/`)
- A read-only "Launch Command" page that consumes the same data the bundle scripts print.

The API patch adds:

- `GET /api/launch/founder-command` (dry-run, returns the example JSON)
- `GET /api/launch/icp-score` (dry-run)
- `GET /api/launch/outreach-draft` (dry-run)
- `GET /api/launch/trust-preflight` (dry-run)

Both are **read-only**. Neither writes to the DB. Neither sends external traffic. Apply them only if you want the UI / API surface.

## 6. What you should NOT do

- Do not copy the bundle into `docs/` wholesale. The bundle is **a folder of decisions**, not a folder of truth. Promote the ones you read every day; leave the rest.
- Do not apply both the bundle scripts and the patched Makefile targets with the same intent. Pick one. Mixing `make launch-validate` with `python _incoming/.../scripts/launch_validate.py` works but is confusing.
- Do not commit the bundle to the repo unless you intend to keep it. The bundle is a one-shot artifact, not a permanent addition.
- Do not delete `00_REPO_LAUNCH_INVENTORY.md` even after merge. It is the documentation of *why* each file exists or does not exist.

## 7. Rollback

```bash
# Roll back the Makefile patch.
git apply -R _incoming/minimax3/.../patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch

# Remove the bundle directory.
rm -rf _incoming/minimax3

# Confirm the repo is clean.
git status
```

The bundle never modifies a tracked file by itself. The rollback is "delete the directory" plus reversing the patch.

## 8. What needs founder review before the first send

The following files contain Saudi-specific copy that needs a native-Arabic pass:

- `docs/offers/REVENUE_LEAK_AUDIT_OFFER_AR.md`
- `docs/offers/WHATSAPP_FOLLOWUP_OS_OFFER_AR.md`
- `docs/offers/SALES_COMMAND_CENTER_OFFER_AR.md`
- `docs/offers/PROPOSAL_PROOF_PACK_OS_OFFER_AR.md`
- `docs/offers/AI_OPERATING_SYSTEM_FOR_SMB_OFFER_AR.md`
- `docs/offers/CUSTOM_ENTERPRISE_OS_OFFER_AR.md`
- `docs/sales/EMAIL_SEQUENCE_LIBRARY_AR.md`
- `docs/sales/LINKEDIN_MANUAL_OUTREACH_LIBRARY_AR.md`
- `docs/sales/PHONE_CALL_SCRIPT_LIBRARY_AR.md`
- `docs/sales/WHATSAPP_AFTER_CONSENT_LIBRARY_AR.md`
- `docs/sales/OBJECTION_HANDLING_BIBLE_AR.md`
- `docs/content/SHORT_VIDEO_SCRIPT_LIBRARY_AR.md`
- `docs/content/WEBSITE_LANDING_PAGE_COPY_AR.md`
- `docs/content/SALES_ONE_PAGER_COPY_AR.md`

Read each one before any external use. The trust preflight will catch **pattern** issues (regex for "guaranteed ROI", "cold WhatsApp", etc.) but it will not catch **tone** issues ("this phrasing sounds off to a Saudi CEO"). The native review is on you.

## 9. Founder-facing decisions that the bundle does **not** make

The bundle ships defaults. The founder decides:

- **The first vertical** — the default is documented in `docs/strategy/BEST_FIRST_WEDGE_DECISION_AR.md`. Override based on your network.
- **The first offer** — the default is `Revenue Leak Audit`. Override if your first 10 leads ask for something else.
- **The first price range** — the bundle ships `pricing_status: draft_only` on every offer. The first price range needs founder sign-off.
- **The first content pillar** — the bundle ships 10 pillars. Pick 1 to start, not all 10.
- **The first partner** — the bundle ships 4 partner playbooks. Do not chase partners in week 1.

## 10. Next: see `02_FIRST_7_DAYS_EXECUTION.md`
