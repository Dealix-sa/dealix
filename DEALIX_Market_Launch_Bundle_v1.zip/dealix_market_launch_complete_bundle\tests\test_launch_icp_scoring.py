"""Tests for the ICP scoring rubric."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _load_script(name: str):
    path = ROOT / "scripts" / name
    spec = importlib.util.spec_from_file_location(name[:-3], path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_icp_score_pursue_today_above_80():
    mod = _load_script("icp_score_dry_run.py")
    result = mod.main()
    assert result == 0


def test_icp_score_thresholds():
    """Manual test of the thresholds logic."""
    cases = [
        (85, "pursue_today"),
        (72, "warm_sequence"),
        (55, "nurture"),
        (40, "ignore"),
    ]
    for total, expected in cases:
        if total >= 80:
            assert expected == "pursue_today"
        elif total >= 65:
            assert expected == "warm_sequence"
        elif total >= 50:
            assert expected == "nurture"
        else:
            assert expected == "ignore"


def test_risk_subtracts_from_total():
    # Verify that compliance_delivery_risk (negative weight) reduces total.
    scores_no_risk = {
        "urgency": 20, "lost_revenue_visibility": 15, "process_chaos": 15,
        "decision_maker_access": 10, "ability_to_start_small": 10, "proof_speed": 10,
        "budget_likelihood": 10, "repeatability": 5, "referral_potential": 5,
        "compliance_delivery_risk": 0,
    }
    total_no_risk = sum(scores_no_risk.values())
    scores_with_risk = dict(scores_no_risk)
    scores_with_risk["compliance_delivery_risk"] = -10
    total_with_risk = sum(scores_with_risk.values())
    assert total_with_risk < total_no_risk
    assert total_with_risk == total_no_risk - 10
