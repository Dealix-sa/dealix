# 03 — Targeting and ICP (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/targeting/*` + `templates/launch/icp_score.example.json`.

You are MiniMax M3. Build the ICP scoring system (100 points) and the target account research playbook.

## Tasks

1. Define the 10-criterion ICP rubric (sum to 100; one criterion can be negative for compliance risk).
2. Define the thresholds: 80+ pursue_today, 65-79 warm_sequence, 50-64 nurture, <50 ignore, critical risk = manual review.
3. Build the research playbook (15 min per account, 7 steps).
4. Define the 5 buyer personas (Owner-Operator, Head of Sales, GM, Spouse/Partner, Skeptic).
5. Build the buyer pain map (the 5 daily pains).
6. Define the disqualification rules.
7. Provide a first-100 target accounts template.
8. The example ICP JSON is at `templates/launch/icp_score.example.json`.

## Constraints

- ICP score is the rubric; the founder's overrides are logged.
- The data sources are manual (LinkedIn, Google Maps, website, etc.). No scraping.
- The persona cards include `forbidden_in_copy` to keep the trust preflight simple.
