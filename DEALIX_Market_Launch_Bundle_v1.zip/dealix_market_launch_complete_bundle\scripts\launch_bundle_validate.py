#!/usr/bin/env python3
"""Launch bundle validator — count files and validate the manifest.

No network. No secrets. Reads the bundle directory and prints counts.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
MANIFEST = BUNDLE / "LAUNCH_BUNDLE_MANIFEST.json"

EXPECTED_TOP_LEVEL = [
    "README_START_HERE_AR.md",
    "README_START_HERE_EN.md",
    "00_REPO_LAUNCH_INVENTORY.md",
    "01_MERGE_PLAN.md",
    "02_FIRST_7_DAYS_EXECUTION.md",
    "03_30_60_90_DAY_PLAN.md",
    "04_DAILY_FOUNDER_COMMAND.md",
    "05_LAUNCH_ACCEPTANCE_REPORT.md",
    "LAUNCH_BUNDLE_MANIFEST.json",
]

EXPECTED_SUBDIRS = {
    "docs/strategy": 5,
    "docs/offers": 8,
    "docs/targeting": 6,
    "docs/sales": 11,
    "docs/proposal": 7,
    "docs/content": 6,
    "docs/delivery": 4,
    "docs/trust": 5,
    "schemas/launch": 12,
    "templates/launch": 11,
    "reports/launch": 10,
    "scripts": 10,
    "tasks/minimax3_launch": 10,
    "evals/launch": 5,
    "tests": 5,
    "patches": 4,
}


def main() -> int:
    print("DEALIX_LAUNCH_BUNDLE_VALIDATE")
    print(f"bundle_root: {BUNDLE}")
    print("")
    print("Top-level files:")
    for name in EXPECTED_TOP_LEVEL:
        path = BUNDLE / name
        status = "OK" if path.exists() else "MISSING"
        print(f"  {status:<10} {name}")

    print("")
    print("Subdirectory counts (expected / actual):")
    for sub, expected in EXPECTED_SUBDIRS.items():
        sub_path = BUNDLE / sub
        if not sub_path.exists():
            print(f"  MISSING  {sub}/  (expected {expected} files)")
            continue
        actual = sum(1 for _ in sub_path.rglob("*") if _.is_file())
        status = "OK" if actual >= expected else "SHORT"
        print(f"  {status:<10} {sub}/  expected>={expected}  actual={actual}")

    print("")
    if MANIFEST.exists():
        try:
            data = json.loads(MANIFEST.read_text(encoding="utf-8"))
            print(f"Manifest: {data.get('bundle_name')} v{data.get('version')}")
            print(f"  non_overwrite_policy: {data.get('non_overwrite_policy')}")
            print(f"  network_free: {data.get('network_free')}")
            print(f"  external_send_free: {data.get('external_send_free')}")
            print(f"  files: {len(data.get('files', []))}")
        except json.JSONDecodeError as exc:
            print(f"Manifest: INVALID JSON ({exc})")
            return 1
    else:
        print("Manifest: MISSING")
        return 1

    print("")
    print("DEALIX_LAUNCH_BUNDLE_VALIDATE=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
