# 00 — Dealix Repo Launch Inventory (for the GTM/Revenue Overlay)

> **Status:** Generated 2026-06-12 for the `dealix_market_launch_complete_bundle/` overlay.
> **Repo state:** `feature/dealix-v6-v10-scale-enterprise-os` @ `f8b4cbb`.
> **Bundle policy:** **non-overwrite, additive only**. Files matching existing repo paths at ≥60% functional overlap are flagged `skip` or `reference_only` and pointed to in the merge plan.

This inventory is a **conflict scan** done by reading the actual repo. It is the basis for every file-or-skip decision in this bundle. Read it before you merge anything.

## 1. How to read this

| Action | Meaning |
| --- | --- |
| `skip` | The repo already has it. We link to it from the bundle but do not duplicate. |
| `create` | New content, no conflict, fills a real gap. |
| `optional_patch` | A patch file in `patches/` is shipped. The founder can apply it but nothing breaks if they don't. |
| `reference_only` | The bundle reads it but ships nothing. |

`risk_level` is the **cost of getting this wrong**:
- `low` = doc/template/example only, no behavior change.
- `medium` = touches config or Makefile; needs a human eyeball.
- `high` = touches runtime, network, secrets, or money paths.

## 2. Repo surface (top-level)

| Path | Purpose | Decision |
| --- | --- | --- |
| `api/` | FastAPI app, 120+ routers | `skip` — bundle references, never edits |
| `apps/web/` (or `frontend/`) | Next.js public + ops UI | `skip` — optional UI patch only |
| `core/`, `integrations/`, `connectors/` | business logic and integrations | `skip` |
| `auto_client_acquisition/`, `autonomous_growth/` | AI agent + growth modules | `skip` |
| `dealix/` | OS layers (commercial, trust, governance, hermes, llm, payments, marketing_factory, revenue_ops_autopilot, execution_assurance) | `skip` — bundle calls into them but ships nothing in them |
| `docs/` | 200+ markdown files across `strategy/`, `sales/`, `offers/`, `outreach/`, `pitch/`, `market/`, `content/`, `customer_success/`, `whatsapp/`, `security/`, `commercial/`, `delivery/`, `go-to-market/` and more | `reference_only` — see §3 |
| `reports/` | 100+ markdown reports (daily, weekly, monthly, sales, finance, governance) | `reference_only` |
| `sales/`, `data/templates/`, `prompts/` | sales scripts, content templates, prompt registry | `reference_only` |
| `schemas/` | existing JSON schemas (governance, model_registry, ...) | `skip` — bundle adds new ones in `schemas/launch/` not at root |
| `scripts/` | 100+ operational scripts (verify, audit, snapshot, lead-machine, founder-cockpit, ...) | `skip` — bundle scripts live in `_incoming/minimax3/.../scripts/` and never touch this dir |
| `tests/` | 500+ pytest files | `skip` — bundle tests live next to the bundle |
| `Makefile` | 30+ targets including `prod-verify`, `doctor`, `v5-verify`, `v10-verify`, `security-redteam`, `trust-gates`, `outbound-safety`, `whatsapp-safety`, `privacy-guard`, `minimax-status`, `minimax-evals` (added in P0 PR) | `skip` — `patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch` only |
| `data/ai_ops/model_registry.yaml` + `schemas/model_registry.schema.json` | LLM provider registry | `skip` |
| `tasks/minimax/` (P0 PR) | MiniMax master + 6 sub-prompts | `reference_only` |
| `_incoming/minimax3/dealix_market_launch_complete_bundle/` | **this bundle** (target location) | n/a |

## 3. Docs and templates that already cover our requested topics

This is the **most important section** — it tells you what to skip.

### 3.1 Strategy & positioning

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| `docs/strategy/DEALIX_MARKET_ENTRY_STRATEGY_AR.md` | `docs/strategy/DEALIX_FULL_OPS_MASTER_PLAN_AR.md` (17.5 KB) + `docs/strategy/DEALIX_CATEGORY_STRATEGY_AR.md` + `docs/strategy/MARKET_MAP_SAUDI.md` | **skip** — link to the three existing docs |
| `docs/strategy/SAUDI_VERTICAL_SELECTION_MATRIX_AR.md` | `docs/strategy/VERTICAL_PLAYBOOKS.md` + `docs/strategy/REVENUE_FOCUS_AREAS.md` + `docs/strategy/STRATEGIC_OPPORTUNITIES.md` | **skip** — bundle adds a sharper, scored matrix in `docs/strategy/SAUDI_VERTICAL_SELECTION_MATRIX_AR.md` (new) because the existing ones are narrative, not scored |
| `docs/strategy/BEST_FIRST_WEDGE_DECISION_AR.md` | none | **create** |
| `docs/strategy/COMPETITOR_POSITIONING_AR.md` | `docs/strategy/COMPETITIVE_POSITIONING_AR.md` (1.5 KB) + `docs/strategy/COMPETITIVE_POSITIONING.md` + `docs/strategy/COMPETITOR_BENCHMARK.md` | **reference_only** — bundle writes a deeper one and cites them |
| `docs/strategy/DEALIX_POSITIONING_BIBLE_AR.md` | `docs/strategy/DEALIX_CATEGORY_STRATEGY_AR.md` + `docs/strategy/FROM_SERVICE_TO_STANDARD.md` | **create** — bundles them with a one-liner and 30s/2m pitches |

### 3.2 Offers

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| `DEALIX_OFFER_LADDER_AR.md` | `docs/offers/OFFER_LANDING_PAGE_SYSTEM_AR.md` (14.8 KB) + `docs/offers/OFFER_FAQ_LIBRARY_AR.md` (22.3 KB) | **skip** — but the bundle still ships a one-page ladder because the existing system is a landing-page system, not a sales ladder |
| Per-offer deep-dive (6 files) | `docs/offers/REVENUE_LEAKAGE_DIAGNOSTIC_PAGE_AR.md` (10.8 KB) + `FOLLOWUP_RECOVERY_WORKFLOW_PAGE_AR.md` (10.4 KB) + `AI_REVENUE_OPS_STARTER_PAGE_AR.md` (10.7 KB) + `MONTHLY_OPTIMIZATION_PAGE_AR.md` (9 KB) + `FULL_REVENUE_OS_PAGE_AR.md` (11.5 KB) + `CUSTOM_COMPANY_OS_PAGE_AR.md` (10.4 KB) | **skip the page versions**; **create one-page "offer card" per offer** that maps to these pages |
| `PRICING_LOGIC_AND_APPROVAL_POLICY_AR.md` | `data/templates/PROPOSAL_PROOF_PAYMENT_OS.md` style pages — none found at the exact title. `docs/strategy/30_pricing.md` is referenced. | **create** |

### 3.3 Targeting & ICP

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| ICP scoring 100-pt system | none in `docs/`; `dealix/lead_scoring/` has code but not docs | **create** — note code-level scoring exists in `dealix/intelligence/` |
| First 100 target accounts template | none | **create** |
| Buyer personas | `dealix/commercial/buyer_persona_engine.py` (likely) + several scattered docs | **reference_only** for code; **create** a 1-page persona doc per ICP |

### 3.4 Sales process & scripts

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| Email sequence library | `docs/outreach/COLD_EMAIL_TRUST_GATE_AR.md` (2.1 KB) + `data/templates/outreach/*.md` | **skip the long version**; **create a one-page library** that maps to the source |
| LinkedIn manual outreach | `docs/outreach/OUTBOUND_SAFETY_POLICY_AR.md` (4.1 KB) | **skip**; bundle's library is shorter and adds the LinkedIn-specific sequence |
| Call scripts | `data/templates/DEALIX_DISCOVERY_SCRIPT_AR.md` | **skip**; bundle links |
| Discovery / demo / closing | `data/templates/DEALIX_DISCOVERY_SCRIPT_AR.md` + `data/templates/DEALIX_OUTREACH_SEQUENCES_AR.md` + `docs/SALES_SCRIPTS_ALL_MOTIONS_AR.md` (19 KB) | **skip**; bundle adds closing and demo scripts that are not in the source |
| Objection handling | `data/templates/DEALIX_OBJECTION_HANDLING_AR.md` | **skip**; bundle writes a deeper "bible" that supersedes |

### 3.5 Proposal / proof / payment

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| Proposal template | `data/templates/proposals/P1_PROPOSAL_TEMPLATE_AR.md` + `api/routers/commercial.py` (13 endpoints) | **skip**; bundle ships a one-page outline + a "what to include / not include" doc |
| Proof pack template | `data/templates/CASE_STUDY_TEMPLATE_AR.md` (in `checklists/`) + `dealix/commercial/proof_builder/` | **skip**; bundle links |
| Case study template | `data/templates/CASE_STUDY_TEMPLATE_AR.md` (already exists) | **skip** |
| Before/after template | none with that exact name | **create** |
| ROI discussion without guarantee | `data/templates/OBJECTION_HANDLING_AR.md` + `dealix/commercial/claim_safety.py` (likely) | **skip**; bundle writes a 1-page "ROI discussion rules" doc |
| Payment handoff policy | `dealix/payments/` + `tests/test_payment_pricing_safety.py` (exists) | **skip**; bundle ships a 1-page policy doc that cites them |

### 3.6 Content & landing

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| Founder authority content system | none in `docs/` | **create** |
| 30-day LinkedIn calendar | `data/templates/operations/AEO_CONTENT_CALENDAR_AR.md` exists; not strictly 30-day LinkedIn | **skip**; bundle ships a 30-day LinkedIn calendar that supersedes |
| Short video scripts | none | **create** |
| Landing page copy | `docs/offers/OFFER_LANDING_PAGE_SYSTEM_AR.md` + per-offer pages | **skip**; bundle writes a one-page copy that cites them |
| Sales one-pager | none | **create** |
| Executive presentation narrative | `docs/pitch/DEALIX_MASTER_PITCH_DECK_AR.md` (2.6 KB) | **skip**; bundle writes a slide-by-slide narrative that the pitch deck can be generated from |

### 3.7 Delivery

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| Client onboarding | `docs/customer_success/CUSTOMER_ONBOARDING_DAY_BY_DAY.md` (6.6 KB) | **skip**; bundle links |
| First 14 days client delivery | `docs/ops/CUSTOMER_ONBOARDING_DAY_BY_DAY.md` (6.6 KB) | **skip**; bundle links |
| Client value reporting | `data/templates/scorecards/WEEKLY_REVENUE_SCORECARD_AR.md` | **skip**; bundle links |
| Renewal/upsell | `data/templates/RENEWAL_QUEUE.md` + `data/templates/EXPANSION_QUEUE.md` | **skip**; bundle links |

### 3.8 Trust & approval

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| Human approval matrix | `auto_client_acquisition/governance_os/approval_matrix.py` (code) | **skip**; bundle writes the 1-page narrative |
| No-overclaim policy | `auto_client_acquisition/governance_os/claim_safety.py` (code) + `tests/test_commercial_claim_safety.py` (tests) | **skip**; bundle writes a 1-page narrative |
| Trust preflight rules | none at `docs/trust/TRUST_PREFLIGHT_RULES_AR.md` | **create** (the script `scripts/trust_preflight_dry_run.py` is the executable form) |
| Client data handling | `docs/privacy/PRIVACY_GUARD_OS_AR.md` + `docs/wave8/DPA_CHECKLIST_AR_EN.md` | **skip**; bundle links |
| Safe claims library | none at this exact path | **create** |

## 4. Schemas

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| `vertical_score`, `icp_score`, `target_account`, `outreach_draft`, `approval_item`, `sales_pipeline_item`, `proposal_pack`, `proof_pack`, `founder_daily_command`, `content_asset`, `trust_preflight`, `launch_manifest` | none match these names; `schemas/` has many others (`model_registry.schema.json`, commercial schemas, etc.) | **create** all 12 in `schemas/launch/`. Bundle does **not** touch root `schemas/` |

## 5. Reports

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| 10 report templates under `reports/launch/` | `reports/company_os/daily/`, `reports/customer_success/`, `reports/offers/`, etc. | **create** the 10 bundle templates — they are day-1 templates with empty-state structure, not operational snapshots |

## 6. Scripts (10)

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| `launch_bundle_validate.py`, `launch_conflict_scan.py`, `vertical_score_dry_run.py`, `icp_score_dry_run.py`, `founder_daily_command_dry_run.py`, `outreach_draft_factory_dry_run.py`, `trust_preflight_dry_run.py`, `proposal_pack_dry_run.py`, `content_factory_dry_run.py`, `weekly_gtm_review_dry_run.py` | Many similar scripts in `scripts/` but none with these exact names | **create** all 10 in the bundle `scripts/`. None of them writes to the repo. None of them makes a network call. |

## 7. Tests (5)

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| `test_launch_manifest.py`, `test_launch_schema_examples.py`, `test_launch_no_external_send.py`, `test_launch_trust_preflight.py`, `test_launch_icp_scoring.py` | none with these exact names | **create** all 5 in the bundle `tests/`. The 5 must run cleanly offline. |

## 8. Patches (3)

| Bundle wants | Decision |
| --- | --- |
| `MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch` | **create** as a unified diff that adds 10 targets. Apply manually; never auto-merge. |
| `WEB_OPTIONAL_LAUNCH_COMMAND_ROOM.patch` | **create** as a unified diff that scaffolds `/ar/command/launch` and `/en/command/launch` (read-only dashboard). |
| `API_OPTIONAL_LAUNCH_ENDPOINTS.patch` | **create** as a unified diff that adds 4 dry-run endpoints under `/api/launch/`. |

## 9. Evals (5)

| Bundle wants | Already in repo | Action |
| --- | --- | --- |
| `claim_safety_cases`, `arabic_sales_tone_cases`, `objection_handling_cases`, `icp_scoring_cases`, `outreach_quality_cases` | `data/evals/` already has 5 JSONL files for safety (`security_prompt_injection_cases.jsonl`, `outbound_safety_cases.jsonl`, `whatsapp_safety_cases.jsonl`, `agent_permission_cases.jsonl`, `commercial_claim_cases.jsonl`) | **create** the 5 YAML ones in `evals/launch/` as a GTM-focused subset |

## 10. Tasks (10)

The bundle ships 10 prompts in `tasks/minimax3_launch/`. They are **read-only** and never executed. They are an extension of the existing `tasks/minimax/` (P0 PR).

## 11. What this bundle explicitly does NOT do

- Does **not** edit any file in `api/`, `apps/web/` (or `frontend/`), `core/`, `dealix/`, `auto_client_acquisition/`, `autonomous_growth/`, `integrations/`, `connectors/`, `db/`, `alembic/`, `scripts/` (root), `tests/` (root), `schemas/` (root), `Makefile`, `.github/`, `data/` (root), `prompts/`, `sales/`, `templates/` (root), `reports/` (root), `docs/` (root), `evals/` (root).
- Does **not** send any external message. The trust preflight explicitly blocks `requests.post`, `smtplib`, `sendgrid`, `twilio`, and any live network.
- Does **not** create a payment link.
- Does **not** set a final price.
- Does **not** claim a guaranteed ROI.
- Does **not** include secrets, real PII, or live API keys.

## 12. Honest limitations

- The bundle is **denser, not deeper** than the existing docs. If the existing `docs/offers/OFFER_LANDING_PAGE_SYSTEM_AR.md` is the canonical offer description, the bundle's `DEALIX_OFFER_LADDER_AR.md` is the **1-page summary** meant to be printed and used in sales calls. Use the page for the full system; use the bundle doc for the snapshot.
- All Arabic copy is **draft**. Native Saudi copywriter review is a follow-up — flagged in §7 of the acceptance report.
- The "first vertical" decision in `BEST_FIRST_WEDGE_DECISION_AR.md` is a **data-driven default** that the founder can override based on local knowledge. The decision is documented as "default, not destiny".
- The trust preflight catches **known patterns** (regex). It is not a substitute for human review of every draft. It exists to fail loudly when a draft is obvious garbage; it does not certify a draft is good.

## 13. Suggested merge order (read before `01_MERGE_PLAN.md`)

1. `git checkout -b feature/gtm-market-launch-overlay` (already created in worktree `wt-gtm-overlay`).
2. `mkdir -p _incoming/minimax3 && unzip <bundle>.zip -d _incoming/minimax3/`.
3. Run `python _incoming/minimax3/.../scripts/launch_conflict_scan.py --repo-root . --bundle-root _incoming/minimax3/...`.
4. Read `01_MERGE_PLAN.md` and `05_LAUNCH_ACCEPTANCE_REPORT.md`.
5. Apply `patches/MAKEFILE_OPTIONAL_LAUNCH_TARGETS.patch` only if you want the `make launch-*` targets.
6. Do **not** apply the web or API patches unless you really want the launch UI / endpoints.

## 14. Next: see `01_MERGE_PLAN.md`
