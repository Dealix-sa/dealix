# Dealix Market Launch — Start Here (AR)

> **Bundle:** `dealix_market_launch_complete_bundle/`
> **Generated:** 2026-06-12.
> **Audience:** the founder. This is the only file you read on day 1.
> **Read time:** 5 minutes.

## ما هذا

حزمة كاملة (100+ ملف) تغطي كل اللي تحتاجه عشان تبدأ السوق السعودي لـ Dealix فعلياً خلال أيام، مو شهور. الحزمة additive — ما تعدل الريبو، ما ترسل رسائل، ما تستخدم APIs، ما تنشئ أسعار نهائية.

## من أنا (أنت)؟

أنت المؤسس. عندك ريبيو Dealix V6-V10 enterprise scale. ما تحتاج build. تحتاج **تشغيل**.

## اقرأ بهذا الترتيب (5 ملفات فقط)

1. **`02_FIRST_7_DAYS_EXECUTION.md`** — يوم بيوم، أول أسبوع.
2. **`docs/strategy/BEST_FIRST_WEDGE_DECISION_AR.md`** — أي قطاع، أي عرض، ليه.
3. **`04_DAILY_FOUNDER_COMMAND.md`** — الروتين اليومي (15 دقيقة).
4. **`docs/offers/REVENUE_LEAK_AUDIT_OFFER_AR.md`** — أول عرض تبيعه.
5. **`docs/sales/OBJECTION_HANDLING_BIBLE_AR.md`** — أهم 25 اعتراض.

## الباقي

- `00_REPO_LAUNCH_INVENTORY.md` — خريطة الريبو (ما الموجود، ما اللي نضيفه).
- `01_MERGE_PLAN.md` — كيف تدمج بأمان.
- `03_30_60_90_DAY_PLAN.md` — خطة 90 يوم.
- `05_LAUNCH_ACCEPTANCE_REPORT.md` — حالة الحزمة، ما يشتغل، ما يحتاج founder review.

## 5 أوامر للتجربة

```bash
# 1. تحقق الحزمة.
python scripts/launch_bundle_validate.py

# 2. شغّل مسح التعارضات.
python scripts/launch_conflict_scan.py --repo-root . --bundle-root .

# 3. شوف أعلى 3 قطاعات.
python scripts/vertical_score_dry_run.py

# 4. جرب ICP scoring.
python scripts/icp_score_dry_run.py

# 5. شغّل الـ tests.
python -m pytest tests/ -q --no-cov
```

## 5 قواعد ما تنكسر أبداً

1. **لا cold WhatsApp.** Consent فقط.
2. **لا guaranteed ROI.** Proof metric فقط.
3. **لا final price بدون founder approval.** كل draft فيه `pricing_status: draft_only`.
4. **لا payment link.** الـ bundle ما يولّدها.
5. **لا trust preflight bypass.** كل draft يمر على `scripts/trust_preflight_dry_run.py`.

## لو عندك 30 دقيقة فقط

1. اقرأ `02_FIRST_7_DAYS_EXECUTION.md`.
2. افتح `templates/launch/target_account.example.json` (في `templates/launch/`).
3. أرسل أول إيميل. بدون تأخير.

## لو عندك 5 أيام

1. اليوم 1: اقرأ + قرر القطاع.
2. اليوم 2: ابحث عن 10 شركات.
3. اليوم 3: اكتب 10 drafts.
4. اليوم 4: شغّل trust preflight، أرسل.
5. اليوم 5: راجع الردود، قرر الخطوة الجاية.

## لو عندك 30 يوم

افتح `03_30_60_90_DAY_PLAN.md` واتبع الخطة.

## أهم شيء

> الـ bundle ما يبيع. أنت تبيع. الـ bundle يخلّيك تبيع بسرعة، بدقة، وبدون كوارث.

ابدأ.
