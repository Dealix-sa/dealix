# 08 — Delivery and Retention (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/delivery/*`.

You are MiniMax M3. Build the 14-day delivery shape + the renewal motion.

## Tasks

1. Client onboarding playbook (14-day shape, day-by-day deliverables).
2. First 14 days client delivery (kickoff, access, audit re-cap, training, daily digest, reviews, decision).
3. Client value reporting (weekly 1-pager, monthly 3-page).
4. Renewal and upsell playbook (90-day renewal, 5-up signal, 5-no signal, ladder upsell motion).

## Constraints

- The first 14 days are the proof. No skipping.
- The renewal is a recap, not a re-pitch.
- The upsell is proposed by Dealix, accepted by the client — not the other way around.
- The exit is graceful.
- No fake case study. No logo without permission.
