"""Tests for the trust preflight."""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
SCRIPT = ROOT / "scripts" / "trust_preflight_dry_run.py"

BANNED_IN_DRAFTS = [
    r"نضمن|guaranteed\s+(?:roi|results|outcome|lift|increase)|guarantee\b",
    r"100%\s*(?:زيادة|increase|lift)|ستضاعف|ستُضاعف|\b(?:double|triple|quadruple)\s+(?:the|your|revenue|sales|pipeline|number)\b|\b(?:2x|10x|5x|3x)\s+(?:pipeline|sales|revenue|leads|conversion)\b",
    r"final\s*price|final\s*pricing|سعر\s*نهائي",
    r"payment\s*link|رابط\s*دفع",
    r"cold\s*whatsapp|cold\s*wa\b",
]

BANNED_IN_SCRIPTS = [
    r"requests\.(post|put)",
    r"smtplib",
    r"sendgrid",
    r"twilio",
]


def test_preflight_passes_example_draft():
    result = subprocess.run([sys.executable, str(SCRIPT)], capture_output=True, text=True)
    assert result.returncode == 0, f"Preflight failed: {result.stdout}\n{result.stderr}"


def test_no_banned_patterns_in_drafts():
    for path in (ROOT / "docs" / "sales").rglob("*.md"):
        text = path.read_text(encoding="utf-8")
        name_upper = path.name.upper()
        for pat in BANNED_IN_DRAFTS:
            if not re.search(pat, text, flags=re.IGNORECASE):
                continue
            # Allowed in OBJECTION_HANDLING_BIBLE_AR.md (the doc quotes the objection)
            if "OBJECTION" in name_upper:
                continue
            # Allowed on lines that themselves forbid the pattern.
            # Allowed on lines that describe the rule itself.
            offending_line = None
            for line in text.splitlines():
                if re.search(pat, line, flags=re.IGNORECASE):
                    lower = line.lower()
                    if any(token in lower for token in ["no ", "not ", "ممنوع", "لا "]):
                        continue
                    if "patterns" in lower and ('(' in line or '"' in line or "'" in line):
                        continue
                    offending_line = line
                    break
            if offending_line is not None:
                pytest.fail(
                    f"Banned pattern {pat!r} found in {path.name}: {offending_line!r}"
                )


def test_no_banned_patterns_in_scripts():
    for path in (ROOT / "scripts").rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        for pat in BANNED_IN_SCRIPTS:
            if re.search(pat, text):
                pytest.fail(f"Banned pattern {pat!r} found in {path}")


def test_no_final_price_in_offers():
    for path in (ROOT / "docs" / "offers").rglob("*.md"):
        text = path.read_text(encoding="utf-8")
        # No SAR amount in an offer card; the policy is "draft_only".
        if re.search(r"\b\d{4,}\s*SAR\b", text):
            # Allow in pricing policy doc which explains the rule.
            if "PRICING_LOGIC" in path.name:
                continue
            pytest.fail(f"Final SAR amount found in {path}")
