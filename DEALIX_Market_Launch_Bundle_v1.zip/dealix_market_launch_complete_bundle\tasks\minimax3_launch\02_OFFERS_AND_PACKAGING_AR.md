# 02 — Offers and Packaging (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/offers/DEALIX_OFFER_LADDER_AR.md` + 6 offer cards.

You are MiniMax M3. Build the 6-offer productized ladder.

## Tasks

1. Define the 6 offers (Revenue Leak Audit, WhatsApp & Follow-up OS, Sales Command Center, Proposal & Proof Pack OS, AI OS for SMB, Custom Enterprise OS).
2. For each: one-liner, target customer, buyer persona, pain, promise (without overclaim), scope, out-of-scope, timeline, deliverables, success metrics, pricing status (`draft_only`), upsell path.
3. The offer cards live at `docs/offers/*_OFFER_AR.md`.
4. The pricing policy lives at `docs/offers/PRICING_LOGIC_AND_APPROVAL_POLICY_AR.md`.
5. The example proposal pack is at `templates/launch/proposal_pack.example.json`.

## Constraints

- No final price in any draft.
- No payment link in any draft.
- No guaranteed ROI in any draft.
- Every offer has a `pricing_status` field.
- The ladder is sequenced: audit → WhatsApp OS → Command Center → Proposal OS → AI OS → Enterprise.
