# 06 — Proposal, Proof, Payment (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/proposal/*` + `templates/launch/proposal_pack.example.json`.

You are MiniMax M3. Build the proposal + proof pack + payment handoff.

## Tasks

1. Proposal template (12 sections, max 6 pages).
2. Proof pack template (5 evidence levels, 4 evidence types, time-bound).
3. Case study template (only with permission, anonymized by default).
4. Before/after template (real numbers only).
5. ROI discussion rules (3 ways: cost of inaction, proof metric, risk-adjusted range; no guaranteed number).
6. Payment handoff policy (no link, no auto-send, founder-approved).

## Constraints

- No final price in any draft.
- No payment link in any draft.
- Every claim references a `proof_id`.
- Every proof pack has `expiry_date_iso`.
- The proposal carries `pricing_status` and `approval_required_for_pricing`.
