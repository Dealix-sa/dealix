#!/usr/bin/env python3
"""Weekly GTM review dry-run.

Aggregates the example data and prints the weekly review template filled in.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLES = BUNDLE / "templates" / "launch"


def main() -> int:
    print("DEALIX_WEEKLY_GTM_REVIEW_DRY_RUN")
    pipeline = json.loads((EXAMPLES / "sales_pipeline.example.json").read_text(encoding="utf-8"))
    drafts = json.loads((EXAMPLES / "outreach_draft.example.json").read_text(encoding="utf-8"))
    cmd = json.loads((EXAMPLES / "founder_daily_command.example.json").read_text(encoding="utf-8"))
    proof = json.loads((EXAMPLES / "proof_pack.example.json").read_text(encoding="utf-8"))

    print("Week review (example data; replace with real numbers in production):")
    print("")
    print(f"  open deals:        {len(pipeline)}")
    print(f"  pending drafts:    {cmd.get('drafts_waiting_approval')}")
    print(f"  meetings to book:  {cmd.get('meetings_to_book')}")
    print(f"  proof packs:       {len([proof])}")
    print("")
    print("Pipeline:")
    for d in pipeline:
        print(f"  - {d.get('deal_id')} | {d.get('stage')} | next: {d.get('next_action')}")
    print("")
    print("Decisions to make this week:")
    print("  1. Double down vertical? (Re-score matrix.)")
    print("  2. Double down offer? (Re-score ladder.)")
    print("  3. Add a content pillar? (Re-pick from 10.)")
    print("  4. Engage a partner? (From the 4 playbooks.)")
    print("  5. Stop something? (Reply rate < 10% = stop.)")
    print("")
    print("DEALIX_WEEKLY_GTM_REVIEW_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
