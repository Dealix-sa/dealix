#!/usr/bin/env python3
"""Content factory dry-run.

Reads the example content asset and prints the post summary.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "content_asset.example.json"


def main() -> int:
    print("DEALIX_CONTENT_FACTORY_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_CONTENT_FACTORY_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    print(f"asset_id:  {data.get('asset_id')}")
    print(f"pillar:    {data.get('pillar')}")
    print(f"format:    {data.get('format')}")
    print(f"language:  {data.get('language')}")
    print(f"persona:   {data.get('target_persona')}")
    print(f"stage:     {data.get('sales_stage')}")
    print(f"evidence:  {data.get('evidence_level')}")
    print(f"approval:  {data.get('approval_required')}")
    print("")
    print(f"hook:  {data.get('hook')}")
    print(f"cta:   {data.get('cta')}")
    print("")
    print("See docs/content/30_DAY_LINKEDIN_CONTENT_CALENDAR_AR.md for the full 30-day plan.")
    print("")
    print("DEALIX_CONTENT_FACTORY_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
