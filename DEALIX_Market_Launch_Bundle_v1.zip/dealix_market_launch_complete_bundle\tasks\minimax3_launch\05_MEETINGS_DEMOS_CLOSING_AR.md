# 05 — Meetings, Demos, Closing (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/sales/DISCOVERY_CALL_SCRIPT_AR.md` + `DEMO_SCRIPT_AR.md` + `CLOSING_SCRIPT_AR.md`.

You are MiniMax M3. Build the discovery, demo, and closing scripts + the objection handling bible.

## Tasks

1. Discovery call script: 5 phases, 8 questions (use 3–5), 30 min cap.
2. Demo script: 20 min cap, one problem, one before/after, one decision.
3. Closing script: 5 phases, 30 min, pilot not commitment, proof metric required.
4. Objection handling bible: 25 objections × 7 fields (what it means, bad response, best response, question, proof, next step, when to walk away).
5. The follow-up system after each.

## Constraints

- Never pitch in the first 5 min of discovery.
- Never demo everything.
- Never close on a "maybe" — walk.
- Every objection has a "when to walk away" signal.
- Every script has a follow-up email template.
