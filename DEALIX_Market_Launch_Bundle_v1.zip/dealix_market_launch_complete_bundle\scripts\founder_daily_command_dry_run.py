#!/usr/bin/env python3
"""Founder daily command dry-run.

Reads the example daily command and prints the 14 lines.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "founder_daily_command.example.json"


def main() -> int:
    print("DEALIX_FOUNDER_DAILY_COMMAND_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_FOUNDER_DAILY_COMMAND_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    print(f"command_date: {data.get('command_date')}")
    print("")
    print(f"1. top_decision:           {data.get('top_decision')}")
    print(f"2. cash_action_today:      {data.get('cash_action_today')}")
    print(f"3. drafts_waiting:         {data.get('drafts_waiting_approval')}")
    print(f"4. meetings_to_book:       {data.get('meetings_to_book')}")
    print(f"5. proposals_to_prepare:   {data.get('proposals_to_prepare')}")
    print(f"6. proof_gaps:             {data.get('proof_gaps')}")
    print(f"7. content_to_publish:     {data.get('content_to_publish')}")
    print(f"8. one_thing_to_stop:      {data.get('one_thing_to_stop')}")
    print(f"9. one_thing_to_double:    {data.get('one_thing_to_double_down')}")
    print("")
    print("next_24h_plan:")
    for step in data.get("next_24h_plan") or []:
        print(f"  - {step}")
    print("")
    print("DEALIX_FOUNDER_DAILY_COMMAND_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
