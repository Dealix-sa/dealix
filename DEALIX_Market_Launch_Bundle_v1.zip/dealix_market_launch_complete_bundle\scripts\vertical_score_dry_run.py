#!/usr/bin/env python3
"""Vertical score dry-run.

Reads the example vertical score and prints the top 3 sectors.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "vertical_score.example.json"


def main() -> int:
    print("DEALIX_VERTICAL_SCORE_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_VERTICAL_SCORE_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    print(f"top_vertical: {data.get('vertical_name')}")
    print(f"total: {data.get('total')}/100")
    print(f"action: {data.get('action')}")
    print("")
    print("Scores breakdown:")
    for k, v in (data.get("scores") or {}).items():
        print(f"  {k:<28} {v}")
    print("")
    print("See docs/strategy/SAUDI_VERTICAL_SELECTION_MATRIX_AR.md for the full 15-sector matrix.")
    print("")
    print("DEALIX_VERTICAL_SCORE_DRY_RUN=OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
