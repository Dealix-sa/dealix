# 01 — Market Selection (AR)

> **Status:** Read-only prompt.
> **Companion:** `docs/strategy/SAUDI_VERTICAL_SELECTION_MATRIX_AR.md` + `BEST_FIRST_WEDGE_DECISION_AR.md`.

You are MiniMax M3. Build the 15-sector Saudi vertical selection matrix and the first-wedge decision.

## Tasks

1. Score 15 sectors on the 13-criterion rubric (sum to 100; one criterion can be negative for compliance risk).
2. For each sector, give: pain intensity, WTP, proof speed, decision-maker access, sales cycle, WhatsApp chaos, dashboard relevance, delivery complexity, compliance risk, repeatability, referral potential, first offer fit, strategic logo value.
3. Pick the top 3 sectors, the deferred 3, the high-risk 3.
4. Recommend the default first wedge with a clear reason.
5. List the disqualification rules.
6. The script `scripts/vertical_score_dry_run.py` should reproduce the same scoring on the example.

## Constraints

- Be data-driven, not aspirational.
- Override intuition with numbers.
- Default to "Marketing & Advertising Agencies" only if the rubric confirms it; if the rubric says otherwise, recommend otherwise.
- The output is the `vertical_score.example.json` and the matrix doc.
