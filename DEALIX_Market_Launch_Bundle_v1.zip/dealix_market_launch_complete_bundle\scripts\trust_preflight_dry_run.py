#!/usr/bin/env python3
"""Trust preflight dry-run.

Runs the preflight on the example draft. Catches:
- Banned patterns (regex).
- Missing required fields.
- Network calls in code (N/A for drafts).
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent.parent
EXAMPLE = BUNDLE / "templates" / "launch" / "outreach_draft.example.json"

BANNED_PATTERNS = [
    (r"نضمن|نَضمن|guaranteed|guarantee", "guaranteed_outcome"),
    (r"100%\s*(?:زيادة|increase|lift)|ستضاعف|ستُضاعف|double|2x|10x", "round_number_no_baseline"),
    (r"final\s*price|final\s*pricing|سعر\s*نهائي", "final_price"),
    (r"payment\s*link|رابط\s*دفع", "payment_link"),
    (r"sk_live_|sk_test_|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}", "secret_pattern"),
    (r"cold\s*whatsapp|cold\s*wa\b", "cold_whatsapp"),
]

REQUIRED_FIELDS = [
    "draft_id", "channel", "target_account_id", "subject", "body",
    "evidence_level", "risk_level", "approval_required", "pricing_status",
]


def main() -> int:
    print("DEALIX_TRUST_PREFLIGHT_DRY_RUN")
    if not EXAMPLE.exists():
        print(f"DEALIX_TRUST_PREFLIGHT_DRY_RUN=ERROR missing:{EXAMPLE}")
        return 1
    data = json.loads(EXAMPLE.read_text(encoding="utf-8"))

    banned_matches = []
    body = (data.get("body") or "") + " " + (data.get("subject") or "")
    for pattern, label in BANNED_PATTERNS:
        if re.search(pattern, body, flags=re.IGNORECASE):
            banned_matches.append(label)

    missing = [f for f in REQUIRED_FIELDS if f not in data]

    print(f"phase_1_pattern: {'PASS' if not banned_matches else 'FAIL'}")
    if banned_matches:
        for m in banned_matches:
            print(f"  - banned: {m}")
    print(f"phase_2_schema:  {'PASS' if not missing else 'FAIL'}")
    if missing:
        for m in missing:
            print(f"  - missing: {m}")
    print(f"phase_3_code:    N/A (draft, not script)")
    print("")
    overall = "PASS" if not banned_matches and not missing else "FAIL"
    print(f"overall_status: {overall}")
    print("")
    print("DEALIX_TRUST_PREFLIGHT_DRY_RUN=OK" if overall == "PASS" else "DEALIX_TRUST_PREFLIGHT_DRY_RUN=FAIL")
    return 0 if overall == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
