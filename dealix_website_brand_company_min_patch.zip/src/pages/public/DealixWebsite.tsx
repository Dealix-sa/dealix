import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Brain,
  Building2,
  CheckCircle2,
  FileCheck2,
  Gauge,
  Layers3,
  LockKeyhole,
  MessageSquareText,
  PhoneCall,
  ShieldCheck,
  Sparkles,
  Target,
  Workflow,
  XCircle,
} from "lucide-react";
import { dealixBrand } from "@/brand/dealix";

type Locale = "ar" | "en";

type Copy = {
  badge: string;
  nav: string[];
  switchLabel: string;
  heroTitle: string;
  heroLead: string;
  ctaPrimary: string;
  ctaSecondary: string;
  heroBullets: string[];
  commandTitle: string;
  commandItems: { label: string; value: string; tone: string }[];
  sectionKicker: string;
  painTitle: string;
  painLead: string;
  pains: { title: string; body: string }[];
  productsTitle: string;
  productsLead: string;
  products: { title: string; body: string; outputs: string[] }[];
  brainTitle: string;
  brainLead: string;
  brainCards: { title: string; body: string }[];
  comparisonTitle: string;
  comparisonLead: string;
  comparisons: { old: string; dealix: string }[];
  methodTitle: string;
  methodLead: string;
  method: { step: string; title: string; body: string }[];
  trustTitle: string;
  trustLead: string;
  trust: { title: string; body: string }[];
  packagesTitle: string;
  packagesLead: string;
  packages: { name: string; price: string; bestFor: string; includes: string[] }[];
  sectorsTitle: string;
  sectors: string[];
  profileTitle: string;
  profileBody: string;
  profileBullets: string[];
  finalTitle: string;
  finalLead: string;
  finalCta: string;
  comparisonHeaders: { old: string; dealix: string };
  packageLabels: { bestFor: string; includes: string };
};

const copy: Record<Locale, Copy> = {
  ar: {
    badge: "Dealix Company Brain OS",
    nav: ["المشكلة", "المنتجات", "المقارنات", "المنهجية", "الثقة", "الباقات"],
    switchLabel: "English",
    heroTitle: "نحوّل شركتك من أدوات متفرقة إلى نظام تشغيل ذكي للإيراد والقرار.",
    heroLead:
      "Dealix تبني للشركات السعودية طبقة تشغيل مدعومة بالذكاء الاصطناعي تربط المبيعات، المتابعة، واتساب، العروض، التقارير، والحوكمة في workflow يومي واضح.",
    ctaPrimary: "احجز تشخيص 20 دقيقة",
    ctaSecondary: "شاهد نموذج غرفة القيادة",
    heroBullets: [
      "لا نبيع chatbot؛ نبني Operating Layer فوق أدواتك الحالية.",
      "النظام يجهز ويقترح، والفريق يراجع قبل أي إجراء خارجي حساس.",
      "تركيز عملي: فرص، متابعات، عروض، قرارات يومية، وإثبات أثر.",
    ],
    commandTitle: "لقطة من غرفة القيادة اليومية",
    commandItems: [
      { label: "فرص موثقة", value: "40–60", tone: "جاهزة للمراجعة" },
      { label: "مسودات متابعة", value: "25", tone: "بدون إرسال تلقائي" },
      { label: "إجراءات المؤسس", value: "10", tone: "أولوية اليوم" },
      { label: "مخاطر مفتوحة", value: "3", tone: "تحتاج قرار" },
    ],
    sectionKicker: "لماذا الآن؟",
    painTitle: "الشركات لا تخسر بسبب نقص الأدوات فقط؛ تخسر بسبب غياب نظام تشغيل يومي.",
    painLead:
      "معظم الشركات لديها CRM، واتساب، إيميل، موظفين، وعروض. المشكلة أن هذه العناصر لا تتحول إلى قرار واضح: من نتابع؟ من يراجع؟ ما العرض التالي؟ أين تضيع الفرص؟",
    pains: [
      { title: "فرص تضيع بين القنوات", body: "واتساب، نماذج، إيميلات، ومكالمات بلا ledger موحد أو owner واضح لكل فرصة." },
      { title: "تقارير لا تتحول إلى قرار", body: "لوحات كثيرة وأرقام كثيرة، لكن لا توجد next actions يومية يمكن تنفيذها وقياسها." },
      { title: "AI بلا حوكمة", body: "استخدام AI بدون سياسة، صلاحيات، مراجعة بشرية، أو ضوابط لحماية بيانات العملاء." },
      { title: "عروض بلا متابعة", body: "العرض يخرج ثم يبرد، ولا يوجد follow-up queue أو اعتراضات منظمة أو proof ledger." },
    ],
    productsTitle: "منتجات Dealix الأساسية",
    productsLead: "نبدأ بخدمة قابلة للبيع والتسليم، ثم نوسعها إلى نظام تشغيل مستمر.",
    products: [
      {
        title: "Revenue Command Room OS",
        body: "غرفة قيادة تربط العملاء المحتملين، المتابعات، العروض، ومؤشرات الإدارة اليومية.",
        outputs: ["Lead ledger", "Follow-up queue", "Proposal queue", "Daily CEO report"],
      },
      {
        title: "WhatsApp / Inbox Follow-up OS",
        body: "نظام يلتقط المتابعات الضائعة ويحوّل المحادثات إلى أولويات ومسودات ومواعيد مراجعة.",
        outputs: ["تصنيف المحادثات", "مسودات ردود", "قائمة عملاء ساخنين", "متابعة 1/3/7"],
      },
      {
        title: "Company Brain OS",
        body: "عقل تشغيلي يقرأ إشارات الشركة ويطلع قرار يومي: ماذا نفعل اليوم، لماذا، ومن المسؤول؟",
        outputs: ["Daily decision", "Future radar", "Risk register", "Board memo"],
      },
      {
        title: "AI Trust & Compliance OS",
        body: "سياسات وضوابط AI: مراجعة بشرية، منع الادعاءات الوهمية، حماية البيانات، وتوثيق القرارات.",
        outputs: ["AI usage policy", "PDPL checklist", "Approval gates", "Data handling SOP"],
      },
    ],
    brainTitle: "Dealix لا يعطيك معلومات أكثر؛ يعطيك قرارًا أوضح.",
    brainLead:
      "Company Brain OS يربط الإيراد، المتابعة، العملاء، المخاطر، والفرص في تقرير تنفيذي يومي قابل للتنفيذ — دون وعود قطعية أو ادعاءات مبالغ فيها.",
    brainCards: [
      { title: "قرار اليوم", body: "ما الإجراء الأعلى أثرًا الآن؟ من المسؤول؟ وما المقياس؟" },
      { title: "رادار المستقبل", body: "سيناريوهات 7–30 يوم مع مستوى ثقة وافتراضات واضحة." },
      { title: "رادار ألم العملاء", body: "يلخص الاعتراضات والأسئلة والشكاوى ويحوّلها إلى تحسينات تجارية." },
      { title: "مذكرة الإدارة", body: "ملخص أسبوعي للمؤسس أو الإدارة: تقدم، مخاطر، قرارات مطلوبة." },
    ],
    comparisonTitle: "لماذا Dealix أقوى من الحلول التقليدية؟",
    comparisonLead: "المنافسة ليست فقط أدوات؛ المنافسة هي من يحوّل الأدوات إلى تشغيل وقرار.",
    comparisonHeaders: { old: "الحل التقليدي", dealix: "Dealix" },
    comparisons: [
      { old: "CRM يسجل البيانات فقط", dealix: "Revenue OS يحدد next action، owner، وموعد المتابعة" },
      { old: "Chatbot يرد على الرسائل", dealix: "AI-assisted system يجهز الرد والفريق يراجع قبل الإرسال" },
      { old: "Dashboard يعرض أرقام", dealix: "Command Room يطلع قرار اليوم ومخاطر التنفيذ" },
      { old: "وكالة ترسل حملات", dealix: "Operating layer يبني targets، drafts، follow-ups، وproof" },
      { old: "استشارات تنتهي بتقرير", dealix: "Map → Build → Operate → Scale مع تسليم وتشغيل شهري" },
    ],
    methodTitle: "منهجية التسليم: Map → Design → Build → Operate → Scale",
    methodLead: "كل مشروع يبدأ من النتيجة التجارية، لا من الأداة المطلوبة. ثم نحول الطلب إلى workflow قابل للقياس.",
    method: [
      { step: "01", title: "Map", body: "نفهم مصادر الإيراد، القنوات، نقاط التعطل، البيانات، والفريق." },
      { step: "02", title: "Design", body: "نصمم blueprint: workflow، الصلاحيات، AI policy، شروط القبول." },
      { step: "03", title: "Build", body: "نبني V0 سريع: ledger، dashboard، prompts، reports، وقوالب تشغيل." },
      { step: "04", title: "Operate", body: "نشغل النظام يوميًا: قرارات، متابعات، proof، وتحسينات." },
      { step: "05", title: "Scale", body: "نوسع من workflow واحد إلى نظام شركة كامل مع retainer واضح." },
    ],
    trustTitle: "الثقة ليست إضافة؛ هي جزء من المنتج.",
    trustLead:
      "Dealix مصمم على مبدأ no uncontrolled external action: لا إرسال خارجي، لا ادعاءات ROI، ولا استخدام بيانات حساسة بدون gate واضح.",
    trust: [
      { title: "Human Approval Gates", body: "كل رسالة أو إجراء عالي الأثر يحتاج موافقة بشرية قبل الخروج." },
      { title: "No Fake Claims", body: "لا نستخدم شهادات وهمية أو ضمانات رقمية غير مثبتة." },
      { title: "Data Handling SOP", body: "تحديد الغرض، تقليل البيانات، وضبط الوصول عند التعامل مع بيانات العميل." },
      { title: "Controlled Outbound", body: "الإرسال المباشر لا يعمل إلا بحدود، opt-out، logging، ومراجعة." },
    ],
    packagesTitle: "باقات واضحة تبدأ بإثبات سريع",
    packagesLead: "لا نبدأ بنظام ضخم. نبدأ بتشخيص أو Sprint يثبت القيمة ثم نوسع.",
    packageLabels: { bestFor: "مناسب لـ", includes: "يشمل" },
    packages: [
      {
        name: "AI Revenue Diagnostic",
        price: "مجاني / 20 دقيقة",
        bestFor: "فتح النقاش مع الإدارة",
        includes: ["3 نقاط تسرب", "توصية workflow", "ملخص تنفيذي"],
      },
      {
        name: "7-Day Revenue Command Room Sprint",
        price: "1,500–5,000 ر.س كبداية",
        bestFor: "أول proof سريع",
        includes: ["Dashboard", "Lead ledger", "Follow-up queue", "Daily report"],
      },
      {
        name: "30-Day AI Operating System Build",
        price: "8,000–25,000 ر.س",
        bestFor: "شركات تحتاج تشغيل فعلي",
        includes: ["Command Room", "Trust policy", "Sales templates", "Training"],
      },
      {
        name: "AI Operations Partner",
        price: "3,000–15,000 ر.س شهريًا",
        bestFor: "تحسين وتشغيل مستمر",
        includes: ["Reports", "Optimization", "New workflows", "Executive memo"],
      },
    ],
    sectorsTitle: "قطاعات نبدأ بها بقوة",
    sectors: ["العيادات", "العقار", "اللوجستيات", "التدريب", "وكالات التسويق", "الخدمات B2B", "المقاولات", "الفعاليات"],
    profileTitle: "ملف الشركة المختصر",
    profileBody:
      "Dealix شركة سعودية تبني أنظمة تشغيل مدعومة بالذكاء الاصطناعي للشركات التي تريد ضبط الإيراد، المتابعة، القرار، والحوكمة دون تغيير كامل لأنظمتها الحالية.",
    profileBullets: [
      "التركيز: Revenue, Follow-up, Command Room, Company Brain, Trust.",
      "طريقة العمل: تشخيص سريع، بناء workflow، تشغيل، إثبات، توسع.",
      "المبدأ: AI يقترح ويجهز؛ الإنسان يوافق على الإجراءات الحساسة.",
    ],
    finalTitle: "ابدأ بنظام واحد يوقف ضياع الفرص خلال 7 أيام.",
    finalLead: "نبدأ بتشخيص عملي، نحدد أول workflow، ثم نبني نموذج غرفة قيادة قابل للاستخدام والمراجعة.",
    finalCta: "ابدأ التشخيص",
  },
  en: {
    badge: "Dealix Company Brain OS",
    nav: ["Pain", "Products", "Comparison", "Method", "Trust", "Packages"],
    switchLabel: "العربية",
    heroTitle: "Turn scattered tools into an AI operating system for revenue and executive decisions.",
    heroLead:
      "Dealix builds an AI-powered operating layer for Saudi B2B companies, connecting sales, follow-up, WhatsApp, proposals, reports, and governance into a clear daily workflow.",
    ctaPrimary: "Book a 20-min diagnostic",
    ctaSecondary: "View command room model",
    heroBullets: [
      "We do not sell a chatbot; we build an operating layer over your existing tools.",
      "The system prepares and recommends; your team approves sensitive external actions.",
      "Practical focus: opportunities, follow-ups, proposals, daily decisions, and proof of work.",
    ],
    commandTitle: "Daily command room snapshot",
    commandItems: [
      { label: "Verified opportunities", value: "40–60", tone: "ready for review" },
      { label: "Follow-up drafts", value: "25", tone: "no auto-send" },
      { label: "Founder actions", value: "10", tone: "today's priority" },
      { label: "Open risks", value: "3", tone: "decision needed" },
    ],
    sectionKicker: "Why now?",
    painTitle: "Companies do not lose because they lack tools only; they lose because they lack a daily operating system.",
    painLead:
      "Most companies have CRM, WhatsApp, email, people, and proposals. The issue is that these assets do not become a clear decision: who to follow up with, who owns it, what proposal comes next, and where opportunities leak.",
    pains: [
      { title: "Opportunities leak across channels", body: "WhatsApp, forms, email, and calls without a unified ledger or owner for every opportunity." },
      { title: "Reports do not become decisions", body: "Many dashboards and numbers, but no executable daily next actions." },
      { title: "AI without governance", body: "AI usage without policy, permissions, human review, or customer data controls." },
      { title: "Proposals without follow-up", body: "Proposals go out, then cool down without a follow-up queue, objection map, or proof ledger." },
    ],
    productsTitle: "Core Dealix products",
    productsLead: "We start with a service that can be sold and delivered, then expand it into an ongoing operating system.",
    products: [
      {
        title: "Revenue Command Room OS",
        body: "A command room connecting leads, follow-ups, proposals, and daily management signals.",
        outputs: ["Lead ledger", "Follow-up queue", "Proposal queue", "Daily CEO report"],
      },
      {
        title: "WhatsApp / Inbox Follow-up OS",
        body: "A system that recovers lost follow-ups and turns conversations into priorities, drafts, and review dates.",
        outputs: ["Conversation triage", "Reply drafts", "Hot customer list", "Day 1/3/7 follow-ups"],
      },
      {
        title: "Company Brain OS",
        body: "An operating brain that reads company signals and produces a daily decision: what to do, why, and who owns it.",
        outputs: ["Daily decision", "Future radar", "Risk register", "Board memo"],
      },
      {
        title: "AI Trust & Compliance OS",
        body: "AI policies and control gates: human review, no fake claims, data protection, and decision logging.",
        outputs: ["AI usage policy", "PDPL checklist", "Approval gates", "Data handling SOP"],
      },
    ],
    brainTitle: "Dealix does not give you more information; it gives you clearer decisions.",
    brainLead:
      "Company Brain OS connects revenue, follow-up, customers, risks, and opportunities into an executive daily report that is actionable, assumption-aware, and free of exaggerated guarantees.",
    brainCards: [
      { title: "Today's decision", body: "What is the highest-impact action now? Who owns it? What is the metric?" },
      { title: "Future radar", body: "7–30 day scenarios with confidence levels and explicit assumptions." },
      { title: "Customer pain radar", body: "Summarizes objections, questions, and complaints into commercial improvements." },
      { title: "Executive memo", body: "A weekly memo for founders and leaders: progress, risks, and decisions required." },
    ],
    comparisonTitle: "Why Dealix is stronger than traditional alternatives",
    comparisonLead: "The competition is not just tools; it is who turns tools into operation and decisions.",
    comparisonHeaders: { old: "Traditional approach", dealix: "Dealix" },
    comparisons: [
      { old: "CRM records data", dealix: "Revenue OS defines next action, owner, and follow-up date" },
      { old: "Chatbot replies to messages", dealix: "AI-assisted system drafts; humans approve before sending" },
      { old: "Dashboard shows numbers", dealix: "Command Room produces today's decision and execution risks" },
      { old: "Agency sends campaigns", dealix: "Operating layer builds targets, drafts, follow-ups, and proof" },
      { old: "Consulting ends with a report", dealix: "Map → Build → Operate → Scale with ongoing delivery" },
    ],
    methodTitle: "Delivery method: Map → Design → Build → Operate → Scale",
    methodLead: "Every project starts from the business outcome, not the requested tool. Then we convert the request into a measurable workflow.",
    method: [
      { step: "01", title: "Map", body: "Understand revenue sources, channels, bottlenecks, data, and team roles." },
      { step: "02", title: "Design", body: "Design the blueprint: workflow, permissions, AI policy, and acceptance criteria." },
      { step: "03", title: "Build", body: "Build a fast V0: ledger, dashboard, prompts, reports, and operating templates." },
      { step: "04", title: "Operate", body: "Run the system daily: decisions, follow-ups, proof, and improvements." },
      { step: "05", title: "Scale", body: "Expand from one workflow into a company-wide operating system with a clear retainer." },
    ],
    trustTitle: "Trust is not an add-on; it is part of the product.",
    trustLead:
      "Dealix is designed around no uncontrolled external action: no external sends, no ROI claims, and no sensitive data use without a clear gate.",
    trust: [
      { title: "Human Approval Gates", body: "Every high-impact message or action requires human approval before leaving the system." },
      { title: "No Fake Claims", body: "No fake testimonials or unsupported numerical guarantees." },
      { title: "Data Handling SOP", body: "Purpose limitation, data minimization, and access control when handling client data." },
      { title: "Controlled Outbound", body: "Live sending requires limits, opt-out, logging, and review." },
    ],
    packagesTitle: "Clear packages that start with fast proof",
    packagesLead: "We do not start with a huge system. We start with a diagnostic or sprint that proves value, then expand.",
    packageLabels: { bestFor: "Best for", includes: "Includes" },
    packages: [
      {
        name: "AI Revenue Diagnostic",
        price: "Free / 20 minutes",
        bestFor: "Opening an executive conversation",
        includes: ["3 leakage points", "Workflow recommendation", "Executive summary"],
      },
      {
        name: "7-Day Revenue Command Room Sprint",
        price: "SAR 1,500–5,000 beta",
        bestFor: "Fast first proof",
        includes: ["Dashboard", "Lead ledger", "Follow-up queue", "Daily report"],
      },
      {
        name: "30-Day AI Operating System Build",
        price: "SAR 8,000–25,000",
        bestFor: "Companies needing real operation",
        includes: ["Command Room", "Trust policy", "Sales templates", "Training"],
      },
      {
        name: "AI Operations Partner",
        price: "SAR 3,000–15,000 / month",
        bestFor: "Ongoing improvement and operation",
        includes: ["Reports", "Optimization", "New workflows", "Executive memo"],
      },
    ],
    sectorsTitle: "High-priority sectors",
    sectors: ["Clinics", "Real estate", "Logistics", "Training", "Marketing agencies", "B2B services", "Contracting", "Events"],
    profileTitle: "Company profile summary",
    profileBody:
      "Dealix is a Saudi company building AI-powered operating systems for companies that need to control revenue, follow-up, decisions, and governance without replacing their entire existing stack.",
    profileBullets: [
      "Focus: Revenue, Follow-up, Command Room, Company Brain, Trust.",
      "Method: fast diagnosis, workflow build, operation, proof, expansion.",
      "Principle: AI prepares and recommends; humans approve sensitive actions.",
    ],
    finalTitle: "Start with one system that stops opportunity leakage in 7 days.",
    finalLead: "We begin with a practical diagnostic, identify the first workflow, then build a usable command room model for review.",
    finalCta: "Start diagnostic",
  },
};

function cx(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function SectionTitle({
  kicker,
  title,
  lead,
  center = false,
  invert = false,
}: {
  kicker?: string;
  title: string;
  lead?: string;
  center?: boolean;
  invert?: boolean;
}) {
  return (
    <div className={cx("max-w-4xl", center && "mx-auto text-center")}>
      {kicker ? <p className="mb-3 text-sm font-semibold uppercase tracking-[0.28em] text-emerald-400">{kicker}</p> : null}
      <h2 className={cx("text-3xl font-black tracking-tight md:text-5xl", invert ? "text-white" : "text-slate-950")}>{title}</h2>
      {lead ? <p className={cx("mt-5 text-lg leading-9", invert ? "text-slate-300" : "text-slate-600")}>{lead}</p> : null}
    </div>
  );
}

function LogoMark() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 via-cyan-300 to-blue-500 shadow-2xl shadow-emerald-950/20">
        <div className="absolute inset-1 rounded-[0.85rem] border border-white/30" />
        <span className="text-xl font-black text-slate-950">D</span>
      </div>
      <div>
        <p className="text-xl font-black tracking-tight text-white">Dealix</p>
        <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-emerald-300">Company OS</p>
      </div>
    </div>
  );
}

export default function DealixWebsite({ locale = "ar" }: { locale?: Locale }) {
  const t = copy[locale];
  const isAr = locale === "ar";
  const otherHref = isAr ? "/en" : "/ar";
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <main dir={isAr ? "rtl" : "ltr"} className={cx("min-h-screen overflow-hidden bg-slate-950 text-white", isAr ? "font-arabic" : "font-sans")}>
      <section className="relative isolate overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_10%,rgba(34,211,238,0.28),transparent_30%),radial-gradient(circle_at_80%_0%,rgba(16,185,129,0.26),transparent_28%),linear-gradient(135deg,#0F172A_0%,#111827_45%,#020617_100%)]" />
        <div className="absolute inset-x-0 top-0 -z-10 h-40 bg-gradient-to-b from-white/10 to-transparent" />

        <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6 lg:px-8">
          <LogoMark />
          <nav className="hidden items-center gap-6 text-sm font-semibold text-slate-300 lg:flex">
            {t.nav.map((item) => (
              <a key={item} href="#products" className="transition hover:text-white">
                {item}
              </a>
            ))}
          </nav>
          <a href={otherHref} className="rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-white backdrop-blur transition hover:bg-white/15">
            {t.switchLabel}
          </a>
        </header>

        <div className="mx-auto grid max-w-7xl gap-12 px-6 pb-20 pt-10 lg:grid-cols-[1.05fr_0.95fr] lg:px-8 lg:pb-28 lg:pt-16">
          <div className="flex flex-col justify-center">
            <div className="mb-6 inline-flex w-fit items-center gap-2 rounded-full border border-emerald-300/25 bg-emerald-400/10 px-4 py-2 text-sm font-bold text-emerald-200">
              <Sparkles className="h-4 w-4" />
              {t.badge}
            </div>
            <h1 className="max-w-5xl text-4xl font-black leading-[1.12] tracking-tight text-white md:text-6xl lg:text-7xl">
              {t.heroTitle}
            </h1>
            <p className="mt-7 max-w-3xl text-lg leading-9 text-slate-200 md:text-xl">
              {t.heroLead}
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <a href="mailto:hello@dealix.me" className="inline-flex items-center justify-center gap-2 rounded-full bg-emerald-400 px-6 py-3 text-base font-black text-slate-950 shadow-2xl shadow-emerald-950/30 transition hover:-translate-y-0.5 hover:bg-emerald-300">
                {t.ctaPrimary}
                <ArrowIcon className="h-4 w-4" />
              </a>
              <a href="#command-room" className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/10 px-6 py-3 text-base font-bold text-white backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/15">
                {t.ctaSecondary}
              </a>
            </div>
            <div className="mt-8 grid gap-3 text-sm leading-7 text-slate-300">
              {t.heroBullets.map((bullet) => (
                <div key={bullet} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-1 h-5 w-5 shrink-0 text-emerald-300" />
                  <span>{bullet}</span>
                </div>
              ))}
            </div>
          </div>

          <div id="command-room" className="relative">
            <div className="absolute -inset-6 rounded-[3rem] bg-gradient-to-br from-emerald-400/20 to-cyan-400/10 blur-2xl" />
            <div className="relative rounded-[2rem] border border-white/15 bg-white/[0.08] p-5 shadow-2xl backdrop-blur-xl">
              <div className="rounded-[1.5rem] border border-white/10 bg-slate-950/80 p-5">
                <div className="flex items-center justify-between border-b border-white/10 pb-5">
                  <div>
                    <p className="text-sm font-bold text-emerald-300">{t.commandTitle}</p>
                    <p className="mt-1 text-xs text-slate-400">{dealixBrand.positioning[locale]}</p>
                  </div>
                  <div className="rounded-full bg-emerald-400/15 px-3 py-1 text-xs font-bold text-emerald-200">Live OS</div>
                </div>

                <div className="mt-5 grid grid-cols-2 gap-3">
                  {t.commandItems.map((item) => (
                    <div key={item.label} className="rounded-2xl border border-white/10 bg-white/[0.06] p-4">
                      <p className="text-xs text-slate-400">{item.label}</p>
                      <p className="mt-2 text-3xl font-black text-white">{item.value}</p>
                      <p className="mt-1 text-xs font-semibold text-emerald-300">{item.tone}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-5 rounded-2xl border border-emerald-300/20 bg-emerald-300/10 p-4">
                  <div className="flex items-center gap-2 text-sm font-black text-emerald-200">
                    <Brain className="h-5 w-5" />
                    {isAr ? "قرار اليوم التنفيذي" : "Today’s executive decision"}
                  </div>
                  <p className="mt-3 text-sm leading-7 text-slate-200">
                    {isAr
                      ? "راجع 10 فرص عالية الثقة، جهز 3 عروض مختصرة، ولا تفتح إرسال خارجي حي قبل اكتمال approval gates."
                      : "Review 10 high-confidence opportunities, prepare 3 focused proposals, and do not open live outbound before approval gates are complete."}
                  </p>
                </div>

                <div className="mt-5 space-y-3">
                  {[70, 52, 88].map((width, index) => (
                    <div key={width}>
                      <div className="mb-2 flex justify-between text-xs text-slate-400">
                        <span>{isAr ? ["جودة البيانات", "جاهزية المتابعة", "سلامة الثقة"][index] : ["Data quality", "Follow-up readiness", "Trust safety"][index]}</span>
                        <span>{width}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-white/10">
                        <div className="h-2 rounded-full bg-gradient-to-r from-emerald-400 to-cyan-300" style={{ width: `${width}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="pain" className="bg-slate-50 px-6 py-24 text-slate-950 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle kicker={t.sectionKicker} title={t.painTitle} lead={t.painLead} />
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {t.pains.map((pain, index) => {
              const icons = [Target, BarChart3, ShieldCheck, FileCheck2];
              const Icon = icons[index];
              return (
                <article key={pain.title} className="rounded-[1.5rem] border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
                  <Icon className="h-8 w-8 text-emerald-600" />
                  <h3 className="mt-6 text-xl font-black">{pain.title}</h3>
                  <p className="mt-3 leading-8 text-slate-600">{pain.body}</p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section id="products" className="bg-white px-6 py-24 text-slate-950 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle title={t.productsTitle} lead={t.productsLead} center />
          <div className="mt-14 grid gap-6 md:grid-cols-2">
            {t.products.map((product, index) => {
              const icons = [Gauge, MessageSquareText, Brain, LockKeyhole];
              const Icon = icons[index];
              return (
                <article key={product.title} className="group rounded-[2rem] border border-slate-200 bg-gradient-to-br from-white to-slate-50 p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-2xl">
                  <div className="flex items-start justify-between gap-5">
                    <div className="grid h-14 w-14 place-items-center rounded-2xl bg-slate-950 text-emerald-300">
                      <Icon className="h-7 w-7" />
                    </div>
                    <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700">OS 0{index + 1}</span>
                  </div>
                  <h3 className="mt-7 text-2xl font-black">{product.title}</h3>
                  <p className="mt-4 leading-8 text-slate-600">{product.body}</p>
                  <div className="mt-6 grid gap-2 sm:grid-cols-2">
                    {product.outputs.map((output) => (
                      <div key={output} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold text-slate-700">
                        {output}
                      </div>
                    ))}
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-slate-950 px-6 py-24 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle title={t.brainTitle} lead={t.brainLead} center invert />
          <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {t.brainCards.map((card) => (
              <article key={card.title} className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-6 backdrop-blur">
                <Brain className="h-8 w-8 text-cyan-300" />
                <h3 className="mt-5 text-xl font-black text-white">{card.title}</h3>
                <p className="mt-3 leading-8 text-slate-300">{card.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="comparison" className="bg-slate-50 px-6 py-24 text-slate-950 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle title={t.comparisonTitle} lead={t.comparisonLead} center />
          <div className="mt-12 overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-xl">
            <div className="grid grid-cols-2 border-b border-slate-200 bg-slate-950 text-white">
              <div className="p-5 text-lg font-black">{t.comparisonHeaders.old}</div>
              <div className="border-slate-700 p-5 text-lg font-black text-emerald-300 ltr:border-l rtl:border-r">{t.comparisonHeaders.dealix}</div>
            </div>
            {t.comparisons.map((row) => (
              <div key={row.old} className="grid grid-cols-2 border-b border-slate-100 last:border-b-0">
                <div className="flex items-start gap-3 p-5 leading-8 text-slate-600">
                  <XCircle className="mt-1 h-5 w-5 shrink-0 text-slate-400" />
                  <span>{row.old}</span>
                </div>
                <div className="flex items-start gap-3 border-slate-100 bg-emerald-50/70 p-5 font-bold leading-8 text-slate-900 ltr:border-l rtl:border-r">
                  <CheckCircle2 className="mt-1 h-5 w-5 shrink-0 text-emerald-600" />
                  <span>{row.dealix}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="method" className="bg-white px-6 py-24 text-slate-950 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle title={t.methodTitle} lead={t.methodLead} />
          <div className="mt-14 grid gap-5 lg:grid-cols-5">
            {t.method.map((step) => (
              <article key={step.step} className="rounded-[1.5rem] border border-slate-200 bg-slate-50 p-6">
                <div className="text-sm font-black text-emerald-600">{step.step}</div>
                <h3 className="mt-4 text-2xl font-black">{step.title}</h3>
                <p className="mt-3 leading-8 text-slate-600">{step.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="trust" className="bg-slate-950 px-6 py-24 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <SectionTitle title={t.trustTitle} lead={t.trustLead} invert />
          <div className="grid gap-5 md:grid-cols-2">
            {t.trust.map((item) => (
              <article key={item.title} className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-6">
                <ShieldCheck className="h-8 w-8 text-emerald-300" />
                <h3 className="mt-5 text-xl font-black text-white">{item.title}</h3>
                <p className="mt-3 leading-8 text-slate-300">{item.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="packages" className="bg-slate-50 px-6 py-24 text-slate-950 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <SectionTitle title={t.packagesTitle} lead={t.packagesLead} center />
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {t.packages.map((pack, index) => (
              <article key={pack.name} className={cx("rounded-[2rem] border p-6 shadow-sm", index === 1 ? "border-emerald-300 bg-white shadow-emerald-950/10" : "border-slate-200 bg-white")}>
                <p className="text-sm font-black text-emerald-600">{pack.price}</p>
                <h3 className="mt-3 text-2xl font-black">{pack.name}</h3>
                <p className="mt-5 text-sm font-bold text-slate-500">{t.packageLabels.bestFor}</p>
                <p className="mt-1 leading-7 text-slate-700">{pack.bestFor}</p>
                <p className="mt-6 text-sm font-bold text-slate-500">{t.packageLabels.includes}</p>
                <ul className="mt-3 space-y-2">
                  {pack.includes.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm leading-7 text-slate-700">
                      <CheckCircle2 className="mt-1 h-4 w-4 shrink-0 text-emerald-600" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white px-6 py-24 text-slate-950 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.95fr_1.05fr]">
          <div>
            <SectionTitle title={t.sectorsTitle} />
            <div className="mt-8 flex flex-wrap gap-3">
              {t.sectors.map((sector) => (
                <span key={sector} className="rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-sm font-black text-slate-700">
                  {sector}
                </span>
              ))}
            </div>
          </div>
          <article className="rounded-[2rem] border border-slate-200 bg-slate-950 p-8 text-white shadow-2xl">
            <div className="flex items-center gap-3 text-emerald-300">
              <Building2 className="h-7 w-7" />
              <p className="font-black">{t.profileTitle}</p>
            </div>
            <p className="mt-6 text-2xl font-black leading-relaxed">{t.profileBody}</p>
            <ul className="mt-6 space-y-3">
              {t.profileBullets.map((bullet) => (
                <li key={bullet} className="flex items-start gap-3 leading-8 text-slate-300">
                  <CheckCircle2 className="mt-1 h-5 w-5 shrink-0 text-emerald-300" />
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          </article>
        </div>
      </section>

      <section className="relative isolate overflow-hidden px-6 py-24 lg:px-8">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_50%_0%,rgba(16,185,129,0.35),transparent_35%),linear-gradient(135deg,#0F172A,#020617)]" />
        <div className="mx-auto max-w-4xl text-center">
          <Workflow className="mx-auto h-12 w-12 text-emerald-300" />
          <h2 className="mt-6 text-4xl font-black leading-tight md:text-6xl">{t.finalTitle}</h2>
          <p className="mt-6 text-lg leading-9 text-slate-300">{t.finalLead}</p>
          <a href="mailto:hello@dealix.me" className="mt-9 inline-flex items-center justify-center gap-2 rounded-full bg-white px-7 py-3 text-base font-black text-slate-950 transition hover:-translate-y-0.5 hover:bg-emerald-100">
            <PhoneCall className="h-4 w-4" />
            {t.finalCta}
          </a>
        </div>
      </section>

      <footer className="border-t border-white/10 bg-slate-950 px-6 py-10 text-slate-400 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <LogoMark />
          <div className="flex items-center gap-2 text-sm">
            <Layers3 className="h-4 w-4 text-emerald-300" />
            <span>{dealixBrand.promise[locale]}</span>
          </div>
        </div>
      </footer>
    </main>
  );
}
