export const dealixBrand = {
  name: "Dealix",
  positioning: {
    ar: "أنظمة تشغيل ذكاء اصطناعي للشركات السعودية",
    en: "AI Operating Systems for Saudi B2B Companies",
  },
  colors: {
    obsidian: "#0F172A",
    ink: "#111827",
    emerald: "#10B981",
    trust: "#047857",
    cyan: "#22D3EE",
    blue: "#2563EB",
    violet: "#7C3AED",
    sand: "#D6A85A",
    cloud: "#F8FAFC",
    line: "#DDE7F0",
  },
  fonts: {
    arabic: "Noto Sans Arabic",
    latin: "Inter",
  },
  promise: {
    ar: "نحوّل الفوضى اليومية في المبيعات، المتابعة، العروض، واتساب، والقرار الإداري إلى نظام تشغيل واضح قابل للقياس والمراجعة.",
    en: "We turn daily revenue, follow-up, proposal, WhatsApp, and executive decision chaos into a measurable operating system with human approval gates.",
  },
} as const;
