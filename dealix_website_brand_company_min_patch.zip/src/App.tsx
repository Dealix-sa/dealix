import { Routes, Route, Navigate } from "react-router";
import { TRPCProvider } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Sidebar } from "@/components/Sidebar";
import { Dashboard } from "@/pages/Dashboard";
import { CompaniesPage } from "@/pages/CompaniesPage";
import { OpportunitiesPage } from "@/pages/OpportunitiesPage";
import { ProjectsPage } from "@/pages/ProjectsPage";
import { DossiersPage } from "@/pages/DossiersPage";
import { ApprovalsPage } from "@/pages/ApprovalsPage";
import { GrowthPage } from "@/pages/founder/GrowthPage";
import { SalesPage } from "@/pages/founder/SalesPage";
import { DeliveryPage } from "@/pages/founder/DeliveryPage";
import { FinancePage } from "@/pages/founder/FinancePage";
import { SettingsPage } from "@/pages/SettingsPage";
import Login from "@/pages/Login";
import NotFound from "@/pages/NotFound";
import DealixWebsite from "@/pages/public/DealixWebsite";

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" />
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <AppLayout>{children}</AppLayout>;
}

function App() {
  return (
    <TRPCProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<DealixWebsite locale="ar" />} />
        <Route path="/ar" element={<DealixWebsite locale="ar" />} />
        <Route path="/en" element={<DealixWebsite locale="en" />} />
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/companies" element={<ProtectedRoute><CompaniesPage /></ProtectedRoute>} />
        <Route path="/opportunities" element={<ProtectedRoute><OpportunitiesPage /></ProtectedRoute>} />
        <Route path="/projects" element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
        <Route path="/dossiers" element={<ProtectedRoute><DossiersPage /></ProtectedRoute>} />
        <Route path="/approvals" element={<ProtectedRoute><ApprovalsPage /></ProtectedRoute>} />
        <Route path="/founder/growth" element={<ProtectedRoute><GrowthPage /></ProtectedRoute>} />
        <Route path="/founder/sales" element={<ProtectedRoute><SalesPage /></ProtectedRoute>} />
        <Route path="/founder/delivery" element={<ProtectedRoute><DeliveryPage /></ProtectedRoute>} />
        <Route path="/founder/finance" element={<ProtectedRoute><FinancePage /></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </TRPCProvider>
  );
}

export default App;
