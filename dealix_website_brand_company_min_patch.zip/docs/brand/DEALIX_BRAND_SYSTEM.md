# Dealix Brand System v1

## Brand position

**Dealix = AI Operating Systems for Saudi B2B Companies.**

Dealix is not positioned as a chatbot, CRM, marketing agency, or generic AI tool. Dealix is positioned as an operating layer that connects revenue, follow-up, WhatsApp, proposals, executive reporting, and AI governance into a daily workflow.

## Core promise

> We turn scattered tools and lost follow-ups into a measurable operating system with human approval gates.

## Arabic promise

> نحوّل الفوضى اليومية في المبيعات، المتابعة، العروض، واتساب، والقرار الإداري إلى نظام تشغيل واضح قابل للقياس والمراجعة.

## Visual direction

- Enterprise, not playful.
- AI-native, not generic tech.
- Saudi B2B focused, not Silicon Valley copycat.
- High trust, with human approval and data governance.
- Command-room energy: dark, focused, decisive.

## Color tokens

| Token | Hex | Usage |
|---|---:|---|
| Obsidian OS | `#0F172A` | Dark hero, command room, footer |
| Ink | `#111827` | Primary text and strong surfaces |
| Revenue Emerald | `#10B981` | Primary CTA, revenue signals, growth |
| Trust Green | `#047857` | Trust, compliance, approval gates |
| Signal Cyan | `#22D3EE` | AI signal, intelligence, data movement |
| Command Blue | `#2563EB` | Product UI and charts |
| Brain Violet | `#7C3AED` | Company Brain / decision intelligence |
| Saudi Sand | `#D6A85A` | Premium accent, Saudi context |
| Cloud | `#F8FAFC` | Light backgrounds |
| Line | `#DDE7F0` | Borders and separators |

## Typography

| Language | Font |
|---|---|
| Arabic | Noto Sans Arabic |
| English | Inter |

## Voice and messaging rules

1. Say “operating system”, “command room”, “decision layer”, “workflow”, and “proof”.
2. Do not overuse “chatbot” or “automation”.
3. Do not promise guaranteed ROI.
4. Use “scenario forecast” and “confidence level”, not absolute prediction.
5. Emphasize human approval gates for sensitive actions.
6. Use direct executive language: clear pain, clear output, clear next action.

## Primary messaging pillars

1. **Revenue clarity** — know which opportunities need action today.
2. **Follow-up recovery** — stop losing prospects across WhatsApp, email, and forms.
3. **Company Brain** — convert signals into daily executive decisions.
4. **Trust and governance** — AI prepares; humans approve sensitive actions.
5. **Proof-led delivery** — every sprint produces visible outputs and a next 30-day plan.

## Implementation notes

The website implementation adds:

- Public Arabic route: `/ar`
- Public English route: `/en`
- Root Arabic website: `/`
- Internal authenticated dashboard moved to `/dashboard`
- Brand tokens in `src/brand/dealix.ts`
- Tailwind color tokens under `dealix.*`
- Arabic/English fonts in `src/index.css`
