# Dealix Company Profile

## Short definition

**Dealix** is a Saudi company building AI-powered business operating systems for companies that need to control revenue, follow-up, decisions, and governance without replacing their existing stack.

Dealix is not just a chatbot provider, not a generic dashboard vendor, and not a traditional marketing agency. Dealix builds an operating layer above the company’s existing tools to convert channels, data, and follow-ups into a clear daily workflow.

## Positioning

> Dealix builds AI operating systems for Saudi B2B companies, connecting sales, follow-up, WhatsApp, proposals, reports, and governance into a measurable daily workflow with human approval gates.

## The problem we solve

Companies usually do not suffer from a lack of tools only. They suffer from the absence of an operating system that connects tools to decisions. They already have WhatsApp, email, forms, Excel, CRM, people, and proposals, but they lack clear daily answers to:

- Which customer needs follow-up today?
- Where are opportunities leaking?
- Which proposal needs action or revision?
- Who owns every opportunity?
- What is today’s most important executive decision?
- Is the team using AI safely and consistently?

## Core products

### 1. Revenue Command Room OS

A daily command room connecting leads, follow-ups, proposals, and management signals.

**Outputs:**

- Lead ledger
- Follow-up queue
- Proposal queue
- Daily CEO report
- Next action list

### 2. WhatsApp / Inbox Follow-up OS

A system that recovers lost follow-ups and turns conversations into priorities, drafts, and review dates.

**Outputs:**

- Conversation triage
- Reply drafts
- Hot customer list
- Day 1 / 3 / 7 follow-ups
- Daily management report

### 3. Company Brain OS

An operating brain that reads company signals and turns them into a daily executable decision.

**Outputs:**

- Today’s executive decision
- Future Radar
- Risk Register
- Weekly Board Memo
- 30-Day Action Plan

### 4. AI Trust & Compliance OS

A governance and trust layer for using AI inside the company.

**Outputs:**

- AI Usage Policy
- Human Approval Gates
- Client Data Handling SOP
- PDPL readiness checklist
- No Fake Claims policy

## Delivery method

### Map

Understand the current state: revenue, channels, data, team, bottlenecks, and risks.

### Design

Design the workflow, permissions, reports, AI policy, and acceptance criteria.

### Build

Build a usable V0: ledger, dashboard, prompts, reports, and operating templates.

### Operate

Run the system daily and produce decisions, follow-ups, proof, and improvements.

### Scale

Expand from one workflow into a broader company operating system.

## Packages

| Package | Starting price | Goal |
|---|---:|---|
| AI Revenue Diagnostic | Free / 20 minutes | Identify 3 leakage points and first workflow |
| 7-Day Revenue Command Room Sprint | SAR 1,500–5,000 | Fast proof and practical outputs |
| 30-Day AI Operating System Build | SAR 8,000–25,000 | Build a real operating system |
| AI Operations Partner | SAR 3,000–15,000 / month | Ongoing operation and optimization |

## Priority sectors

- Clinics
- Real estate
- Logistics
- Training
- Marketing agencies
- B2B services
- Contracting
- Events

## Why Dealix?

| Traditional approach | Dealix |
|---|---|
| CRM records data | Revenue OS defines owner, next action, and follow-up date |
| Chatbot auto-replies | AI-assisted system drafts; humans review |
| Dashboard shows numbers | Command Room produces today’s decision |
| Agency sends campaigns | Operating layer builds targets, drafts, follow-ups, and proof |
| Consulting ends with a report | Map → Build → Operate → Scale |

## Trust rules

- No uncontrolled external sending.
- No unsupported ROI promises.
- No fake testimonials.
- No sensitive data use without a clear gate.
- AI prepares and recommends; humans approve sensitive actions.

## Short sales message

Many companies have many tools, but no clear operating system. Dealix builds an AI-powered command room that connects sales, follow-up, proposals, and daily decisions into one workflow, with human review and data governance before sensitive actions.
