# Dealix Website Implementation

## What changed

This package adds a complete bilingual public website to the existing React/Vite app.

## Routes

| Route | Purpose |
|---|---|
| `/` | Arabic public website |
| `/ar` | Arabic public website |
| `/en` | English public website |
| `/dashboard` | Protected internal dashboard |

## New source files

- `src/pages/public/DealixWebsite.tsx`
- `src/brand/dealix.ts`
- `docs/brand/DEALIX_BRAND_SYSTEM.md`
- `docs/company/DEALIX_COMPANY_PROFILE_AR.md`
- `docs/company/DEALIX_COMPANY_PROFILE_EN.md`

## Updated files

- `src/App.tsx`
- `src/index.css`
- `tailwind.config.js`

## Design system

The website uses:

- Obsidian dark hero and trust sections
- Emerald primary CTAs
- Cyan AI signal accents
- Noto Sans Arabic for Arabic
- Inter for English
- Responsive cards and comparison tables
- No unsupported ROI claims
- Human approval gates and trust positioning

## Recommended next repo commands

```bash
npm install
npm run check
npm run build
```

## Recommended deployment notes

If this app is already deployed on Railway, the public website becomes available after merging and deploying the branch. Keep production variables safe and do not commit secrets.
